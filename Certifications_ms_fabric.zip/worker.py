"""
Worker Script - Staffing Tool Automation

This module contains the actual work that will be executed when you click
"Start Process" in the web interface. It integrates with get_users.py and
post_schedule_automatizado.py to automate the staffing tool.
"""

import time
from pathlib import Path

# Import the automation modules
from get_users import fetch_users
from post_schedule_automatizado import post_schedules

BASE_DIR = Path(__file__).resolve().parent

# These will be set by the main app
_progress_callback = None
_stop_check = None


def setup(progress_callback, stop_check):
    """Called by app.py to set up communication functions."""
    global _progress_callback, _stop_check
    _progress_callback = progress_callback
    _stop_check = stop_check


def report_progress(percent, message, msg_type="info"):
    """Report progress to the web UI."""
    if _progress_callback:
        _progress_callback(percent, message, msg_type)


def should_stop():
    """Check if the user requested to stop the process."""
    if _stop_check:
        return _stop_check()
    return False


def run_task(cookie_string, csv_path):
    """
    Main task function - Runs the staffing tool automation.

    Args:
        cookie_string: The staffingplanning_ cookie value from the web UI
        csv_path: Path to the uploaded alocacoes.csv file

    Returns:
        bool: True if successful, False otherwise
    """
    if not cookie_string:
        report_progress(None, "Cookie string is required", "error")
        return False

    if not csv_path:
        report_progress(None, "CSV file path is required", "error")
        return False

    report_progress(0, "Starting automation task...", "info")

    # =========================================================================
    # STEP 1: Fetch users from the staffing tool
    # =========================================================================

    if should_stop():
        report_progress(None, "Process cancelled by user", "warning")
        return False

    report_progress(5, "Fetching user IDs from staffing tool...", "info")

    usuarios_path = BASE_DIR / "usuarios.json"
    success, message, user_count = fetch_users(cookie_string, usuarios_path)

    if not success:
        report_progress(None, f"Failed to fetch users: {message}", "error")
        return False

    report_progress(20, f"Successfully fetched {user_count} users", "success")

    # =========================================================================
    # STEP 2: Wait before sending schedules
    # =========================================================================

    if should_stop():
        report_progress(None, "Process cancelled by user", "warning")
        return False

    report_progress(25, "Waiting 5 seconds before sending schedules...", "info")

    # Wait with periodic stop checks
    for i in range(5):
        if should_stop():
            report_progress(None, "Process cancelled by user", "warning")
            return False
        time.sleep(1)

    # =========================================================================
    # STEP 3: Post schedules to the staffing tool
    # =========================================================================

    if should_stop():
        report_progress(None, "Process cancelled by user", "warning")
        return False

    report_progress(30, "Starting to send schedules...", "info")

    def schedule_progress_callback(progress, msg, msg_type):
        """Map the schedule progress to 30-95% of overall progress."""
        if progress is not None:
            overall_progress = 30 + (progress * 0.65)
            report_progress(overall_progress, msg, msg_type)
        else:
            report_progress(None, msg, msg_type)

    success, message, stats = post_schedules(
        cookie_string,
        csv_path,
        usuarios_path,
        progress_callback=schedule_progress_callback,
        should_stop=should_stop
    )

    # =========================================================================
    # STEP 4: Report final results
    # =========================================================================

    report_progress(95, "Finalizing...", "info")

    if stats:
        report_progress(None, f"Summary: {stats.get('sucessos', 0)} successful, {stats.get('falhas', 0)} failures", "info")

    if success:
        report_progress(100, "All tasks completed successfully!", "success")
        return True
    else:
        report_progress(100, f"Completed with issues: {message}", "warning")
        # Return True even with some failures, as the process completed
        return stats.get('sucessos', 0) > 0
