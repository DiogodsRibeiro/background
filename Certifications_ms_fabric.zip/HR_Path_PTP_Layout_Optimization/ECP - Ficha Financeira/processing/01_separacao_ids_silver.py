# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/ECP - Ficha Financeira/utils/utils"

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window

# COMMAND ----------

df_base = spark.table(BRONZE_PTP_EVENTOS).select("CSSECAO", "CSENTRADA", "CSVALOR")
spark.sql(f"TRUNCATE TABLE {SILVER_PTP_EVENTOS}")
df_base.write.insertInto(SILVER_PTP_EVENTOS)
print(f"PTP_EVENTOS copiada para silver: {df_base.count():,} linhas")

ids_base = spark.sql(f"""
    SELECT
        f.FUPESSOAID AS id_empr,
        f.FUCODEMP   AS codemp,
        f.FUMATFUNC  AS matfunc,
        f.FUVINCULO  AS vinculo,
        f.FUDATAID   AS dataid
    FROM {BRONZE_FUNCIONA} f
    INNER JOIN {SILVER_PTP_EVENTOS} p
        ON  p.CSENTRADA = 'DEXPARA_ID'
        AND p.CSSECAO   = f.FUPESSOAID
    WHERE f.FUCODEMP IN ({','.join(f"'{e}'" for e in EMPRESAS_PERMITIDAS)})
      AND f.FUDATAID = (
            SELECT MAX(f1.FUDATAID)
            FROM {BRONZE_FUNCIONA} f1
            WHERE f1.FUPESSOAID = f.FUPESSOAID
              AND f1.FUDATAID  <= '{DATA_CORTE_MOCK}'
      )
""").cache()

print(f"IDs base encontrados: {ids_base.count():,}")

reintegrados = spark.sql(f"""
    SELECT DISTINCT f.FUPESSOAID AS id_empr
    FROM {BRONZE_FUNCIONA} f
    INNER JOIN {BRONZE_OCORFUNC} o
        ON  o.OFCODEMP  = f.FUCODEMP
        AND o.OFMATFUNC = f.FUMATFUNC
    INNER JOIN {SILVER_PTP_EVENTOS} p
        ON  p.CSENTRADA = 'DEXPARA_ID'
        AND p.CSSECAO   = f.FUPESSOAID
    WHERE f.FUCODEMP IN ({','.join(f"'{e}'" for e in EMPRESAS_PERMITIDAS)})
      AND f.FUDATAID = (
            SELECT MAX(f1.FUDATAID)
            FROM {BRONZE_FUNCIONA} f1
            WHERE f1.FUPESSOAID = f.FUPESSOAID
              AND f1.FUDATAID  <= '{DATA_CORTE_MOCK}'
      )
      AND o.OFCODOCORR = '1019'
      AND o.OFDTINIOCO = (
            SELECT MAX(o1.OFDTINIOCO)
            FROM {BRONZE_OCORFUNC} o1
            WHERE o1.OFCODEMP   = o.OFCODEMP
              AND o1.OFMATFUNC  = o.OFMATFUNC
              AND o1.OFCODOCORR = '1019'
              AND o1.OFDTINIOCO >= '{DATA_INICIO}01'
              AND o1.OFDTINIOCO <= '{DATA_CORTE_MOCK}'
      )
      AND o.OFDTINIOCO >= '{DATA_INICIO}01'
      AND o.OFDTINIOCO <= '{DATA_CORTE_MOCK}'
""")

print(f"Reintegrados identificados: {reintegrados.count():,}")

estagiarios = ids_base.filter(F.col("vinculo") == "14").select("id_empr")
vps         = ids_base.filter(F.col("vinculo") == "15").select("id_empr")

print(f"Estagiários : {estagiarios.count():,}")
print(f"VPs         : {vps.count():,}")

ids_marcados = (
    ids_base.select("id_empr")
    .join(reintegrados.withColumn("is_rei",  F.lit(True)), "id_empr", "left")
    .join(estagiarios.withColumn("is_estag", F.lit(True)), "id_empr", "left")
    .join(vps.withColumn("is_vp",            F.lit(True)), "id_empr", "left")
    .fillna(False, subset=["is_rei", "is_estag", "is_vp"])
    .withColumn(
        "subgrupo",
        F.when(F.col("is_rei"),   "ID_REI_FICHA_MOCK4")
         .when(F.col("is_estag"), "ID_ESTAG_FICHA_MOCK4")
         .when(F.col("is_vp"),    "ID_VP_FICHA_MOCK4")
         .otherwise(              "ID_FICHA_MOCK4")
    )
)

w_subgrupo = Window.partitionBy("subgrupo").orderBy("id_empr")

novas_linhas = (
    ids_marcados
    .withColumn("seq", F.row_number().over(w_subgrupo))
    .withColumn("CSSECAO",   F.concat(F.col("subgrupo"), F.lit("_"), F.col("seq").cast("string")))
    .withColumn("CSENTRADA", F.col("subgrupo"))
    .withColumn("CSVALOR",   F.col("id_empr").cast("string"))
    .select("CSSECAO", "CSENTRADA", "CSVALOR")
)

print(f"Total de linhas a inserir: {novas_linhas.count():,}")
# display(novas_linhas.limit(20))

for sg in list(SUBGRUPOS.keys()):
    spark.sql(f"DELETE FROM {SILVER_PTP_EVENTOS} WHERE CSENTRADA = '{sg}'")

novas_linhas.write.format("delta").mode("append").saveAsTable(SILVER_PTP_EVENTOS)

resumo = novas_linhas.groupBy("CSENTRADA").count().orderBy("CSENTRADA")
display(resumo)

total = novas_linhas.count()
print(f"\nTotal de IDs classificados: {total:,}")

ids_base.unpersist()