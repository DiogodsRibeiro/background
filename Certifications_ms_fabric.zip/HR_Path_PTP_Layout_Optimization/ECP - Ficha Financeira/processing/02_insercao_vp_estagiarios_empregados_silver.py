# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/ECP - Ficha Financeira/utils/utils"

# COMMAND ----------

from pyspark.sql.types import *
import pandas as pd
from datetime import date, timedelta
from dateutil.relativedelta import relativedelta

# COMMAND ----------

def processa_subgrupo(subgrupo: str, crano_header: int, crano_body: int) -> tuple:
    """
    Gera as linhas 558B (header) e 558D (body) para um subgrupo.

    Args:
        subgrupo:      nome do subgrupo em PTP_EVENTOS
        crano_header:  código CRANO do cabeçalho (100, 200 ou 300)
        crano_body:    código CRANO do corpo (101, 201 ou 301)

    Returns:
        Tupla (rows_558b, rows_558d, rows_param)
    """
    print(f"\n{'='*60}")
    print(f"Processando: {subgrupo} | CRANO {crano_header}/{crano_body}")
    print(f"{'='*60}")

    # ── Query base ────────────────────────────────────────────────
    df_raw = spark.sql(f"""
        WITH ranked_func AS (
            SELECT FUPESSOAID,
                   FUCODEMP,
                   FUMATFUNC,
                   FUDATAID,
                   FUDTADMIS,
                   ROW_NUMBER() OVER (
                       PARTITION BY FUPESSOAID
                       ORDER BY FUDATAID DESC
                   ) AS rn
            FROM {BRONZE_FUNCIONA}
            WHERE FUDATAID <= '{DATA_CORTE_ID}'
        ),
        max_func AS (
            SELECT FUPESSOAID,
                   FUCODEMP,
                   FUMATFUNC,
                   FUDATAID,
                   FUDTADMIS
            FROM ranked_func
            WHERE rn = 1
        )
        SELECT DISTINCT
            f.FUPESSOAID                                               AS id_empr,
            v.VACODEMP                                                 AS empresa,
            v.VAMATFUNC                                                AS matfunc,
            v.VACODFOLHA                                               AS folha,
            SUBSTR(v.VADTREFER, 1, 4)                                  AS ano,
            SUBSTR(v.VADTREFER, 5, 2)                                  AS mes,
            v.VADTREFER                                                AS data_comp,
            TO_DATE(
                CONCAT('01', SUBSTR(v.VADTREFER, 5, 2),
                             SUBSTR(v.VADTREFER, 1, 4)),
                'ddMMyyyy'
            )                                                          AS dtini,
            DATE_FORMAT(
                LAST_DAY(TO_DATE(v.VADTREFER, 'yyyyMM')),
                'ddMMyyyy'
            )                                                          AS dtfim,
            COALESCE(
                (SELECT d.DTDTPAGTO
                 FROM {BRONZE_DATAS} d
                 WHERE d.DTCODEMP   = '1'
                   AND d.DTCODFOLHA = v.VACODFOLHA
                   AND d.DTDTREFER  = v.VADTREFER
                 LIMIT 1),
                (SELECT o.OFDTHOMRES
                 FROM {BRONZE_OCORFUNC} o
                 WHERE o.OFCODEMP   = v.VACODEMP
                   AND o.OFMATFUNC  = v.VAMATFUNC
                   AND o.OFCODOCORR = '1001'
                   AND SUBSTR(o.OFDTINIOCO, 1, 6) = v.VADTREFER
                   AND v.VACODFOLHA = '2'
                 LIMIT 1),
                (SELECT o.OFDTHOMRES
                 FROM {BRONZE_OCORFUNC} o
                 WHERE o.OFCODEMP   = v.VACODEMP
                   AND o.OFMATFUNC  = v.VAMATFUNC
                   AND o.OFCODOCORR = '1004'
                   AND SUBSTR(o.OFDTINIOCO, 1, 6) = v.VADTREFER
                   AND v.VACODFOLHA = '5'
                 LIMIT 1),
                (SELECT o.OFDTHOMRES
                 FROM {BRONZE_OCORFUNC} o
                 WHERE o.OFCODEMP   = v.VACODEMP
                   AND o.OFMATFUNC  = v.VAMATFUNC
                   AND o.OFCODOCORR = '1019'
                   AND v.VACODFOLHA = '5'
                 LIMIT 1)
            )                                                          AS data_pagto,
            f.FUDTADMIS                                                AS fudtadmis,
            TO_DATE(
                CONCAT(SUBSTR(f.FUDTADMIS, 7, 2),
                       SUBSTR(f.FUDTADMIS, 5, 2),
                       SUBSTR(f.FUDTADMIS, 1, 4)),
                'ddMMyyyy'
            )                                                          AS dt_admis,
            pe.CSVALOR                                                 AS id_final
        FROM {BRONZE_VALANO} v
        INNER JOIN max_func f
            ON  f.FUCODEMP  = v.VACODEMP
            AND f.FUMATFUNC = v.VAMATFUNC
        INNER JOIN {SILVER_PTP_EVENTOS} p1
            ON  p1.CSENTRADA = '{subgrupo}'
            AND p1.CSVALOR   = f.FUPESSOAID
        INNER JOIN {SILVER_PTP_EVENTOS} p2
            ON  p2.CSENTRADA = 'BASE_EVENTOS_FICHA'
            AND p2.CSVALOR   = v.VACODEVENT
        LEFT JOIN {SILVER_PTP_EVENTOS} pe
            ON  pe.CSSECAO   = f.FUPESSOAID
            AND pe.CSENTRADA = 'DEXPARA_ID'
        WHERE v.VADTREFER BETWEEN '{DATA_INICIO}' AND '{DATA_FIM}'
          AND v.VACODFOLHA IN ({','.join(f"'{fl}'" for fl in FOLHAS_PERMITIDAS)})
          AND v.VACODEMP   IN ({','.join(f"'{e}'" for e in EMPRESAS_PERMITIDAS)})
          AND COALESCE(
                (SELECT d.DTDTPAGTO
                 FROM {BRONZE_DATAS} d
                 WHERE d.DTCODEMP   = v.VACODEMP
                   AND d.DTCODFOLHA = v.VACODFOLHA
                   AND d.DTDTREFER  = v.VADTREFER
                 LIMIT 1),
                '99999999'
          ) >= f.FUDTADMIS
        ORDER BY id_empr, dt_admis
    """)
    # ── Regra VP: elimina folha 1 quando existe folha 7 na mesma referência ──
    if subgrupo == "ID_VP_FICHA_MOCK4":
        df_raw = spark.sql(f"""
            SELECT * FROM ({df_raw._jdf.schema()}) t
            WHERE NOT (
                folha = '1'
                AND EXISTS (
                    SELECT 1 FROM {BRONZE_VALANO} v2
                    WHERE v2.VACODEMP  = t.empresa
                      AND v2.VAMATFUNC = t.matfunc
                      AND v2.VADTREFER = t.data_comp
                      AND v2.VACODFOLHA = '7'
                )
            )
        """)
        # abordagem correta via filter no DataFrame
        df_raw = df_raw.createOrReplaceTempView("vw_vp_raw") or spark.sql("""
            SELECT * FROM vw_vp_raw
        """)

    # Converte para Pandas para manter estado sequencial (equivale ao cursor PL/SQL)
    df_pd = df_raw.toPandas()
    print(f"Linhas base: {len(df_pd):,}")

    rows_558b  = []
    rows_558d  = []
    rows_param = []

    # Número de arquivo inicial por subgrupo (conforme SQL original)
    num_arquivo_header = {100: 1, 200: 2, 300: 3}.get(crano_header, 1)
    num_arquivo_body   = {101: 1, 201: 2, 301: 9}.get(crano_body, 1)

    limite_header = 500_000
    limite_body   = 10_000
    aux_id        = None
    seqnr         = 0
    contador_h    = 0
    contador_b    = 0

    for _, row in df_pd.iterrows():
        id_empr    = str(row["id_empr"])
        id_final   = str(row["id_final"]) if pd.notna(row["id_final"]) else id_empr
        empresa    = int(row["empresa"])
        matfunc    = str(row["matfunc"])
        folha      = int(row["folha"])
        ano        = str(row["ano"])
        mes        = str(row["mes"]).zfill(2)
        dtini      = row["dtini"]
        dtfim      = str(row["dtfim"])
        dt_admis_  = row["dt_admis"]
        data_pagto = str(row["data_pagto"]) if pd.notna(row["data_pagto"]) else None
        data_comp  = str(row["data_comp"])
        fudtadmis  = str(row["fudtadmis"])

        # Reinicia sequencial ao mudar de empregado
        if aux_id != id_empr:
            aux_id = id_empr
            seqnr  = 1
        else:
            seqnr += 1

        dtini_d    = pd.Timestamp(dtini).date()    if pd.notna(dtini)    else date.today()
        dt_admis_d = pd.Timestamp(dt_admis_).date() if pd.notna(dt_admis_) else date.today()

        # ── Monta campos e conteúdo 558B ──────────────────────────
        cfg        = campos_558b(folha, ano, mes, dtini_d, dtfim, dt_admis_d, data_pagto or "")
        conteudo_b = monta_conteudo_558b(id_final, seqnr, cfg)

        # Controla número de arquivo cabeçalho
        if contador_h >= limite_header:
            num_arquivo_header += 1
            contador_h = 1
        else:
            contador_h += 1

        rows_558b.append({
            "CRCODEMP":   str(seqnr).zfill(5),
            "CRMATFUNC":  id_empr,
            "CRANO":      str(crano_header),
            "CRCONTEUDO": conteudo_b,
            "CRFUCPF":    str(num_arquivo_header),
        })

        # Chave de sequencial para retificadoras
        rows_param.append({
            "CSSECAO":   id_final,
            "CSENTRADA": f"{data_comp};{folha};{data_pagto};{num_arquivo_body}",
            "CSVALOR":   str(seqnr).zfill(5),
        })

        # ── Busca eventos e monta 558D ────────────────────────────
        eventos = spark.sql(f"""
            SELECT v.VACODEVENT AS cod_evento,
                   v.VAVALEVENT AS valor_evento
            FROM {BRONZE_VALANO} v
            INNER JOIN {SILVER_PTP_EVENTOS} p
                ON  p.CSENTRADA = 'BASE_EVENTOS_FICHA'
                AND p.CSVALOR   = v.VACODEVENT
            WHERE v.VACODEMP   = '{empresa}'
              AND v.VAMATFUNC  = '{matfunc}'
              AND v.VADTREFER  = '{data_comp}'
              AND v.VACODFOLHA = '{folha}'
        """).collect()

        if contador_b >= limite_body:
            num_arquivo_body += 1
            contador_b = 1
        else:
            contador_b += 1

        for ev in eventos:
            rows_558d.append({
                "CRCODEMP":   str(seqnr).zfill(5),
                "CRMATFUNC":  id_empr,
                "CRANO":      str(crano_body),
                "CRCONTEUDO": monta_conteudo_558d(
                                  folha, id_final, seqnr,
                                  str(ev["cod_evento"]),
                                  str(ev["valor_evento"])
                              ),
                "CRFUCPF":    str(num_arquivo_body),
            })

    print(f"558B ({crano_header}): {len(rows_558b):,} linhas")
    print(f"558D ({crano_body}):   {len(rows_558d):,} linhas")
    print(f"Chaves param:          {len(rows_param):,}")
    return rows_558b, rows_558d, rows_param

# COMMAND ----------
# MAGIC %md ## Processamento dos três subgrupos

schema_f = schema_dados_ficha()
schema_p = schema_ptp_eventos()

# Remove CRANOs anteriores para idempotência
for cr in ["100", "101", "200", "201", "300", "301"]:
    spark.sql(f"DELETE FROM {SILVER_DADOS_FICHA} WHERE CRANO = '{cr}'")

subgrupos_processar = [
    ("ID_VP_FICHA_MOCK4",    100, 101),
    ("ID_ESTAG_FICHA_MOCK4", 200, 201),
    ("ID_FICHA_MOCK4",       300, 301),
]

for sg, ch, cb in subgrupos_processar:
    b558, d558, param = processa_subgrupo(sg, ch, cb)

    if b558:
        spark.createDataFrame(b558, schema_f) \
             .write.format("delta").mode("append").saveAsTable(SILVER_DADOS_FICHA)

    if d558:
        spark.createDataFrame(d558, schema_f) \
             .write.format("delta").mode("append").saveAsTable(SILVER_DADOS_FICHA)

    if param:
        # Remove chaves anteriores do subgrupo antes de inserir
        spark.sql(f"""
            DELETE FROM {SILVER_PTP_EVENTOS}
            WHERE CSENTRADA RLIKE '^[0-9]{{6}};[0-9]+;'
              AND CSSECAO IN (
                    SELECT CSVALOR FROM {SILVER_PTP_EVENTOS}
                    WHERE CSENTRADA = '{sg}'
              )
        """)
        spark.createDataFrame(param, schema_p) \
             .write.format("delta").mode("append").saveAsTable(SILVER_PTP_EVENTOS)

print("\n✅ VP / Estagiários / Empregados processados com sucesso.")