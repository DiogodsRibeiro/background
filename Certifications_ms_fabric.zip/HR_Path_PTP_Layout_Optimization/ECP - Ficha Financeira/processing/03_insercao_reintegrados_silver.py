# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/ECP - Ficha Financeira/utils/utils"

# COMMAND ----------

from pyspark.sql.types import *
import pandas as pd
from datetime import date, timedelta
from dateutil.relativedelta import relativedelta

# COMMAND ----------

df_rei_raw = spark.sql(f"""
    SELECT DISTINCT
        f.FUPESSOAID                                                   AS id_empr,
        v.VACODEMP                                                     AS empresa,
        v.VAMATFUNC                                                    AS matfunc,
        v.VACODFOLHA                                                   AS folha,
        SUBSTR(v.VADTREFER, 1, 4)                                      AS ano,
        SUBSTR(v.VADTREFER, 5, 2)                                      AS mes,
        v.VADTREFER                                                    AS data_ref,
        TO_DATE(
            CONCAT('01', SUBSTR(v.VADTREFER, 5, 2),
                         SUBSTR(v.VADTREFER, 1, 4)),
            'ddMMyyyy'
        )                                                              AS dtini,
        DATE_FORMAT(
            LAST_DAY(TO_DATE(v.VADTREFER, 'yyyyMM')),
            'ddMMyyyy'
        )                                                              AS dtfim,
        f.FUDTADMIS                                                    AS fudtadmis,
        TO_DATE(
            CONCAT(SUBSTR(f.FUDTADMIS, 7, 2),
                   SUBSTR(f.FUDTADMIS, 5, 2),
                   SUBSTR(f.FUDTADMIS, 1, 4)),
            'ddMMyyyy'
        )                                                              AS dt_admis,
        pe.CSVALOR                                                     AS id_final
    FROM {BRONZE_VALANO} v
    INNER JOIN {BRONZE_FUNCIONA} f
        ON  f.FUCODEMP  = v.VACODEMP
        AND f.FUMATFUNC = v.VAMATFUNC
        AND f.FUDATAID  = (
                SELECT MAX(f1.FUDATAID)
                FROM {BRONZE_FUNCIONA} f1
                WHERE f1.FUPESSOAID = f.FUPESSOAID
                  AND f1.FUDATAID  <= '{DATA_CORTE_ID}'
        )
    INNER JOIN {TBL_PTP_EVENTOS} p1
        ON  p1.CSENTRADA = 'ID_REI_FICHA_MOCK4'
        AND p1.CSVALOR   = f.FUPESSOAID
    INNER JOIN {TBL_PTP_EVENTOS} p2
        ON  p2.CSENTRADA = 'BASE_EVENTOS_FICHA'
        AND p2.CSVALOR   = v.VACODEVENT
    LEFT JOIN {TBL_PTP_EVENTOS} pe
        ON  pe.CSSECAO   = f.FUPESSOAID
        AND pe.CSENTRADA = 'DEXPARA_ID'
    WHERE v.VADTREFER BETWEEN '{DATA_INICIO}' AND '{DATA_FIM}'
      AND v.VACODFOLHA IN ({','.join(f"'{f}'" for f in FOLHAS_PERMITIDAS)})
      AND v.VACODEMP   IN ({','.join(f"'{e}'" for e in EMPRESAS_PERMITIDAS)})
      AND COALESCE(
            (SELECT d.DTDTPAGTO
             FROM {BRONZE_DATAS} d
             WHERE d.DTCODEMP   = v.VACODEMP
               AND d.DTCODFOLHA = v.VACODFOLHA
               AND d.DTDTREFER  = v.VADTREFER
             LIMIT 1),
            '99999999'
      ) >= f.FUDTADMIS
    ORDER BY f.FUPESSOAID, dt_admis
""")

df_rei_pd = df_rei_raw.toPandas()
print(f"Linhas base REI: {len(df_rei_pd):,}")

# O PL/SQL original usa cursor sequencial com variáveis de estado entre iterações.
# No Spark a abordagem equivalente é processar em Pandas agrupado por empregado,
# mantendo SEQNR e DATA_VERIF como estado local do loop.

rows_558b  = []
rows_558d  = []
rows_param = []

for id_empr, grp in df_rei_pd.groupby("id_empr", sort=True):
    grp        = grp.sort_values(["data_ref", "folha"]).reset_index(drop=True)
    seqnr      = 1
    data_verif = DATA_INICIO   # YYYYMM — ponteiro de controle de buracos
    conta_pulo = 0

    id_final   = str(grp.iloc[0]["id_final"]) if pd.notna(grp.iloc[0]["id_final"]) else str(id_empr)
    dt_admis   = grp.iloc[0]["dt_admis"]
    empresa    = int(grp.iloc[0]["empresa"])
    matfunc    = str(grp.iloc[0]["matfunc"])

    # Não criar linhas antes da admissão do empregado
    admis_ym = pd.Timestamp(dt_admis).strftime("%Y%m") if pd.notna(dt_admis) else DATA_INICIO
    if data_verif < admis_ym:
        data_verif = admis_ym

    for _, row in grp.iterrows():
        data_ref   = str(row["data_ref"])
        folha      = int(row["folha"])
        ano        = str(row["ano"])
        mes        = str(row["mes"]).zfill(2)
        dtini      = row["dtini"]
        dtfim      = str(row["dtfim"])
        dt_admis_  = row["dt_admis"]
        fudtadmis  = str(row["fudtadmis"])

        dtini_d    = pd.Timestamp(dtini).date()     if pd.notna(dtini)    else date.today()
        dt_admis_d = pd.Timestamp(dt_admis_).date() if pd.notna(dt_admis_) else date.today()

        # ── Detecta buraco: mês esperado < data_ref atual ─────────
        expected_next = (
            pd.Timestamp(data_verif + "01") + relativedelta(months=1)
        ).strftime("%Y%m")

        if data_verif != data_ref and expected_next < data_ref:
            if conta_pulo == 0:
                data_verif = expected_next
                conta_pulo = 1

            # Verifica se há rescisão no mês do buraco
            resc_check = spark.sql(f"""
                SELECT 1 FROM {BRONZE_VALANO}
                WHERE VACODEMP   = '{empresa}'
                  AND VAMATFUNC  = '{matfunc}'
                  AND VADTREFER  = '{data_verif}'
                  AND VACODFOLHA = '5'
                LIMIT 1
            """).collect()

            if not resc_check:
                # Fabrica linha mensal para cobrir o buraco
                rows_558b.append({
                    "CRCODEMP":   str(seqnr).zfill(5),
                    "CRMATFUNC":  str(id_empr),
                    "CRANO":      "400",
                    "CRCONTEUDO": monta_conteudo_558b_fabricado(
                                      id_final, seqnr, empresa,
                                      data_verif, dt_admis_d
                                  ),
                    "CRFUCPF":    str(NUM_ARQUIVO_REI),
                })
                rows_param.append({
                    "CSSECAO":   id_final,
                    "CSENTRADA": f"{data_verif};S/F;"
                                 f"{data_pagto_fabricada(empresa, data_verif)};"
                                 f"{NUM_ARQUIVO_REI}",
                    "CSVALOR":   str(seqnr).zfill(5),
                })
                seqnr += 1

            data_verif = (
                pd.Timestamp(data_verif + "01") + relativedelta(months=1)
            ).strftime("%Y%m")

        else:
            data_verif = data_ref

        # ── Preenche buracos anteriores (empregado desligado antes do início) ──
        while pd.Timestamp(data_verif + "01") < pd.Timestamp(data_ref + "01"):
            rows_558b.append({
                "CRCODEMP":   str(seqnr).zfill(5),
                "CRMATFUNC":  str(id_empr),
                "CRANO":      "400",
                "CRCONTEUDO": monta_conteudo_558b_fabricado(
                                  id_final, seqnr, empresa,
                                  data_verif, dt_admis_d
                              ),
                "CRFUCPF":    str(NUM_ARQUIVO_REI),
            })
            rows_param.append({
                "CSSECAO":   id_final,
                "CSENTRADA": f"{data_verif};S/F;"
                             f"{data_pagto_fabricada(empresa, data_verif)};"
                             f"{NUM_ARQUIVO_REI}",
                "CSVALOR":   str(seqnr).zfill(5),
            })
            data_verif = (
                pd.Timestamp(data_verif + "01") + relativedelta(months=1)
            ).strftime("%Y%m")
            seqnr += 1

        # ── Caso especial: PLR (folha 12) ─────────────────────────
        # Se não há mensal nem rescisão no mesmo mês, fabrica mensal antes do PLR
        if folha == 12:
            mensal_ok = spark.sql(f"""
                SELECT 1 FROM {BRONZE_VALANO}
                WHERE VACODEMP   = '{empresa}'
                  AND VAMATFUNC  = '{matfunc}'
                  AND VADTREFER  = '{data_ref}'
                  AND VACODFOLHA = '1'
                LIMIT 1
            """).collect()
            resc_ok = spark.sql(f"""
                SELECT 1 FROM {BRONZE_VALANO}
                WHERE VACODEMP   = '{empresa}'
                  AND VAMATFUNC  = '{matfunc}'
                  AND VADTREFER  = '{data_ref}'
                  AND VACODFOLHA = '5'
                LIMIT 1
            """).collect()
            if not mensal_ok and not resc_ok:
                rows_558b.append({
                    "CRCODEMP":   str(seqnr).zfill(5),
                    "CRMATFUNC":  str(id_empr),
                    "CRANO":      "400",
                    "CRCONTEUDO": monta_conteudo_558b_fabricado(
                                      id_final, seqnr, empresa,
                                      data_ref, dt_admis_d
                                  ),
                    "CRFUCPF":    str(NUM_ARQUIVO_REI),
                })
                rows_param.append({
                    "CSSECAO":   id_final,
                    "CSENTRADA": f"{data_ref};S/F;"
                                 f"{data_pagto_fabricada(empresa, data_ref)};"
                                 f"{NUM_ARQUIVO_REI}",
                    "CSVALOR":   str(seqnr).zfill(5),
                })
                seqnr += 1

        # ── Caso especial: Adiantamento de 13 (folha 4) ───────────
        # Se há rescisão no mês anterior, insere linha extra antes da principal
        inseriu_extra = False
        if folha == 4:
            mes_ant  = (
                pd.Timestamp(data_ref + "01") - relativedelta(months=1)
            ).strftime("%Y%m")
            resc_ant = spark.sql(f"""
                SELECT 1 FROM {BRONZE_VALANO}
                WHERE VACODEMP   = '{empresa}'
                  AND VAMATFUNC  = '{matfunc}'
                  AND VADTREFER  = '{mes_ant}'
                  AND VACODFOLHA = '5'
                LIMIT 1
            """).collect()
            if resc_ant:
                data_pagto_str = resolve_data_pagto(
                    empresa, int(matfunc), data_ref, folha, fudtadmis
                )
                cfg = campos_558b(
                    folha, ano, mes, dtini_d, dtfim, dt_admis_d,
                    data_pagto_str or ""
                )
                rows_558b.append({
                    "CRCODEMP":   str(seqnr).zfill(5),
                    "CRMATFUNC":  str(id_empr),
                    "CRANO":      "400",
                    "CRCONTEUDO": monta_conteudo_558b(id_final, seqnr, cfg),
                    "CRFUCPF":    str(NUM_ARQUIVO_REI),
                })
                rows_param.append({
                    "CSSECAO":   id_final,
                    "CSENTRADA": f"{data_ref};{folha};"
                                 f"{data_pagto_str};{NUM_ARQUIVO_REI}",
                    "CSVALOR":   str(seqnr).zfill(5),
                })
                seqnr += 1
                # Fabrica mensal logo após
                rows_558b.append({
                    "CRCODEMP":   str(seqnr).zfill(5),
                    "CRMATFUNC":  str(id_empr),
                    "CRANO":      "400",
                    "CRCONTEUDO": monta_conteudo_558b_fabricado(
                                      id_final, seqnr, empresa,
                                      data_verif, dt_admis_d
                                  ),
                    "CRFUCPF":    str(NUM_ARQUIVO_REI),
                })
                rows_param.append({
                    "CSSECAO":   id_final,
                    "CSENTRADA": f"{data_verif};S/F;"
                                 f"{data_pagto_fabricada(empresa, data_verif)};"
                                 f"{NUM_ARQUIVO_REI}",
                    "CSVALOR":   str(seqnr).zfill(5),
                })
                seqnr        += 1
                conta_pulo    = 0
                inseriu_extra = True

        if inseriu_extra:
            continue   # pula inserção principal — já foi feita acima

        # ── Inserção principal — cabeçalho 558B (CRANO 400) ───────
        data_pagto_str = resolve_data_pagto(
            empresa, int(matfunc), data_ref, folha, fudtadmis
        )
        cfg = campos_558b(
            folha, ano, mes, dtini_d, dtfim, dt_admis_d,
            data_pagto_str or ""
        )
        rows_558b.append({
            "CRCODEMP":   str(seqnr).zfill(5),
            "CRMATFUNC":  str(id_empr),
            "CRANO":      "400",
            "CRCONTEUDO": monta_conteudo_558b(id_final, seqnr, cfg),
            "CRFUCPF":    str(NUM_ARQUIVO_REI),
        })
        rows_param.append({
            "CSSECAO":   id_final,
            "CSENTRADA": f"{data_ref};{folha};"
                         f"{data_pagto_str};{NUM_ARQUIVO_REI}",
            "CSVALOR":   str(seqnr).zfill(5),
        })

        # ── Eventos 558D (CRANO 401) ───────────────────────────────
        eventos = spark.sql(f"""
            SELECT v.VACODEVENT AS cod_evento,
                   v.VAVALEVENT AS valor_evento
            FROM {BRONZE_VALANO} v
            WHERE v.VACODEMP   = '{empresa}'
              AND v.VAMATFUNC  = '{matfunc}'
              AND v.VADTREFER  = '{data_ref}'
              AND v.VACODFOLHA = '{folha}'
              AND EXISTS (
                    SELECT 1 FROM {BRONZE_VALANO}
                    WHERE CSVALOR   = v.VACODEVENT
                      AND CSENTRADA = 'BASE_EVENTOS_FICHA'
              )
        """).collect()

        for ev in eventos:
            rows_558d.append({
                "CRCODEMP":   str(seqnr).zfill(5),
                "CRMATFUNC":  str(id_empr),
                "CRANO":      "401",
                "CRCONTEUDO": monta_conteudo_558d(
                                  folha, id_final, seqnr,
                                  str(ev["cod_evento"]),
                                  str(ev["valor_evento"])
                              ),
                "CRFUCPF":    str(NUM_ARQUIVO_REI),
            })

        seqnr      += 1
        conta_pulo  = 0

print(f"Linhas 558B (400): {len(rows_558b):,}")
print(f"Linhas 558D (401): {len(rows_558d):,}")
print(f"Chaves param     : {len(rows_param):,}")

# COMMAND ----------
# MAGIC %md ## 3 · Persiste resultados

schema_f = schema_dados_ficha()
schema_p = schema_ptp_eventos()

# Remove CRANOs anteriores para idempotência
spark.sql(f"DELETE FROM {TBL_DADOS_FICHA} WHERE CRANO IN ('400', '401')")

if rows_558b:
    spark.createDataFrame(rows_558b, schema_f) \
         .write.format("delta").mode("append").saveAsTable(TBL_DADOS_FICHA)
    print(f"✅ {len(rows_558b):,} linhas gravadas — 558B (CRANO 400)")

if rows_558d:
    spark.createDataFrame(rows_558d, schema_f) \
         .write.format("delta").mode("append").saveAsTable(TBL_DADOS_FICHA)
    print(f"✅ {len(rows_558d):,} linhas gravadas — 558D (CRANO 401)")

if rows_param:
    spark.sql(f"""
        DELETE FROM {TBL_PTP_EVENTOS}
        WHERE CSENTRADA LIKE '%;S/F;%'
           OR CSENTRADA RLIKE '^[0-9]{{6}};[0-9]+;'
    """)
    spark.createDataFrame(rows_param, schema_p) \
         .write.format("delta").mode("append").saveAsTable(TBL_PTP_EVENTOS)
    print(f"✅ {len(rows_param):,} chaves de sequencial gravadas em PTP_EVENTOS")