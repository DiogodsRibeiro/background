# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/ECP - Ficha Financeira/utils/utils"

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window

# COMMAND ----------

print("Estatísticas da TBL_DADOS_FICHA:")

stats = spark.sql(f"""
    SELECT
        CRANO,
        CASE
            WHEN CRANO IN ('100','200','300','400') THEN '558B (cabeçalho)'
            ELSE                                        '558D (corpo)'
        END                                AS tipo,
        COUNT(*)                           AS total_linhas,
        COUNT(DISTINCT CRMATFUNC)          AS total_ids,
        COUNT(DISTINCT CRFUCPF)            AS total_arquivos
    FROM {TBL_DADOS_FICHA}
    GROUP BY CRANO
    ORDER BY CRANO
""")
display(stats)

# COMMAND ----------
# MAGIC %md ## 2 · Validação de sequenciais (sem buracos)
# MAGIC
# MAGIC Para cada (CRMATFUNC, CRANO), os CRCODEMP devem ser contínuos de 1 a N.
# MAGIC Qualquer buraco indica problema no processamento e bloqueia a exportação.

def valida_sequenciais() -> int:
    print("Validando integridade dos sequenciais...")

    w = Window.partitionBy("CRMATFUNC", "CRANO").orderBy(F.col("CRCODEMP").cast("int"))

    df_check = (
        spark.sql(f"""
            SELECT CRMATFUNC,
                   CRANO,
                   CAST(CRCODEMP AS INT) AS seqnr
            FROM {TBL_DADOS_FICHA}
            WHERE CRANO IN ('100','200','300','400')
        """)
        .withColumn("seq_esperado", F.row_number().over(w))
        .withColumn("tem_buraco",   F.col("seqnr") != F.col("seq_esperado"))
    )

    buracos = df_check.filter(F.col("tem_buraco") == True)
    total   = buracos.count()

    if total > 0:
        print(f"⚠️  {total:,} buracos encontrados nos sequenciais:")
        display(
            buracos.select("CRMATFUNC", "CRANO", "seqnr", "seq_esperado")
                   .limit(50)
        )
    else:
        print("✅ Nenhum buraco encontrado. Sequenciais íntegros.")

    return total

n_buracos = valida_sequenciais()

if n_buracos > 0:
    raise Exception(
        f"⛔ Exportação interrompida: {n_buracos:,} buracos encontrados. "
        f"Corrija antes de exportar."
    )

# COMMAND ----------
# MAGIC %md ## 3 · Gera arquivos 558B (cabeçalho)

def gera_arquivos_558b() -> int:
    """
    Para cada (CRANO, CRFUCPF) de cabeçalho, gera um arquivo TXT com as linhas 558B
    ordenadas por CRMATFUNC (ID) e CRCODEMP (SEQNR).
    """
    df_header = spark.sql(f"""
        SELECT CRCODEMP, CRMATFUNC, CRANO, CRCONTEUDO, CRFUCPF
        FROM {TBL_DADOS_FICHA}
        WHERE CRANO IN ('100','200','300','400')
    """)

    combinacoes = (
        df_header
        .select("CRANO", "CRFUCPF")
        .distinct()
        .orderBy("CRANO", "CRFUCPF")
        .collect()
    )

    print(f"Arquivos 558B a gerar: {len(combinacoes)}")

    for row in combinacoes:
        crano   = row["CRANO"]
        num_arq = row["CRFUCPF"]
        caminho = f"{OUTPUT_BASE_PATH}/558B/T558B_{crano}_{num_arq}.txt"

        df_arq = (
            df_header
            .filter(
                (F.col("CRANO") == crano) &
                (F.col("CRFUCPF") == num_arq)
            )
            .orderBy("CRMATFUNC", F.col("CRCODEMP").cast("int"))
            .select("CRCONTEUDO")
        )

        df_arq.coalesce(1).write.mode("overwrite").text(caminho)
        print(f"  ✅ T558B_{crano}_{num_arq}.txt → {df_arq.count():,} linhas")

    return len(combinacoes)

n_558b = gera_arquivos_558b()

# COMMAND ----------
# MAGIC %md ## 4 · Gera arquivos 558D (corpo)

def gera_arquivos_558d() -> int:
    """
    Para cada (CRANO, CRFUCPF) de corpo, gera um arquivo TXT com as linhas 558D
    ordenadas por CRMATFUNC (ID) e CRCODEMP (SEQNR).
    """
    df_body = spark.sql(f"""
        SELECT CRCODEMP, CRMATFUNC, CRANO, CRCONTEUDO, CRFUCPF
        FROM {TBL_DADOS_FICHA}
        WHERE CRANO IN ('101','201','301','401')
    """)

    combinacoes = (
        df_body
        .select("CRANO", "CRFUCPF")
        .distinct()
        .orderBy("CRANO", "CRFUCPF")
        .collect()
    )

    print(f"Arquivos 558D a gerar: {len(combinacoes)}")

    for row in combinacoes:
        crano   = row["CRANO"]
        num_arq = row["CRFUCPF"]
        caminho = f"{OUTPUT_BASE_PATH}/558D/T558D_{crano}_{num_arq}.txt"

        df_arq = (
            df_body
            .filter(
                (F.col("CRANO") == crano) &
                (F.col("CRFUCPF") == num_arq)
            )
            .orderBy("CRMATFUNC", F.col("CRCODEMP").cast("int"))
            .select("CRCONTEUDO")
        )

        df_arq.coalesce(1).write.mode("overwrite").text(caminho)
        print(f"  ✅ T558D_{crano}_{num_arq}.txt → {df_arq.count():,} linhas")

    return len(combinacoes)

n_558d = gera_arquivos_558d()

# COMMAND ----------

print(f"""
╔══════════════════════════════════════════╗
║     EXPORTAÇÃO CONCLUÍDA                 ║
╠══════════════════════════════════════════╣
║  Arquivos 558B gerados : {str(n_558b).rjust(5)}            ║
║  Arquivos 558D gerados : {str(n_558d).rjust(5)}            ║
╚══════════════════════════════════════════╝
Caminho: {OUTPUT_BASE_PATH}

Próximos passos:
  1. Retirar os arquivos do caminho acima
  2. Passar pelo conversor PeopleSoft (de-para de rubricas FPw → SAP)
  3. Fazer upload no Portal MFT para carga no SAP ECP
""")