# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/ECP - Ficha Financeira/utils/utils"

# COMMAND ----------

from pyspark.sql import functions as F

# COMMAND ----------

def processa_retificadoras(subgrupo: str, crano: str) -> None:
    """
    Substitui as linhas da folha base pelas da folha retificadora
    para todos os empregados de um subgrupo que possuem folhas
    retificadoras no período.

    Args:
        subgrupo: nome do subgrupo (ex: 'ID_VP_FICHA_MOCK4')
        crano:    código CRANO do corpo a substituir (string: '101', '201', '301' ou '401')
    """
    print(f"\n{'='*60}")
    print(f"Retificadoras — subgrupo: {subgrupo} | CRANO: {crano}")
    print(f"{'='*60}")

    # ── 1. Busca empregados do subgrupo com folhas retificadoras ──
    folhas_ret_str = ','.join(f"'{f}'" for f in RETIFICADORAS_MAP.keys())

    df_ret = spark.sql(f"""
        SELECT DISTINCT
            f.FUPESSOAID   AS id_empr,
            v.VACODEMP     AS empresa,
            v.VAMATFUNC    AS matfunc,
            v.VACODFOLHA   AS folha,
            v.VADTREFER    AS data_comp,
            pe.CSSECAO     AS id_inicial,
            pe.CSVALOR     AS id_final
        FROM {TBL_VALANO} v
        INNER JOIN {TBL_FUNCIONA} f
            ON  f.FUCODEMP  = v.VACODEMP
            AND f.FUMATFUNC = v.VAMATFUNC
            AND f.FUDATAID  = (
                    SELECT MAX(f1.FUDATAID)
                    FROM {TBL_FUNCIONA} f1
                    WHERE f1.FUPESSOAID = f.FUPESSOAID
                      AND f1.FUDATAID  <= '{DATA_CORTE_ID}'
            )
        INNER JOIN {TBL_PTP_EVENTOS} p1
            ON  p1.CSENTRADA = 'BASE_EVENTOS_FICHA'
            AND p1.CSVALOR   = v.VACODEVENT
        INNER JOIN {TBL_PTP_EVENTOS} p2
            ON  p2.CSENTRADA = '{subgrupo}'
            AND p2.CSVALOR   = f.FUPESSOAID
        LEFT JOIN {TBL_PTP_EVENTOS} pe
            ON  pe.CSSECAO   = f.FUPESSOAID
            AND pe.CSENTRADA = 'DEXPARA_ID'
        WHERE v.VADTREFER BETWEEN '{DATA_INICIO}' AND '{DATA_FIM}'
          AND v.VACODFOLHA IN ({folhas_ret_str})
          AND v.VACODEMP   IN ({','.join(f"'{e}'" for e in EMPRESAS_PERMITIDAS)})
        ORDER BY f.FUPESSOAID, v.VADTREFER
    """)

    registros     = df_ret.collect()
    substituicoes = 0
    nao_encontr   = 0

    print(f"Combinações encontradas: {len(registros):,}")

    for row in registros:
        empresa   = str(row["empresa"])
        matfunc   = str(row["matfunc"])
        folha_ret = int(row["folha"])
        data_comp = str(row["data_comp"])
        id_empr   = str(row["id_empr"])
        id_inicial = str(row["id_inicial"]) if row["id_inicial"] else id_empr
        id_final   = str(row["id_final"])   if row["id_final"]   else id_empr

        cfg_ret   = RETIFICADORAS_MAP[folha_ret]
        aux_folha = str(cfg_ret["folha_base_crano"])
        pares     = cfg_ret["par"]
        pares_str = ','.join(f"'{p}'" for p in pares)

        # ── 2. Resolve DEFINE_FOLHA ────────────────────────────────
        # Verifica se existe folha sobrepositora — a de maior código vence
        sobrepostas = spark.sql(f"""
            SELECT MAX(CAST(VACODFOLHA AS INT)) AS max_folha
            FROM {TBL_VALANO}
            WHERE VACODEMP   = '{empresa}'
              AND VAMATFUNC  = '{matfunc}'
              AND VADTREFER  = '{data_comp}'
              AND VACODFOLHA IN ({pares_str})
        """).collect()

        max_sob    = sobrepostas[0]["max_folha"] if sobrepostas else None
        define_f   = str(int(max_sob)) if max_sob else str(folha_ret)

        # ── 3. Busca SEQNR e NUM_ARQUIVO em PTP_EVENTOS ───────────
        seqnr_row = spark.sql(f"""
            SELECT
                SPLIT(CSENTRADA, ';')[0] AS dtrefer,
                SPLIT(CSENTRADA, ';')[1] AS folha_chave,
                SPLIT(CSENTRADA, ';')[3] AS num_arquivo,
                CSVALOR                  AS seqnr
            FROM {TBL_PTP_EVENTOS}
            WHERE CSSECAO                    = '{id_final}'
              AND SPLIT(CSENTRADA, ';')[0]   = '{data_comp}'
              AND SPLIT(CSENTRADA, ';')[1]   = '{aux_folha}'
            LIMIT 1
        """).collect()

        if not seqnr_row:
            print(f"  ⚠️  SEQNR não encontrado: "
                  f"id={id_final} | ref={data_comp} | folha_base={aux_folha}")
            nao_encontr += 1
            continue

        seqnr       = str(seqnr_row[0]["seqnr"])
        num_arquivo = str(seqnr_row[0]["num_arquivo"])

        # ── 4. Deleta linha antiga da folha base ───────────────────
        spark.sql(f"""
            DELETE FROM {TBL_DADOS_FICHA}
            WHERE CRMATFUNC = '{id_inicial}'
              AND CRCODEMP  = '{seqnr}'
              AND CRANO     = '{crano}'
        """)

        # ── 5. Reinsere com dados da retificadora ──────────────────
        eventos = spark.sql(f"""
            SELECT v.VACODEVENT AS evento,
                   v.VAVALEVENT AS valor
            FROM {TBL_VALANO} v
            INNER JOIN {TBL_PTP_EVENTOS} p
                ON  p.CSENTRADA = 'BASE_EVENTOS_FICHA'
                AND p.CSVALOR   = v.VACODEVENT
            WHERE v.VACODEMP   = '{empresa}'
              AND v.VAMATFUNC  = '{matfunc}'
              AND v.VADTREFER  = '{data_comp}'
              AND v.VACODFOLHA = '{define_f}'
        """).collect()

        for ev in eventos:
            conteudo_ret = monta_conteudo_558d(
                int(define_f), id_final, int(seqnr),
                str(ev["evento"]), str(ev["valor"])
            )
            spark.sql(f"""
                INSERT INTO {TBL_DADOS_FICHA}
                VALUES (
                    '{seqnr}',
                    '{id_inicial}',
                    '{crano}',
                    '{conteudo_ret}',
                    '{num_arquivo}'
                )
            """)

        substituicoes += 1

    print(f"Substituições realizadas   : {substituicoes:,}")
    print(f"Sequenciais não encontrados: {nao_encontr:,}")

# COMMAND ----------
# MAGIC %md ## Execução para todos os subgrupos

SUBGRUPO_CRANO = {
    "ID_VP_FICHA_MOCK4":    "101",
    "ID_ESTAG_FICHA_MOCK4": "201",
    "ID_FICHA_MOCK4":       "301",
    "ID_REI_FICHA_MOCK4":   "401",
}

for sg, cr in SUBGRUPO_CRANO.items():
    processa_retificadoras(sg, cr)

print("\n✅ Retificadoras processadas para todos os subgrupos.")