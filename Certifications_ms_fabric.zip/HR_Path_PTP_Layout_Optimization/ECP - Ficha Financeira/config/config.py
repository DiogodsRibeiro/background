# Databricks notebook source
ORACLE_JDBC_URL = "jdbc:oracle:thin:@//broci1exa012-soo1s-scan.snetdb0112.vcndb001.oraclevcn.com:1521/JVT015_PTP.snetdb0112.vcndb001.oraclevcn.com"
ORACLE_DRIVER   = "oracle.jdbc.driver.OracleDriver"

# ORACLE_USER     = dbutils.secrets.get(scope="oracle-ptp", key="user")
# ORACLE_PASSWORD = dbutils.secrets.get(scope="oracle-ptp", key="password")

ORACLE_USER = "C0721527"
ORACLE_PASSWORD = "KhJeBXR6ms4Gxz"


# Tabelas Oracle de origem
TBL_FUNCIONA_ORACLE    = "PCFPW.FUNCIONA"
TBL_VALANO_ORACLE      = "PCFPW.VALANO"
TBL_OCORFUNC_ORACLE    = "PCFPW.OCORFUNC"
TBL_DATAS_ORACLE       = "PCFPW.DATAS"
TBL_PTP_EVENTOS_ORACLE = "PCFPW.PTP_EVENTOS"
TBL_PTP_DADOS_FICHA_ORACLE = "PCFPW.PTP_DADOS_FICHA"




DATA_INICIO     = "202302"   # Início do período de extração (YYYYMM)
DATA_FIM        = "202505"   # Fim do período de extração (YYYYMM)
DATA_CORTE_ID   = 20250531   # Data máxima para buscar FUDATAID
DATA_CORTE_MOCK = 20250630   # Data de corte usada na separação dos IDs


CATALOG       = "humanresources_insight"
BRONZE_SCHEMA = f"{CATALOG}.bron_pcecpfichafinanceira"
SILVER_SCHEMA = f"{CATALOG}.silv_pcecpfichafinanceira"


BRONZE_FUNCIONA    = f"{BRONZE_SCHEMA}.funciona_fpw"
BRONZE_VALANO      = f"{BRONZE_SCHEMA}.valano_fpw"
BRONZE_OCORFUNC    = f"{BRONZE_SCHEMA}.ocorfunc_fpw"
BRONZE_DATAS       = f"{BRONZE_SCHEMA}.datas_fpw"
BRONZE_PTP_EVENTOS = f"{BRONZE_SCHEMA}.ptp_eventos_fpw"
BRONZE_PTP_DADOS_FICHA = f"{BRONZE_SCHEMA}.ptp_dados_ficha_fpw"
CHECKPOINT_TABLE = f"{BRONZE_SCHEMA}.checkpoint_ingestao"


SILVER_DADOS_FICHA = f"{SILVER_SCHEMA}.ptp_dados_ficha"
SILVER_PTP_EVENTOS = f"{SILVER_SCHEMA}.ptp_eventos"


ABFSS_BASE       = "abfss://lakehouseinsight@usazu1valesa001.dfs.core.windows.net"
OUTPUT_BASE_PATH = f"{ABFSS_BASE}/HumanResources/Bronze/PTP_Migracao/ficha_financeira_output"


EMPRESAS_PERMITIDAS       = [1, 3, 4, 46, 64, 68, 90, 112, 360, 632, 646]
EMPRESAS_PAGTO_ULTIMO_DIA = [3, 68, 360, 632]

FOLHAS_BASE               = [1, 2, 3, 4, 5, 6, 7, 10, 12, 19, 30, 31, 32, 501]
FOLHAS_RETIFICADORAS      = [102, 105, 108, 111, 114, 117, 122, 125, 126, 130,
                             134, 137, 140, 143, 146, 149, 152, 155, 158,
                             205, 208, 211, 214, 217, 220, 223, 226, 229, 232, 235, 238]
FOLHAS_PERMITIDAS         = FOLHAS_BASE + FOLHAS_RETIFICADORAS


FOLHA_MAP = {
    1:   {"payty": "",  "payid": "",  "ocrsn": "",     "permo": "01", "usa_pabrj_pabrp": True,  "usa_fpbeg_fpend": True},
    5:   {"payty": "",  "payid": "",  "ocrsn": "RESC", "permo": "01", "usa_pabrj_pabrp": True,  "usa_fpbeg_fpend": True},
    7:   {"payty": "",  "payid": "",  "ocrsn": "",     "permo": "01", "usa_pabrj_pabrp": True,  "usa_fpbeg_fpend": True},
    2:   {"payty": "A", "payid": "F", "ocrsn": "FERI", "permo": "",   "usa_pabrj_pabrp": False, "usa_fpbeg_fpend": False},
    3:   {"payty": "A", "payid": "J", "ocrsn": "1313", "permo": "",   "usa_pabrj_pabrp": False, "usa_fpbeg_fpend": False},
    4:   {"payty": "A", "payid": "I", "ocrsn": "131P", "permo": "",   "usa_pabrj_pabrp": False, "usa_fpbeg_fpend": False},
    6:   {"payty": "B", "payid": "",  "ocrsn": "AJUS", "permo": "01", "usa_pabrj_pabrp": False, "usa_fpbeg_fpend": False},
    10:  {"payty": "A", "payid": "A", "ocrsn": "ADIA", "permo": "",   "usa_pabrj_pabrp": False, "usa_fpbeg_fpend": False},
    12:  {"payty": "A", "payid": "P", "ocrsn": "ZPLR", "permo": "",   "usa_pabrj_pabrp": False, "usa_fpbeg_fpend": False},
    30:  {"payty": "A", "payid": "D", "ocrsn": "ZADI", "permo": "",   "usa_pabrj_pabrp": False, "usa_fpbeg_fpend": False},
    31:  {"payty": "A", "payid": "D", "ocrsn": "ZADI", "permo": "",   "usa_pabrj_pabrp": False, "usa_fpbeg_fpend": False},
    32:  {"payty": "A", "payid": "D", "ocrsn": "ZADI", "permo": "",   "usa_pabrj_pabrp": False, "usa_fpbeg_fpend": False},
    19:  {"payty": "A", "payid": "",  "ocrsn": "",     "permo": "",   "usa_pabrj_pabrp": False, "usa_fpbeg_fpend": False},
    501: {"payty": "A", "payid": "",  "ocrsn": "",     "permo": "",   "usa_pabrj_pabrp": False, "usa_fpbeg_fpend": False},
}


RETIFICADORAS_MAP = {
    102: {"par": [105],                                                                      "folha_base_crano": 1},
    108: {"par": [111],                                                                      "folha_base_crano": 3},
    114: {"par": [117,122,125,126,130,137,140,143,146,149,152,155,158,208,211,214],         "folha_base_crano": 5},
    134: {"par": [205,217,220,223,226,229,232,235,238],                                     "folha_base_crano": 7},
}



SUBGRUPOS = {
    "ID_VP_FICHA_MOCK4":    {"crano_header": 100, "crano_body": 101},
    "ID_ESTAG_FICHA_MOCK4": {"crano_header": 200, "crano_body": 201},
    "ID_FICHA_MOCK4":       {"crano_header": 300, "crano_body": 301},
    "ID_REI_FICHA_MOCK4":   {"crano_header": 400, "crano_body": 401},
}

NUM_ARQUIVO_REI = 900


print("✅ Configurações carregadas com sucesso.")
print(f"   Período : {DATA_INICIO} → {DATA_FIM}")
print(f"   Empresas: {EMPRESAS_PERMITIDAS}")
print(f"   Folhas  : {FOLHAS_PERMITIDAS}")
print(f"   Bronze  : {BRONZE_SCHEMA}")
print(f"   Silver  : {SILVER_SCHEMA}")
print(f"   Output  : {OUTPUT_BASE_PATH}")