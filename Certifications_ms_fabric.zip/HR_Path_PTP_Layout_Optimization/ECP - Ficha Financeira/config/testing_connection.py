# Databricks notebook source
# DBTITLE 1,Cell 1
jdbc_url = "jdbc:oracle:thin:@//broci1exa012-soo1s-scan.snetdb0112.vcndb001.oraclevcn.com:1521/JVT015_PTP.snetdb0112.vcndb001.oraclevcn.com"

query = "(SELECT * FROM PCFPW.VALANO WHERE ROWNUM <=5)"

df = spark.read.format("jdbc") \
    .option("url", jdbc_url) \
    .option("dbtable", query) \
    .option("user", "C0721527") \
    .option("password", "KhJeBXR6ms4Gxz") \
    .option("driver", "oracle.jdbc.driver.OracleDriver") \
    .load()

df.display()

# COMMAND ----------

jdbc_url = "jdbc:oracle:thin:@//broci1exa012-soo1s-scan.snetdb0112.vcndb001.oraclevcn.com:1521/JVT015_PTP.snetdb0112.vcndb001.oraclevcn.com"

query = """
(
    SELECT COUNT(*) AS CNT
    FROM PCFPW.VALANO
    WHERE VADTREFER  = 202303
      AND VACODEMP   IN (1, 3, 4, 46, 64, 68, 90, 112, 360, 632, 646)
      AND VACODFOLHA IN (1, 2, 3, 4, 5, 6, 7, 10, 12, 19, 30, 31, 32, 501,
                         102, 105, 108, 111, 114, 117, 122, 125, 126, 130,
                         134, 137, 140, 143, 146, 149, 152, 155, 158,
                         205, 208, 211, 214, 217, 220, 223, 226, 229, 232, 235, 238)
      AND VAINDPERM = 'T'
) Q
"""

df = spark.read.format("jdbc") \
    .option("url",      jdbc_url) \
    .option("dbtable",  query) \
    .option("user",     "C0721527") \
    .option("password", "KhJeBXR6ms4Gxz") \
    .option("driver",   "oracle.jdbc.driver.OracleDriver") \
    .load()

df.display()