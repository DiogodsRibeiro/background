# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/ECP - Ficha Financeira/config/config"

# COMMAND ----------

from pyspark.sql import DataFrame, functions as F
from pyspark.sql.types import StructType, StructField, StringType, IntegerType
from datetime import date, timedelta
from dateutil.relativedelta import relativedelta
import pandas as pd

# COMMAND ----------

# MAGIC %run ../config/config

# COMMAND ----------

from pyspark.sql import DataFrame, functions as F
from pyspark.sql.types import StructType, StructField, StringType, IntegerType
from datetime import date, timedelta
from dateutil.relativedelta import relativedelta
import pandas as pd

# COMMAND ----------

def save_table(df: DataFrame, table: str) -> None:
    """
    Trunca e reinsere um DataFrame como tabela Delta.

    Usa TRUNCATE + insertInto para preservar schema, permissões e
    propriedades configuradas no Unity Catalog.
    Evita o mode('overwrite') que recria a tabela e quebra permissões.
    """
    spark.sql(f"TRUNCATE TABLE {table}")
    df.write.insertInto(table)
    print(f"Gravado: {table} ({df.count():,} registros)")


def resolve_data_pagto(empresa: int, matfunc: int, dtrefer: str,
                       folha: int, dt_admis_str: str):
    """
    Replica a lógica NVL aninhada do SQL original para buscar a data de pagamento.

    Prioridade:
      1. Férias (folha 2)   → OCORFUNC ocorrência 1001
      2. Demais             → tabela DATAS (dtdtpagto >= fudtadmis)
      3. Rescisão (folha 5) → OCORFUNC ocorrências 1004 e 1019

    Args:
        empresa:      VACODEMP
        matfunc:      VAMATFUNC
        dtrefer:      referência no formato YYYYMM (string)
        folha:        VACODFOLHA
        dt_admis_str: data de admissão no formato YYYYMMDD (string)

    Returns:
        String YYYYMMDD ou None se não encontrada.
    """
    if folha == 2:
        row = spark.sql(f"""
            SELECT o.OFDTHOMRES AS pagto
            FROM {TBL_OCORFUNC} o
            INNER JOIN {TBL_VALANO} v
                ON  v.VACODEMP  = o.OFCODEMP
                AND v.VAMATFUNC = o.OFMATFUNC
            WHERE v.VACODEMP   = '{empresa}'
              AND v.VAMATFUNC  = '{matfunc}'
              AND v.VADTREFER  = '{dtrefer}'
              AND v.VACODFOLHA = '2'
              AND o.OFCODOCORR = '1001'
              AND SUBSTR(o.OFDTINIOCO, 1, 6) = '{dtrefer}'
            LIMIT 1
        """).collect()
        if row and row[0]["pagto"]:
            return str(row[0]["pagto"])

    row = spark.sql(f"""
        SELECT d.DTDTPAGTO AS pagto
        FROM {TBL_DATAS} d
        WHERE d.DTCODEMP   = '{empresa}'
          AND d.DTCODFOLHA = '{folha}'
          AND d.DTDTREFER  = '{dtrefer}'
          AND d.DTDTPAGTO >= '{dt_admis_str}'
        LIMIT 1
    """).collect()
    if row and row[0]["pagto"]:
        return str(row[0]["pagto"])

    if folha == 5:
        for ocorr in ["1004", "1019"]:
            row = spark.sql(f"""
                SELECT o.OFDTHOMRES AS pagto
                FROM {TBL_OCORFUNC} o
                INNER JOIN {TBL_VALANO} v
                    ON  v.VACODEMP  = o.OFCODEMP
                    AND v.VAMATFUNC = o.OFMATFUNC
                WHERE v.VACODEMP   = '{empresa}'
                  AND v.VAMATFUNC  = '{matfunc}'
                  AND v.VADTREFER  = '{dtrefer}'
                  AND v.VACODFOLHA = '5'
                  AND o.OFCODOCORR = '{ocorr}'
                  AND SUBSTR(o.OFDTINIOCO, 1, 6) = '{dtrefer}'
                LIMIT 1
            """).collect()
            if row and row[0]["pagto"]:
                return str(row[0]["pagto"])

    return None


def data_pagto_fabricada(empresa: int, data_verif_yyyymm: str) -> str:
    """
    Calcula a data de pagamento para linhas fabricadas pelo TAPA_BURACO.

    Regra (conforme SQL original Script400-401):
      - Empresas 3, 68, 360, 632 → último dia do mês corrente
      - Demais                   → primeiro dia do mês seguinte

    Args:
        empresa:           VACODEMP (int)
        data_verif_yyyymm: mês de referência no formato YYYYMM (string)

    Returns:
        String DDMMYYYY.
    """
    ano      = int(data_verif_yyyymm[:4])
    mes      = int(data_verif_yyyymm[4:])
    primeiro = date(ano, mes, 1)

    if empresa in EMPRESAS_PAGTO_ULTIMO_DIA:
        resultado = primeiro + relativedelta(months=1) - timedelta(days=1)
    else:
        resultado = primeiro + relativedelta(months=1)

    return resultado.strftime("%d%m%Y")


def campos_558b(folha: int, ano: str, mes: str,
                dtini_date: date, dtfim_str: str,
                dt_admis_date: date, data_pagto_str: str) -> dict:
    """
    Monta o dicionário de campos do layout 558B para uma dada folha.

    Segue as regras da Tabela 1 do Documento de Regras.
    Converte data de pagamento de YYYYMMDD → DDMMYYYY.

    Args:
        folha:          VACODFOLHA (int)
        ano:            ano de referência (string YYYY)
        mes:            mês de referência (string MM)
        dtini_date:     primeiro dia do mês (date)
        dtfim_str:      último dia do mês no formato DDMMYYYY
        dt_admis_date:  data de admissão (date)
        data_pagto_str: data de pagamento no formato YYYYMMDD

    Returns:
        Dicionário com: payty, payid, ocrsn, permo, pabrj, pabrp, fpbeg, fpend, paydt
    """
    cfg = FOLHA_MAP.get(folha, {
        "payty": "", "payid": "", "ocrsn": "",
        "permo": "", "usa_pabrj_pabrp": False, "usa_fpbeg_fpend": False
    })

    pabrj = str(ano)          if cfg["usa_pabrj_pabrp"] else ""
    pabrp = str(mes).zfill(2) if cfg["usa_pabrj_pabrp"] else ""

    if cfg["usa_fpbeg_fpend"]:
        fpbeg = max(dtini_date, dt_admis_date).strftime("%d%m%Y")
        fpend = dtfim_str
    else:
        fpbeg = ""
        fpend = ""

    # Converte YYYYMMDD → DDMMYYYY
    if data_pagto_str and len(str(data_pagto_str)) == 8:
        try:
            paydt = date(
                int(str(data_pagto_str)[:4]),
                int(str(data_pagto_str)[4:6]),
                int(str(data_pagto_str)[6:])
            ).strftime("%d%m%Y")
        except (ValueError, TypeError):
            paydt = str(data_pagto_str)
    else:
        paydt = str(data_pagto_str) if data_pagto_str else ""

    return {
        "payty": cfg["payty"],
        "payid": cfg["payid"],
        "ocrsn": cfg["ocrsn"],
        "permo": cfg["permo"],
        "pabrj": pabrj,
        "pabrp": pabrp,
        "fpbeg": fpbeg,
        "fpend": fpend,
        "paydt": paydt,
    }

# COMMAND ----------
# MAGIC %md ## monta_conteudo_558b

def monta_conteudo_558b(id_final: str, seqnr: int, campos: dict) -> str:
    """
    Serializa os campos em string separada por ';' no formato exato do layout 558B.

    Layout T558B (11 campos):
      PERNR ; SEQNR ; PAYTY ; PAYID ; PAYDT ; PERMO ; PABRJ ; PABRP ; FPBEG ; FPEND ; OCRSN

    Args:
        id_final: ID destino do empregado (de-para)
        seqnr:    número sequencial (int)
        campos:   dicionário retornado por campos_558b()

    Returns:
        String com os 11 campos separados por ';'
    """
    return (
        f"{id_final};"
        f"{str(seqnr).zfill(5)};"
        f"{campos['payty']};"
        f"{campos['payid']};"
        f"{campos['paydt']};"
        f"{campos['permo']};"
        f"{campos['pabrj']};"
        f"{campos['pabrp']};"
        f"{campos['fpbeg']};"
        f"{campos['fpend']};"
        f"{campos['ocrsn']}"
    )

# COMMAND ----------
# MAGIC %md ## monta_conteudo_558b_fabricado

def monta_conteudo_558b_fabricado(id_final: str, seqnr: int,
                                   empresa: int, data_verif_yyyymm: str,
                                   dt_admis_date: date) -> str:
    """
    Monta a linha 558B sintética para o TAPA_BURACO (mês sem folha regular).

    Equivale à procedure TAPA_BURACO do Script400-401-InsercaoREI_v3.sql.
    PAYTY, PAYID e OCRSN ficam vazios. PERMO = '01'.

    Layout T558B (11 campos):
      PERNR ; SEQNR ; PAYTY ; PAYID ; PAYDT ; PERMO ; PABRJ ; PABRP ; FPBEG ; FPEND ; OCRSN

    Args:
        id_final:           ID destino do empregado
        seqnr:              sequencial da linha (int)
        empresa:            VACODEMP (int)
        data_verif_yyyymm:  mês a ser fabricado no formato YYYYMM
        dt_admis_date:      data de admissão (date)

    Returns:
        String com os 11 campos separados por ';'
    """
    pagto_fab = data_pagto_fabricada(empresa, data_verif_yyyymm)
    ano       = data_verif_yyyymm[:4]
    mes       = data_verif_yyyymm[4:]
    dtini_fab = date(int(ano), int(mes), 1)
    fpbeg_fab = max(dtini_fab, dt_admis_date).strftime("%d%m%Y")
    fpend_fab = (
        pd.Timestamp(data_verif_yyyymm + "01")
        + relativedelta(months=1)
        - timedelta(days=1)
    ).strftime("%d%m%Y")

    return (
        f"{id_final};"
        f"{str(seqnr).zfill(5)};"
        f";"           # PAYTY  — vazio para mensal fabricada
        f";"           # PAYID  — vazio para mensal fabricada
        f"{pagto_fab};"
        f"01;"         # PERMO
        f"{ano};"      # PABRJ
        f"{mes};"      # PABRP
        f"{fpbeg_fab};"
        f"{fpend_fab};"
        f""            # OCRSN  — vazio para mensal
    )

# COMMAND ----------
# MAGIC %md ## monta_conteudo_558d

def monta_conteudo_558d(folha: int, id_final: str, seqnr: int,
                        cod_evento: str, valor_evento: str) -> str:
    """
    Serializa os campos em string separada por ';' no formato exato do layout 558D.

    Layout T558D (20 campos):
      LGART ; PERNR ; SEQNR ; ABART ; COD_EVENTO ;
      APZNR ; CNTR1 ; CNTR2 ; CNTR3 ; ALZNR ; C1ZNR ; BTZNR ; ABZNR ; V0TYP ; V0ZNR ; ZEINH ;
      MOLGA ; BETPE ; ANZHL ; BETRG

    Campos fixos  : ABART = '*', MOLGA = '37'
    Campos vazios : APZNR até ZEINH (11 campos), BETPE, ANZHL
    Campo de valor: BETRG — separador decimal vírgula

    Args:
        folha:        VACODFOLHA (usado como LGART no 558D)
        id_final:     ID destino do empregado (PERNR)
        seqnr:        sequencial (int)
        cod_evento:   código do evento FPw
        valor_evento: valor do evento (ponto → vírgula)

    Returns:
        String com os 20 campos separados por ';'
    """
    valor_fmt = str(valor_evento).replace(".", ",")

    return (
        f"{folha};"                  # LGART
        f"{id_final};"               # PERNR
        f"{str(seqnr).zfill(5)};"   # SEQNR
        f"*;"                        # ABART (fixo)
        f"{cod_evento};"             # COD_EVENTO
        f";"                         # APZNR
        f";"                         # CNTR1
        f";"                         # CNTR2
        f";"                         # CNTR3
        f";"                         # ALZNR
        f";"                         # C1ZNR
        f";"                         # BTZNR
        f";"                         # ABZNR
        f";"                         # V0TYP
        f";"                         # V0ZNR
        f";"                         # ZEINH
        f"37;"                       # MOLGA (fixo)
        f";"                         # BETPE
        f";"                         # ANZHL
        f"{valor_fmt}"               # BETRG
    )

# COMMAND ----------
# MAGIC %md ## schema_dados_ficha / schema_ptp_eventos

def schema_dados_ficha() -> StructType:
    """Retorna o schema da tabela PTP_DADOS_FICHA (Silver)."""
    return StructType([
        StructField("CRCODEMP",   StringType(),  True),
        StructField("CRMATFUNC",  StringType(),  True),
        StructField("CRANO",      StringType(),  True),
        StructField("CRCONTEUDO", StringType(),  True),
        StructField("CRFUCPF",    StringType(),  True),
    ])


def schema_ptp_eventos() -> StructType:
    """Retorna o schema da tabela PTP_EVENTOS (Silver)."""
    return StructType([
        StructField("CSSECAO",   StringType(), True),
        StructField("CSENTRADA", StringType(), True),
        StructField("CSVALOR",   StringType(), True),
    ])

# COMMAND ----------

print("✅ utils.py carregado com sucesso.")
print("   Funções disponíveis:")
_funcs = [
    "save_table(df, table)",
    "resolve_data_pagto(empresa, matfunc, dtrefer, folha, dt_admis_str)",
    "data_pagto_fabricada(empresa, data_verif_yyyymm)",
    "campos_558b(folha, ano, mes, dtini_date, dtfim_str, dt_admis_date, data_pagto_str)",
    "monta_conteudo_558b(id_final, seqnr, campos)",
    "monta_conteudo_558b_fabricado(id_final, seqnr, empresa, data_verif_yyyymm, dt_admis_date)",
    "monta_conteudo_558d(folha, id_final, seqnr, cod_evento, valor_evento)",
    "schema_dados_ficha()",
    "schema_ptp_eventos()",
]
for f in _funcs:
    print(f"   · {f}")