# Databricks notebook source
# MAGIC %md
# MAGIC # ECP — Ficha Financeira · Ordem de Execução
# MAGIC
# MAGIC ## Dependências entre notebooks
# MAGIC ```
# MAGIC Momento 1 — paralelo (sem dependência entre si)
# MAGIC     ├── ingestion/01_funciona_bronze
# MAGIC     ├── ingestion/02_valano_bronze
# MAGIC     ├── ingestion/03_ocorfunc_bronze
# MAGIC     ├── ingestion/04_datas_bronze
# MAGIC     └── ingestion/05_ptp_eventos_bronze
# MAGIC               ↓
# MAGIC Momento 2 — sequencial (aguarda todos do momento 1)
# MAGIC     └── processing/01_separacao_ids_silver
# MAGIC               ↓
# MAGIC Momento 3 — paralelo (subgrupos independentes)
# MAGIC     ├── processing/02_insercao_vp_estagiarios_empregados_silver
# MAGIC     └── processing/03_insercao_reintegrados_silver
# MAGIC               ↓
# MAGIC Momento 4 — sequencial (aguarda os dois do momento 3)
# MAGIC     └── processing/04_retificadoras_silver
# MAGIC               ↓
# MAGIC Momento 5 — sequencial
# MAGIC     └── processing/05_exportacao_558b_558d_silver
# MAGIC               ↓
# MAGIC Momento 6 — opcional (não bloqueia entrega)
# MAGIC     └── validation/layout_validation
# MAGIC ```
# MAGIC
# MAGIC ## Dependências detalhadas
# MAGIC
# MAGIC | Notebook | Depende de |
# MAGIC |---|---|
# MAGIC | `ingestion/01_funciona_bronze` | — |
# MAGIC | `ingestion/02_valano_bronze` | — |
# MAGIC | `ingestion/03_ocorfunc_bronze` | — |
# MAGIC | `ingestion/04_datas_bronze` | — |
# MAGIC | `ingestion/05_ptp_eventos_bronze` | — |
# MAGIC | `processing/01_separacao_ids_silver` | Todos os `ingestion/` |
# MAGIC | `processing/02_insercao_vp_estagiarios_empregados_silver` | `processing/01_separacao_ids_silver` |
# MAGIC | `processing/03_insercao_reintegrados_silver` | `processing/01_separacao_ids_silver` |
# MAGIC | `processing/04_retificadoras_silver` | `processing/02_...` e `processing/03_...` |
# MAGIC | `processing/05_exportacao_558b_558d_silver` | `processing/04_retificadoras_silver` |
# MAGIC | `validation/layout_validation` | `processing/05_exportacao_558b_558d_silver` |
# MAGIC