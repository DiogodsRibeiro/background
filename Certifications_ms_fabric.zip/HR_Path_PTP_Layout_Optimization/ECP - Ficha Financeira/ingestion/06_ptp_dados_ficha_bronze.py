# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/ECP - Ficha Financeira/utils/utils"

# COMMAND ----------

import time
from pyspark.sql.functions import md5, concat_ws, coalesce, col, lit
from pyspark.sql.types import StringType

# COMMAND ----------

def _fmt(s):
    if s < 60:   return f"{s:.1f}s"
    if s < 3600: return f"{int(s//60)}min {s%60:.1f}s"
    return f"{int(s//3600)}h {int((s%3600)//60)}min {s%60:.0f}s"

t0 = time.time()
print("Lendo PTP_DADOS_FICHA do Oracle...")

query = f"""
(
    SELECT
        CRCODEMP,
        CRMATFUNC,
        CRANO,
        CRCONTEUDO,
        CRFUCPF
    FROM {TBL_PTP_DADOS_FICHA_ORACLE}
) Q
"""

df = (
    spark.read.format("jdbc")
    .option("url",      ORACLE_JDBC_URL)
    .option("dbtable",  query)
    .option("user",     ORACLE_USER)
    .option("password", ORACLE_PASSWORD)
    .option("driver",   ORACLE_DRIVER)
    .load()
)

df = df.select(*[df[c].cast("string").alias(c) for c in df.columns])

print(f"Leitura concluída: {df.count():,} linhas | {_fmt(time.time()-t0)}")
display(df.limit(5))

# COMMAND ----------

save_table(df, BRONZE_PTP_DADOS_FICHA)
print(f"ptp_dados_ficha_fpw gravada | tempo total: {_fmt(time.time()-t0)}")

# COMMAND ----------

query_count = f"(SELECT COUNT(*) AS total FROM {TBL_PTP_DADOS_FICHA_ORACLE}) Q"

df_count = (
    spark.read.format("jdbc")
    .option("url",      ORACLE_JDBC_URL)
    .option("dbtable",  query_count)
    .option("user",     ORACLE_USER)
    .option("password", ORACLE_PASSWORD)
    .option("driver",   ORACLE_DRIVER)
    .load()
)

total = df_count.collect()[0]["TOTAL"]
print(f"Registros: {total:,}")