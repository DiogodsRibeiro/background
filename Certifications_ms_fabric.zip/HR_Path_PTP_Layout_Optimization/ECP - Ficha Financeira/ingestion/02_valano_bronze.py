# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/ECP - Ficha Financeira/utils/utils"

# COMMAND ----------

import time
from pyspark.sql.functions import md5, concat_ws, coalesce, col, lit
from pyspark.sql.types import StringType

# COMMAND ----------

spark.table(BRONZE_VALANO).count()

# COMMAND ----------

spark.table(BRONZE_VALANO).distinct().count()

# COMMAND ----------

VAINDPERM_CONHECIDOS = ['P', None, 'T', 'F']

def _fmt(s):
    if s < 60:   return f"{s:.1f}s"
    if s < 3600: return f"{int(s//60)}min {s%60:.1f}s"
    return f"{int(s//3600)}h {int((s%3600)//60)}min {s%60:.0f}s"

def gerar_periodos(inicio, fim):
    periodos = []
    ano, mes = int(inicio[:4]), int(inicio[4:])
    ano_fim, mes_fim = int(fim[:4]), int(fim[4:])
    while (ano, mes) <= (ano_fim, mes_fim):
        periodos.append(f"{ano}{mes:02d}")
        mes += 1
        if mes > 12:
            mes = 1
            ano += 1
    return periodos

def get_checkpoint(tabela):
    try:
        df_ckpt = spark.table(CHECKPOINT_TABLE)
        row = df_ckpt.filter(col("TABELA_DESTINO") == tabela) \
                     .orderBy(col("TS_FIM").desc()) \
                     .limit(1) \
                     .collect()
        if row:
            return str(int(row[0]["LAST_VALUE"])), row[0]["LAST_SUBVALUE"]
        return None, None
    except:
        return None, None

def set_checkpoint(tabela, last_value, last_subvalue):
    from pyspark.sql import Row
    from pyspark.sql.types import StructType, StructField, StringType, LongType, TimestampType
    from datetime import datetime

    schema = StructType([
        StructField("TABELA_DESTINO", StringType(), True),
        StructField("LAST_VALUE",     LongType(),   True),
        StructField("LAST_SUBVALUE",  StringType(), True),
        StructField("TS_FIM",         TimestampType(), True),
    ])

    df_ckpt = spark.createDataFrame([Row(
        TABELA_DESTINO = tabela,
        LAST_VALUE     = int(last_value),
        LAST_SUBVALUE  = last_subvalue,
        TS_FIM         = datetime.now()
    )], schema=schema)

    df_ckpt.write.format("delta").mode("append").saveAsTable(CHECKPOINT_TABLE)

# ── loop ─────────────────────────────────────────────────────────
t0 = time.time()
print("Lendo VALANO do Oracle (loop por período)...")

ultimo_periodo, ultimo_subvalue = get_checkpoint(BRONZE_VALANO)
print(f"Último checkpoint: {ultimo_periodo or 'nenhum'} | subvalue: {ultimo_subvalue}")

periodos = gerar_periodos(DATA_INICIO, DATA_FIM)
if ultimo_periodo:
    periodos = [p for p in periodos if p >= ultimo_periodo]

print(f"Períodos a processar: {len(periodos)} | {periodos[0]} → {periodos[-1]}")

valores = VAINDPERM_CONHECIDOS + ["NOT_IN"]

for periodo in periodos:
    for vaindperm in valores:

        if ultimo_periodo and periodo == ultimo_periodo and ultimo_subvalue:
            idx_ultimo = [str(v) for v in valores].index(str(ultimo_subvalue))
            idx_atual  = [str(v) for v in valores].index(str(vaindperm))
            if idx_atual <= idx_ultimo:
                print(f"  ⏭ {periodo} | {vaindperm} — já processado")
                continue

        if vaindperm == "NOT_IN":
            known = [f"'{v}'" for v in VAINDPERM_CONHECIDOS if v is not None]
            filtro = f"AND VAINDPERM NOT IN ({','.join(known)}) AND VAINDPERM IS NOT NULL"
        elif vaindperm is None:
            filtro = "AND VAINDPERM IS NULL"
        else:
            filtro = f"AND VAINDPERM = '{vaindperm}'"

        t1 = time.time()
        print(f"  {periodo} | {vaindperm}...")

        count_query = f"""
        (
            SELECT COUNT(*) AS CNT
            FROM {TBL_VALANO_ORACLE}
            WHERE VADTREFER  = {periodo}
              AND VACODEMP   IN ({','.join(map(str, EMPRESAS_PERMITIDAS))})
              AND VACODFOLHA IN ({','.join(map(str, FOLHAS_PERMITIDAS))})
              {filtro}
        ) Q
        """

        count_df = (
            spark.read.format("jdbc")
            .option("url",      ORACLE_JDBC_URL)
            .option("dbtable",  count_query)
            .option("user",     ORACLE_USER)
            .option("password", ORACLE_PASSWORD)
            .option("driver",   ORACLE_DRIVER)
            .load()
        )
        total = int(count_df.collect()[0]["CNT"])

        if total == 0:
            print(f"  ⏭ {periodo} | {vaindperm} — vazio")
            continue

        query = f"""
        (
            SELECT
                CAST(ROWNUM AS INTEGER) AS RN,
                VACODEMP, VACODFOLHA, VAMATFUNC, VADTREFER,
                VACODEVENT, VAINDPERM, VAPRAZO, VAREALIZAD, VAVALEVENT
            FROM {TBL_VALANO_ORACLE}
            WHERE VADTREFER  = {periodo}
              AND VACODEMP   IN ({','.join(map(str, EMPRESAS_PERMITIDAS))})
              AND VACODFOLHA IN ({','.join(map(str, FOLHAS_PERMITIDAS))})
              {filtro}
        ) Q
        """

        df = (
            spark.read.format("jdbc")
            .option("url",             ORACLE_JDBC_URL)
            .option("dbtable",         query)
            .option("user",            ORACLE_USER)
            .option("password",        ORACLE_PASSWORD)
            .option("driver",          ORACLE_DRIVER)
            .option("partitionColumn", "RN")
            .option("lowerBound",      "1")
            .option("upperBound",      str(total))
            .option("numPartitions",   "4")
            .option("fetchsize",       "10000")
            .load()
        )

        df = df.select(
            col("VACODEMP").cast("string"),
            col("VACODFOLHA").cast("string"),
            col("VAMATFUNC").cast("string"),
            col("VADTREFER").cast("string"),
            col("VACODEVENT").cast("string"),
            col("VAINDPERM").cast("string"),
            col("VAPRAZO").cast("string"),
            col("VAREALIZAD").cast("string"),
            col("VAVALEVENT").cast("string"),
        )

        colunas_hash = [coalesce(col(c).cast(StringType()), lit("")) for c in df.columns]
        df = df.withColumn("id_hash", md5(concat_ws("|", *colunas_hash)))
        df = df.select(spark.table(BRONZE_VALANO).columns)

        filtro_delete = 'IS NULL' if vaindperm is None else f"= '{vaindperm}'"
        spark.sql(f"DELETE FROM {BRONZE_VALANO} WHERE VADTREFER = '{periodo}' AND VAINDPERM {filtro_delete}")
        df.write.insertInto(BRONZE_VALANO)
        set_checkpoint(BRONZE_VALANO, periodo, str(vaindperm) if vaindperm else None)
        print(f"  ✅ {periodo} | {vaindperm} | {total:,} linhas | {_fmt(time.time()-t1)}")

print(f"\nVALANO gravada | tempo total: {_fmt(time.time()-t0)}")

# COMMAND ----------

