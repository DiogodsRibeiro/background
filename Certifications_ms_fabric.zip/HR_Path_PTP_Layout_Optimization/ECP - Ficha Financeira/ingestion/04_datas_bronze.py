# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/ECP - Ficha Financeira/utils/utils"

# COMMAND ----------

import time
from pyspark.sql.functions import md5, concat_ws, coalesce, col, lit
from pyspark.sql.types import StringType

# COMMAND ----------

def _fmt(s):
    if s < 60:   return f"{s:.1f}s"
    if s < 3600: return f"{int(s//60)}min {s%60:.1f}s"
    return f"{int(s//3600)}h {int((s%3600)//60)}min {s%60:.0f}s"

t0 = time.time()
print("Lendo DATAS do Oracle...")

query = f"""
(
    SELECT
        ROWNUM AS RN,
        DTCODEMP,
        DTCODFOLHA,
        DTDTREFER,
        DTDTPAGTO,
        DTDTINIPER,
        DTDTFINPER,
        DTCODLOT
    FROM {TBL_DATAS_ORACLE}
) Q
"""

df = (
    spark.read.format("jdbc")
    .option("url",             ORACLE_JDBC_URL)
    .option("dbtable",         query)
    .option("user",            ORACLE_USER)
    .option("password",        ORACLE_PASSWORD)
    .option("driver",          ORACLE_DRIVER)
    .option("partitionColumn", "RN")
    .option("lowerBound",      "1")
    .option("upperBound",      "5000000")
    .option("numPartitions",   "8")
    .load()
)

df = df.select(
    col("DTCODEMP").cast("string"),
    col("DTCODFOLHA").cast("string"),
    col("DTDTREFER").cast("string"),
    col("DTDTPAGTO").cast("string"),
    col("DTDTINIPER").cast("string"),
    col("DTDTFINPER").cast("string"),
    col("DTCODLOT").cast("string"),
)

colunas_hash = [coalesce(col(c).cast(StringType()), lit("")) for c in df.columns]
df = df.withColumn("id_hash", md5(concat_ws("|", *colunas_hash)))
df = df.select(spark.table(BRONZE_DATAS).columns)

df.cache()
print(f"Leitura concluída: {df.count():,} linhas | {_fmt(time.time()-t0)}")
# display(df.limit(5))

spark.sql(f"TRUNCATE TABLE {BRONZE_DATAS}")
df.write.insertInto(BRONZE_DATAS)
df.unpersist()
print(f"✅ datas_fpw gravada | tempo total: {_fmt(time.time()-t0)}")

# COMMAND ----------



# COMMAND ----------

# query_count = f"(SELECT COUNT(*) AS total FROM {TBL_DATAS_ORACLE}) Q"

# df_count = (
#     spark.read.format("jdbc")
#     .option("url",      ORACLE_JDBC_URL)
#     .option("dbtable",  query_count)
#     .option("user",     ORACLE_USER)
#     .option("password", ORACLE_PASSWORD)
#     .option("driver",   ORACLE_DRIVER)
#     .load()
# )

# total = df_count.collect()[0]["TOTAL"]
# print(f"Registros: {total:,}")