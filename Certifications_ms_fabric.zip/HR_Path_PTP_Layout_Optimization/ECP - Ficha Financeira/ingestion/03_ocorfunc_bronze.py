# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/ECP - Ficha Financeira/utils/utils"

# COMMAND ----------

import time
from pyspark.sql.functions import md5, concat_ws, coalesce, col, lit
from pyspark.sql.types import StringType

# COMMAND ----------

def _fmt(s):
    if s < 60:   return f"{s:.1f}s"
    if s < 3600: return f"{int(s//60)}min {s%60:.1f}s"
    return f"{int(s//3600)}h {int((s%3600)//60)}min {s%60:.0f}s"

t0 = time.time()
print("Lendo OCORFUNC do Oracle (push-down)...")

count_query = f"""
(
    SELECT COUNT(*) AS CNT
    FROM {TBL_OCORFUNC_ORACLE}
    WHERE OFCODOCORR IN (1001, 1004, 1019)
      AND (
          (OFCODOCORR IN (1001, 1004) AND OFDTINIOCO >= {DATA_INICIO}01 AND OFDTINIOCO <= {DATA_CORTE_MOCK})
          OR
          (OFCODOCORR = 1019 AND OFDTINIOCO <= {DATA_CORTE_MOCK})
      )
) Q
"""

count_df = (
    spark.read.format("jdbc")
    .option("url",      ORACLE_JDBC_URL)
    .option("dbtable",  count_query)
    .option("user",     ORACLE_USER)
    .option("password", ORACLE_PASSWORD)
    .option("driver",   ORACLE_DRIVER)
    .load()
)
total = int(count_df.collect()[0]["CNT"])
print(f"Total a processar: {total:,} linhas")

query = f"""
(
    SELECT
        CAST(ROWNUM AS INTEGER) AS RN,
        OFCODEMP,
        OFMATFUNC,
        OFCODOCORR,
        OFDTINIOCO,
        OFDTFINOCO,
        OFNUMDIAAX,
        OFDTAUX,
        OFINDMET13,
        OFINDABONO,
        OFNUMDIAAB,
        OFNUMPARC,
        OFDTHOMRES,
        OFCODRAIS,
        OFCODPROXS,
        OFNUMDIAFE,
        OFCODLTANT,
        OFCODCGANT,
        OFCODNVANT,
        OFOBS,
        OFOBS2,
        OFOBS3,
        OFDESCVARA,
        OFSEQUENCIA,
        OFCODFOLHA
    FROM {TBL_OCORFUNC_ORACLE}
    WHERE OFCODOCORR IN (1001, 1004, 1019)
      AND (
          (OFCODOCORR IN (1001, 1004) AND OFDTINIOCO >= {DATA_INICIO}01 AND OFDTINIOCO <= {DATA_CORTE_MOCK})
          OR
          (OFCODOCORR = 1019 AND OFDTINIOCO <= {DATA_CORTE_MOCK})
      )
) Q
"""

df = (
    spark.read.format("jdbc")
    .option("url",             ORACLE_JDBC_URL)
    .option("dbtable",         query)
    .option("user",            ORACLE_USER)
    .option("password",        ORACLE_PASSWORD)
    .option("driver",          ORACLE_DRIVER)
    .option("partitionColumn", "RN")
    .option("lowerBound",      "1")
    .option("upperBound",      str(total))
    .option("numPartitions",   "4")
    .option("fetchsize",       "10000")
    .load()
)

df = df.select(
    col("OFCODEMP").cast("string"),
    col("OFMATFUNC").cast("string"),
    col("OFCODOCORR").cast("string"),
    col("OFDTINIOCO").cast("string"),
    col("OFDTFINOCO").cast("string"),
    col("OFNUMDIAAX").cast("string"),
    col("OFDTAUX").cast("string"),
    col("OFINDMET13").cast("string"),
    col("OFINDABONO").cast("string"),
    col("OFNUMDIAAB").cast("string"),
    col("OFNUMPARC").cast("string"),
    col("OFDTHOMRES").cast("string"),
    col("OFCODRAIS").cast("string"),
    col("OFCODPROXS").cast("string"),
    col("OFNUMDIAFE").cast("string"),
    col("OFCODLTANT").cast("string"),
    col("OFCODCGANT").cast("string"),
    col("OFCODNVANT").cast("string"),
    col("OFOBS").cast("string"),
    col("OFOBS2").cast("string"),
    col("OFOBS3").cast("string"),
    col("OFDESCVARA").cast("string"),
    col("OFSEQUENCIA").cast("string"),
    col("OFCODFOLHA").cast("string"),
)

colunas_hash = [coalesce(col(c).cast(StringType()), lit("")) for c in df.columns]
df = df.withColumn("id_hash", md5(concat_ws("|", *colunas_hash)))
df = df.select(spark.table(BRONZE_OCORFUNC).columns)

spark.sql(f"TRUNCATE TABLE {BRONZE_OCORFUNC}")
df.write.insertInto(BRONZE_OCORFUNC)
print(f"✅ ocorfunc_fpw gravada | {total:,} linhas | tempo total: {_fmt(time.time()-t0)}")

# COMMAND ----------

# query_count = f"""
# (
#     SELECT COUNT(*) AS total
#     FROM {TBL_OCORFUNC_ORACLE}
#     WHERE OFCODOCORR IN (1001, 1004, 1019)
#       AND OFDTINIOCO >= {DATA_INICIO}01
#       AND OFDTINIOCO <= {DATA_CORTE_MOCK}
# ) Q
# """

# df_count = (
#     spark.read.format("jdbc")
#     .option("url",      ORACLE_JDBC_URL)
#     .option("dbtable",  query_count)
#     .option("user",     ORACLE_USER)
#     .option("password", ORACLE_PASSWORD)
#     .option("driver",   ORACLE_DRIVER)
#     .load()
# )

# total = df_count.collect()[0]["TOTAL"]
# print(f"Registros: {total:,}")