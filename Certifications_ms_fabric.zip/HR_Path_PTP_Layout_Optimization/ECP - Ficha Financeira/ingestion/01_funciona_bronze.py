# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/ECP - Ficha Financeira/utils/utils"

# COMMAND ----------

import time
from pyspark.sql.functions import md5, concat_ws, coalesce, col, lit
from pyspark.sql.types import StringType

# COMMAND ----------

def _fmt(s):
    if s < 60:   return f"{s:.1f}s"
    if s < 3600: return f"{int(s//60)}min {s%60:.1f}s"
    return f"{int(s//3600)}h {int((s%3600)//60)}min {s%60:.0f}s"

t0 = time.time()
print("Lendo FUNCIONA do Oracle (push-down)...")

query = f"""
(
    SELECT
        ROWNUM AS RN,
        FUPESSOAID,
        FUCODEMP,
        FUMATFUNC,
        FUDATAID,
        FUDTADMIS,
        FUVINCULO,
        FUCODSITU,
        FUNOMFUNC,
        FUCPF
    FROM {TBL_FUNCIONA_ORACLE}
    WHERE FUCODEMP IN ({','.join(map(str, EMPRESAS_PERMITIDAS))})
      AND FUDATAID <= {DATA_CORTE_ID}
) Q
"""

df = (
    spark.read.format("jdbc")
    .option("url",             ORACLE_JDBC_URL)
    .option("dbtable",         query)
    .option("user",            ORACLE_USER)
    .option("password",        ORACLE_PASSWORD)
    .option("driver",          ORACLE_DRIVER)
    .option("partitionColumn", "RN")
    .option("lowerBound",      "1")
    .option("upperBound",      "500000")
    .option("numPartitions",   "8")
    .load()
)

df = df.select(
    col("FUPESSOAID").cast("string"),
    col("FUCODEMP").cast("string"),
    col("FUMATFUNC").cast("string"),
    col("FUDATAID").cast("string"),
    col("FUDTADMIS").cast("string"),
    col("FUVINCULO").cast("string"),
    col("FUCODSITU").cast("string"),
    col("FUNOMFUNC").cast("string"),
    col("FUCPF").cast("string"),
)

colunas_hash = [coalesce(col(c).cast(StringType()), lit("")) for c in df.columns]
df = df.withColumn("id_hash", md5(concat_ws("|", *colunas_hash)))
df = df.select(spark.table(BRONZE_FUNCIONA).columns)

df.cache()
print(f"Leitura concluída: {df.count():,} linhas | {_fmt(time.time()-t0)}")
# display(df.limit(5))

spark.sql(f"TRUNCATE TABLE {BRONZE_FUNCIONA}")
df.write.insertInto(BRONZE_FUNCIONA)
df.unpersist()
print(f"✅ funciona gravada | tempo total: {_fmt(time.time()-t0)}")