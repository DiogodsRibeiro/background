# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/ECP - Ficha Financeira/utils/utils"

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window

# COMMAND ----------

print("─" * 60)
print("1. Distribuição de linhas por CRANO")
print("─" * 60)

stats = spark.sql(f"""
    SELECT
        CRANO,
        CASE
            WHEN CRANO IN ('100','200','300','400') THEN '558B (cabeçalho)'
            ELSE                                        '558D (corpo)'
        END                               AS tipo,
        COUNT(*)                          AS total_linhas,
        COUNT(DISTINCT CRMATFUNC)         AS total_ids,
        COUNT(DISTINCT CRFUCPF)           AS total_arquivos
    FROM {TBL_DADOS_FICHA}
    GROUP BY CRANO
    ORDER BY CRANO
""")
display(stats)

# COMMAND ----------
# MAGIC %md ## 2 · Sequenciais sem buracos

print("─" * 60)
print("2. Integridade dos sequenciais (sem buracos por empregado)")
print("─" * 60)

w_seq = Window.partitionBy("CRMATFUNC", "CRANO").orderBy(F.col("CRCODEMP").cast("int"))

df_seq = (
    spark.sql(f"""
        SELECT CRMATFUNC,
               CRANO,
               CAST(CRCODEMP AS INT) AS seqnr
        FROM {TBL_DADOS_FICHA}
        WHERE CRANO IN ('100','200','300','400')
    """)
    .withColumn("seq_esperado", F.row_number().over(w_seq))
    .withColumn("tem_buraco",   F.col("seqnr") != F.col("seq_esperado"))
)

buracos   = df_seq.filter(F.col("tem_buraco") == True)
n_buracos = buracos.count()

if n_buracos > 0:
    print(f"⚠️  {n_buracos:,} buracos encontrados:")
    display(
        buracos.select("CRMATFUNC", "CRANO", "seqnr", "seq_esperado")
               .limit(100)
    )
else:
    print("✅ Nenhum buraco. Sequenciais íntegros.")

# COMMAND ----------
# MAGIC %md ## 3 · PAYDT obrigatório (558B)
# MAGIC
# MAGIC Layout 558B — posições separadas por ';':
# MAGIC PERNR(0) ; SEQNR(1) ; PAYTY(2) ; PAYID(3) ; PAYDT(4) ; PERMO(5) ;
# MAGIC PABRJ(6) ; PABRP(7) ; FPBEG(8) ; FPEND(9) ; OCRSN(10)

print("─" * 60)
print("3. PAYDT obrigatório (558B)")
print("─" * 60)

df_558b = spark.sql(f"""
    SELECT
        CRMATFUNC,
        CRANO,
        CRCONTEUDO,
        SPLIT(CRCONTEUDO, ';')[4]  AS paydt,
        SPLIT(CRCONTEUDO, ';')[5]  AS permo,
        SPLIT(CRCONTEUDO, ';')[8]  AS fpbeg,
        SPLIT(CRCONTEUDO, ';')[9]  AS fpend,
        SPLIT(CRCONTEUDO, ';')[10] AS ocrsn
    FROM {TBL_DADOS_FICHA}
    WHERE CRANO IN ('100','200','300','400')
""")

paydt_nulos = df_558b.filter(
    F.col("paydt").isNull() | (F.trim(F.col("paydt")) == "")
)
n_paydt = paydt_nulos.count()
print(f"  PAYDT nulo/vazio : {n_paydt:,}" + (" ✅" if n_paydt == 0 else " ⚠️"))

if n_paydt > 0:
    display(paydt_nulos.select("CRMATFUNC", "CRANO", "paydt", "fpbeg", "fpend").limit(50))

# COMMAND ----------
# MAGIC %md ## 4 · FPBEG obrigatório em folhas mensais (558B)
# MAGIC
# MAGIC Para folhas com PERMO = '01' (mensais, rescisão, VP), FPBEG não pode ser vazio.

print("─" * 60)
print("4. FPBEG obrigatório em folhas mensais (558B)")
print("─" * 60)

fpbeg_nulos = df_558b.filter(
    (F.col("permo") == "01") &
    (F.col("fpbeg").isNull() | (F.trim(F.col("fpbeg")) == ""))
)
n_fpbeg = fpbeg_nulos.count()
print(f"  FPBEG nulo (permo=01): {n_fpbeg:,}" + (" ✅" if n_fpbeg == 0 else " ⚠️"))

if n_fpbeg > 0:
    display(fpbeg_nulos.select("CRMATFUNC", "CRANO", "permo", "fpbeg", "fpend").limit(50))

# COMMAND ----------
# MAGIC %md ## 5 · ABART e MOLGA (558D)
# MAGIC
# MAGIC Layout 558D — posições separadas por ';':
# MAGIC LGART(0) ; PERNR(1) ; SEQNR(2) ; ABART(3) ; COD_EVENTO(4) ;
# MAGIC APZNR(5) ; CNTR1(6) ; CNTR2(7) ; CNTR3(8) ; ALZNR(9) ; C1ZNR(10) ;
# MAGIC BTZNR(11) ; ABZNR(12) ; V0TYP(13) ; V0ZNR(14) ; ZEINH(15) ;
# MAGIC MOLGA(16) ; BETPE(17) ; ANZHL(18) ; BETRG(19)

print("─" * 60)
print("5. ABART e MOLGA (558D)")
print("─" * 60)

df_558d = spark.sql(f"""
    SELECT
        CRMATFUNC,
        CRANO,
        CRCONTEUDO,
        SPLIT(CRCONTEUDO, ';')[3]  AS abart,
        SPLIT(CRCONTEUDO, ';')[16] AS molga,
        SPLIT(CRCONTEUDO, ';')[19] AS betrg
    FROM {TBL_DADOS_FICHA}
    WHERE CRANO IN ('101','201','301','401')
""")

abart_errado = df_558d.filter(F.col("abart") != "*")
molga_errado = df_558d.filter(F.col("molga") != "37")
n_abart      = abart_errado.count()
n_molga      = molga_errado.count()

print(f"  ABART ≠ '*'  : {n_abart:,}" + (" ✅" if n_abart == 0 else " ⚠️"))
print(f"  MOLGA ≠ '37' : {n_molga:,}" + (" ✅" if n_molga == 0 else " ⚠️"))

if n_abart > 0 or n_molga > 0:
    display(
        df_558d.filter(
            (F.col("abart") != "*") | (F.col("molga") != "37")
        ).limit(50)
    )

# COMMAND ----------
# MAGIC %md ## 6 · IDs com cabeçalho 558B mas sem corpo 558D

print("─" * 60)
print("6. IDs com cabeçalho 558B mas sem linhas 558D correspondentes")
print("─" * 60)

df_header_ids = spark.sql(f"""
    SELECT DISTINCT
        CRMATFUNC,
        CRANO                        AS crano_h,
        CAST(CRANO AS INT) + 1       AS crano_d_esperado
    FROM {TBL_DADOS_FICHA}
    WHERE CRANO IN ('100','200','300','400')
""")

df_body_ids = spark.sql(f"""
    SELECT DISTINCT
        CRMATFUNC,
        CRANO AS crano_d
    FROM {TBL_DADOS_FICHA}
    WHERE CRANO IN ('101','201','301','401')
""")

sem_corpo = (
    df_header_ids
    .join(
        df_body_ids,
        (df_header_ids["CRMATFUNC"] == df_body_ids["CRMATFUNC"]) &
        (df_header_ids["crano_d_esperado"].cast("string") == df_body_ids["crano_d"]),
        "left_anti"
    )
)
n_sem_corpo = sem_corpo.count()
print(f"  IDs sem 558D : {n_sem_corpo:,}" + (" ✅" if n_sem_corpo == 0 else " ⚠️"))

if n_sem_corpo > 0:
    display(sem_corpo.limit(50))

# COMMAND ----------
# MAGIC %md ## 7 · Duplicatas de chave (CRMATFUNC, CRCODEMP, CRANO)

print("─" * 60)
print("7. Duplicatas de chave primária (CRMATFUNC, CRCODEMP, CRANO)")
print("─" * 60)

dupl = spark.sql(f"""
    SELECT CRMATFUNC, CRCODEMP, CRANO, COUNT(*) AS qtd
    FROM {TBL_DADOS_FICHA}
    GROUP BY CRMATFUNC, CRCODEMP, CRANO
    HAVING COUNT(*) > 1
""")
n_dupl = dupl.count()
print(f"  Duplicatas : {n_dupl:,}" + (" ✅" if n_dupl == 0 else " ⚠️"))

if n_dupl > 0:
    display(dupl.limit(50))

# COMMAND ----------
# MAGIC %md ## Resumo final

total_ok = all([
    n_buracos   == 0,
    n_paydt     == 0,
    n_fpbeg     == 0,
    n_abart     == 0,
    n_molga     == 0,
    n_sem_corpo == 0,
    n_dupl      == 0,
])

status = "✅  APROVADO — todos os checks passaram" if total_ok \
    else "⚠️  ATENÇÃO — há itens a revisar antes da entrega"

print(f"""
╔══════════════════════════════════════════╗
║       RESULTADO DA VALIDAÇÃO             ║
╠══════════════════════════════════════════╣
║  Buracos sequenciais  : {str(n_buracos).rjust(8)}        ║
║  PAYDT nulos          : {str(n_paydt).rjust(8)}        ║
║  FPBEG nulos (mensal) : {str(n_fpbeg).rjust(8)}        ║
║  ABART ≠ '*'          : {str(n_abart).rjust(8)}        ║
║  MOLGA ≠ '37'         : {str(n_molga).rjust(8)}        ║
║  IDs sem 558D         : {str(n_sem_corpo).rjust(8)}        ║
║  Duplicatas chave     : {str(n_dupl).rjust(8)}        ║
╠══════════════════════════════════════════╣
║  {status:<42}║
╚══════════════════════════════════════════╝
""")
```