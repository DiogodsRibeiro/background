# Databricks notebook source
# Importações
from pyspark.sql import *
from pyspark.sql.types import *
from pyspark.sql.functions import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output final 
# MAGIC _(gerado pelo time da Vale)_

# COMMAND ----------

all_files = [f.path for f in dbutils.fs.ls("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/validation_files/") 
             if f.path.endswith(".csv") and "update" not in f.path]

df_output_final = spark.read.csv(
    all_files,
    header=True,
    inferSchema=True,
    sep=","
).offset(1)

df_output_final = df_output_final.select(
    col("userid").cast(StringType()).alias("user_id"),
    col("`timeType.externalCode`").cast(StringType()).alias("timeType_externalCode"),
    col("startDate").cast(StringType()).alias("startDate"),
    col("endDate").cast(StringType()).alias("endDate"),
    col("approvalStatus").cast(StringType()).alias("approvalStatus"),
    col("quantityInDays").cast(DecimalType(22, 2)).alias("quantityInDays"),
    col("quantityInHours").cast(DecimalType(22, 2)).alias("quantityInHours"),
    col("workflowRequestId").cast(LongType()).alias("workflowRequestId"),
    col("cancellationWorkflowRequestId").cast(LongType()).alias("cancellationWorkflowRequestId"),
    col("fractionQuantity").cast(DecimalType(22, 2)).alias("fractionQuantity"),
    when(upper(trim(col("editable"))) == "TRUE", True)
     .when(upper(trim(col("editable"))) == "FALSE", False)
     .otherwise(None).cast(BooleanType()).alias("editable"),
    col("loaStartJobInfoId").cast(LongType()).alias("loaStartJobInfoId"),
    col("loaEndJobInfoId").cast(LongType()).alias("loaEndJobInfoId"),
    col("loaExpectedReturnDate").cast(StringType()).alias("loaExpectedReturnDate"),
    col("loaActualReturnDate").cast(StringType()).alias("loaActualReturnDate"),
    when(upper(trim(col("flexibleRequesting"))) == "TRUE", True)
     .when(upper(trim(col("flexibleRequesting"))) == "FALSE", False)
     .otherwise(None).cast(BooleanType()).alias("flexibleRequesting"),
    col("deductionQuantity").cast(DecimalType(22, 2)).alias("deductionQuantity"),
    col("startTime").cast(StringType()).alias("startTime"),
    col("endTime").cast(StringType()).alias("endTime"),
    when(upper(trim(col("undeterminedEndDate"))) == "TRUE", True)
     .when(upper(trim(col("undeterminedEndDate"))) == "FALSE", False)
     .otherwise(None).cast(BooleanType()).alias("undeterminedEndDate"),
    col("`recurrenceGroup.externalCode`").cast(StringType()).alias("recurrenceGroup"),
    col("displayQuantity").cast(DecimalType(22, 2)).alias("displayQuantity"),
    col("physicalStartDate").cast(DecimalType(22, 2)).alias("physicalStartDate"),
    col("physicalEndDate").cast(DecimalType(22, 2)).alias("physicalEndDate"),
    col("externalCode").cast(StringType()).alias("externalCode")
)

df_output_final = df_output_final.withColumn(
    "hash_key", 
    md5(concat_ws("||", *[coalesce(col(c).cast(StringType()), lit("")) for c in df_output_final.columns]))
).withColumn(
    "file_name", 
    regexp_extract(col("_metadata.file_path"), r"([^/]+\.csv)$", 1)
)

print(f"Total de registros: {df_output_final.count()}")
# display(df_output_final)
df_output_final.createOrReplaceTempView("df_output_final")

# COMMAND ----------

offender_rows = spark.sql(
  """
  SELECT 
    *
  FROM df_output_final
  WHERE user_id LIKE '%"%"%'
  """
)
offender_rows.createOrReplaceTempView("offender_rows")

offender_files = spark.sql(
  """
  SELECT 
    DISTINCT file_name
  FROM offender_rows
  """
)

offender_files_list = [row.file_name for row in offender_files.collect()]

print(f"Total de arquivos com erros: {len(offender_files_list)}\n")
print(f"Arquivos com erros: {offender_files_list}\n")
print(f"Total de registros com erro: {offender_rows.count()}\n")
# display(offender_rows)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extrator Ásia

# COMMAND ----------

# CARGA DAS TABELAS BASE COM ALIAS ORIGINAIS

# Arquivos de controle
df_strings = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_strings_tbl.txt", header=True, inferSchema=True, sep=";").alias("s")
df_region = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_reg_region_tbl.txt", header=True, inferSchema=True, sep=";").alias("rr")
df_conv = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_v_ptp_conv_tbl.txt", header=True, inferSchema=True, sep=";").alias("v")


# Arquivos principais
df_job = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_job.txt", header=True, inferSchema=True, sep=";").alias("j")
df_pers_data = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_pers_data_effdt.txt", header=True, inferSchema=True, sep=";").alias("ef")
df_employment = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_employment.txt", header=True, inferSchema=True, sep=";").alias("e")
df_tmp_dat = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_v_ptp_tmp_dat2.txt", header=True, inferSchema=True, sep=";").alias("x")

# PREPARAÇÃO: FILTROS E BROADCASTS

# Filtrar strings_tbl antecipadamente
df_date_ptp = df_strings.filter(
    (col("s.string_id") == "DATE_PTP")
).select(
    to_date(col("s.string_text"), "dd/MM/yyyy").alias("date_ptp")
).first()

date_ptp_value = df_date_ptp["date_ptp"]

df_ini_mov = df_strings.filter(
    (col("s.string_id") == "PTP_INI_MOV")
).select(
    to_date(col("s.string_text"), "dd/MM/yyyy").alias("ptp_ini_mov")
)

# Broadcast de tabelas pequenas
df_region_filtered = broadcast(
    df_region.filter(
        col("rr.country").isin(['MYS', 'SGP', 'ARE', 'IND', 'IDN', 'OMN', 'AUS'])
    )
)

# Filtrar conversion table para ABSENCE_ASIA
df_conv_asia = broadcast(
    df_conv.filter(col("v.v_convert_id") == "ABSENCE_ASIA")
    .withColumn(
        "action_reason_key",
        substring(col("v.descr100"), 1, 11)
    )
    .withColumn(
        "sex_indicator",
        when(substring(col("v.descr100"), 12, 1) == "|", lit(""))
        .otherwise(substring(col("v.descr100"), 12, 1))
    )
    .withColumn(
        "end_action_key",
        when(
            substring(col("v.descr100"), 12, 1) == "|",
            substring(col("v.descr100"), 17, 7)
        ).otherwise(
            substring(col("v.descr100"), 18, 7)
        )
    )
)

# PREPARAÇÃO: DADOS DE PESSOA COM SEX NORMALIZADO

# Window para pegar a maior data efetiva de pessoa
w_pers = Window.partitionBy("ef.emplid").orderBy(col("ef.effdt").desc())

df_pers_enriched = df_pers_data.withColumn(
    "rn",
    row_number().over(w_pers)
).filter(
    col("rn") == 1
).withColumn(
    "sex_normalized",
    when(trim(col("ef.sex")) == "F", lit("F"))
    .when(trim(col("ef.sex")) == "M", lit("M"))
    .otherwise(lit("X"))
).select(
    col("ef.emplid"),
    col("ef.effdt"),
    col("ef.sex"),
    col("sex_normalized")
).alias("ef")

# PREPARAÇÃO: FILTRAR TMP_DAT PARA GO_LIVE

df_tmp_filtered = df_tmp_dat.filter(
    col("x.processtype") == "GO_LIVE"
).select(
    col("x.oprid").alias("user_id"),
    col("x.vp_emplid"),
    col("x.empl_rcd")
).alias("x")

# JOIN PRINCIPAL: JOB + REGION + CONVERSION + PERSON + TMP

df_job_filtered = df_job.filter(
    col("j.effdt") <= lit(date_ptp_value)
).alias("j")

# Join job com region
df_job_region = df_job_filtered.join(
    df_region_filtered,
    col("j.reg_region") == col("rr.reg_region"),
    "inner"
)

# Join com tmp_dat
df_job_tmp = df_job_region.join(
    df_tmp_filtered,
    (col("j.emplid") == col("x.vp_emplid")) &
    (col("j.empl_rcd") == col("x.empl_rcd")),
    "inner"
)

# Join com person data
df_job_person = df_job_tmp.join(
    df_pers_enriched,
    col("j.emplid") == col("ef.emplid"),
    "inner"
)

# Criar chave de action para join com conversion
df_job_enriched = df_job_person.withColumn(
    "action_key",
    concat(lit("INI|"), col("j.action"), lit("|"), col("j.action_reason"))
)

# Join com conversion table
df_main = df_job_enriched.join(
    df_conv_asia,
    (col("action_key") == col("action_reason_key")) &
    (
        (col("sex_indicator") == "") |
        (col("sex_indicator") == col("sex_normalized"))
    ),
    "inner"
)

# Selecionar colunas importantes para os próximos passos
df_main = df_main.select(
    col("user_id"),
    col("v.v_char_to").alias("timeType_externalCode"),
    col("j.emplid").alias("emplid"),
    col("j.empl_rcd").alias("empl_rcd"),
    col("j.effdt").alias("effdt"),
    col("j.effseq").alias("effseq"),
    col("j.action").alias("action"),
    col("j.action_reason").alias("action_reason"),
    col("sex_normalized"),
    col("end_action_key")
)

# ENCONTRAR MAIOR EFFDT/EFFSEQ POR EMPLID

# Criar coluna composta para ordenação
df_main = df_main.withColumn(
    "effdt_seq_key",
    concat(
        date_format(col("effdt"), "yyyyMMdd"),
        lpad(col("effseq"), 4, "0")
    )
)

# Window para encontrar max effdt/seq
w_max = Window.partitionBy(
    col("emplid"),
    col("empl_rcd")
).orderBy(col("effdt_seq_key").desc())

df_main = df_main.withColumn(
    "max_effdt_seq",
    first(col("effdt_seq_key")).over(w_max)
).filter(
    col("effdt_seq_key") == col("max_effdt_seq")
)

# ENCONTRAR DATA DE FIM (PRÓXIMA ACTION)

# Preparar segunda conversion table para end actions
df_conv_end = df_conv_asia.select(
    col("end_action_key"),
    col("sex_indicator").alias("sex_ind_end")
).alias("cv2")

# Self-join de job para encontrar próxima action
df_job_next = df_job.select(
    col("j.emplid").alias("next_emplid"),
    col("j.empl_rcd").alias("next_empl_rcd"),
    col("j.effdt").alias("next_effdt"),
    col("j.effseq").alias("next_effseq"),
    col("j.action").alias("next_action"),
    col("j.action_reason").alias("next_action_reason"),
    concat(
        date_format(col("j.effdt"), "yyyyMMdd"),
        lpad(col("j.effseq"), 4, "0")
    ).alias("next_effdt_seq_key")
).alias("r")

# Join para encontrar próximas actions
df_with_next = df_main.join(
    df_job_next,
    (col("emplid") == col("next_emplid")) &
    (col("empl_rcd") == col("next_empl_rcd")) &
    (col("next_effdt_seq_key") > col("effdt_seq_key")),
    "left"
)

# Criar chave para validar se é action de fim
df_with_next = df_with_next.withColumn(
    "next_action_key",
    concat(col("next_action"), lit("|"), col("next_action_reason"))
)

# Join com conversion end para validar
df_with_end_validated = df_with_next.join(
    df_conv_end,
    (col("next_action_key") == col("cv2.end_action_key")) &
    (
        (col("cv2.sex_ind_end") == "") |
        (col("cv2.sex_ind_end") == col("sex_normalized"))
    ),
    "left"
)

# Window para pegar a menor data de fim válida
w_min_end = Window.partitionBy(
    col("emplid"),
    col("empl_rcd"),
    col("effdt_seq_key")
).orderBy(col("next_effdt").asc())

df_with_end_date = df_with_end_validated.withColumn(
    "rn_end",
    row_number().over(w_min_end)
).filter(
    (col("rn_end") == 1) | col("next_effdt").isNull()
).withColumn(
    "endDate_calc",
    when(
        col("next_effdt").isNotNull(),
        when(
            col("next_effdt") == col("effdt"),
            date_add(col("next_effdt"), 1)
        ).otherwise(col("next_effdt"))
    )
)

# VERIFICAÇÃO: NÃO PODE HAVER OUTRA ACTION APÓS

df_job_after = df_job.filter(
    col("j.effdt") <= lit(date_ptp_value)
).select(
    col("j.emplid").alias("after_emplid"),
    col("j.empl_rcd").alias("after_empl_rcd"),
    col("j.action").alias("after_action"),
    col("j.action_reason").alias("after_action_reason"),
    concat(
        date_format(col("j.effdt"), "yyyyMMdd"),
        lpad(col("j.effseq"), 4, "0")
    ).alias("after_effdt_seq_key")
).alias("b")

# Join para verificar se existe action posterior
df_check_after = df_with_end_date.join(
    df_job_after,
    (col("emplid") == col("after_emplid")) &
    (col("empl_rcd") == col("after_empl_rcd")) &
    (col("after_effdt_seq_key") > col("effdt_seq_key")) &
    (col("after_effdt_seq_key") <= 
     concat(date_format(lit(date_ptp_value), "yyyyMMdd"), lit("9999"))),
    "left"
).withColumn(
    "after_action_key",
    concat(lit("INI|"), col("after_action"), lit("|"), col("after_action_reason"))
)

# Join com conversion para validar action posterior
df_conv_after = df_conv_asia.select(
    col("action_reason_key").alias("after_conv_key"),
    col("sex_indicator").alias("sex_ind_after")
).alias("cv3")

df_final_check = df_check_after.join(
    df_conv_after,
    (col("after_action_key") == col("cv3.after_conv_key")) &
    (
        (col("cv3.sex_ind_after") == "") |
        (col("cv3.sex_ind_after") == col("sex_normalized"))
    ),
    "left"
).filter(
    col("cv3.after_conv_key").isNull()  # Não deve existir action posterior válida
)

# SELEÇÃO FINAL E CÁLCULOS

df_base_result = df_final_check.select(
    col("user_id"),
    col("timeType_externalCode"),
    date_format(col("effdt"), "dd/MM/yyyy").alias("startDate"),
    coalesce(
        date_format(date_sub(col("endDate_calc"), 1), "dd/MM/yyyy"),
        lit("")
    ).alias("endDate"),
    col("emplid"),
    col("empl_rcd")
).distinct()

# Join com employment
df_with_employment = df_base_result.join(
    df_employment.select(
        col("e.emplid").alias("e_emplid"),
        col("e.hire_dt"),
        col("e.rehire_dt")
    ),
    col("emplid") == col("e_emplid"),
    "inner"
)

# Join com ini_mov para filtro final
df_final_filtered = df_with_employment.crossJoin(df_ini_mov).filter(
    (
        coalesce(
            to_date(col("endDate"), "dd/MM/yyyy"),
            col("ptp_ini_mov")
        ) >= col("ptp_ini_mov")
    ) &
    (
        coalesce(
            col("e.rehire_dt"),
            coalesce(
                col("e.hire_dt"),
                to_date(col("startDate"), "dd/MM/yyyy")
            )
        ) <= to_date(col("startDate"), "dd/MM/yyyy")
    )
)

# CÁLCULOS FINAIS E FORMATAÇÃO

df_result = df_final_filtered.select(
    col("user_id"),
    col("timeType_externalCode"),
    col("startDate"),
    col("endDate"),
    lit("APPROVED").alias("approvalStatus"),
    lit("").alias("quantityInDays"),
    lit("").alias("quantityInHours"),
    lit("").alias("workflowRequestId"),
    lit("").alias("cancellationWorkflowRequestId"),
    coalesce(
        datediff(
            to_date(col("endDate"), "dd/MM/yyyy"),
            to_date(col("startDate"), "dd/MM/yyyy")
        ) + 1,
        lit(0)
    ).alias("fractionQuantity"),
    lit("TRUE").alias("editable"),
    lit("").alias("loaStartJobInfoId"),
    lit("").alias("loaEndJobInfoId"),
    coalesce(
        date_format(
            date_add(to_date(col("endDate"), "dd/MM/yyyy"), 1),
            "dd/MM/yyyy"
        ),
        date_format(
            add_months(to_date(col("startDate"), "dd/MM/yyyy"), 24),
            "dd/MM/yyyy"
        )
    ).alias("loaExpectedReturnDate"),
    coalesce(trim(col("endDate")), lit("")).alias("loaActualReturnDate"),
    lit("FALSE").alias("flexibleRequesting"),
    lit("").alias("deductionQuantity"),
    lit("").alias("startTime"),
    lit("").alias("endTime"),
    lit("FALSE").alias("undeterminedEndDate"),
    lit("").alias("recurrenceGroup"),
    lit("").alias("displayQuantity"),
    lit("").alias("physicalStartDate"),
    lit("").alias("physicalEndDate"),
    lit("").alias("externalCode")
).orderBy(
    lpad(col("user_id"), 15, "0"),
    to_date(col("startDate"), "dd/MM/yyyy")
)

# Mapeamento de colunas com suas respectivas tipagens e tamanhos máximos, baseado na especificação do SAP SuccessFactors
df_with_types = df_result \
    .withColumn("user_id", col("user_id").cast(StringType())) \
    .withColumn("user_id", substring(col("user_id"), 1, 40)) \
    .withColumn("timeType_externalCode", col("timeType_externalCode").cast(StringType())) \
    .withColumn("timeType_externalCode", substring(col("timeType_externalCode"), 1, 38)) \
    .withColumn("startDate", col("startDate").cast(StringType())) \
    .withColumn("endDate", col("endDate").cast(StringType())) \
    .withColumn("approvalStatus", substring(col("approvalStatus"), 1, 128)) \
    .withColumn("quantityInDays", 
                when(col("quantityInDays") == "", lit(None))
                 .otherwise(col("quantityInDays").cast(DecimalType(22, 2)))) \
    .withColumn("quantityInHours", 
                when(col("quantityInHours") == "", lit(None))
                 .otherwise(col("quantityInHours").cast(DecimalType(22, 2)))) \
    .withColumn("workflowRequestId", 
                when(col("workflowRequestId") == "", lit(None))
                 .otherwise(col("workflowRequestId").cast(LongType()))) \
    .withColumn("cancellationWorkflowRequestId", 
                when(col("cancellationWorkflowRequestId") == "", lit(None))
                 .otherwise(col("cancellationWorkflowRequestId").cast(LongType()))) \
    .withColumn("fractionQuantity", col("fractionQuantity").cast(DecimalType(22, 2))) \
    .withColumn("editable", 
                when(upper(col("editable")) == "TRUE", lit(True))
                 .when(upper(col("editable")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("loaStartJobInfoId", 
                when(col("loaStartJobInfoId") == "", lit(None))
                 .otherwise(col("loaStartJobInfoId").cast(LongType()))) \
    .withColumn("loaEndJobInfoId", 
                when(col("loaEndJobInfoId") == "", lit(None))
                 .otherwise(col("loaEndJobInfoId").cast(LongType()))) \
    .withColumn("loaExpectedReturnDate", col("loaExpectedReturnDate").cast(StringType())) \
    .withColumn("loaActualReturnDate", col("loaActualReturnDate").cast(StringType())) \
    .withColumn("flexibleRequesting", 
                when(upper(col("flexibleRequesting")) == "TRUE", lit(True))
                 .when(upper(col("flexibleRequesting")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("deductionQuantity", 
                when(col("deductionQuantity") == "", lit(None))
                 .otherwise(col("deductionQuantity").cast(DecimalType(22, 2)))) \
    .withColumn("startTime", substring(col("startTime"), 1, 21)) \
    .withColumn("endTime", substring(col("endTime"), 1, 21)) \
    .withColumn("undeterminedEndDate", 
                when(upper(col("undeterminedEndDate")) == "TRUE", lit(True))
                 .when(upper(col("undeterminedEndDate")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("recurrenceGroup", substring(col("recurrenceGroup"), 1, 38)) \
    .withColumn("displayQuantity", 
                when(col("displayQuantity") == "", lit(None))
                 .otherwise(col("displayQuantity").cast(DecimalType(22, 2)))) \
    .withColumn("physicalStartDate", 
                when(col("physicalStartDate") == "", lit(None))
                 .otherwise(col("physicalStartDate").cast(DecimalType(22, 2)))) \
    .withColumn("physicalEndDate", 
                when(col("physicalEndDate") == "", lit(None))
                 .otherwise(col("physicalEndDate").cast(DecimalType(22, 2)))) \
    .withColumn("externalCode", substring(col("externalCode"), 1, 128)) \
    .withColumn("hash_key", md5(concat_ws("||", *[coalesce(col(c).cast(StringType()), lit("")) for c in df_result.columns])))

# Selecionar colunas finais e ordernar
df_output_extrator_asia = df_with_types.select(
    "user_id",
    "timeType_externalCode",
    "startDate",
    "endDate",
    "approvalStatus",
    "quantityInDays",
    "quantityInHours",
    "workflowRequestId",
    "cancellationWorkflowRequestId",
    "fractionQuantity",
    "editable",
    "loaStartJobInfoId",
    "loaEndJobInfoId",
    "loaExpectedReturnDate",
    "loaActualReturnDate",
    "flexibleRequesting",
    "deductionQuantity",
    "startTime",
    "endTime",
    "undeterminedEndDate",
    "recurrenceGroup",
    "displayQuantity",
    "physicalStartDate",
    "physicalEndDate",
    "externalCode",
    "hash_key"
).distinct() \
 .orderBy(
     lpad(col("user_id"), 15, "0"),
     to_date(col("startDate"), "dd/MM/yyyy")
 )

print(f"Total de registros: {df_output_extrator_asia.count()}")
# display(df_output_extrator_asia)
# df_output.write.mode("overwrite").saveAsTable("silver.extrator_asia")
df_output_extrator_asia.createOrReplaceTempView("df_output_extrator_asia")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extrator CAN/USA/UK

# COMMAND ----------

# Tabelas de controle
df_strings = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_strings_tbl.txt", header=True, inferSchema=True, sep=";").alias("s")
df_reg_region = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_reg_region_tbl.txt", header=True, inferSchema=True, sep=";").alias("rr")
df_conv_tbl = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_v_ptp_conv_tbl.txt", header=True, inferSchema=True, sep=";").alias("v")


# Tabelas principais
df_job = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_job.txt", header=True, inferSchema=True, sep=";").alias("j")
df_pers_data = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_pers_data_effdt.txt", header=True, inferSchema=True, sep=";").alias("ef")
df_employment = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_employment.txt", header=True, inferSchema=True, sep=";").alias("e")
df_tmp_dat2 = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_v_ptp_tmp_dat2.txt", header=True, inferSchema=True, sep=";").alias("x")

# FILTROS INICIAIS E CACHE DE TABELAS PEQUENAS

# Filtrar e cachear strings_tbl (tabela pequena, usada múltiplas vezes)
'''
df_strings_filtered = df_strings.filter(
    (col("program_id") == "V_PTP_DT")
).cache()
'''

# Obter data de referência PTP
date_ptp = df_strings.filter(
    col("string_id") == "DATE_PTP"
).select(to_date(col("string_text"), "dd/MM/yyyy").alias("date_ptp")).first()["date_ptp"]

# Obter data de início de movimento
ptp_ini_mov = df_strings.filter(
    col("string_id") == "PTP_INI_MOV"
).select(to_date(col("string_text"), "dd/MM/yyyy").alias("ptp_ini_mov")).first()["ptp_ini_mov"]

# Broadcast de tabelas pequenas
df_strings = broadcast(df_strings)

# Filtrar conversion table para ABSENCE_CAN_USA_UK
df_conv_absence = df_conv_tbl.filter(
    col("v_convert_id") == "ABSENCE_CAN_USA_UK"
).cache()

# Separar conversion tables por tipo
df_conv_position = df_conv_absence.filter(
    substring(col("descr100"), 1, 12) == "INI_POSITION"
).withColumn("position_nbr", substring(col("descr100"), 14, 8)) \
 .withColumn("end_action_reason", substring(col("descr100"), 27, 7))

df_conv_ini = df_conv_absence.filter(
    substring(col("descr100"), 1, 4) == "INI|"
).withColumn("action_reason_key", substring(col("descr100"), 5, 7)) \
 .withColumn("gender_flag", substring(col("descr100"), 12, 1)) \
 .withColumn("end_action_offset", 
             when(substring(col("descr100"), 12, 1) == "|", 17).otherwise(18)) \
 .withColumn("end_action_reason", 
             expr("substring(descr100, end_action_offset, 7)"))

# Filtrar regiões para CAN, USA, GBR
df_reg_region_filtered = broadcast(
    df_reg_region.filter(col("country").isin("CAN", "USA", "GBR"))
)

# Filtrar tmp_dat2 para GO_LIVE
df_tmp_dat2_filtered = df_tmp_dat2.filter(
    col("processtype") == "GO_LIVE"
)

# Preparação dO DataFrame df_job com chave composta
df_job_prepared = df_job \
    .withColumn("job_key", 
                concat(
                    lpad(date_format(col("effdt"), "yyyyMMdd"), 8, "0"),
                    lpad(col("effseq").cast("string"), 4, "0")
                )) \
    .withColumn("action_reason_key", 
                concat(col("action"), lit("|"), col("action_reason"))) \
    .filter(col("effdt") <= lit(date_ptp))

# Preparação dos dados de pessoa com "Gender Decode"
df_pers_prepared = df_pers_data \
    .withColumn("gender_decoded", 
                when(trim(col("sex")) == "F", "F")
                 .when(trim(col("sex")) == "M", "M")
                 .otherwise("X"))

# Window para pegar max effdt por emplid
window_pers = Window.partitionBy("emplid").orderBy(col("effdt").desc())

df_pers_with_rank = df_pers_prepared \
    .withColumn("rank", row_number().over(window_pers)) \
    .filter(col("rank") == 1) \
    .select("emplid", "effdt", "sex", "gender_decoded")

# UNION PARTE 1: INI_POSITION

# Join base para UNION 1 - criar com colunas explícitas para evitar ambiguidade
df_union1_base = df_job_prepared \
    .select(
        col("emplid").alias("j_emplid"),
        col("empl_rcd").alias("j_empl_rcd"),
        col("job_key").alias("j_job_key"),
        col("effdt").alias("j_effdt"),
        col("position_nbr").alias("j_position_nbr"),
        col("action_reason_key").alias("j_action_reason_key"),
        col("reg_region").alias("j_reg_region")
    ) \
    .join(
        df_conv_position.select(
            col("position_nbr").alias("v_position_nbr"),
            col("v_char_to").alias("v_char_to"),
            col("end_action_reason").alias("v_end_action_reason")
        ),
        col("j_position_nbr") == col("v_position_nbr"), 
        "inner"
    ) \
    .join(
        df_reg_region_filtered.select(
            col("reg_region").alias("rr_reg_region"),
            col("country").alias("rr_country")
        ),
        col("j_reg_region") == col("rr_reg_region"), 
        "inner"
    ) \
    .join(
        df_tmp_dat2_filtered.select(
            col("vp_emplid").alias("x_vp_emplid"),
            col("empl_rcd").alias("x_empl_rcd"),
            col("oprid").alias("x_oprid")
        ),
        (col("j_emplid") == col("x_vp_emplid")) & 
        (col("j_empl_rcd") == col("x_empl_rcd")), 
        "inner"
    ) \
    .join(
        df_pers_with_rank.select(
            col("emplid").alias("ef_emplid"),
            col("gender_decoded").alias("ef_gender_decoded")
        ),
        col("j_emplid") == col("ef_emplid"), 
        "inner"
    )

# Subquery para encontrar próxima data de término (min effdt futuro) - UNION 1
df_job_for_end_1 = df_job_prepared \
    .select(
        col("emplid").alias("r_emplid"),
        col("empl_rcd").alias("r_empl_rcd"),
        col("job_key").alias("r_job_key"),
        col("effdt").alias("r_effdt"),
        col("effseq").alias("r_effseq"),
        col("action_reason_key").alias("r_action_reason_key")
    ) \
    .join(
        df_conv_position.select(
            col("end_action_reason").alias("v2_end_action_reason")
        ).distinct(),
        col("r_action_reason_key") == col("v2_end_action_reason"), 
        "inner"
    )

window_next_job_1 = Window.partitionBy("base_emplid", "base_empl_rcd", "base_job_key") \
    .orderBy("r_effdt", "r_effseq")

df_end_dates_1 = df_union1_base \
    .select(
        col("j_emplid").alias("base_emplid"),
        col("j_empl_rcd").alias("base_empl_rcd"),
        col("j_job_key").alias("base_job_key"),
        col("j_effdt").alias("base_effdt")
    ).distinct() \
    .join(df_job_for_end_1,
          (col("base_emplid") == col("r_emplid")) &
          (col("base_empl_rcd") == col("r_empl_rcd")) &
          (col("r_job_key") > col("base_job_key")),
          "left") \
    .withColumn("adjusted_effdt",
                when(col("r_effdt") == col("base_effdt"), 
                       date_add(col("r_effdt"), 1))
                 .otherwise(col("r_effdt"))) \
    .withColumn("rank", row_number().over(window_next_job_1)) \
    .filter(col("rank") == 1) \
    .select(
        col("base_emplid"),
        col("base_job_key"),
        date_sub(col("adjusted_effdt"), 1).alias("end_date")
    )

# Aplicar NOT EXISTS conditions para UNION 1

# NOT EXISTS 1: Não pode ter job futuro com position diferente no conv_position
df_ne1_jobs = df_job_prepared \
    .select(
        col("emplid").alias("b1_emplid"),
        col("empl_rcd").alias("b1_empl_rcd"),
        col("job_key").alias("b1_job_key"),
        col("position_nbr").alias("b1_position_nbr")
    ) \
    .join(
        df_conv_position.select(
            col("position_nbr").alias("cv21_position_nbr")
        ).distinct(),
        col("b1_position_nbr") == col("cv21_position_nbr"), 
        "inner"
    )

df_union1_step1 = df_union1_base \
    .join(df_ne1_jobs,
          (col("j_emplid") == col("b1_emplid")) &
          (col("j_empl_rcd") == col("b1_empl_rcd")) &
          (col("b1_job_key") > col("j_job_key")) &
          (col("b1_position_nbr") != col("j_position_nbr")),
          "left_anti")

# NOT EXISTS 2: Não pode ter job futuro com INI action_reason no conv_ini
df_ne2_jobs = df_job_prepared \
    .select(
        col("emplid").alias("b2_emplid"),
        col("empl_rcd").alias("b2_empl_rcd"),
        col("job_key").alias("b2_job_key"),
        col("action_reason_key").alias("b2_action_reason_key")
    ) \
    .join(
        df_conv_ini.select(
            col("action_reason_key").alias("cv22_action_reason_key"),
            col("gender_flag").alias("cv22_gender_flag")
        ),
        col("b2_action_reason_key") == col("cv22_action_reason_key"),
        "inner"
    ) \
    .join(
        df_pers_with_rank.select(
            col("emplid").alias("ef2_emplid"),
            col("gender_decoded").alias("ef2_gender")
        ),
        col("b2_emplid") == col("ef2_emplid"),
        "inner"
    ) \
    .filter(
        coalesce(
            when(col("cv22_gender_flag") == "|", lit("")),
            col("ef2_gender")
        ) == col("ef2_gender")
    ) \
    .select("b2_emplid", "b2_empl_rcd", "b2_job_key")

df_union1_step2 = df_union1_step1 \
    .join(df_ne2_jobs,
          (col("j_emplid") == col("b2_emplid")) &
          (col("j_empl_rcd") == col("b2_empl_rcd")) &
          (col("b2_job_key") > col("j_job_key")),
          "left_anti")

# NOT EXISTS 3: Não pode ter job >= com end_action_reason da position
df_ne3_jobs = df_job_prepared \
    .select(
        col("emplid").alias("j5_emplid"),
        col("job_key").alias("j5_job_key"),
        col("position_nbr").alias("j5_position_nbr"),
        col("action_reason_key").alias("j5_action_reason_key")
    ) \
    .join(
        df_conv_position.select(
            col("position_nbr").alias("v5_position_nbr"),
            col("end_action_reason").alias("v5_end_action_reason")
        ),
        (col("j5_action_reason_key") == col("v5_end_action_reason")),
        "inner"
    ) \
    .select("j5_emplid", "j5_job_key", "v5_position_nbr")

df_union1_filtered = df_union1_step2 \
    .join(df_ne3_jobs,
          (col("j_emplid") == col("j5_emplid")) &
          (col("j5_job_key") >= col("j_job_key")) &
          (col("v5_position_nbr") == col("j_position_nbr")),
          "left_anti")

# Juntar com end_dates e selecionar colunas finais
df_union1 = df_union1_filtered \
    .join(df_end_dates_1,
          (col("j_emplid") == col("base_emplid")) &
          (col("j_job_key") == col("base_job_key")),
          "left") \
    .select(
        col("j_emplid").alias("emplid"),
        col("x_oprid").alias("user_id"),
        col("v_char_to").alias("timeType_externalCode"),
        date_format(col("j_effdt"), "dd/MM/yyyy").alias("startDate"),
        coalesce(
            date_format(col("end_date"), "dd/MM/yyyy"),
            lit("")
        ).alias("endDate")
    )

# UNION PARTE 2: INI|action|action_reason
df_union2_base = df_job_prepared \
    .select(
        col("emplid").alias("j_emplid"),
        col("empl_rcd").alias("j_empl_rcd"),
        col("job_key").alias("j_job_key"),
        col("effdt").alias("j_effdt"),
        col("position_nbr").alias("j_position_nbr"),
        col("action_reason_key").alias("j_action_reason_key"),
        col("reg_region").alias("j_reg_region"),
        col("action").alias("j_action"),
        col("action_reason").alias("j_action_reason")
    ) \
    .join(
        df_conv_ini.select(
            col("action_reason_key").alias("v_action_reason_key"),
            col("v_char_to").alias("v_char_to"),
            col("gender_flag").alias("v_gender_flag"),
            col("end_action_reason").alias("v_end_action_reason")
        ),
        col("j_action_reason_key") == col("v_action_reason_key"),
        "inner"
    ) \
    .join(
        df_reg_region_filtered.select(
            col("reg_region").alias("rr_reg_region")
        ),
        col("j_reg_region") == col("rr_reg_region"), 
        "inner"
    ) \
    .join(
        df_tmp_dat2_filtered.select(
            col("vp_emplid").alias("x_vp_emplid"),
            col("empl_rcd").alias("x_empl_rcd"),
            col("oprid").alias("x_oprid")
        ),
        (col("j_emplid") == col("x_vp_emplid")) & 
        (col("j_empl_rcd") == col("x_empl_rcd")), 
        "inner"
    ) \
    .join(
        df_pers_with_rank.select(
            col("emplid").alias("ef_emplid"),
            col("gender_decoded").alias("ef_gender_decoded")
        ),
        (col("j_emplid") == col("ef_emplid")) &
        (coalesce(
            when(col("v_gender_flag") == "|", lit("")),
            col("ef_gender_decoded")
        ) == col("ef_gender_decoded")),
        "inner"
    )

# Subquery para end dates da UNION 2
df_job_for_end_2 = df_job_prepared \
    .select(
        col("emplid").alias("r_emplid"),
        col("empl_rcd").alias("r_empl_rcd"),
        col("job_key").alias("r_job_key"),
        col("effdt").alias("r_effdt"),
        col("effseq").alias("r_effseq"),
        col("action_reason_key").alias("r_action_reason_key")
    ) \
    .join(
        df_conv_ini.select(
            col("end_action_reason").alias("v2_end_action_reason"),
            col("gender_flag").alias("v2_gender_flag")
        ),
        col("r_action_reason_key") == col("v2_end_action_reason"),
        "inner"
    ) \
    .join(
        df_pers_with_rank.select(
            col("emplid").alias("ef2_emplid"),
            col("gender_decoded").alias("ef2_gender")
        ),
        (col("r_emplid") == col("ef2_emplid")),
        "inner"
    ) \
    .filter(
        coalesce(
            when(col("v2_gender_flag") == "|", lit("")),
            col("ef2_gender")
        ) == col("ef2_gender")
    )

window_next_job_2 = Window.partitionBy("base_emplid", "base_empl_rcd", "base_job_key") \
    .orderBy("r_effdt", "r_effseq")

df_end_dates_2 = df_union2_base \
    .select(
        col("j_emplid").alias("base_emplid"),
        col("j_empl_rcd").alias("base_empl_rcd"),
        col("j_job_key").alias("base_job_key"),
        col("j_effdt").alias("base_effdt"),
        col("ef_gender_decoded").alias("base_gender")
    ).distinct() \
    .join(df_job_for_end_2,
          (col("base_emplid") == col("r_emplid")) &
          (col("base_empl_rcd") == col("r_empl_rcd")) &
          (col("r_job_key") > col("base_job_key")),
          "left") \
    .withColumn("adjusted_effdt",
                when(col("r_effdt") == col("base_effdt"), 
                       date_add(col("r_effdt"), 1))
                 .otherwise(col("r_effdt"))) \
    .withColumn("rank", row_number().over(window_next_job_2)) \
    .filter(col("rank") == 1) \
    .select(
        col("base_emplid"),
        col("base_job_key"),
        date_sub(col("adjusted_effdt"), 1).alias("end_date")
    )

# Aplicar NOT EXISTS para UNION 2
df_ne2_1_jobs = df_job_prepared \
    .select(
        col("emplid").alias("b_emplid"),
        col("empl_rcd").alias("b_empl_rcd"),
        col("job_key").alias("b_job_key"),
        col("action_reason_key").alias("b_action_reason_key")
    ) \
    .join(
        df_conv_ini.select(
            col("action_reason_key").alias("cv2_action_reason_key"),
            col("gender_flag").alias("cv2_gender_flag")
        ),
        col("b_action_reason_key") == col("cv2_action_reason_key"),
        "inner"
    ) \
    .join(
        df_pers_with_rank.select(
            col("emplid").alias("ef_cv2_emplid"),
            col("gender_decoded").alias("ef_cv2_gender")
        ),
        col("b_emplid") == col("ef_cv2_emplid"),
        "inner"
    ) \
    .filter(
        coalesce(
            when(col("cv2_gender_flag") == "|", lit("")),
            col("ef_cv2_gender")
        ) == col("ef_cv2_gender")
    ) \
    .select("b_emplid", "b_empl_rcd", "b_job_key")

df_union2_filtered = df_union2_base \
    .join(df_ne2_1_jobs,
          (col("j_emplid") == col("b_emplid")) &
          (col("j_empl_rcd") == col("b_empl_rcd")) &
          (col("b_job_key") > col("j_job_key")),
          "left_anti")

# Join com end_dates e selecionar colunas finais
df_union2 = df_union2_filtered \
    .join(df_end_dates_2,
          (col("j_emplid") == col("base_emplid")) &
          (col("j_job_key") == col("base_job_key")),
          "left") \
    .select(
        col("j_emplid").alias("emplid"),
        col("x_oprid").alias("user_id"),
        col("v_char_to").alias("timeType_externalCode"),
        date_format(col("j_effdt"), "dd/MM/yyyy").alias("startDate"),
        coalesce(
            date_format(col("end_date"), "dd/MM/yyyy"),
            lit("")
        ).alias("endDate")
    )

# Union das duas partes
df_combined = df_union1.union(df_union2)

# Join com strings e employment + cálculos finais
df_final = df_combined \
    .join(
        df_strings.filter(
            (col("string_id") == "PTP_INI_MOV")
        ).select(
            col("string_text").alias("s_string_text")
        ),
        lit(True),  # cross join
        "inner"
    ) \
    .join(
        df_employment.select(
            col("emplid").alias("e_emplid"),
            col("rehire_dt").alias("e_rehire_dt"),
            col("hire_dt").alias("e_hire_dt")
        ),
        col("emplid") == col("e_emplid"),
        "inner"
    ) \
    .filter(
        coalesce(
            to_date(col("endDate"), "dd/MM/yyyy"),
            to_date(col("s_string_text"), "dd/MM/yyyy")
        ) >= to_date(col("s_string_text"), "dd/MM/yyyy")
    ) \
    .filter(
        coalesce(
            col("e_rehire_dt"),
            coalesce(
                col("e_hire_dt"),
                to_date(col("startDate"), "dd/MM/yyyy")
            )
        ) <= to_date(col("startDate"), "dd/MM/yyyy")
    )

# Cálculos das colunas finais
df_result = df_final \
    .withColumn("approvalStatus", lit("APPROVED")) \
    .withColumn("quantityInDays", lit("")) \
    .withColumn("quantityInHours", lit("")) \
    .withColumn("workflowRequestId", lit("")) \
    .withColumn("cancellationWorkflowRequestId", lit("")) \
    .withColumn("fractionQuantity",
                coalesce(
                    datediff(
                        to_date(col("endDate"), "dd/MM/yyyy"),
                        to_date(col("startDate"), "dd/MM/yyyy")
                    ) + 1,
                    lit(0)
                )) \
    .withColumn("editable", lit("TRUE")) \
    .withColumn("loaStartJobInfoId", lit("")) \
    .withColumn("loaEndJobInfoId", lit("")) \
    .withColumn("loaExpectedReturnDate",
                coalesce(
                    date_format(
                        date_add(to_date(col("endDate"), "dd/MM/yyyy"), 1),
                        "dd/MM/yyyy"
                    ),
                    date_format(
                        add_months(to_date(col("startDate"), "dd/MM/yyyy"), 24),
                        "dd/MM/yyyy"
                    )
                )) \
    .withColumn("loaActualReturnDate",
                coalesce(
                    date_format(
                        date_add(to_date(col("endDate"), "dd/MM/yyyy"), 1),
                        "dd/MM/yyyy"
                    ),
                    lit("")
                )) \
    .withColumn("flexibleRequesting", lit("FALSE")) \
    .withColumn("deductionQuantity", lit("")) \
    .withColumn("startTime", lit("")) \
    .withColumn("endTime", lit("")) \
    .withColumn("undeterminedEndDate", lit("FALSE")) \
    .withColumn("recurrenceGroup", lit("")) \
    .withColumn("displayQuantity", lit("")) \
    .withColumn("physicalStartDate", lit("")) \
    .withColumn("physicalEndDate", lit("")) \
    .withColumn("externalCode", lit(""))

# Mapeamento de colunas com suas respectivas tipagens e tamanhos máximos, baseado na especificação do SAP SuccessFactors
df_with_types = df_result \
    .withColumn("user_id", col("user_id").cast(StringType())) \
    .withColumn("user_id", substring(col("user_id"), 1, 40)) \
    .withColumn("timeType_externalCode", col("timeType_externalCode").cast(StringType())) \
    .withColumn("timeType_externalCode", substring(col("timeType_externalCode"), 1, 38)) \
    .withColumn("startDate", col("startDate").cast(StringType())) \
    .withColumn("endDate", col("endDate").cast(StringType())) \
    .withColumn("approvalStatus", substring(col("approvalStatus"), 1, 128)) \
    .withColumn("quantityInDays", 
                when(col("quantityInDays") == "", lit(None))
                 .otherwise(col("quantityInDays").cast(DecimalType(22, 2)))) \
    .withColumn("quantityInHours", 
                when(col("quantityInHours") == "", lit(None))
                 .otherwise(col("quantityInHours").cast(DecimalType(22, 2)))) \
    .withColumn("workflowRequestId", 
                when(col("workflowRequestId") == "", lit(None))
                 .otherwise(col("workflowRequestId").cast(LongType()))) \
    .withColumn("cancellationWorkflowRequestId", 
                when(col("cancellationWorkflowRequestId") == "", lit(None))
                 .otherwise(col("cancellationWorkflowRequestId").cast(LongType()))) \
    .withColumn("fractionQuantity", col("fractionQuantity").cast(DecimalType(22, 2))) \
    .withColumn("editable", 
                when(upper(col("editable")) == "TRUE", lit(True))
                 .when(upper(col("editable")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("loaStartJobInfoId", 
                when(col("loaStartJobInfoId") == "", lit(None))
                 .otherwise(col("loaStartJobInfoId").cast(LongType()))) \
    .withColumn("loaEndJobInfoId", 
                when(col("loaEndJobInfoId") == "", lit(None))
                 .otherwise(col("loaEndJobInfoId").cast(LongType()))) \
    .withColumn("loaExpectedReturnDate", col("loaExpectedReturnDate").cast(StringType())) \
    .withColumn("loaActualReturnDate", col("loaActualReturnDate").cast(StringType())) \
    .withColumn("flexibleRequesting", 
                when(upper(col("flexibleRequesting")) == "TRUE", lit(True))
                 .when(upper(col("flexibleRequesting")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("deductionQuantity", 
                when(col("deductionQuantity") == "", lit(None))
                 .otherwise(col("deductionQuantity").cast(DecimalType(22, 2)))) \
    .withColumn("startTime", substring(col("startTime"), 1, 21)) \
    .withColumn("endTime", substring(col("endTime"), 1, 21)) \
    .withColumn("undeterminedEndDate", 
                when(upper(col("undeterminedEndDate")) == "TRUE", lit(True))
                 .when(upper(col("undeterminedEndDate")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("recurrenceGroup", substring(col("recurrenceGroup"), 1, 38)) \
    .withColumn("displayQuantity", 
                when(col("displayQuantity") == "", lit(None))
                 .otherwise(col("displayQuantity").cast(DecimalType(22, 2)))) \
    .withColumn("physicalStartDate", 
                when(col("physicalStartDate") == "", lit(None))
                 .otherwise(col("physicalStartDate").cast(DecimalType(22, 2)))) \
    .withColumn("physicalEndDate", 
                when(col("physicalEndDate") == "", lit(None))
                 .otherwise(col("physicalEndDate").cast(DecimalType(22, 2)))) \
    .withColumn("externalCode", substring(col("externalCode"), 1, 128)) \
    .withColumn("hash_key", md5(concat_ws("||", *[coalesce(col(c).cast(StringType()), lit("")) for c in df_result.columns])))

# Selecionar colunas finais e ordernar
df_output_extrator_can_usa_uk = df_with_types.select(
    "user_id",
    "timeType_externalCode",
    "startDate",
    "endDate",
    "approvalStatus",
    "quantityInDays",
    "quantityInHours",
    "workflowRequestId",
    "cancellationWorkflowRequestId",
    "fractionQuantity",
    "editable",
    "loaStartJobInfoId",
    "loaEndJobInfoId",
    "loaExpectedReturnDate",
    "loaActualReturnDate",
    "flexibleRequesting",
    "deductionQuantity",
    "startTime",
    "endTime",
    "undeterminedEndDate",
    "recurrenceGroup",
    "displayQuantity",
    "physicalStartDate",
    "physicalEndDate",
    "externalCode",
    "hash_key"
).distinct() \
 .orderBy(
     lpad(col("user_id"), 15, "0"),
     to_date(col("startDate"), "dd/MM/yyyy")
 )

print(f"Total de registros: {df_output_extrator_can_usa_uk.count()}")
# display(df_output_extrator_can_usa_uk)
# df_output.write.mode("overwrite").saveAsTable("silver.extrator_can_usa_uk")
df_output_extrator_can_usa_uk.createOrReplaceTempView("df_output_extrator_can_usa_uk")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extrator férias

# COMMAND ----------

# Carregar os arquivos do Volume
df_dat2 = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_v_ptp_tmp_dat2.txt", header=True, inferSchema=True, sep=";")
df_conv_tbl = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_v_ptp_conv_tbl.txt", header=True, inferSchema=True, sep=";")

# Processar tabela de conversão (subquery 'f'), usando SPLIT para dividir strings pelo delimitador '|'
df_f = (
    df_conv_tbl
    .filter(col("v_convert_id") == "FERIAS_FPW")
    .withColumn("descr_split", split(col("descr100"), "\\|"))
    .withColumn("v_char_split", split(col("v_char_to"), "\\|"))
    .select(
        # ID: primeiro elemento de descr100
        col("descr_split")[0].alias("id"),
        
        # Data início: segundo elemento de v_char_to (índice 1)
        to_date(col("v_char_split")[1], "dd/MM/yyyy").alias("dt_inicio"),
        
        # Data fim: terceiro elemento de v_char_to (índice 2)
        to_date(col("v_char_split")[2], "dd/MM/yyyy").alias("dt_fim"),
        
        # Timetype: primeiro elemento de v_char_to (índice 0)
        col("v_char_split")[0].alias("timetype_externalcode")
    )
)

# Cache da tabela processada para reutilização
df_f.cache()

# PROCESSAR DADOS DE CONTRATAÇÃO

# Criar aliases para self-join
df_d1 = df_dat2.alias("d1")
df_h = df_dat2.alias("h")

# Filtrar registros de HIRE
df_hire = (
    df_h
    .filter(col("h.processtype") == "HIRE")
    .select(
        col("h.vp_emplid").alias("h_vp_emplid"),
        col("h.empl_rcd").alias("h_empl_rcd"),
        col("h.oprid").alias("h_oprid"),
        col("h.effdt").alias("dt_hire")
    )
)

# Aplicar filtros na tabela principal
df_d1_filtered = (
    df_d1
    .filter(
        (col("d1.country") == "BRA") &
        (
            (col("d1.processtype") == "GO_LIVE") |
            (
                (col("d1.hr_status") == "A") &
                (col("d1.rowname1").like("CURRENT%")) &
                (~col("d1.processtype").isin("FORA_DO_ESCOPO", "HOST_HIRE", "HOST_HIST", "HOST_TER"))
            )
        )
    )
)

# Join otimizado
df_dat = (
    df_d1_filtered
    .join(
        df_hire,
        (col("d1.vp_emplid") == col("h_vp_emplid")) &
        (col("d1.empl_rcd") == col("h_empl_rcd")) &
        (col("d1.oprid") == col("h_oprid")),
        "inner"
    )
    .select(
        col("d1.vp_emplid"),
        col("d1.empl_rcd"),
        col("d1.emplid2"),
        col("d1.oprid"),
        col("d1.hr_status"),
        col("d1.country"),
        col("dt_hire")
    )
    .distinct()
)

# Cache da tabela de dados para reutilização
df_dat.cache()

# Join final e construção do resultado
df_result = (
    df_dat
    .join(
        df_f,
        col("vp_emplid") == col("id"),
        "inner"
    )
    .select(
        col("oprid").alias("userid"),
        col("timetype_externalcode"),
        date_format(col("dt_inicio"), "dd/MM/yyyy").alias("startdate"),
        date_format(col("dt_fim"), "dd/MM/yyyy").alias("enddate"),
        lit("APPROVED").alias("approvalstatus"),
        lit("").alias("quantityindays"),
        lit("").alias("quantityinhours"),
        lit("").alias("workflowrequestid"),
        lit("").alias("cancellationworkflowrequestid"),
        (datediff(col("dt_fim"), col("dt_inicio")) + 1).alias("fractionquantity"),
        lit("TRUE").alias("editable"),
        lit("").alias("loastartjobinfoid"),
        lit("").alias("loaendjobinfoid"),
        lit("").alias("loaexpectedreturndate"),
        lit("").alias("loaactualreturndate"),
        lit("FALSE").alias("flexiblerequesting"),
        lit("").alias("deductionquantity"),
        lit("").alias("starttime"),
        lit("").alias("endtime"),
        lit("FALSE").alias("undeterminedenddate"),
        lit("").alias("recurrencegroup"),
        lit("").alias("displayquantity"),
        lit("").alias("physicalstartdate"),
        lit("").alias("physicalenddate"),
        lit("").alias("externalcode")
    )
    .orderBy(
        col("userid").cast("int"),
        to_date(col("startdate"), "dd/MM/yyyy")
    )
)


# Mapeamento de colunas com suas respectivas tipagens e tamanhos máximos, baseado na especificação do SAP SuccessFactors
df_with_types = df_result \
    .withColumn("userid", col("userid").cast(StringType())) \
    .withColumn("userid", substring(col("userid"), 1, 40)) \
    .withColumn("timeType_externalCode", col("timeType_externalCode").cast(StringType())) \
    .withColumn("timeType_externalCode", substring(col("timeType_externalCode"), 1, 38)) \
    .withColumn("startDate", col("startDate").cast(StringType())) \
    .withColumn("endDate", col("endDate").cast(StringType())) \
    .withColumn("approvalStatus", substring(col("approvalStatus"), 1, 128)) \
    .withColumn("quantityInDays", 
                when(col("quantityInDays") == "", lit(None))
                 .otherwise(col("quantityInDays").cast(DecimalType(22, 2)))) \
    .withColumn("quantityInHours", 
                when(col("quantityInHours") == "", lit(None))
                 .otherwise(col("quantityInHours").cast(DecimalType(22, 2)))) \
    .withColumn("workflowRequestId", 
                when(col("workflowRequestId") == "", lit(None))
                 .otherwise(col("workflowRequestId").cast(LongType()))) \
    .withColumn("cancellationWorkflowRequestId", 
                when(col("cancellationWorkflowRequestId") == "", lit(None))
                 .otherwise(col("cancellationWorkflowRequestId").cast(LongType()))) \
    .withColumn("fractionQuantity", col("fractionQuantity").cast(DecimalType(22, 2))) \
    .withColumn("editable", 
                when(upper(col("editable")) == "TRUE", lit(True))
                 .when(upper(col("editable")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("loaStartJobInfoId", 
                when(col("loaStartJobInfoId") == "", lit(None))
                 .otherwise(col("loaStartJobInfoId").cast(LongType()))) \
    .withColumn("loaEndJobInfoId", 
                when(col("loaEndJobInfoId") == "", lit(None))
                 .otherwise(col("loaEndJobInfoId").cast(LongType()))) \
    .withColumn("loaExpectedReturnDate", col("loaExpectedReturnDate").cast(StringType())) \
    .withColumn("loaActualReturnDate", col("loaActualReturnDate").cast(StringType())) \
    .withColumn("flexibleRequesting", 
                when(upper(col("flexibleRequesting")) == "TRUE", lit(True))
                 .when(upper(col("flexibleRequesting")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("deductionQuantity", 
                when(col("deductionQuantity") == "", lit(None))
                 .otherwise(col("deductionQuantity").cast(DecimalType(22, 2)))) \
    .withColumn("startTime", substring(col("startTime"), 1, 21)) \
    .withColumn("endTime", substring(col("endTime"), 1, 21)) \
    .withColumn("undeterminedEndDate", 
                when(upper(col("undeterminedEndDate")) == "TRUE", lit(True))
                 .when(upper(col("undeterminedEndDate")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("recurrenceGroup", substring(col("recurrenceGroup"), 1, 38)) \
    .withColumn("displayQuantity", 
                when(col("displayQuantity") == "", lit(None))
                 .otherwise(col("displayQuantity").cast(DecimalType(22, 2)))) \
    .withColumn("physicalStartDate", 
                when(col("physicalStartDate") == "", lit(None))
                 .otherwise(col("physicalStartDate").cast(DecimalType(22, 2)))) \
    .withColumn("physicalEndDate", 
                when(col("physicalEndDate") == "", lit(None))
                 .otherwise(col("physicalEndDate").cast(DecimalType(22, 2)))) \
    .withColumn("externalCode", substring(col("externalCode"), 1, 128)) \
    .withColumn("hash_key", md5(concat_ws("||", *[coalesce(col(c).cast(StringType()), lit("")) for c in df_result.columns])))

# Selecionar colunas finais e ordernar
df_output_extrator_ferias = df_with_types.select(
    "userid",
    "timeType_externalCode",
    "startDate",
    "endDate",
    "approvalStatus",
    "quantityInDays",
    "quantityInHours",
    "workflowRequestId",
    "cancellationWorkflowRequestId",
    "fractionQuantity",
    "editable",
    "loaStartJobInfoId",
    "loaEndJobInfoId",
    "loaExpectedReturnDate",
    "loaActualReturnDate",
    "flexibleRequesting",
    "deductionQuantity",
    "startTime",
    "endTime",
    "undeterminedEndDate",
    "recurrenceGroup",
    "displayQuantity",
    "physicalStartDate",
    "physicalEndDate",
    "externalCode",
    "hash_key"
).distinct() \
 .orderBy(
     lpad(col("userid"), 15, "0"),
     to_date(col("startDate"), "dd/MM/yyyy")
 )

print(f"Total de registros: {df_output_extrator_ferias.count()}")
# display(df_output_extrator_ferias)
# df_output.write.mode("overwrite").saveAsTable("silver.extrator_ferias")
df_output_extrator_ferias.createOrReplaceTempView("df_output_extrator_ferias")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extrator LOA

# COMMAND ----------

# Carregamento dos arquivos base com cache para reutilização
df_tmp_dat2_d1 = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_v_ptp_tmp_dat2.txt", header=True, inferSchema=True, sep=";").alias("d1")
df_tmp_dat2_h = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_v_ptp_tmp_dat2.txt", header=True, inferSchema=True, sep=";").alias("h")
df_conv_tbl = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_v_ptp_conv_tbl.txt", header=True, inferSchema=True, sep=";").alias("a")

# Filtros e preparação do dataset DAT

# Filtra registros de contratação (HIRE) para obter data de contratação
df_hire = df_tmp_dat2_h.filter(
    (col("h.processtype") == "HIRE") &
    (col("h.country") == "BRA")
).select(
    col("h.vp_emplid"),
    col("h.empl_rcd"),
    col("h.oprid"),
    col("h.effdt").alias("dt_hire")
)

# Filtra registros ativos ou GO_LIVE
df_active = df_tmp_dat2_d1.filter(
    (
        (col("d1.processtype") == "GO_LIVE") |
        (
            (col("d1.hr_status") == "A") &
            (col("d1.rowname1").like("CURRENT%")) &
            (~col("d1.processtype").isin(["FORA_DO_ESCOPO", "HOST_HIRE", "HOST_HIST", "HOST_TER"]))
        )
    ) &
    (col("d1.country") == "BRA")
).select(
    col("d1.vp_emplid"),
    col("d1.empl_rcd"),
    col("d1.emplid2"),
    col("d1.oprid"),
    col("d1.hr_status"),
    col("d1.country")
)

# Join entre dados ativos e data de contratação
df_dat = df_active.join(
    df_hire,
    on=[
        df_active["vp_emplid"] == df_hire["vp_emplid"],
        df_active["empl_rcd"] == df_hire["empl_rcd"],
        df_active["oprid"] == df_hire["oprid"]
    ],
    how="inner"
).select(
    df_active["vp_emplid"],
    df_active["empl_rcd"],
    df_active["emplid2"],
    df_active["oprid"],
    df_active["hr_status"],
    df_active["country"],
    df_hire["dt_hire"]
).distinct()

# Cache para reutilização
df_dat.cache()


# Processamento da tabela de conversão (afastamentos)

# Lista de códigos de afastamento válidos
valid_time_types = [
    '0251', '0210', '0290', '0390', '0294', '0253', '0211', '0310', '0252',
    '0293', '0292', '0250', '9012', '9019', '9011', '9010', '9013', '0291', '0311'
]

# Filtra e processa tabela de conversão
df_afastamentos = df_conv_tbl.filter(
    col("a.v_convert_id") == "AFASTAMENTOS_BRA"
).withColumn(
    # Split do v_char_to por '|' para facilitar extração
    "v_char_to_parts", split(col("a.v_char_to"), "\\|")
).withColumn(
    # Split do descr100 por '|' para facilitar extração
    "descr100_parts", split(col("a.descr100"), "\\|")
).select(
    # Extrai vp_emplid do campo descr100 (primeira parte antes do '|')
    col("descr100_parts")[0].alias("vp_emplid_conv"),
    
    # Extrai timetype_externalcode (primeira parte de v_char_to)
    col("v_char_to_parts")[0].alias("timetype_externalcode"),
    
    # Extrai startdate (segunda parte de v_char_to)
    col("v_char_to_parts")[1].alias("startdate_str"),
    
    # Extrai enddate (terceira parte de v_char_to)
    col("v_char_to_parts")[2].alias("enddate_str"),
    
    col("a.v_char_to")
)

# Aplica filtros adicionais
df_afastamentos = df_afastamentos.filter(
    col("timetype_externalcode").isin(valid_time_types)
)


# Join entre DAT e Afastamentos
df_joined = df_dat.join(
    df_afastamentos,
    on=[df_dat["vp_emplid"] == df_afastamentos["vp_emplid_conv"]],
    how="inner"
)

# Converte strings de data para tipo Date
df_joined = df_joined.withColumn(
    "startdate_parsed",
    to_date(col("startdate_str"), "dd/MM/yyyy")
).withColumn(
    "enddate_parsed",
    to_date(col("enddate_str"), "dd/MM/yyyy")
)

# Filtro: startdate >= dt_hire
df_joined = df_joined.filter(
    col("startdate_parsed") >= col("dt_hire")
)


# Transformações e cálculos das colunas finais
df_result = df_joined.select(
    col("oprid").alias("userid"),
    col("timetype_externalcode"),
    date_format(col("startdate_parsed"), "dd/MM/yyyy").alias("startdate"),
    when(
        col("enddate_str") == "01/01/9999",
        date_format(add_months(col("startdate_parsed"), 324), "dd/MM/yyyy")
    ).otherwise(
        date_format(col("enddate_parsed"), "dd/MM/yyyy")
    ).alias("enddate"),
    lit("APPROVED").alias("approvalstatus"),
    lit("").alias("quantityindays"),
    lit("").alias("quantityinhours"),
    lit("").alias("workflowrequestid"),
    lit("").alias("cancellationworkflowrequestid"),
    when(
        col("enddate_str") == "01/01/9999",
        lit(0)
    ).otherwise(
        datediff(col("enddate_parsed"), col("startdate_parsed")) + 1
    ).alias("fractionquantity"),
    lit("TRUE").alias("editable"),
    lit("").alias("loastartjobinfoid"),
    lit("").alias("loaendjobinfoid"),
    when(
        col("enddate_str") == "01/01/9999",
        date_format(add_months(col("startdate_parsed"), 324) + expr("INTERVAL 1 DAY"), "dd/MM/yyyy")
    ).otherwise(
        date_format(expr("enddate_parsed + INTERVAL 1 DAY"), "dd/MM/yyyy")
    ).alias("loaexpectedreturndate"),
    when(
        col("enddate_parsed") == to_date(lit("01/01/9999"), "dd/MM/yyyy"),
        lit("")
    ).when(
        col("enddate_parsed") > to_date(lit("31/05/2025"), "dd/MM/yyyy"),
        lit("")
    ).otherwise(
        date_format(expr("enddate_parsed + INTERVAL 1 DAY"), "dd/MM/yyyy")
    ).alias("loaactualreturndate"),
    lit("FALSE").alias("flexiblerequesting"),
    lit("").alias("deductionquantity"),
    lit("").alias("starttime"),
    lit("").alias("endtime"),
    lit("FALSE").alias("undeterminedenddate"),
    lit("").alias("recurrencegroup"),
    lit("").alias("displayquantity"),
    lit("").alias("physicalstartdate"),
    lit("").alias("physicalenddate"),
    lit("").alias("externalcode")
)

# Mapeamento de colunas com suas respectivas tipagens e tamanhos máximos, baseado na especificação do SAP SuccessFactors
df_with_types = df_result \
    .withColumn("userid", col("userid").cast(StringType())) \
    .withColumn("userid", substring(col("userid"), 1, 40)) \
    .withColumn("timeType_externalCode", col("timeType_externalCode").cast(StringType())) \
    .withColumn("timeType_externalCode", substring(col("timeType_externalCode"), 1, 38)) \
    .withColumn("startDate", col("startDate").cast(StringType())) \
    .withColumn("endDate", col("endDate").cast(StringType())) \
    .withColumn("approvalStatus", substring(col("approvalStatus"), 1, 128)) \
    .withColumn("quantityInDays", 
                when(col("quantityInDays") == "", lit(None))
                 .otherwise(col("quantityInDays").cast(DecimalType(22, 2)))) \
    .withColumn("quantityInHours", 
                when(col("quantityInHours") == "", lit(None))
                 .otherwise(col("quantityInHours").cast(DecimalType(22, 2)))) \
    .withColumn("workflowRequestId", 
                when(col("workflowRequestId") == "", lit(None))
                 .otherwise(col("workflowRequestId").cast(LongType()))) \
    .withColumn("cancellationWorkflowRequestId", 
                when(col("cancellationWorkflowRequestId") == "", lit(None))
                 .otherwise(col("cancellationWorkflowRequestId").cast(LongType()))) \
    .withColumn("fractionQuantity", col("fractionQuantity").cast(DecimalType(22, 2))) \
    .withColumn("editable", 
                when(upper(col("editable")) == "TRUE", lit(True))
                 .when(upper(col("editable")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("loaStartJobInfoId", 
                when(col("loaStartJobInfoId") == "", lit(None))
                 .otherwise(col("loaStartJobInfoId").cast(LongType()))) \
    .withColumn("loaEndJobInfoId", 
                when(col("loaEndJobInfoId") == "", lit(None))
                 .otherwise(col("loaEndJobInfoId").cast(LongType()))) \
    .withColumn("loaExpectedReturnDate", col("loaExpectedReturnDate").cast(StringType())) \
    .withColumn("loaActualReturnDate", col("loaActualReturnDate").cast(StringType())) \
    .withColumn("flexibleRequesting", 
                when(upper(col("flexibleRequesting")) == "TRUE", lit(True))
                 .when(upper(col("flexibleRequesting")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("deductionQuantity", 
                when(col("deductionQuantity") == "", lit(None))
                 .otherwise(col("deductionQuantity").cast(DecimalType(22, 2)))) \
    .withColumn("startTime", substring(col("startTime"), 1, 21)) \
    .withColumn("endTime", substring(col("endTime"), 1, 21)) \
    .withColumn("undeterminedEndDate", 
                when(upper(col("undeterminedEndDate")) == "TRUE", lit(True))
                 .when(upper(col("undeterminedEndDate")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("recurrenceGroup", substring(col("recurrenceGroup"), 1, 38)) \
    .withColumn("displayQuantity", 
                when(col("displayQuantity") == "", lit(None))
                 .otherwise(col("displayQuantity").cast(DecimalType(22, 2)))) \
    .withColumn("physicalStartDate", 
                when(col("physicalStartDate") == "", lit(None))
                 .otherwise(col("physicalStartDate").cast(DecimalType(22, 2)))) \
    .withColumn("physicalEndDate", 
                when(col("physicalEndDate") == "", lit(None))
                 .otherwise(col("physicalEndDate").cast(DecimalType(22, 2)))) \
    .withColumn("externalCode", substring(col("externalCode"), 1, 128)) \
    .withColumn("hash_key", md5(concat_ws("||", *[coalesce(col(c).cast(StringType()), lit("")) for c in df_result.columns])))

# Selecionar colunas finais e ordernar
df_output_extrator_loa = df_with_types.select(
    "userid",
    "timeType_externalCode",
    "startDate",
    "endDate",
    "approvalStatus",
    "quantityInDays",
    "quantityInHours",
    "workflowRequestId",
    "cancellationWorkflowRequestId",
    "fractionQuantity",
    "editable",
    "loaStartJobInfoId",
    "loaEndJobInfoId",
    "loaExpectedReturnDate",
    "loaActualReturnDate",
    "flexibleRequesting",
    "deductionQuantity",
    "startTime",
    "endTime",
    "undeterminedEndDate",
    "recurrenceGroup",
    "displayQuantity",
    "physicalStartDate",
    "physicalEndDate",
    "externalCode",
    "hash_key"
).distinct() \
 .orderBy(
     lpad(col("userid"), 15, "0"),
     to_date(col("startDate"), "dd/MM/yyyy")
 )

# display(df_output_extrator_loa)
print(f"Total de registros: {df_output_extrator_loa.count()}")
# df_output.write.mode("overwrite").saveAsTable("silver.extrator_loa")
df_output_extrator_loa.createOrReplaceTempView("df_output_extrator_loa")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extrator Não LOA

# COMMAND ----------

df_ptp_tmp_dat2 = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_v_ptp_tmp_dat2.txt", header=True, inferSchema=True, sep=";")
df_ptp_conv_tbl = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_v_ptp_conv_tbl.txt", header=True, inferSchema=True, sep=";")

codigos_ausencia = [
    '0380', '0201', '0255', '0300', '0320', '9015', '9003', '9007', 
    '0340', '9005', '9008', '0256', '0297', '0200', '9021', '9006', 
    '0371', '9009', '0386', '9004', '9002', '0385', '9016', '9017'
]

# Subquery DAT - Obter dados dos funcionários
# Filtrar registros HIRE
df_hire = df_ptp_tmp_dat2.filter(
    col("processtype") == "HIRE"
).select(
    col("vp_emplid"),
    col("empl_rcd"),
    col("oprid"),
    col("effdt").alias("dt_hire")
)

# Filtrar registros GO_LIVE ou registros ativos
df_dat = df_ptp_tmp_dat2.filter(
    (col("country") == "BRA") &
    (
        (col("processtype") == "GO_LIVE") |
        (
            (col("hr_status") == "A") &
            (col("rowname1").like("CURRENT%")) &
            (~col("processtype").isin(["FORA_DO_ESCOPO", "HOST_HIRE", "HOST_HIST", "HOST_TER"]))
        )
    )
).select(
    col("vp_emplid"),
    col("empl_rcd"),
    col("emplid2"),
    col("oprid"),
    col("hr_status"),
    col("country")
)

# Join para obter dt_hire
df_dat_final = df_dat.join(
    df_hire,
    (df_dat.vp_emplid == df_hire.vp_emplid) &
    (df_dat.empl_rcd == df_hire.empl_rcd) &
    (df_dat.oprid == df_hire.oprid),
    "inner"
).select(
    df_dat.vp_emplid,
    df_dat.empl_rcd,
    df_dat.emplid2,
    df_dat.oprid,
    df_dat.hr_status,
    df_dat.country,
    df_hire.dt_hire
).distinct()

# Processar tabela de conversão (afastamentos)
df_afastamentos = df_ptp_conv_tbl.filter(
    col("v_convert_id") == "AFASTAMENTOS_BRA"
).withColumn(
    "ID",
    expr("substring(descr100, 1, instr(descr100, '|') - 1)")
).withColumn(
    "cod_ausencia",
    expr("substring(v_char_to, 1, instr(v_char_to, '|') - 1)")
).withColumn(
    "pos_first_pipe",
    expr("instr(v_char_to, '|')")
).withColumn(
    "dt_ini_str",
    trim(expr("substring(v_char_to, pos_first_pipe + 1, 10)"))
).withColumn(
    "dt_ini",
    to_date(col("dt_ini_str"), "dd/MM/yyyy")
).withColumn(
    "pos_second_pipe",
    expr("instr(substring(v_char_to, pos_first_pipe + 1), '|') + pos_first_pipe")
).withColumn(
    "dt_fim_str",
    trim(expr("substring(v_char_to, pos_second_pipe + 1, 10)"))
).withColumn(
    "dt_fim",
    when(
        col("dt_fim_str") == "01/01/9999",
        add_months(col("dt_ini"), 324)
    ).otherwise(
        to_date(col("dt_fim_str"), "dd/MM/yyyy")
    )
).withColumn(
    "days",
    when(
        col("dt_fim_str") == "01/01/9999",
        datediff(add_months(col("dt_ini"), 324), add_months(col("dt_ini"), 72)) + 1
    ).otherwise(
        datediff(to_date(col("dt_fim_str"), "dd/MM/yyyy"), col("dt_ini")) + 1
    )
).select(
    "ID",
    "cod_ausencia",
    "dt_ini",
    "dt_fim",
    "days"
)

# Filtrar códigos de ausência na lista
df_afastamentos_filtrado = df_afastamentos.filter(
    col("cod_ausencia").isin(codigos_ausencia)
)

# Join entre DAT e AFASTAMENTOS
df_joined = df_dat_final.join(
    df_afastamentos_filtrado,
    (df_dat_final.vp_emplid == df_afastamentos_filtrado.ID) &
    (df_dat_final.country == "BRA") &
    (df_afastamentos_filtrado.dt_ini >= df_dat_final.dt_hire),
    "inner"
)

# Selecionar e formatar campos finais
df_resultado_final = df_joined.select(
    col("oprid").alias("userid"),
    col("cod_ausencia").alias("timetype_externalcode"),
    date_format(col("dt_ini"), "dd/MM/yyyy").alias("startdate"),
    date_format(col("dt_fim"), "dd/MM/yyyy").alias("endDate"),
    lit("APPROVED").alias("approvalstatus"),
    lit("").alias("quantityindays"),
    lit("").alias("quantityinhours"),
    lit("").alias("workflowrequestid"),
    lit("").alias("cancellationworkflowrequestid"),
    col("days").alias("fractionquantity"),
    lit("TRUE").alias("editable"),
    lit("").alias("loastartjobinfoid"),
    lit("").alias("loaendjobinfoid"),
    lit("").alias("loaexpectedreturndate"),
    lit("").alias("loaactualreturndate"),
    lit("FALSE").alias("flexiblerequesting"),
    lit("").alias("deductionquantity"),
    lit("").alias("starttime"),
    lit("").alias("endtime"),
    lit("FALSE").alias("undeterminedenddate"),
    lit("").alias("recurrencegroup"),
    lit("").alias("displayquantity"),
    lit("").alias("physicalstartdate"),
    lit("").alias("physicalenddate"),
    lit("").alias("externalcode")
).orderBy(
    col("userid").cast("int"),
    to_date(col("startdate"), "dd/MM/yyyy")
)

df_output_extrator_nao_loa = df_resultado_final \
    .withColumn("userid", substring(col("userid").cast(StringType()), 1, 40)) \
    .withColumn("timetype_externalcode", substring(col("timetype_externalcode").cast(StringType()), 1, 38)) \
    .withColumn("startdate", col("startdate").cast(StringType())) \
    .withColumn("endDate", col("endDate").cast(StringType())) \
    .withColumn("approvalstatus", substring(col("approvalstatus"), 1, 128)) \
    .withColumn("quantityindays", 
                when(col("quantityindays") == "", lit(None))
                 .otherwise(col("quantityindays").cast(DecimalType(22, 2)))) \
    .withColumn("quantityinhours", 
                when(col("quantityinhours") == "", lit(None))
                 .otherwise(col("quantityinhours").cast(DecimalType(22, 2)))) \
    .withColumn("workflowrequestid", 
                when(col("workflowrequestid") == "", lit(None))
                 .otherwise(col("workflowrequestid").cast(LongType()))) \
    .withColumn("cancellationworkflowrequestid", 
                when(col("cancellationworkflowrequestid") == "", lit(None))
                 .otherwise(col("cancellationworkflowrequestid").cast(LongType()))) \
    .withColumn("fractionquantity", col("fractionquantity").cast(DecimalType(22, 2))) \
    .withColumn("editable", 
                when(upper(col("editable")) == "TRUE", lit(True))
                 .when(upper(col("editable")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("loastartjobinfoid", 
                when(col("loastartjobinfoid") == "", lit(None))
                 .otherwise(col("loastartjobinfoid").cast(LongType()))) \
    .withColumn("loaendjobinfoid", 
                when(col("loaendjobinfoid") == "", lit(None))
                 .otherwise(col("loaendjobinfoid").cast(LongType()))) \
    .withColumn("loaexpectedreturndate", col("loaexpectedreturndate").cast(StringType())) \
    .withColumn("loaactualreturndate", col("loaactualreturndate").cast(StringType())) \
    .withColumn("flexiblerequesting", 
                when(upper(col("flexiblerequesting")) == "TRUE", lit(True))
                 .when(upper(col("flexiblerequesting")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("deductionquantity", 
                when(col("deductionquantity") == "", lit(None))
                 .otherwise(col("deductionquantity").cast(DecimalType(22, 2)))) \
    .withColumn("starttime", substring(col("starttime"), 1, 21)) \
    .withColumn("endtime", substring(col("endtime"), 1, 21)) \
    .withColumn("undeterminedenddate", 
                when(upper(col("undeterminedenddate")) == "TRUE", lit(True))
                 .when(upper(col("undeterminedenddate")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("recurrencegroup", substring(col("recurrencegroup"), 1, 38)) \
    .withColumn("displayquantity", 
                when(col("displayquantity") == "", lit(None))
                 .otherwise(col("displayquantity").cast(DecimalType(22, 2)))) \
    .withColumn("physicalstartdate", 
                when(col("physicalstartdate") == "", lit(None))
                 .otherwise(col("physicalstartdate").cast(DecimalType(22, 2)))) \
    .withColumn("physicalenddate", 
                when(col("physicalenddate") == "", lit(None))
                 .otherwise(col("physicalenddate").cast(DecimalType(22, 2)))) \
    .withColumn("externalcode", substring(col("externalcode"), 1, 128)) \
    .withColumn("hash_key", md5(concat_ws("||", *[coalesce(col(c).cast(StringType()), lit("")) for c in df_resultado_final.columns])))

print(f"Total de registros: {df_output_extrator_nao_loa.count()}")
# display(df_output_extrator_nao_loa)
# df_with_types.write.mode("overwrite").format("delta").saveAsTable("silver.extrator_nao_loa")
df_output_extrator_nao_loa.createOrReplaceTempView("df_output_extrator_nao_loa")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Extrator Não LOA Prorrog

# COMMAND ----------

df_ptp_tmp_dat2 = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_v_ptp_tmp_dat2.txt", header=True, inferSchema=True, sep=";")
df_ptp_conv_tbl = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/layout_optimization/ec_49/raw_files/ps_v_ptp_conv_tbl.txt", header=True, inferSchema=True, sep=";")

# Filtrar registros HIRE
df_hire = df_ptp_tmp_dat2.filter(
    col("processtype") == "HIRE"
).select(
    col("vp_emplid"),
    col("empl_rcd"),
    col("oprid"),
    col("effdt").alias("dt_hire")
)

# Filtrar registros GO_LIVE ou registros ativos
df_dat = df_ptp_tmp_dat2.filter(
    (col("country") == "BRA") &
    (
        (col("processtype") == "GO_LIVE") |
        (
            (col("hr_status") == "A") &
            (col("rowname1").like("CURRENT%")) &
            (~col("processtype").isin(["FORA_DO_ESCOPO", "HOST_HIRE", "HOST_HIST", "HOST_TER"]))
        )
    )
).select(
    col("vp_emplid"),
    col("empl_rcd"),
    col("emplid2"),
    col("oprid"),
    col("hr_status"),
    col("country")
)

# Join para obter dt_hire
df_dat_final = df_dat.join(
    df_hire,
    (df_dat.vp_emplid == df_hire.vp_emplid) &
    (df_dat.empl_rcd == df_hire.empl_rcd) &
    (df_dat.oprid == df_hire.oprid),
    "inner"
).select(
    df_dat.vp_emplid,
    df_dat.empl_rcd,
    df_dat.emplid2,
    df_dat.oprid,
    df_dat.hr_status,
    df_dat.country,
    df_hire.dt_hire
).distinct()

# Processar tabela de conversão (afastamentos)
df_afastamentos = df_ptp_conv_tbl.filter(
    col("v_convert_id") == "AFASTAMENTOS_BRA"
).withColumn(
    "ID",
    expr("substring(descr100, 1, instr(descr100, '|') - 1)")
).withColumn(
    "cod_ausencia",
    expr("substring(v_char_to, 1, instr(v_char_to, '|') - 1)")
).withColumn(
    "pos_first_pipe",
    expr("instr(v_char_to, '|')")
).withColumn(
    "dt_ini_str",
    trim(expr("substring(v_char_to, pos_first_pipe + 1, 10)"))
).withColumn(
    "dt_ini",
    to_date(col("dt_ini_str"), "dd/MM/yyyy")
).withColumn(
    "pos_second_pipe",
    expr("instr(substring(v_char_to, pos_first_pipe + 1), '|') + pos_first_pipe")
).withColumn(
    "dt_fim_str",
    trim(expr("substring(v_char_to, pos_second_pipe + 1, 10)"))
).withColumn(
    "dt_fim",
    when(
        col("dt_fim_str") == "01/01/9999",
        add_months(col("dt_ini"), 324)
    ).otherwise(
        to_date(col("dt_fim_str"), "dd/MM/yyyy")
    )
).withColumn(
    "days",
    when(
        col("dt_fim_str") == "01/01/9999",
        datediff(add_months(col("dt_ini"), 324), add_months(col("dt_ini"), 72)) + 1
    ).otherwise(
        datediff(to_date(col("dt_fim_str"), "dd/MM/yyyy"), col("dt_ini")) + 1
    )
).select(
    "ID",
    "cod_ausencia",
    "dt_ini",
    "dt_fim",
    "days"
)

# Filtrar apenas código de ausência 0383
df_afastamentos_filtrado = df_afastamentos.filter(
    col("cod_ausencia") == "0383"
)

# PASSO 3: Join entre DAT e AFASTAMENTOS
df_joined = df_dat_final.join(
    df_afastamentos_filtrado,
    (df_dat_final.vp_emplid == df_afastamentos_filtrado.ID) &
    (df_dat_final.country == "BRA") &
    (df_afastamentos_filtrado.dt_ini >= df_dat_final.dt_hire),
    "inner"
)

# PASSO 4: Selecionar e formatar campos finais
df_resultado_final = df_joined.select(
    col("oprid").alias("userid"),
    col("cod_ausencia").alias("timetype_externalcode"),
    date_format(col("dt_ini"), "dd/MM/yyyy").alias("startdate"),
    date_format(col("dt_fim"), "dd/MM/yyyy").alias("endDate"),
    lit("APPROVED").alias("approvalstatus"),
    lit("").alias("quantityindays"),
    lit("").alias("quantityinhours"),
    lit("").alias("workflowrequestid"),
    lit("").alias("cancellationworkflowrequestid"),
    col("days").alias("fractionquantity"),
    lit("TRUE").alias("editable"),
    lit("").alias("loastartjobinfoid"),
    lit("").alias("loaendjobinfoid"),
    lit("").alias("loaexpectedreturndate"),
    lit("").alias("loaactualreturndate"),
    lit("FALSE").alias("flexiblerequesting"),
    lit("").alias("deductionquantity"),
    lit("").alias("starttime"),
    lit("").alias("endtime"),
    lit("FALSE").alias("undeterminedenddate"),
    lit("").alias("recurrencegroup"),
    lit("").alias("displayquantity"),
    lit("").alias("physicalstartdate"),
    lit("").alias("physicalenddate"),
    lit("").alias("externalcode")
).orderBy(
    col("userid").cast("int"),
    to_date(col("startdate"), "dd/MM/yyyy")
)

# ============================================================================
# APLICAR TIPAGEM E VALIDAÇÕES
# ============================================================================
df_output_extrator_nao_loa_prorrog = df_resultado_final \
    .withColumn("userid", substring(col("userid").cast(StringType()), 1, 40)) \
    .withColumn("timetype_externalcode", substring(col("timetype_externalcode").cast(StringType()), 1, 38)) \
    .withColumn("startdate", col("startdate").cast(StringType())) \
    .withColumn("endDate", col("endDate").cast(StringType())) \
    .withColumn("approvalstatus", substring(col("approvalstatus"), 1, 128)) \
    .withColumn("quantityindays", 
                when(col("quantityindays") == "", lit(None))
                 .otherwise(col("quantityindays").cast(DecimalType(22, 2)))) \
    .withColumn("quantityinhours", 
                when(col("quantityinhours") == "", lit(None))
                 .otherwise(col("quantityinhours").cast(DecimalType(22, 2)))) \
    .withColumn("workflowrequestid", 
                when(col("workflowrequestid") == "", lit(None))
                 .otherwise(col("workflowrequestid").cast(LongType()))) \
    .withColumn("cancellationworkflowrequestid", 
                when(col("cancellationworkflowrequestid") == "", lit(None))
                 .otherwise(col("cancellationworkflowrequestid").cast(LongType()))) \
    .withColumn("fractionquantity", col("fractionquantity").cast(DecimalType(22, 2))) \
    .withColumn("editable", 
                when(upper(col("editable")) == "TRUE", lit(True))
                 .when(upper(col("editable")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("loastartjobinfoid", 
                when(col("loastartjobinfoid") == "", lit(None))
                 .otherwise(col("loastartjobinfoid").cast(LongType()))) \
    .withColumn("loaendjobinfoid", 
                when(col("loaendjobinfoid") == "", lit(None))
                 .otherwise(col("loaendjobinfoid").cast(LongType()))) \
    .withColumn("loaexpectedreturndate", col("loaexpectedreturndate").cast(StringType())) \
    .withColumn("loaactualreturndate", col("loaactualreturndate").cast(StringType())) \
    .withColumn("flexiblerequesting", 
                when(upper(col("flexiblerequesting")) == "TRUE", lit(True))
                 .when(upper(col("flexiblerequesting")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("deductionquantity", 
                when(col("deductionquantity") == "", lit(None))
                 .otherwise(col("deductionquantity").cast(DecimalType(22, 2)))) \
    .withColumn("starttime", substring(col("starttime"), 1, 21)) \
    .withColumn("endtime", substring(col("endtime"), 1, 21)) \
    .withColumn("undeterminedenddate", 
                when(upper(col("undeterminedenddate")) == "TRUE", lit(True))
                 .when(upper(col("undeterminedenddate")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("recurrencegroup", substring(col("recurrencegroup"), 1, 38)) \
    .withColumn("displayquantity", 
                when(col("displayquantity") == "", lit(None))
                 .otherwise(col("displayquantity").cast(DecimalType(22, 2)))) \
    .withColumn("physicalstartdate", 
                when(col("physicalstartdate") == "", lit(None))
                 .otherwise(col("physicalstartdate").cast(DecimalType(22, 2)))) \
    .withColumn("physicalenddate", 
                when(col("physicalenddate") == "", lit(None))
                 .otherwise(col("physicalenddate").cast(DecimalType(22, 2)))) \
    .withColumn("externalcode", substring(col("externalcode"), 1, 128)) \
    .withColumn("hash_key", md5(concat_ws("||", *[coalesce(col(c).cast(StringType()), lit("")) for c in df_resultado_final.columns])))


# Exibir ou salvar resultado
# display(df_output_nao_loa_prorrog)
print(f"Total de registros: {df_output_extrator_nao_loa_prorrog.count()}")
# df_with_types.write.mode("overwrite").format("delta").saveAsTable("silver.extrator_nao_loa_prorrog")
df_output_extrator_nao_loa_prorrog.createOrReplaceTempView("df_output_extrator_nao_loa_prorrog")

# COMMAND ----------

# MAGIC %md
# MAGIC ### União dos extratores em um único DataFrame

# COMMAND ----------

df_extratores = spark.sql(
  """
  SELECT * FROM df_output_extrator_asia
  UNION ALL
  SELECT * FROM df_output_extrator_can_usa_uk
  UNION ALL
  SELECT * FROM df_output_extrator_ferias
  UNION ALL
  SELECT * FROM df_output_extrator_loa
  UNION ALL
  SELECT * FROM df_output_extrator_nao_loa
  UNION ALL
  SELECT * FROM df_output_extrator_nao_loa_prorrog
  """
)

print(f"Total de registros: {df_extratores.count()}")
# display(df_extratores)
df_extratores.createOrReplaceTempView("df_extratores")


# COMMAND ----------

# MAGIC %md
# MAGIC ### Validação final

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT 
# MAGIC   otp.file_name,
# MAGIC   count(*) as qtd_registros
# MAGIC FROM df_output_final otp
# MAGIC LEFT JOIN df_extratores ext
# MAGIC   ON otp.hash_key = ext.hash_key
# MAGIC WHERE ext.hash_key IS NULL
# MAGIC GROUP BY otp.file_name
# MAGIC ORDER BY qtd_registros DESC;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*) FROM (
# MAGIC SELECT *
# MAGIC FROM df_output_final otp
# MAGIC LEFT JOIN df_extratores ext
# MAGIC   ON otp.hash_key = ext.hash_key
# MAGIC WHERE ext.hash_key IS NULL
# MAGIC );

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COUNT(*)
# MAGIC FROM df_output_final
# MAGIC WHERE hash_key NOT IN (
# MAGIC   SELECT hash_key
# MAGIC   FROM df_extratores
# MAGIC   WHERE hash_key IS NOT NULL
# MAGIC );

# COMMAND ----------

# MAGIC %md
# MAGIC ### DataViz

# COMMAND ----------

# MAGIC %md
# MAGIC ### Visão geral dos números
# MAGIC
# MAGIC | Métrica | Valor |
# MAGIC |---------|-------|
# MAGIC | **Nº de registros nos extratores otimizados** | 373.785 |
# MAGIC | **Nº de registros do output VALE (Portal MFT)** | 368.462 |
# MAGIC | **Diferença identificada** | 5.323 |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### Análise de compatibilidade
# MAGIC
# MAGIC #### Taxa de compatibilidade: **95,7%**
# MAGIC
# MAGIC | Status | Registros | Percentual |
# MAGIC |--------|-----------|------------|
# MAGIC | ✅ **Compatíveis** | 352.571 | **95,7%** |
# MAGIC | ❌ **Não Compatíveis** | 15.891 | 4,3% |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### Fatores que impactam a incompatibilidade
# MAGIC
# MAGIC #### 1. **Processamento manual posterior**
# MAGIC Análise manual realizada por pessoa responsável, que exclui registros dos extratores de acordo com **regras de negócio não mapeadas**.
# MAGIC
# MAGIC #### 2. **Problemas de formatação no output**
# MAGIC
# MAGIC ##### Arquivos problemáticos identificados:
# MAGIC ```
# MAGIC ec_49_00_afast_comuns_bra_181220250027_seq_09.csv
# MAGIC ec_49_00_ferias_bra_151220251641 - pos_go_live.csv
# MAGIC ec_49_00_ferias_bra_151220251641.csv
# MAGIC ec_49_00_afast_bra_loa_161220251405-maternidade_pos_go_love.csv
# MAGIC ```
# MAGIC
# MAGIC
# MAGIC
# MAGIC ##### Problemas detectados:
# MAGIC
# MAGIC **a) BOM (Byte Order Mark)**
# MAGIC - Presença de BOM no início do arquivo causando inconsistências
# MAGIC
# MAGIC **b) Aspas duplicadas**
# MAGIC - Padrão incorreto: `""campo""` 
# MAGIC - Padrão esperado: `"campo"`
# MAGIC
# MAGIC **c) Encoding corrompido**
# MAGIC - Caracteres acentuados apresentando corrupção
# MAGIC - Impacto na leitura e processamento dos dados
# MAGIC
# MAGIC **d) Vírgulas extras**
# MAGIC - Vírgulas adicionais após `userId` e antes das outras colunas
# MAGIC - Quebra da estrutura CSV padrão
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ### Conclusão
# MAGIC
# MAGIC Apesar dos desafios identificados, o resultado de **95,7% de compatibilidade** demonstra que a otimização dos extratores foi bem-sucedida. Os problemas residuais estão concentrados em questões de formatação e regras de negócio não documentadas, que podem ser tratados em iterações futuras.
# MAGIC
# MAGIC ---

# COMMAND ----------

# Queries corrigidas
result_null = spark.sql(
  """
    SELECT COUNT(*) as count FROM ( 
      SELECT * 
      FROM df_output_final otp 
      LEFT JOIN df_extratores ext 
        ON otp.hash_key = ext.hash_key 
      WHERE ext.hash_key IS NULL
    )
  """
)

result_match = spark.sql(
  """
    SELECT COUNT(*) as count FROM ( 
      SELECT * 
      FROM df_output_final otp 
      LEFT JOIN df_extratores ext 
        ON otp.hash_key = ext.hash_key 
      WHERE ext.hash_key IS NOT NULL
    )
  """
)

# Converter para Pandas
df_null = result_null.toPandas()
df_match = result_match.toPandas()

# Extrair valores
sem_match = df_null['count'].iloc[0]
com_match = df_match['count'].iloc[0]
total = sem_match + com_match

# Calcular porcentagens
pct_sem = (sem_match / total) * 100
pct_com = (com_match / total) * 100

# Criar gráfico
import matplotlib.pyplot as plt

categorias = ['Sem Match', 'Com Match']
valores = [sem_match, com_match]
cores = ['#e74c3c', '#2ecc71']

plt.figure(figsize=(10, 6))
barras = plt.bar(categorias, valores, color=cores, edgecolor='black', linewidth=1.2)

# Adicionar valores e porcentagens nas barras
for i, (barra, valor, pct) in enumerate(zip(barras, valores, [pct_sem, pct_com])):
    altura = barra.get_height()
    plt.text(barra.get_x() + barra.get_width()/2., altura/2,
             f'{valor:,}\n({pct:.1f}%)',
             ha='center', va='center', fontsize=12, fontweight='bold', color='white')

plt.ylabel('Quantidade', fontsize=12)
plt.title('Análise de Matches - df_output_final vs df_extratores', fontsize=14, fontweight='bold')
plt.grid(axis='y', alpha=0.3, linestyle='--')
plt.tight_layout()
plt.show()

# Imprimir resumo
print(f"\n{'='*50}")
print(f"Total de registros: {total:,}")
print(f"Com Match: {com_match:,} ({pct_com:.2f}%)")
print(f"Sem Match: {sem_match:,} ({pct_sem:.2f}%)")
print(f"{'='*50}")

# COMMAND ----------

import matplotlib.pyplot as plt
import pandas as pd

# Lista dos extratores individuais
extratores = [
    'df_output_extrator_asia',
    'df_output_extrator_can_usa_uk',
    'df_output_extrator_ferias',
    'df_output_extrator_loa',
    'df_output_extrator_nao_loa',
    'df_output_extrator_nao_loa_prorrog'
]

# Dicionário para armazenar resultados
resultados = []

print(f"{'='*80}")
print(f"{'Extrator':<40} {'Total':<10} {'Match':<10} {'Sem Match':<10} {'% Match':<10}")
print(f"{'='*80}")

for extrator in extratores:
    # Contar total de registros no extrator
    total_extrator = spark.sql(f"SELECT COUNT(*) as count FROM {extrator}").toPandas()['count'].iloc[0]
    
    # Contar registros COM match
    query_match = f"""
        SELECT COUNT(*) as count FROM (
            SELECT ext.*
            FROM {extrator} ext
            INNER JOIN df_output_final otp
                ON ext.hash_key = otp.hash_key
        )
    """
    com_match = spark.sql(query_match).toPandas()['count'].iloc[0]
    
    # Calcular sem match
    sem_match = total_extrator - com_match
    
    # Calcular porcentagem
    pct_match = (com_match / total_extrator * 100) if total_extrator > 0 else 0
    
    # Armazenar resultados
    resultados.append({
        'extrator': extrator.replace('df_output_extrator_', ''),
        'total': total_extrator,
        'com_match': com_match,
        'sem_match': sem_match,
        'pct_match': pct_match
    })
    
    # Imprimir linha
    nome_curto = extrator.replace('df_output_extrator_', '')
    print(f"{nome_curto:<40} {total_extrator:<10} {com_match:<10} {sem_match:<10} {pct_match:<10.2f}%")

print(f"{'='*80}\n")

# Converter para DataFrame pandas
df_resultados = pd.DataFrame(resultados)

# Ordenar por porcentagem de match (decrescente)
df_resultados = df_resultados.sort_values('pct_match', ascending=False)

# ============================================
# GRÁFICO 1: Barras empilhadas por extrator
# ============================================
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

# Gráfico de barras empilhadas
extratores_nomes = df_resultados['extrator'].tolist()
x_pos = range(len(extratores_nomes))

bar1 = ax1.barh(x_pos, df_resultados['com_match'], color='#2ecc71', label='Com Match')
bar2 = ax1.barh(x_pos, df_resultados['sem_match'], left=df_resultados['com_match'], 
                color='#e74c3c', label='Sem Match')

# Adicionar porcentagens
for i, (idx, row) in enumerate(df_resultados.iterrows()):
    total = row['total']
    pct = row['pct_match']
    ax1.text(total/2, i, f"{pct:.1f}%", 
             ha='center', va='center', fontsize=10, fontweight='bold', color='white')

ax1.set_yticks(x_pos)
ax1.set_yticklabels(extratores_nomes)
ax1.set_xlabel('Quantidade de Registros', fontsize=11)
ax1.set_title('Análise de Match por Extrator (valores absolutos)', fontsize=13, fontweight='bold')
ax1.legend(loc='lower right')
ax1.grid(axis='x', alpha=0.3, linestyle='--')

# ============================================
# GRÁFICO 2: Barras de porcentagem de match
# ============================================
cores = ['#27ae60' if pct >= 90 else '#f39c12' if pct >= 70 else '#e74c3c' 
         for pct in df_resultados['pct_match']]

bars = ax2.barh(x_pos, df_resultados['pct_match'], color=cores, edgecolor='black', linewidth=1.2)

# Adicionar valores nas barras
for i, (bar, pct) in enumerate(zip(bars, df_resultados['pct_match'])):
    ax2.text(pct + 1, i, f"{pct:.1f}%", 
             ha='left', va='center', fontsize=10, fontweight='bold')

ax2.set_yticks(x_pos)
ax2.set_yticklabels(extratores_nomes)
ax2.set_xlabel('Porcentagem de Match (%)', fontsize=11)
ax2.set_title('% de Match por Extrator', fontsize=13, fontweight='bold')
ax2.set_xlim(0, 105)
ax2.axvline(x=90, color='green', linestyle='--', alpha=0.5, label='Meta: 90%')
ax2.legend()
ax2.grid(axis='x', alpha=0.3, linestyle='--')

plt.tight_layout()
plt.show()

# ============================================
# RESUMO FINAL
# ============================================
print("\n" + "="*80)
print("RESUMO GERAL:")
print("="*80)
print(f"Total de extratores analisados: {len(extratores)}")
print(f"Extratores com 100% de match: {len(df_resultados[df_resultados['pct_match'] == 100])}")
print(f"Extratores com ≥90% de match: {len(df_resultados[df_resultados['pct_match'] >= 90])}")
print(f"Extratores com <90% de match: {len(df_resultados[df_resultados['pct_match'] < 90])}")
print(f"\nMédia de match: {df_resultados['pct_match'].mean():.2f}%")
print(f"Melhor extrator: {df_resultados.iloc[0]['extrator']} ({df_resultados.iloc[0]['pct_match']:.2f}%)")
print(f"Pior extrator: {df_resultados.iloc[-1]['extrator']} ({df_resultados.iloc[-1]['pct_match']:.2f}%)")
print("="*80)