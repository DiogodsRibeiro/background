# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql.window import Window

# COMMAND ----------

df_situacao = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/situacao.txt", header=True, inferSchema=True, sep=";")
df_ocorfunc = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ocorfunc.txt", header=True, inferSchema=True, sep=";")
df_funciona = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/funciona.txt", header=True, inferSchema=True, sep=";")


# COMMAND ----------

data_corte = 20250630
empresas_validas = [1, 3, 4, 46, 64, 68, 90, 112, 360, 632, 646]
codproxs_validos = [9, 29, 30, 36, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 
                    62, 63, 64, 65, 67, 69, 70, 71, 72, 73, 74, 77, 78, 83, 84, 85, 
                    87, 88, 91, 92, 98]

subty_mapping = {
    9: '0290', 29: '0390', 30: '0380', 36: '0294', 49: '0310', 50: '0201', 51: '0255',
    52: '0300', 53: '0320', 54: '9015', 55: '9003', 56: '9007', 57: '0340', 58: '9005',
    59: '9008', 60: '0291', 62: '0256', 63: '0293', 64: '0292', 65: '0297', 67: '0200',
    69: '9021', 70: '9012', 71: '9019', 72: '9006', 73: '0371', 74: '9009', 77: '0386',
    78: '9011', 83: '9010', 84: '9004', 85: '9002', 87: '0385', 88: '9013', 91: '9017',
    92: '0311', 98: '0383'
}

# COMMAND ----------


# Obter a última DATA_ID por funcionário (substitui o loop X)
window_spec = Window.partitionBy("FUPESSOAID").orderBy(F.col("FUDATAID").desc())

df_funcionarios = df_funciona.alias("f") \
    .join(df_situacao.alias("s"), 
          (F.col("f.FUCODSITU") == F.col("s.STCODSITU")) & 
          (F.col("s.STCODEMP") == 1)) \
    .filter(F.col("f.FUDATAID") <= data_corte) \
    .withColumn("rank", F.row_number().over(window_spec)) \
    .filter(F.col("rank") == 1) \
    .select(
        F.col("f.FUPESSOAID").alias("EMP_MAT"),
        F.col("f.FUDATAID").alias("DATA_ID"),
        F.col("f.FUCODEMP").alias("FUCODEMP"),
        F.col("f.FUMATFUNC").alias("FUMATFUNC"),
        F.col("f.FUDTADMIS").alias("FUDTADMIS")
    ) \
    .orderBy("EMP_MAT")

# Join com OCORFUNC para buscar as ocorrências (substitui o loop Y)
df_resultado = df_funcionarios.alias("emp") \
    .join(df_ocorfunc.alias("o"),
          (F.col("emp.FUCODEMP") == F.col("o.OFCODEMP")) &
          (F.col("emp.FUMATFUNC") == F.col("o.OFMATFUNC"))) \
    .filter(
        (F.col("o.OFCODOCORR") == 1002) &
        (F.col("o.OFCODEMP").isin(empresas_validas)) &
        (F.col("o.OFDTINIOCO") <= data_corte) &
        (F.col("o.OFDTINIOCO") > F.col("emp.FUDTADMIS")) &
        (F.col("o.OFCODPROXS").isin(codproxs_validos))
    )

# Aplicar transformações de data e DECODE
# Criar função para mapear SUBTY
subty_expr = F.create_map([F.lit(x) for pair in subty_mapping.items() for x in pair])

df_final = df_resultado \
    .withColumn("data_inicio_date", F.to_date(F.col("OFDTINIOCO").cast("string"), "yyyyMMdd")) \
    .withColumn("data_fim_date", F.to_date(F.col("OFDTFINOCO").cast("string"), "yyyyMMdd")) \
    .withColumn("data_inicio", F.date_format("data_inicio_date", "dd/MM/yyyy")) \
    .withColumn("data_fim_temp", 
                F.when(F.date_format("data_fim_date", "ddMMyyyy") == "01019999",
                       F.date_format("data_fim_date", "dd/MM/yyyy"))
                .otherwise(F.date_format(F.expr("date_sub(data_fim_date, 1)"), "dd/MM/yyyy"))) \
    .withColumn("data_fim", F.col("data_fim_temp")) \
    .withColumn("subty", 
                F.coalesce(
                    subty_expr[F.col("OFCODPROXS")],
                    F.lpad(F.col("OFCODPROXS").cast("string"), 4, "0")
                )) \
    .withColumn("output_line",
                F.concat_ws("",
                    F.col("EMP_MAT"),
                    F.lit("|"),
                    F.col("data_inicio"),
                    F.lit(";"),
                    F.trim(F.col("subty")),
                    F.lit("|"),
                    F.col("data_inicio"),
                    F.lit("|"),
                    F.col("data_fim")
                )) \
    .select(
        "EMP_MAT",
        "data_inicio",
        "data_fim",
        "subty",
        "OFNUMDIAAX",
        "output_line"
    ) \
    .orderBy("EMP_MAT", "data_inicio")


# Salvar em tabela
# df_final.write.mode("overwrite").format("delta").saveAsTable("silver.fpw_afast_menor")


display(df_final)