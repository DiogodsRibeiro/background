# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import *

# COMMAND ----------

df_ocorfunc = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ocorfunc.txt", header=True, inferSchema=True, sep=";")
df_funciona = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/funciona.txt", header=True, inferSchema=True, sep=";")

# COMMAND ----------

empresas = [1, 3, 4, 46, 64, 68, 90, 112, 360, 632, 646]
codigos_proxs = [8, 39, 66, 7, 61, 38, 90]

subty_original_mapping = {
    8: '0210',
    39: '0211',
    66: '0250',
    7: '0251',
    61: '0252',
    38: '0257',
    90: '9016'
}
subty_transformado_mapping = {
    '0210': '0201',
    '0211': '0202',
    '0250': '0200',
    '0251': '0255',
    '0252': '0256',
    '0257': '0258',
    '9016': '9017'
}

# COMMAND ----------

subty_original_expr = F.create_map([F.lit(x) for pair in subty_original_mapping.items() for x in pair])
subty_transformado_expr = F.create_map([F.lit(x) for pair in subty_transformado_mapping.items() for x in pair])

# COMMAND ----------

# # Obter o último DATA_ID de cada funcionário até 20250531
window_spec = Window.partitionBy("fupessoaid").orderBy(F.col("fudataid").desc())

df_funcionarios_filtrados = df_funciona.filter(
    (F.col("FUDATAID") <= 20250531) & 
    (F.col("FUCODEMP").isin(empresas))
).withColumn("rank", F.row_number().over(window_spec)) \
 .filter(F.col("rank") == 1) \
 .select(
     F.col("FUPESSOAID").alias("emp_mat"),
     F.col("FUDATAID").alias("data_id"),
     F.col("FUCODEMP"),
     F.col("FUMATFUNC"),
     F.col("FUDTADMIS")
 )

# Filtrar ocorrências
df_ocorrencias = df_ocorfunc.filter(
    (F.col("OFCODOCORR") == 1002) &
    (F.col("OFCODEMP").isin(empresas)) &
    (F.col("OFDTINIOCO") <= 20250531) &
    (F.col("OFCODPROXS").isin(codigos_proxs)) &
    (F.col("OFNUMDIAAX") <= 15)
)

# Join entre funcionários e ocorrências
df_afastamentos = df_funcionarios_filtrados.join(
    df_ocorrencias,
    (F.col("FUCODEMP") == F.col("OFCODEMP")) &
    (F.col("FUMATFUNC") == F.col("OFMATFUNC")) &
    (F.col("OFDTINIOCO") > F.col("FUDTADMIS")),
    "inner"
)

# Converter datas e aplicar transformações
df_transformado = df_afastamentos.withColumn(
    "data_inicio",
    F.to_date(F.col("OFDTINIOCO").cast("string"), "yyyyMMdd")
).withColumn(
    "data_fim_calc",
    F.to_date(F.col("OFDTFINOCO").cast("string"), "yyyyMMdd") - F.expr("INTERVAL 1 DAY")
).withColumn(
    "dias_aux",
    F.col("OFNUMDIAAX")
).withColumn(
    # Calcular quantidade de dias
    "vqtde_dias",
    F.when(F.col("OFNUMDIAAX") > 0, 
         F.datediff(F.col("data_fim_calc"), F.col("data_inicio")) + 1
    ).otherwise(0)
).withColumn(
    # Ajustar data fim se for 31/12/9998
    "data_fim",
    F.when(F.date_format(F.col("data_fim_calc"), "ddMMyyyy") == "31129998",
         F.to_date(F.lit("31129999"), "ddMMyyyy")
    ).otherwise(F.col("data_fim_calc"))
).withColumn(
    # Mapear SUBTY original usando dicionário
    "subty_original",
    F.coalesce(
        subty_original_expr[F.col("OFCODPROXS")],
        F.col("OFCODPROXS").cast("string")
    )
).withColumn(
    # Mapear SUBTY transformado usando dicionário
    "subty_transformado",
    F.coalesce(
        subty_transformado_expr[F.col("subty_original")],
        F.col("subty_original")
    )
)

# Aplicar lógica condicional (IF/ELSIF do PL/SQL)

# Caso 1: VQTDE_DIAS <= DIAS_AUX AND VQTDE_DIAS > 0
df_resultado_caso1 = df_transformado.filter(
    (F.col("vqtde_dias") <= F.col("dias_aux")) & (F.col("vqtde_dias") > 0)
).select(
    F.col("emp_mat"),
    F.date_format(F.col("data_inicio"), "dd/MM/yyyy").alias("dt_inicio_key"),
    F.col("subty_transformado").alias("subty"),
    F.date_format(F.col("data_inicio"), "dd/MM/yyyy").alias("dt_inicio"),
    F.date_format(F.col("data_fim"), "dd/MM/yyyy").alias("dt_fim")
)

# Caso 2: VQTDE_DIAS <= DIAS_AUX AND VQTDE_DIAS = 0
df_resultado_caso2 = df_transformado.filter(
    (F.col("vqtde_dias") <= F.col("dias_aux")) & (F.col("vqtde_dias") == 0)
).select(
    F.col("emp_mat"),
    F.date_format(F.col("data_inicio"), "dd/MM/yyyy").alias("dt_inicio_key"),
    F.col("subty_original").alias("subty"),  # Usa original
    F.date_format(F.col("data_inicio"), "dd/MM/yyyy").alias("dt_inicio"),
    F.date_format(F.col("data_fim"), "dd/MM/yyyy").alias("dt_fim")
)

# Caso 3: VQTDE_DIAS > DIAS_AUX - Gera 2 registros (parte 1)
df_resultado_caso3_parte1 = df_transformado.filter(
    F.col("vqtde_dias") > F.col("dias_aux")
).withColumn(
    "data_fim_parte1",
    F.expr("date_add(data_inicio, dias_aux - 1)")
).select(
    F.col("emp_mat"),
    F.date_format(F.col("data_inicio"), "dd/MM/yyyy").alias("dt_inicio_key"),
    F.col("subty_transformado").alias("subty"),
    F.date_format(F.col("data_inicio"), "dd/MM/yyyy").alias("dt_inicio"),
    F.date_format(F.col("data_fim_parte1"), "dd/MM/yyyy").alias("dt_fim")
)

# Caso 3: VQTDE_DIAS > DIAS_AUX - Gera 2 registros (parte 2)
df_resultado_caso3_parte2 = df_transformado.filter(
    F.col("vqtde_dias") > F.col("dias_aux")
).withColumn(
    "data_inicio_parte2",
    F.expr("date_add(data_inicio, dias_aux)")
).select(
    F.col("emp_mat"),
    F.date_format(F.col("data_inicio_parte2"), "dd/MM/yyyy").alias("dt_inicio_key"),
    F.col("subty_original").alias("subty"),  # Usa original
    F.date_format(F.col("data_inicio_parte2"), "dd/MM/yyyy").alias("dt_inicio"),
    F.date_format(F.col("data_fim"), "dd/MM/yyyy").alias("dt_fim")
)

# Unir todos os resultados
df_resultado_final = df_resultado_caso1.unionByName(df_resultado_caso2) \
    .unionByName(df_resultado_caso3_parte1) \
    .unionByName(df_resultado_caso3_parte2) \
    .orderBy("emp_mat", "dt_inicio_key")

# Formatar saída no padrão do DBMS_OUTPUT.PUT_LINE
df_resultado_final = df_resultado_final.withColumn(
    "output",
    F.concat(
        F.col("emp_mat"),
        F.lit("|"),
        F.col("dt_inicio_key"),
        F.lit(";"),
        F.trim(F.lpad(F.col("subty"), 4, "0")),  
        F.lit("|"),
        F.col("dt_inicio"),
        F.lit("|"),
        F.col("dt_fim")
    )
)


# ============================================================================
# APLICAR TIPAGEM E VALIDAÇÕES (apenas nas colunas existentes)
# ============================================================================
df_with_types = df_resultado_final \
    .withColumn("emp_mat", F.col("emp_mat").cast(StringType())) \
    .withColumn("dt_inicio_key", F.col("dt_inicio_key").cast(StringType())) \
    .withColumn("subty", F.col("subty").cast(StringType())) \
    .withColumn("dt_inicio", F.col("dt_inicio").cast(StringType())) \
    .withColumn("dt_fim", F.col("dt_fim").cast(StringType())) \
    .withColumn("output", F.col("output").cast(StringType()))

# ============================================================================
# EXIBIR OU SALVAR
# ============================================================================
display(df_with_types)

# Salvar em tabela Delta
# df_with_types.write.mode("overwrite").format("delta").saveAsTable("silver.fpw_afast_maior_15_dias")