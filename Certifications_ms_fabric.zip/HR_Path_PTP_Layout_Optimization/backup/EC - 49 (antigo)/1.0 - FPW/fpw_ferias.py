# Databricks notebook source
# Importações
from pyspark.sql import Window
from pyspark.sql.functions import (
    col, max as spark_max, sum as spark_sum, coalesce, 
    to_date, date_add, add_months, concat, lit, when,
    row_number, date_format
)
from datetime import datetime

# COMMAND ----------

# Data de referência
data_referencia = "20250630"
data_ref_date = datetime.strptime(data_referencia, "%Y%m%d")

# Carregamento dos arquivos
funciona = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/funciona.txt", header=True, inferSchema=True, sep=";")
situacao = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/situacao.txt", header=True, inferSchema=True, sep=";")
ocorfunc = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ocorfunc.txt", header=True, inferSchema=True, sep=";")

# COMMAND ----------

# IDENTIFICAR EMPREGADOS ATIVOS

# Subconsulta: Última data para cada pessoa
ultima_data = funciona.filter(
    col("FUDATAID") <= data_referencia
).groupBy("FUPESSOAID").agg(
    spark_max("FUDATAID").alias("MAX_DATAID")
)

# Subconsulta: Verificar ocorrência 1004
ocorr_1004 = ocorfunc.filter(
    (col("OFCODOCORR") == 1004) &
    (col("OFDTINIOCO") > data_referencia)
).select(
    col("OFCODEMP").alias("OFCODEMP_1004"),
    col("OFMATFUNC").alias("OFMATFUNC_1004")
).distinct().withColumn("TEM_OCORR_1004", lit(True))

# Subconsulta: Verificar ocorrência 1019 (exclusão)
ocorr_1019_exclusao = ocorfunc.filter(
    (col("OFCODOCORR") == 1019) &
    (col("OFDTINIOCO") > data_referencia) &
    (col("OFDTHOMRES") <= data_referencia)
).select(
    col("OFCODEMP").alias("OFCODEMP_1019"),
    col("OFMATFUNC").alias("OFMATFUNC_1019")
).distinct().withColumn("TEM_OCORR_1019", lit(True))

# Empregados ativos
empregados_ativos = (
    funciona
    .join(ultima_data, on="FUPESSOAID", how="inner")
    .filter(col("FUDATAID") == col("MAX_DATAID"))
    .join(situacao, 
          (funciona["FUCODSITU"] == situacao["STCODSITU"]) &
          (situacao["STCODEMP"] == 1),
          how="inner")
    .filter(
        col("FUCODEMP").isin([1, 3, 4, 46, 64, 68, 90, 112, 360, 632, 646])
    )
    # Filtro do STTIPOSITU com exceção para ocorrência 1004
    .join(ocorr_1004, 
          (col("FUCODEMP") == col("OFCODEMP_1004")) &
          (col("FUMATFUNC") == col("OFMATFUNC_1004")),
          how="left")
    .filter(
        (col("STTIPOSITU") != "R") | 
        (col("TEM_OCORR_1004") == True)
    )
    # Exclusão de ocorrência 1019
    .join(ocorr_1019_exclusao, 
          (col("FUCODEMP") == col("OFCODEMP_1019")) &
          (col("FUMATFUNC") == col("OFMATFUNC_1019")),
          how="left")
    .filter(col("TEM_OCORR_1019").isNull())
    .select(
        col("FUPESSOAID").alias("IDEMPR"),
        col("FUCODEMP").alias("EMPRESA"),
        col("FUMATFUNC").alias("MATFUNC")
    )
    .distinct()
)

# Cache para reutilização
empregados_ativos.cache()

# BUSCAR PERÍODO AQUISITIVO (OCORRÊNCIA 1001)

# Última ocorrência 1001 por empregado
window_ocorr_1001 = Window.partitionBy("OFCODEMP", "OFMATFUNC").orderBy(col("OFDTINIOCO").desc())

periodo_aquisitivo = (
    ocorfunc
    .filter(
        (col("OFCODOCORR") == 1001) &
        (col("OFDTINIOCO") <= data_referencia)
    )
    .withColumn("rn", row_number().over(window_ocorr_1001))
    .filter(col("rn") == 1)
    .select(
        col("OFCODEMP").alias("OFCODEMP_PA"),
        col("OFMATFUNC").alias("OFMATFUNC_PA"),
        col("OFDTAUX").alias("PER_AQUISITIVO")
    )
)

# Join com empregados ativos
emp_com_periodo = (
    empregados_ativos
    .join(periodo_aquisitivo,
          (empregados_ativos["EMPRESA"] == periodo_aquisitivo["OFCODEMP_PA"]) &
          (empregados_ativos["MATFUNC"] == periodo_aquisitivo["OFMATFUNC_PA"]),
          how="left")
    .withColumn("PER_AQUISITIVO", coalesce(col("PER_AQUISITIVO"), lit("0")))
    .select("IDEMPR", "EMPRESA", "MATFUNC", "PER_AQUISITIVO")
)

# CALCULAR DIAS GOZADOS

# Conversão de data para validação
ocorfunc_com_datas = (
    ocorfunc
    .withColumn("DATA_INICIO_CONV", to_date(col("OFDTINIOCO").cast("string"), "yyyyMMdd"))
    .withColumn("DATA_AUX_CONV", to_date(col("OFDTAUX").cast("string"), "yyyyMMdd"))
    .withColumn("DATA_AUX_MAIS_1ANO", add_months(col("DATA_AUX_CONV"), 12))
    .select(
        col("OFCODEMP").alias("OFCODEMP_DG"),
        col("OFMATFUNC").alias("OFMATFUNC_DG"),
        col("OFDTAUX").alias("OFDTAUX_DG"),
        col("OFCODOCORR").alias("OFCODOCORR_DG"),
        col("OFDTINIOCO").alias("OFDTINIOCO_DG"),
        col("OFNUMDIAFE"),
        col("OFNUMDIAAB"),
        col("OFNUMDIAAX"),
        col("DATA_INICIO_CONV"),
        col("DATA_AUX_CONV"),
        col("DATA_AUX_MAIS_1ANO")
    )
)

dias_gozados = (
    emp_com_periodo
    .join(
        ocorfunc_com_datas,
        (emp_com_periodo["EMPRESA"] == ocorfunc_com_datas["OFCODEMP_DG"]) &
        (emp_com_periodo["MATFUNC"] == ocorfunc_com_datas["OFMATFUNC_DG"]) &
        (emp_com_periodo["PER_AQUISITIVO"] == ocorfunc_com_datas["OFDTAUX_DG"]) &
        (ocorfunc_com_datas["OFCODOCORR_DG"] == 1001) &
        (ocorfunc_com_datas["DATA_INICIO_CONV"] >= ocorfunc_com_datas["DATA_AUX_MAIS_1ANO"]) &
        (ocorfunc_com_datas["OFDTINIOCO_DG"] <= data_referencia),
        how="left"
    )
    .groupBy("IDEMPR", "EMPRESA", "MATFUNC", "PER_AQUISITIVO")
    .agg(
        coalesce(
            spark_sum(col("OFNUMDIAFE")) + 
            spark_sum(col("OFNUMDIAAB")) + 
            spark_sum(col("OFNUMDIAAX")),
            lit(0)
        ).alias("DIAS_GOZADOS"),
        spark_max(col("OFDTAUX_DG")).alias("OF_PERIODO_AQUISITIVO")
    )
    .withColumn("OF_PERIODO_AQUISITIVO", coalesce(col("OF_PERIODO_AQUISITIVO"), col("PER_AQUISITIVO")))
)

# GERAR SAÍDA FINAL (DIAS < 30)

# Filtrar empregados com menos de 30 dias gozados
emp_pendentes = dias_gozados.filter(col("DIAS_GOZADOS") < 30)

# Buscar detalhes das férias e criar o DataFrame final
df_final = (
    emp_pendentes
    .join(
        ocorfunc.select(
            col("OFCODEMP").alias("OFCODEMP_FINAL"),
            col("OFMATFUNC").alias("OFMATFUNC_FINAL"),
            col("OFDTAUX").alias("OFDTAUX_FINAL"),
            col("OFCODOCORR").alias("OFCODOCORR_FINAL"),
            col("OFDTINIOCO").alias("OFDTINIOCO_FINAL"),
            col("OFDTFINOCO").alias("OFDTFINOCO_FINAL"),
            col("OFOBS2")
        ),
        (emp_pendentes["EMPRESA"] == col("OFCODEMP_FINAL")) &
        (emp_pendentes["MATFUNC"] == col("OFMATFUNC_FINAL")) &
        (emp_pendentes["OF_PERIODO_AQUISITIVO"] == col("OFDTAUX_FINAL")) &
        (col("OFCODOCORR_FINAL") == 1001) &
        (col("OFDTINIOCO_FINAL") <= data_referencia) &
        (coalesce(col("OFOBS2"), lit("")) != "TRE"),
        how="inner"
    )
    .withColumn("DATA_INI", to_date(col("OFDTINIOCO_FINAL").cast("string"), "yyyyMMdd"))
    .withColumn("DATA_FIM", to_date(col("OFDTFINOCO_FINAL").cast("string"), "yyyyMMdd"))
    .select(
        col("IDEMPR"),
        col("DATA_INI"),
        col("DATA_FIM")
    )
    .distinct()
    .orderBy("IDEMPR", "DATA_INI")
)

# Formatar saída para adicionar o campo OUTPUT
output = df_final.withColumn(
    "OUTPUT",
    concat(
        col("IDEMPR"),
        lit("|"),
        date_format(col("DATA_INI"), "dd/MM/yyyy"),
        lit(";0100|"),
        date_format(col("DATA_INI"), "dd/MM/yyyy"),
        lit("|"),
        date_format(col("DATA_FIM"), "dd/MM/yyyy")
    )
)

display(output)
# output.write.mode("overwrite").format("delta").saveAsTable("silver.fpw_ferias")

# Limpar cache
empregados_ativos.unpersist()

# COMMAND ----------

