# Databricks notebook source
# Importações
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import StringType, DecimalType, DateType, BooleanType, LongType

# COMMAND ----------

# Tabelas de controle
df_strings = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_strings_tbl.txt", header=True, inferSchema=True, sep=";").alias("s")
df_reg_region = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_reg_region_tbl.txt", header=True, inferSchema=True, sep=";").alias("rr")
df_conv_tbl = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_v_ptp_conv_tbl.txt", header=True, inferSchema=True, sep=";").alias("v")


# Tabelas principais
df_job = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_job.txt", header=True, inferSchema=True, sep=";").alias("j")
df_pers_data = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_pers_data_effdt.txt", header=True, inferSchema=True, sep=";").alias("ef")
df_employment = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_employment.txt", header=True, inferSchema=True, sep=";").alias("e")
df_tmp_dat2 = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_v_ptp_tmp_dat2.txt", header=True, inferSchema=True, sep=";").alias("x")


# COMMAND ----------

# FILTROS INICIAIS E CACHE DE TABELAS PEQUENAS

# Filtrar e cachear strings_tbl (tabela pequena, usada múltiplas vezes)
'''
df_strings_filtered = df_strings.filter(
    (F.col("program_id") == "V_PTP_DT")
).cache()
'''

# Obter data de referência PTP
date_ptp = df_strings.filter(
    F.col("string_id") == "DATE_PTP"
).select(F.to_date(F.col("string_text"), "dd/MM/yyyy").alias("date_ptp")).first()["date_ptp"]

# Obter data de início de movimento
ptp_ini_mov = df_strings.filter(
    F.col("string_id") == "PTP_INI_MOV"
).select(F.to_date(F.col("string_text"), "dd/MM/yyyy").alias("ptp_ini_mov")).first()["ptp_ini_mov"]

# Broadcast de tabelas pequenas
df_strings = F.broadcast(df_strings)

# Filtrar conversion table para ABSENCE_CAN_USA_UK
df_conv_absence = df_conv_tbl.filter(
    F.col("v_convert_id") == "ABSENCE_CAN_USA_UK"
).cache()

# Separar conversion tables por tipo
df_conv_position = df_conv_absence.filter(
    F.substring(F.col("descr100"), 1, 12) == "INI_POSITION"
).withColumn("position_nbr", F.substring(F.col("descr100"), 14, 8)) \
 .withColumn("end_action_reason", F.substring(F.col("descr100"), 27, 7))

df_conv_ini = df_conv_absence.filter(
    F.substring(F.col("descr100"), 1, 4) == "INI|"
).withColumn("action_reason_key", F.substring(F.col("descr100"), 5, 7)) \
 .withColumn("gender_flag", F.substring(F.col("descr100"), 12, 1)) \
 .withColumn("end_action_offset", 
             F.when(F.substring(F.col("descr100"), 12, 1) == "|", 17).otherwise(18)) \
 .withColumn("end_action_reason", 
             F.expr("substring(descr100, end_action_offset, 7)"))

# Filtrar regiões para CAN, USA, GBR
df_reg_region_filtered = F.broadcast(
    df_reg_region.filter(F.col("country").isin("CAN", "USA", "GBR"))
)

# Filtrar tmp_dat2 para GO_LIVE
df_tmp_dat2_filtered = df_tmp_dat2.filter(
    F.col("processtype") == "GO_LIVE"
)

# Preparação dO DataFrame df_job com chave composta
df_job_prepared = df_job \
    .withColumn("job_key", 
                F.concat(
                    F.lpad(F.date_format(F.col("effdt"), "yyyyMMdd"), 8, "0"),
                    F.lpad(F.col("effseq").cast("string"), 4, "0")
                )) \
    .withColumn("action_reason_key", 
                F.concat(F.col("action"), F.lit("|"), F.col("action_reason"))) \
    .filter(F.col("effdt") <= F.lit(date_ptp))

# Preparação dos dados de pessoa com "Gender Decode"
df_pers_prepared = df_pers_data \
    .withColumn("gender_decoded", 
                F.when(F.trim(F.col("sex")) == "F", "F")
                 .when(F.trim(F.col("sex")) == "M", "M")
                 .otherwise("X"))

# Window para pegar max effdt por emplid
window_pers = Window.partitionBy("emplid").orderBy(F.col("effdt").desc())

df_pers_with_rank = df_pers_prepared \
    .withColumn("rank", F.row_number().over(window_pers)) \
    .filter(F.col("rank") == 1) \
    .select("emplid", "effdt", "sex", "gender_decoded")

# UNION PARTE 1: INI_POSITION

# Join base para UNION 1 - criar com colunas explícitas para evitar ambiguidade
df_union1_base = df_job_prepared \
    .select(
        F.col("emplid").alias("j_emplid"),
        F.col("empl_rcd").alias("j_empl_rcd"),
        F.col("job_key").alias("j_job_key"),
        F.col("effdt").alias("j_effdt"),
        F.col("position_nbr").alias("j_position_nbr"),
        F.col("action_reason_key").alias("j_action_reason_key"),
        F.col("reg_region").alias("j_reg_region")
    ) \
    .join(
        df_conv_position.select(
            F.col("position_nbr").alias("v_position_nbr"),
            F.col("v_char_to").alias("v_char_to"),
            F.col("end_action_reason").alias("v_end_action_reason")
        ),
        F.col("j_position_nbr") == F.col("v_position_nbr"), 
        "inner"
    ) \
    .join(
        df_reg_region_filtered.select(
            F.col("reg_region").alias("rr_reg_region"),
            F.col("country").alias("rr_country")
        ),
        F.col("j_reg_region") == F.col("rr_reg_region"), 
        "inner"
    ) \
    .join(
        df_tmp_dat2_filtered.select(
            F.col("vp_emplid").alias("x_vp_emplid"),
            F.col("empl_rcd").alias("x_empl_rcd"),
            F.col("oprid").alias("x_oprid")
        ),
        (F.col("j_emplid") == F.col("x_vp_emplid")) & 
        (F.col("j_empl_rcd") == F.col("x_empl_rcd")), 
        "inner"
    ) \
    .join(
        df_pers_with_rank.select(
            F.col("emplid").alias("ef_emplid"),
            F.col("gender_decoded").alias("ef_gender_decoded")
        ),
        F.col("j_emplid") == F.col("ef_emplid"), 
        "inner"
    )

# Subquery para encontrar próxima data de término (min effdt futuro) - UNION 1
df_job_for_end_1 = df_job_prepared \
    .select(
        F.col("emplid").alias("r_emplid"),
        F.col("empl_rcd").alias("r_empl_rcd"),
        F.col("job_key").alias("r_job_key"),
        F.col("effdt").alias("r_effdt"),
        F.col("effseq").alias("r_effseq"),
        F.col("action_reason_key").alias("r_action_reason_key")
    ) \
    .join(
        df_conv_position.select(
            F.col("end_action_reason").alias("v2_end_action_reason")
        ).distinct(),
        F.col("r_action_reason_key") == F.col("v2_end_action_reason"), 
        "inner"
    )

window_next_job_1 = Window.partitionBy("base_emplid", "base_empl_rcd", "base_job_key") \
    .orderBy("r_effdt", "r_effseq")

df_end_dates_1 = df_union1_base \
    .select(
        F.col("j_emplid").alias("base_emplid"),
        F.col("j_empl_rcd").alias("base_empl_rcd"),
        F.col("j_job_key").alias("base_job_key"),
        F.col("j_effdt").alias("base_effdt")
    ).distinct() \
    .join(df_job_for_end_1,
          (F.col("base_emplid") == F.col("r_emplid")) &
          (F.col("base_empl_rcd") == F.col("r_empl_rcd")) &
          (F.col("r_job_key") > F.col("base_job_key")),
          "left") \
    .withColumn("adjusted_effdt",
                F.when(F.col("r_effdt") == F.col("base_effdt"), 
                       F.date_add(F.col("r_effdt"), 1))
                 .otherwise(F.col("r_effdt"))) \
    .withColumn("rank", F.row_number().over(window_next_job_1)) \
    .filter(F.col("rank") == 1) \
    .select(
        F.col("base_emplid"),
        F.col("base_job_key"),
        F.date_sub(F.col("adjusted_effdt"), 1).alias("end_date")
    )

# Aplicar NOT EXISTS conditions para UNION 1

# NOT EXISTS 1: Não pode ter job futuro com position diferente no conv_position
df_ne1_jobs = df_job_prepared \
    .select(
        F.col("emplid").alias("b1_emplid"),
        F.col("empl_rcd").alias("b1_empl_rcd"),
        F.col("job_key").alias("b1_job_key"),
        F.col("position_nbr").alias("b1_position_nbr")
    ) \
    .join(
        df_conv_position.select(
            F.col("position_nbr").alias("cv21_position_nbr")
        ).distinct(),
        F.col("b1_position_nbr") == F.col("cv21_position_nbr"), 
        "inner"
    )

df_union1_step1 = df_union1_base \
    .join(df_ne1_jobs,
          (F.col("j_emplid") == F.col("b1_emplid")) &
          (F.col("j_empl_rcd") == F.col("b1_empl_rcd")) &
          (F.col("b1_job_key") > F.col("j_job_key")) &
          (F.col("b1_position_nbr") != F.col("j_position_nbr")),
          "left_anti")

# NOT EXISTS 2: Não pode ter job futuro com INI action_reason no conv_ini
df_ne2_jobs = df_job_prepared \
    .select(
        F.col("emplid").alias("b2_emplid"),
        F.col("empl_rcd").alias("b2_empl_rcd"),
        F.col("job_key").alias("b2_job_key"),
        F.col("action_reason_key").alias("b2_action_reason_key")
    ) \
    .join(
        df_conv_ini.select(
            F.col("action_reason_key").alias("cv22_action_reason_key"),
            F.col("gender_flag").alias("cv22_gender_flag")
        ),
        F.col("b2_action_reason_key") == F.col("cv22_action_reason_key"),
        "inner"
    ) \
    .join(
        df_pers_with_rank.select(
            F.col("emplid").alias("ef2_emplid"),
            F.col("gender_decoded").alias("ef2_gender")
        ),
        F.col("b2_emplid") == F.col("ef2_emplid"),
        "inner"
    ) \
    .filter(
        F.coalesce(
            F.when(F.col("cv22_gender_flag") == "|", F.lit("")),
            F.col("ef2_gender")
        ) == F.col("ef2_gender")
    ) \
    .select("b2_emplid", "b2_empl_rcd", "b2_job_key")

df_union1_step2 = df_union1_step1 \
    .join(df_ne2_jobs,
          (F.col("j_emplid") == F.col("b2_emplid")) &
          (F.col("j_empl_rcd") == F.col("b2_empl_rcd")) &
          (F.col("b2_job_key") > F.col("j_job_key")),
          "left_anti")

# NOT EXISTS 3: Não pode ter job >= com end_action_reason da position
df_ne3_jobs = df_job_prepared \
    .select(
        F.col("emplid").alias("j5_emplid"),
        F.col("job_key").alias("j5_job_key"),
        F.col("position_nbr").alias("j5_position_nbr"),
        F.col("action_reason_key").alias("j5_action_reason_key")
    ) \
    .join(
        df_conv_position.select(
            F.col("position_nbr").alias("v5_position_nbr"),
            F.col("end_action_reason").alias("v5_end_action_reason")
        ),
        (F.col("j5_action_reason_key") == F.col("v5_end_action_reason")),
        "inner"
    ) \
    .select("j5_emplid", "j5_job_key", "v5_position_nbr")

df_union1_filtered = df_union1_step2 \
    .join(df_ne3_jobs,
          (F.col("j_emplid") == F.col("j5_emplid")) &
          (F.col("j5_job_key") >= F.col("j_job_key")) &
          (F.col("v5_position_nbr") == F.col("j_position_nbr")),
          "left_anti")

# Juntar com end_dates e selecionar colunas finais
df_union1 = df_union1_filtered \
    .join(df_end_dates_1,
          (F.col("j_emplid") == F.col("base_emplid")) &
          (F.col("j_job_key") == F.col("base_job_key")),
          "left") \
    .select(
        F.col("j_emplid").alias("emplid"),
        F.col("x_oprid").alias("user_id"),
        F.col("v_char_to").alias("timeType_externalCode"),
        F.date_format(F.col("j_effdt"), "dd/MM/yyyy").alias("startDate"),
        F.coalesce(
            F.date_format(F.col("end_date"), "dd/MM/yyyy"),
            F.lit("")
        ).alias("endDate")
    )

# UNION PARTE 2: INI|action|action_reason
df_union2_base = df_job_prepared \
    .select(
        F.col("emplid").alias("j_emplid"),
        F.col("empl_rcd").alias("j_empl_rcd"),
        F.col("job_key").alias("j_job_key"),
        F.col("effdt").alias("j_effdt"),
        F.col("position_nbr").alias("j_position_nbr"),
        F.col("action_reason_key").alias("j_action_reason_key"),
        F.col("reg_region").alias("j_reg_region"),
        F.col("action").alias("j_action"),
        F.col("action_reason").alias("j_action_reason")
    ) \
    .join(
        df_conv_ini.select(
            F.col("action_reason_key").alias("v_action_reason_key"),
            F.col("v_char_to").alias("v_char_to"),
            F.col("gender_flag").alias("v_gender_flag"),
            F.col("end_action_reason").alias("v_end_action_reason")
        ),
        F.col("j_action_reason_key") == F.col("v_action_reason_key"),
        "inner"
    ) \
    .join(
        df_reg_region_filtered.select(
            F.col("reg_region").alias("rr_reg_region")
        ),
        F.col("j_reg_region") == F.col("rr_reg_region"), 
        "inner"
    ) \
    .join(
        df_tmp_dat2_filtered.select(
            F.col("vp_emplid").alias("x_vp_emplid"),
            F.col("empl_rcd").alias("x_empl_rcd"),
            F.col("oprid").alias("x_oprid")
        ),
        (F.col("j_emplid") == F.col("x_vp_emplid")) & 
        (F.col("j_empl_rcd") == F.col("x_empl_rcd")), 
        "inner"
    ) \
    .join(
        df_pers_with_rank.select(
            F.col("emplid").alias("ef_emplid"),
            F.col("gender_decoded").alias("ef_gender_decoded")
        ),
        (F.col("j_emplid") == F.col("ef_emplid")) &
        (F.coalesce(
            F.when(F.col("v_gender_flag") == "|", F.lit("")),
            F.col("ef_gender_decoded")
        ) == F.col("ef_gender_decoded")),
        "inner"
    )

# Subquery para end dates da UNION 2
df_job_for_end_2 = df_job_prepared \
    .select(
        F.col("emplid").alias("r_emplid"),
        F.col("empl_rcd").alias("r_empl_rcd"),
        F.col("job_key").alias("r_job_key"),
        F.col("effdt").alias("r_effdt"),
        F.col("effseq").alias("r_effseq"),
        F.col("action_reason_key").alias("r_action_reason_key")
    ) \
    .join(
        df_conv_ini.select(
            F.col("end_action_reason").alias("v2_end_action_reason"),
            F.col("gender_flag").alias("v2_gender_flag")
        ),
        F.col("r_action_reason_key") == F.col("v2_end_action_reason"),
        "inner"
    ) \
    .join(
        df_pers_with_rank.select(
            F.col("emplid").alias("ef2_emplid"),
            F.col("gender_decoded").alias("ef2_gender")
        ),
        (F.col("r_emplid") == F.col("ef2_emplid")),
        "inner"
    ) \
    .filter(
        F.coalesce(
            F.when(F.col("v2_gender_flag") == "|", F.lit("")),
            F.col("ef2_gender")
        ) == F.col("ef2_gender")
    )

window_next_job_2 = Window.partitionBy("base_emplid", "base_empl_rcd", "base_job_key") \
    .orderBy("r_effdt", "r_effseq")

df_end_dates_2 = df_union2_base \
    .select(
        F.col("j_emplid").alias("base_emplid"),
        F.col("j_empl_rcd").alias("base_empl_rcd"),
        F.col("j_job_key").alias("base_job_key"),
        F.col("j_effdt").alias("base_effdt"),
        F.col("ef_gender_decoded").alias("base_gender")
    ).distinct() \
    .join(df_job_for_end_2,
          (F.col("base_emplid") == F.col("r_emplid")) &
          (F.col("base_empl_rcd") == F.col("r_empl_rcd")) &
          (F.col("r_job_key") > F.col("base_job_key")),
          "left") \
    .withColumn("adjusted_effdt",
                F.when(F.col("r_effdt") == F.col("base_effdt"), 
                       F.date_add(F.col("r_effdt"), 1))
                 .otherwise(F.col("r_effdt"))) \
    .withColumn("rank", F.row_number().over(window_next_job_2)) \
    .filter(F.col("rank") == 1) \
    .select(
        F.col("base_emplid"),
        F.col("base_job_key"),
        F.date_sub(F.col("adjusted_effdt"), 1).alias("end_date")
    )

# Aplicar NOT EXISTS para UNION 2
df_ne2_1_jobs = df_job_prepared \
    .select(
        F.col("emplid").alias("b_emplid"),
        F.col("empl_rcd").alias("b_empl_rcd"),
        F.col("job_key").alias("b_job_key"),
        F.col("action_reason_key").alias("b_action_reason_key")
    ) \
    .join(
        df_conv_ini.select(
            F.col("action_reason_key").alias("cv2_action_reason_key"),
            F.col("gender_flag").alias("cv2_gender_flag")
        ),
        F.col("b_action_reason_key") == F.col("cv2_action_reason_key"),
        "inner"
    ) \
    .join(
        df_pers_with_rank.select(
            F.col("emplid").alias("ef_cv2_emplid"),
            F.col("gender_decoded").alias("ef_cv2_gender")
        ),
        F.col("b_emplid") == F.col("ef_cv2_emplid"),
        "inner"
    ) \
    .filter(
        F.coalesce(
            F.when(F.col("cv2_gender_flag") == "|", F.lit("")),
            F.col("ef_cv2_gender")
        ) == F.col("ef_cv2_gender")
    ) \
    .select("b_emplid", "b_empl_rcd", "b_job_key")

df_union2_filtered = df_union2_base \
    .join(df_ne2_1_jobs,
          (F.col("j_emplid") == F.col("b_emplid")) &
          (F.col("j_empl_rcd") == F.col("b_empl_rcd")) &
          (F.col("b_job_key") > F.col("j_job_key")),
          "left_anti")

# Join com end_dates e selecionar colunas finais
df_union2 = df_union2_filtered \
    .join(df_end_dates_2,
          (F.col("j_emplid") == F.col("base_emplid")) &
          (F.col("j_job_key") == F.col("base_job_key")),
          "left") \
    .select(
        F.col("j_emplid").alias("emplid"),
        F.col("x_oprid").alias("user_id"),
        F.col("v_char_to").alias("timeType_externalCode"),
        F.date_format(F.col("j_effdt"), "dd/MM/yyyy").alias("startDate"),
        F.coalesce(
            F.date_format(F.col("end_date"), "dd/MM/yyyy"),
            F.lit("")
        ).alias("endDate")
    )

# Union das duas partes
df_combined = df_union1.union(df_union2)

# Join com strings e employment + cálculos finais
df_final = df_combined \
    .join(
        df_strings.filter(
            (F.col("string_id") == "PTP_INI_MOV")
        ).select(
            F.col("string_text").alias("s_string_text")
        ),
        F.lit(True),  # cross join
        "inner"
    ) \
    .join(
        df_employment.select(
            F.col("emplid").alias("e_emplid"),
            F.col("rehire_dt").alias("e_rehire_dt"),
            F.col("hire_dt").alias("e_hire_dt")
        ),
        F.col("emplid") == F.col("e_emplid"),
        "inner"
    ) \
    .filter(
        F.coalesce(
            F.to_date(F.col("endDate"), "dd/MM/yyyy"),
            F.to_date(F.col("s_string_text"), "dd/MM/yyyy")
        ) >= F.to_date(F.col("s_string_text"), "dd/MM/yyyy")
    ) \
    .filter(
        F.coalesce(
            F.col("e_rehire_dt"),
            F.coalesce(
                F.col("e_hire_dt"),
                F.to_date(F.col("startDate"), "dd/MM/yyyy")
            )
        ) <= F.to_date(F.col("startDate"), "dd/MM/yyyy")
    )

# Cálculos das colunas finais
df_result = df_final \
    .withColumn("approvalStatus", F.lit("APPROVED")) \
    .withColumn("quantityInDays", F.lit("")) \
    .withColumn("quantityInHours", F.lit("")) \
    .withColumn("workflowRequestId", F.lit("")) \
    .withColumn("cancellationWorkflowRequestId", F.lit("")) \
    .withColumn("fractionQuantity",
                F.coalesce(
                    F.datediff(
                        F.to_date(F.col("endDate"), "dd/MM/yyyy"),
                        F.to_date(F.col("startDate"), "dd/MM/yyyy")
                    ) + 1,
                    F.lit(0)
                )) \
    .withColumn("editable", F.lit("TRUE")) \
    .withColumn("loaStartJobInfoId", F.lit("")) \
    .withColumn("loaEndJobInfoId", F.lit("")) \
    .withColumn("loaExpectedReturnDate",
                F.coalesce(
                    F.date_format(
                        F.date_add(F.to_date(F.col("endDate"), "dd/MM/yyyy"), 1),
                        "dd/MM/yyyy"
                    ),
                    F.date_format(
                        F.add_months(F.to_date(F.col("startDate"), "dd/MM/yyyy"), 24),
                        "dd/MM/yyyy"
                    )
                )) \
    .withColumn("loaActualReturnDate",
                F.coalesce(
                    F.date_format(
                        F.date_add(F.to_date(F.col("endDate"), "dd/MM/yyyy"), 1),
                        "dd/MM/yyyy"
                    ),
                    F.lit("")
                )) \
    .withColumn("flexibleRequesting", F.lit("FALSE")) \
    .withColumn("deductionQuantity", F.lit("")) \
    .withColumn("startTime", F.lit("")) \
    .withColumn("endTime", F.lit("")) \
    .withColumn("undeterminedEndDate", F.lit("FALSE")) \
    .withColumn("recurrenceGroup", F.lit("")) \
    .withColumn("displayQuantity", F.lit("")) \
    .withColumn("physicalStartDate", F.lit("")) \
    .withColumn("physicalEndDate", F.lit("")) \
    .withColumn("externalCode", F.lit(""))

# Mapeamento de colunas com suas respectivas tipagens e tamanhos máximos, baseado na especificação do SAP SuccessFactors
df_with_types = df_result \
    .withColumn("user_id", F.col("user_id").cast(StringType())) \
    .withColumn("user_id", F.substring(F.col("user_id"), 1, 40)) \
    .withColumn("timeType_externalCode", F.col("timeType_externalCode").cast(StringType())) \
    .withColumn("timeType_externalCode", F.substring(F.col("timeType_externalCode"), 1, 38)) \
    .withColumn("startDate", F.col("startDate").cast(StringType())) \
    .withColumn("endDate", F.col("endDate").cast(StringType())) \
    .withColumn("approvalStatus", F.substring(F.col("approvalStatus"), 1, 128)) \
    .withColumn("quantityInDays", 
                F.when(F.col("quantityInDays") == "", F.lit(None))
                 .otherwise(F.col("quantityInDays").cast(DecimalType(22, 2)))) \
    .withColumn("quantityInHours", 
                F.when(F.col("quantityInHours") == "", F.lit(None))
                 .otherwise(F.col("quantityInHours").cast(DecimalType(22, 2)))) \
    .withColumn("workflowRequestId", 
                F.when(F.col("workflowRequestId") == "", F.lit(None))
                 .otherwise(F.col("workflowRequestId").cast(LongType()))) \
    .withColumn("cancellationWorkflowRequestId", 
                F.when(F.col("cancellationWorkflowRequestId") == "", F.lit(None))
                 .otherwise(F.col("cancellationWorkflowRequestId").cast(LongType()))) \
    .withColumn("fractionQuantity", F.col("fractionQuantity").cast(DecimalType(22, 2))) \
    .withColumn("editable", 
                F.when(F.upper(F.col("editable")) == "TRUE", F.lit(True))
                 .when(F.upper(F.col("editable")) == "FALSE", F.lit(False))
                 .otherwise(F.lit(None)).cast(BooleanType())) \
    .withColumn("loaStartJobInfoId", 
                F.when(F.col("loaStartJobInfoId") == "", F.lit(None))
                 .otherwise(F.col("loaStartJobInfoId").cast(LongType()))) \
    .withColumn("loaEndJobInfoId", 
                F.when(F.col("loaEndJobInfoId") == "", F.lit(None))
                 .otherwise(F.col("loaEndJobInfoId").cast(LongType()))) \
    .withColumn("loaExpectedReturnDate", F.col("loaExpectedReturnDate").cast(StringType())) \
    .withColumn("loaActualReturnDate", F.col("loaActualReturnDate").cast(StringType())) \
    .withColumn("flexibleRequesting", 
                F.when(F.upper(F.col("flexibleRequesting")) == "TRUE", F.lit(True))
                 .when(F.upper(F.col("flexibleRequesting")) == "FALSE", F.lit(False))
                 .otherwise(F.lit(None)).cast(BooleanType())) \
    .withColumn("deductionQuantity", 
                F.when(F.col("deductionQuantity") == "", F.lit(None))
                 .otherwise(F.col("deductionQuantity").cast(DecimalType(22, 2)))) \
    .withColumn("startTime", F.substring(F.col("startTime"), 1, 21)) \
    .withColumn("endTime", F.substring(F.col("endTime"), 1, 21)) \
    .withColumn("undeterminedEndDate", 
                F.when(F.upper(F.col("undeterminedEndDate")) == "TRUE", F.lit(True))
                 .when(F.upper(F.col("undeterminedEndDate")) == "FALSE", F.lit(False))
                 .otherwise(F.lit(None)).cast(BooleanType())) \
    .withColumn("recurrenceGroup", F.substring(F.col("recurrenceGroup"), 1, 38)) \
    .withColumn("displayQuantity", 
                F.when(F.col("displayQuantity") == "", F.lit(None))
                 .otherwise(F.col("displayQuantity").cast(DecimalType(22, 2)))) \
    .withColumn("physicalStartDate", 
                F.when(F.col("physicalStartDate") == "", F.lit(None))
                 .otherwise(F.col("physicalStartDate").cast(DecimalType(22, 2)))) \
    .withColumn("physicalEndDate", 
                F.when(F.col("physicalEndDate") == "", F.lit(None))
                 .otherwise(F.col("physicalEndDate").cast(DecimalType(22, 2)))) \
    .withColumn("externalCode", F.substring(F.col("externalCode"), 1, 128)) \
    .withColumn("hash_key", F.md5(F.concat_ws("||", *[F.coalesce(F.col(c).cast(StringType()), F.lit("")) for c in df_result.columns])))

# Selecionar colunas finais e ordernar
df_output = df_with_types.select(
    "user_id",
    "timeType_externalCode",
    "startDate",
    "endDate",
    "approvalStatus",
    "quantityInDays",
    "quantityInHours",
    "workflowRequestId",
    "cancellationWorkflowRequestId",
    "fractionQuantity",
    "editable",
    "loaStartJobInfoId",
    "loaEndJobInfoId",
    "loaExpectedReturnDate",
    "loaActualReturnDate",
    "flexibleRequesting",
    "deductionQuantity",
    "startTime",
    "endTime",
    "undeterminedEndDate",
    "recurrenceGroup",
    "displayQuantity",
    "physicalStartDate",
    "physicalEndDate",
    "externalCode",
    "hash_key"
).distinct() \
 .orderBy(
     F.lpad(F.col("user_id"), 15, "0"),
     F.to_date(F.col("startDate"), "dd/MM/yyyy")
 )

display(df_output)
# df_output.write.mode("overwrite").saveAsTable("silver.extrator_can_usa_uk")