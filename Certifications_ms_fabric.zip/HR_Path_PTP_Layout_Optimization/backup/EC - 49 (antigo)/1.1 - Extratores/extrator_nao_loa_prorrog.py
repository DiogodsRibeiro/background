# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import *


# COMMAND ----------

df_ptp_tmp_dat2 = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_v_ptp_tmp_dat2.txt", header=True, inferSchema=True, sep=";")
df_ptp_conv_tbl = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_v_ptp_conv_tbl.txt", header=True, inferSchema=True, sep=";")

# COMMAND ----------

# Filtrar registros HIRE
df_hire = df_ptp_tmp_dat2.filter(
    F.col("processtype") == "HIRE"
).select(
    F.col("vp_emplid"),
    F.col("empl_rcd"),
    F.col("oprid"),
    F.col("effdt").alias("dt_hire")
)

# Filtrar registros GO_LIVE ou registros ativos
df_dat = df_ptp_tmp_dat2.filter(
    (F.col("country") == "BRA") &
    (
        (F.col("processtype") == "GO_LIVE") |
        (
            (F.col("hr_status") == "A") &
            (F.col("rowname1").like("CURRENT%")) &
            (~F.col("processtype").isin(["FORA_DO_ESCOPO", "HOST_HIRE", "HOST_HIST", "HOST_TER"]))
        )
    )
).select(
    F.col("vp_emplid"),
    F.col("empl_rcd"),
    F.col("emplid2"),
    F.col("oprid"),
    F.col("hr_status"),
    F.col("country")
)

# Join para obter dt_hire
df_dat_final = df_dat.join(
    df_hire,
    (df_dat.vp_emplid == df_hire.vp_emplid) &
    (df_dat.empl_rcd == df_hire.empl_rcd) &
    (df_dat.oprid == df_hire.oprid),
    "inner"
).select(
    df_dat.vp_emplid,
    df_dat.empl_rcd,
    df_dat.emplid2,
    df_dat.oprid,
    df_dat.hr_status,
    df_dat.country,
    df_hire.dt_hire
).distinct()

# Processar tabela de conversão (afastamentos)
df_afastamentos = df_ptp_conv_tbl.filter(
    F.col("v_convert_id") == "AFASTAMENTOS_BRA"
).withColumn(
    "ID",
    F.expr("substring(descr100, 1, instr(descr100, '|') - 1)")
).withColumn(
    "cod_ausencia",
    F.expr("substring(v_char_to, 1, instr(v_char_to, '|') - 1)")
).withColumn(
    "pos_first_pipe",
    F.expr("instr(v_char_to, '|')")
).withColumn(
    "dt_ini_str",
    F.trim(F.expr("substring(v_char_to, pos_first_pipe + 1, 10)"))
).withColumn(
    "dt_ini",
    F.to_date(F.col("dt_ini_str"), "dd/MM/yyyy")
).withColumn(
    "pos_second_pipe",
    F.expr("instr(substring(v_char_to, pos_first_pipe + 1), '|') + pos_first_pipe")
).withColumn(
    "dt_fim_str",
    F.trim(F.expr("substring(v_char_to, pos_second_pipe + 1, 10)"))
).withColumn(
    "dt_fim",
    F.when(
        F.col("dt_fim_str") == "01/01/9999",
        F.add_months(F.col("dt_ini"), 324)
    ).otherwise(
        F.to_date(F.col("dt_fim_str"), "dd/MM/yyyy")
    )
).withColumn(
    "days",
    F.when(
        F.col("dt_fim_str") == "01/01/9999",
        F.datediff(F.add_months(F.col("dt_ini"), 324), F.add_months(F.col("dt_ini"), 72)) + 1
    ).otherwise(
        F.datediff(F.to_date(F.col("dt_fim_str"), "dd/MM/yyyy"), F.col("dt_ini")) + 1
    )
).select(
    "ID",
    "cod_ausencia",
    "dt_ini",
    "dt_fim",
    "days"
)

# Filtrar apenas código de ausência 0383
df_afastamentos_filtrado = df_afastamentos.filter(
    F.col("cod_ausencia") == "0383"
)

# PASSO 3: Join entre DAT e AFASTAMENTOS
df_joined = df_dat_final.join(
    df_afastamentos_filtrado,
    (df_dat_final.vp_emplid == df_afastamentos_filtrado.ID) &
    (df_dat_final.country == "BRA") &
    (df_afastamentos_filtrado.dt_ini >= df_dat_final.dt_hire),
    "inner"
)

# PASSO 4: Selecionar e formatar campos finais
df_resultado_final = df_joined.select(
    F.col("oprid").alias("userid"),
    F.col("cod_ausencia").alias("timetype_externalcode"),
    F.date_format(F.col("dt_ini"), "dd/MM/yyyy").alias("startdate"),
    F.date_format(F.col("dt_fim"), "dd/MM/yyyy").alias("endDate"),
    F.lit("APPROVED").alias("approvalstatus"),
    F.lit("").alias("quantityindays"),
    F.lit("").alias("quantityinhours"),
    F.lit("").alias("workflowrequestid"),
    F.lit("").alias("cancellationworkflowrequestid"),
    F.col("days").alias("fractionquantity"),
    F.lit("TRUE").alias("editable"),
    F.lit("").alias("loastartjobinfoid"),
    F.lit("").alias("loaendjobinfoid"),
    F.lit("").alias("loaexpectedreturndate"),
    F.lit("").alias("loaactualreturndate"),
    F.lit("FALSE").alias("flexiblerequesting"),
    F.lit("").alias("deductionquantity"),
    F.lit("").alias("starttime"),
    F.lit("").alias("endtime"),
    F.lit("FALSE").alias("undeterminedenddate"),
    F.lit("").alias("recurrencegroup"),
    F.lit("").alias("displayquantity"),
    F.lit("").alias("physicalstartdate"),
    F.lit("").alias("physicalenddate"),
    F.lit("").alias("externalcode")
).orderBy(
    F.col("userid").cast("int"),
    F.to_date(F.col("startdate"), "dd/MM/yyyy")
)

# ============================================================================
# APLICAR TIPAGEM E VALIDAÇÕES
# ============================================================================
df_with_types = df_resultado_final \
    .withColumn("userid", F.substring(F.col("userid").cast(StringType()), 1, 40)) \
    .withColumn("timetype_externalcode", F.substring(F.col("timetype_externalcode").cast(StringType()), 1, 38)) \
    .withColumn("startdate", F.col("startdate").cast(StringType())) \
    .withColumn("endDate", F.col("endDate").cast(StringType())) \
    .withColumn("approvalstatus", F.substring(F.col("approvalstatus"), 1, 128)) \
    .withColumn("quantityindays", 
                F.when(F.col("quantityindays") == "", F.lit(None))
                 .otherwise(F.col("quantityindays").cast(DecimalType(22, 2)))) \
    .withColumn("quantityinhours", 
                F.when(F.col("quantityinhours") == "", F.lit(None))
                 .otherwise(F.col("quantityinhours").cast(DecimalType(22, 2)))) \
    .withColumn("workflowrequestid", 
                F.when(F.col("workflowrequestid") == "", F.lit(None))
                 .otherwise(F.col("workflowrequestid").cast(LongType()))) \
    .withColumn("cancellationworkflowrequestid", 
                F.when(F.col("cancellationworkflowrequestid") == "", F.lit(None))
                 .otherwise(F.col("cancellationworkflowrequestid").cast(LongType()))) \
    .withColumn("fractionquantity", F.col("fractionquantity").cast(DecimalType(22, 2))) \
    .withColumn("editable", 
                F.when(F.upper(F.col("editable")) == "TRUE", F.lit(True))
                 .when(F.upper(F.col("editable")) == "FALSE", F.lit(False))
                 .otherwise(F.lit(None)).cast(BooleanType())) \
    .withColumn("loastartjobinfoid", 
                F.when(F.col("loastartjobinfoid") == "", F.lit(None))
                 .otherwise(F.col("loastartjobinfoid").cast(LongType()))) \
    .withColumn("loaendjobinfoid", 
                F.when(F.col("loaendjobinfoid") == "", F.lit(None))
                 .otherwise(F.col("loaendjobinfoid").cast(LongType()))) \
    .withColumn("loaexpectedreturndate", F.col("loaexpectedreturndate").cast(StringType())) \
    .withColumn("loaactualreturndate", F.col("loaactualreturndate").cast(StringType())) \
    .withColumn("flexiblerequesting", 
                F.when(F.upper(F.col("flexiblerequesting")) == "TRUE", F.lit(True))
                 .when(F.upper(F.col("flexiblerequesting")) == "FALSE", F.lit(False))
                 .otherwise(F.lit(None)).cast(BooleanType())) \
    .withColumn("deductionquantity", 
                F.when(F.col("deductionquantity") == "", F.lit(None))
                 .otherwise(F.col("deductionquantity").cast(DecimalType(22, 2)))) \
    .withColumn("starttime", F.substring(F.col("starttime"), 1, 21)) \
    .withColumn("endtime", F.substring(F.col("endtime"), 1, 21)) \
    .withColumn("undeterminedenddate", 
                F.when(F.upper(F.col("undeterminedenddate")) == "TRUE", F.lit(True))
                 .when(F.upper(F.col("undeterminedenddate")) == "FALSE", F.lit(False))
                 .otherwise(F.lit(None)).cast(BooleanType())) \
    .withColumn("recurrencegroup", F.substring(F.col("recurrencegroup"), 1, 38)) \
    .withColumn("displayquantity", 
                F.when(F.col("displayquantity") == "", F.lit(None))
                 .otherwise(F.col("displayquantity").cast(DecimalType(22, 2)))) \
    .withColumn("physicalstartdate", 
                F.when(F.col("physicalstartdate") == "", F.lit(None))
                 .otherwise(F.col("physicalstartdate").cast(DecimalType(22, 2)))) \
    .withColumn("physicalenddate", 
                F.when(F.col("physicalenddate") == "", F.lit(None))
                 .otherwise(F.col("physicalenddate").cast(DecimalType(22, 2)))) \
    .withColumn("externalcode", F.substring(F.col("externalcode"), 1, 128)) \
    .withColumn("hash_key", F.md5(F.concat_ws("||", *[F.coalesce(F.col(c).cast(StringType()), F.lit("")) for c in df_resultado_final.columns])))


# Exibir ou salvar resultado
display(df_with_types)

print(f"Total de registros: {df_with_types.count()}")


# Salvar em tabela
#df_with_types.write.mode("overwrite").format("delta").saveAsTable("silver.extrator_nao_loa_prorrog")