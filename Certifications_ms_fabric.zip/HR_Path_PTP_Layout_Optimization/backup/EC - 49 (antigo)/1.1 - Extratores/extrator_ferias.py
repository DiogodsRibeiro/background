# Databricks notebook source
# Importações
from pyspark.sql import functions as F
from pyspark.sql.types import StringType, DecimalType, DateType, BooleanType, LongType

# COMMAND ----------

# Carregar os arquivos do Volume
df_dat2 = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_v_ptp_tmp_dat2.txt", header=True, inferSchema=True, sep=";")
df_conv_tbl = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_v_ptp_conv_tbl.txt", header=True, inferSchema=True, sep=";")

# COMMAND ----------

# Processar tabela de conversão (subquery 'f'), usando SPLIT para dividir strings pelo delimitador '|'
df_f = (
    df_conv_tbl
    .filter(F.col("v_convert_id") == "FERIAS_FPW")
    .withColumn("descr_split", F.split(F.col("descr100"), "\\|"))
    .withColumn("v_char_split", F.split(F.col("v_char_to"), "\\|"))
    .select(
        # ID: primeiro elemento de descr100
        F.col("descr_split")[0].alias("id"),
        
        # Data início: segundo elemento de v_char_to (índice 1)
        F.to_date(F.col("v_char_split")[1], "dd/MM/yyyy").alias("dt_inicio"),
        
        # Data fim: terceiro elemento de v_char_to (índice 2)
        F.to_date(F.col("v_char_split")[2], "dd/MM/yyyy").alias("dt_fim"),
        
        # Timetype: primeiro elemento de v_char_to (índice 0)
        F.col("v_char_split")[0].alias("timetype_externalcode")
    )
)

# Cache da tabela processada para reutilização
df_f.cache()

# PROCESSAR DADOS DE CONTRATAÇÃO

# Criar aliases para self-join
df_d1 = df_dat2.alias("d1")
df_h = df_dat2.alias("h")

# Filtrar registros de HIRE
df_hire = (
    df_h
    .filter(F.col("h.processtype") == "HIRE")
    .select(
        F.col("h.vp_emplid").alias("h_vp_emplid"),
        F.col("h.empl_rcd").alias("h_empl_rcd"),
        F.col("h.oprid").alias("h_oprid"),
        F.col("h.effdt").alias("dt_hire")
    )
)

# Aplicar filtros na tabela principal
df_d1_filtered = (
    df_d1
    .filter(
        (F.col("d1.country") == "BRA") &
        (
            (F.col("d1.processtype") == "GO_LIVE") |
            (
                (F.col("d1.hr_status") == "A") &
                (F.col("d1.rowname1").like("CURRENT%")) &
                (~F.col("d1.processtype").isin("FORA_DO_ESCOPO", "HOST_HIRE", "HOST_HIST", "HOST_TER"))
            )
        )
    )
)

# Join otimizado
df_dat = (
    df_d1_filtered
    .join(
        df_hire,
        (F.col("d1.vp_emplid") == F.col("h_vp_emplid")) &
        (F.col("d1.empl_rcd") == F.col("h_empl_rcd")) &
        (F.col("d1.oprid") == F.col("h_oprid")),
        "inner"
    )
    .select(
        F.col("d1.vp_emplid"),
        F.col("d1.empl_rcd"),
        F.col("d1.emplid2"),
        F.col("d1.oprid"),
        F.col("d1.hr_status"),
        F.col("d1.country"),
        F.col("dt_hire")
    )
    .distinct()
)

# Cache da tabela de dados para reutilização
df_dat.cache()

# Join final e construção do resultado
df_result = (
    df_dat
    .join(
        df_f,
        F.col("vp_emplid") == F.col("id"),
        "inner"
    )
    .select(
        F.col("oprid").alias("userid"),
        F.col("timetype_externalcode"),
        F.date_format(F.col("dt_inicio"), "dd/MM/yyyy").alias("startdate"),
        F.date_format(F.col("dt_fim"), "dd/MM/yyyy").alias("enddate"),
        F.lit("APPROVED").alias("approvalstatus"),
        F.lit("").alias("quantityindays"),
        F.lit("").alias("quantityinhours"),
        F.lit("").alias("workflowrequestid"),
        F.lit("").alias("cancellationworkflowrequestid"),
        (F.datediff(F.col("dt_fim"), F.col("dt_inicio")) + 1).alias("fractionquantity"),
        F.lit("TRUE").alias("editable"),
        F.lit("").alias("loastartjobinfoid"),
        F.lit("").alias("loaendjobinfoid"),
        F.lit("").alias("loaexpectedreturndate"),
        F.lit("").alias("loaactualreturndate"),
        F.lit("FALSE").alias("flexiblerequesting"),
        F.lit("").alias("deductionquantity"),
        F.lit("").alias("starttime"),
        F.lit("").alias("endtime"),
        F.lit("FALSE").alias("undeterminedenddate"),
        F.lit("").alias("recurrencegroup"),
        F.lit("").alias("displayquantity"),
        F.lit("").alias("physicalstartdate"),
        F.lit("").alias("physicalenddate"),
        F.lit("").alias("externalcode")
    )
    .orderBy(
        F.col("userid").cast("int"),
        F.to_date(F.col("startdate"), "dd/MM/yyyy")
    )
)


# Mapeamento de colunas com suas respectivas tipagens e tamanhos máximos, baseado na especificação do SAP SuccessFactors
df_with_types = df_result \
    .withColumn("userid", F.col("userid").cast(StringType())) \
    .withColumn("userid", F.substring(F.col("userid"), 1, 40)) \
    .withColumn("timeType_externalCode", F.col("timeType_externalCode").cast(StringType())) \
    .withColumn("timeType_externalCode", F.substring(F.col("timeType_externalCode"), 1, 38)) \
    .withColumn("startDate", F.col("startDate").cast(StringType())) \
    .withColumn("endDate", F.col("endDate").cast(StringType())) \
    .withColumn("approvalStatus", F.substring(F.col("approvalStatus"), 1, 128)) \
    .withColumn("quantityInDays", 
                F.when(F.col("quantityInDays") == "", F.lit(None))
                 .otherwise(F.col("quantityInDays").cast(DecimalType(22, 2)))) \
    .withColumn("quantityInHours", 
                F.when(F.col("quantityInHours") == "", F.lit(None))
                 .otherwise(F.col("quantityInHours").cast(DecimalType(22, 2)))) \
    .withColumn("workflowRequestId", 
                F.when(F.col("workflowRequestId") == "", F.lit(None))
                 .otherwise(F.col("workflowRequestId").cast(LongType()))) \
    .withColumn("cancellationWorkflowRequestId", 
                F.when(F.col("cancellationWorkflowRequestId") == "", F.lit(None))
                 .otherwise(F.col("cancellationWorkflowRequestId").cast(LongType()))) \
    .withColumn("fractionQuantity", F.col("fractionQuantity").cast(DecimalType(22, 2))) \
    .withColumn("editable", 
                F.when(F.upper(F.col("editable")) == "TRUE", F.lit(True))
                 .when(F.upper(F.col("editable")) == "FALSE", F.lit(False))
                 .otherwise(F.lit(None)).cast(BooleanType())) \
    .withColumn("loaStartJobInfoId", 
                F.when(F.col("loaStartJobInfoId") == "", F.lit(None))
                 .otherwise(F.col("loaStartJobInfoId").cast(LongType()))) \
    .withColumn("loaEndJobInfoId", 
                F.when(F.col("loaEndJobInfoId") == "", F.lit(None))
                 .otherwise(F.col("loaEndJobInfoId").cast(LongType()))) \
    .withColumn("loaExpectedReturnDate", F.col("loaExpectedReturnDate").cast(StringType())) \
    .withColumn("loaActualReturnDate", F.col("loaActualReturnDate").cast(StringType())) \
    .withColumn("flexibleRequesting", 
                F.when(F.upper(F.col("flexibleRequesting")) == "TRUE", F.lit(True))
                 .when(F.upper(F.col("flexibleRequesting")) == "FALSE", F.lit(False))
                 .otherwise(F.lit(None)).cast(BooleanType())) \
    .withColumn("deductionQuantity", 
                F.when(F.col("deductionQuantity") == "", F.lit(None))
                 .otherwise(F.col("deductionQuantity").cast(DecimalType(22, 2)))) \
    .withColumn("startTime", F.substring(F.col("startTime"), 1, 21)) \
    .withColumn("endTime", F.substring(F.col("endTime"), 1, 21)) \
    .withColumn("undeterminedEndDate", 
                F.when(F.upper(F.col("undeterminedEndDate")) == "TRUE", F.lit(True))
                 .when(F.upper(F.col("undeterminedEndDate")) == "FALSE", F.lit(False))
                 .otherwise(F.lit(None)).cast(BooleanType())) \
    .withColumn("recurrenceGroup", F.substring(F.col("recurrenceGroup"), 1, 38)) \
    .withColumn("displayQuantity", 
                F.when(F.col("displayQuantity") == "", F.lit(None))
                 .otherwise(F.col("displayQuantity").cast(DecimalType(22, 2)))) \
    .withColumn("physicalStartDate", 
                F.when(F.col("physicalStartDate") == "", F.lit(None))
                 .otherwise(F.col("physicalStartDate").cast(DecimalType(22, 2)))) \
    .withColumn("physicalEndDate", 
                F.when(F.col("physicalEndDate") == "", F.lit(None))
                 .otherwise(F.col("physicalEndDate").cast(DecimalType(22, 2)))) \
    .withColumn("externalCode", F.substring(F.col("externalCode"), 1, 128)) \
    .withColumn("hash_key", F.md5(F.concat_ws("||", *[F.coalesce(F.col(c).cast(StringType()), F.lit("")) for c in df_result.columns])))

# Selecionar colunas finais e ordernar
df_output = df_with_types.select(
    "userid",
    "timeType_externalCode",
    "startDate",
    "endDate",
    "approvalStatus",
    "quantityInDays",
    "quantityInHours",
    "workflowRequestId",
    "cancellationWorkflowRequestId",
    "fractionQuantity",
    "editable",
    "loaStartJobInfoId",
    "loaEndJobInfoId",
    "loaExpectedReturnDate",
    "loaActualReturnDate",
    "flexibleRequesting",
    "deductionQuantity",
    "startTime",
    "endTime",
    "undeterminedEndDate",
    "recurrenceGroup",
    "displayQuantity",
    "physicalStartDate",
    "physicalEndDate",
    "externalCode",
    "hash_key"
).distinct() \
 .orderBy(
     F.lpad(F.col("userid"), 15, "0"),
     F.to_date(F.col("startDate"), "dd/MM/yyyy")
 )

display(df_output)
# df_output.write.mode("overwrite").saveAsTable("silver.extrator_ferias")