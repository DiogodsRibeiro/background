# Databricks notebook source
# Importações
from pyspark.sql.functions import (
    col, lit, when, to_date, date_format, add_months, 
    substring, expr, instr, length, trim, datediff, concat,
    split, regexp_extract, regexp_replace, upper, lpad, md5, coalesce, concat_ws
)
from pyspark.sql.types import StringType, DecimalType, DateType, BooleanType, LongType


# COMMAND ----------

# Carregamento dos arquivos base com cache para reutilização
df_tmp_dat2_d1 = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_v_ptp_tmp_dat2.txt", header=True, inferSchema=True, sep=";").alias("d1")
df_tmp_dat2_h = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_v_ptp_tmp_dat2.txt", header=True, inferSchema=True, sep=";").alias("h")
df_conv_tbl = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_v_ptp_conv_tbl.txt", header=True, inferSchema=True, sep=";").alias("a")

# COMMAND ----------

# Filtros e preparação do dataset DAT

# Filtra registros de contratação (HIRE) para obter data de contratação
df_hire = df_tmp_dat2_h.filter(
    (col("h.processtype") == "HIRE") &
    (col("h.country") == "BRA")
).select(
    col("h.vp_emplid"),
    col("h.empl_rcd"),
    col("h.oprid"),
    col("h.effdt").alias("dt_hire")
)

# Filtra registros ativos ou GO_LIVE
df_active = df_tmp_dat2_d1.filter(
    (
        (col("d1.processtype") == "GO_LIVE") |
        (
            (col("d1.hr_status") == "A") &
            (col("d1.rowname1").like("CURRENT%")) &
            (~col("d1.processtype").isin(["FORA_DO_ESCOPO", "HOST_HIRE", "HOST_HIST", "HOST_TER"]))
        )
    ) &
    (col("d1.country") == "BRA")
).select(
    col("d1.vp_emplid"),
    col("d1.empl_rcd"),
    col("d1.emplid2"),
    col("d1.oprid"),
    col("d1.hr_status"),
    col("d1.country")
)

# Join entre dados ativos e data de contratação
df_dat = df_active.join(
    df_hire,
    on=[
        df_active["vp_emplid"] == df_hire["vp_emplid"],
        df_active["empl_rcd"] == df_hire["empl_rcd"],
        df_active["oprid"] == df_hire["oprid"]
    ],
    how="inner"
).select(
    df_active["vp_emplid"],
    df_active["empl_rcd"],
    df_active["emplid2"],
    df_active["oprid"],
    df_active["hr_status"],
    df_active["country"],
    df_hire["dt_hire"]
).distinct()

# Cache para reutilização
df_dat.cache()


# Processamento da tabela de conversão (afastamentos)

# Lista de códigos de afastamento válidos
valid_time_types = [
    '0251', '0210', '0290', '0390', '0294', '0253', '0211', '0310', '0252',
    '0293', '0292', '0250', '9012', '9019', '9011', '9010', '9013', '0291', '0311'
]

# Filtra e processa tabela de conversão
df_afastamentos = df_conv_tbl.filter(
    col("a.v_convert_id") == "AFASTAMENTOS_BRA"
).withColumn(
    # Split do v_char_to por '|' para facilitar extração
    "v_char_to_parts", split(col("a.v_char_to"), "\\|")
).withColumn(
    # Split do descr100 por '|' para facilitar extração
    "descr100_parts", split(col("a.descr100"), "\\|")
).select(
    # Extrai vp_emplid do campo descr100 (primeira parte antes do '|')
    col("descr100_parts")[0].alias("vp_emplid_conv"),
    
    # Extrai timetype_externalcode (primeira parte de v_char_to)
    col("v_char_to_parts")[0].alias("timetype_externalcode"),
    
    # Extrai startdate (segunda parte de v_char_to)
    col("v_char_to_parts")[1].alias("startdate_str"),
    
    # Extrai enddate (terceira parte de v_char_to)
    col("v_char_to_parts")[2].alias("enddate_str"),
    
    col("a.v_char_to")
)

# Aplica filtros adicionais
df_afastamentos = df_afastamentos.filter(
    col("timetype_externalcode").isin(valid_time_types)
)


# Join entre DAT e Afastamentos
df_joined = df_dat.join(
    df_afastamentos,
    on=[df_dat["vp_emplid"] == df_afastamentos["vp_emplid_conv"]],
    how="inner"
)

# Converte strings de data para tipo Date
df_joined = df_joined.withColumn(
    "startdate_parsed",
    to_date(col("startdate_str"), "dd/MM/yyyy")
).withColumn(
    "enddate_parsed",
    to_date(col("enddate_str"), "dd/MM/yyyy")
)

# Filtro: startdate >= dt_hire
df_joined = df_joined.filter(
    col("startdate_parsed") >= col("dt_hire")
)


# Transformações e cálculos das colunas finais
df_result = df_joined.select(
    col("oprid").alias("userid"),
    col("timetype_externalcode"),
    date_format(col("startdate_parsed"), "dd/MM/yyyy").alias("startdate"),
    when(
        col("enddate_str") == "01/01/9999",
        date_format(add_months(col("startdate_parsed"), 324), "dd/MM/yyyy")
    ).otherwise(
        date_format(col("enddate_parsed"), "dd/MM/yyyy")
    ).alias("enddate"),
    lit("APPROVED").alias("approvalstatus"),
    lit("").alias("quantityindays"),
    lit("").alias("quantityinhours"),
    lit("").alias("workflowrequestid"),
    lit("").alias("cancellationworkflowrequestid"),
    when(
        col("enddate_str") == "01/01/9999",
        lit(0)
    ).otherwise(
        datediff(col("enddate_parsed"), col("startdate_parsed")) + 1
    ).alias("fractionquantity"),
    lit("TRUE").alias("editable"),
    lit("").alias("loastartjobinfoid"),
    lit("").alias("loaendjobinfoid"),
    when(
        col("enddate_str") == "01/01/9999",
        date_format(add_months(col("startdate_parsed"), 324) + expr("INTERVAL 1 DAY"), "dd/MM/yyyy")
    ).otherwise(
        date_format(expr("enddate_parsed + INTERVAL 1 DAY"), "dd/MM/yyyy")
    ).alias("loaexpectedreturndate"),
    when(
        col("enddate_parsed") == to_date(lit("01/01/9999"), "dd/MM/yyyy"),
        lit("")
    ).when(
        col("enddate_parsed") > to_date(lit("31/05/2025"), "dd/MM/yyyy"),
        lit("")
    ).otherwise(
        date_format(expr("enddate_parsed + INTERVAL 1 DAY"), "dd/MM/yyyy")
    ).alias("loaactualreturndate"),
    lit("FALSE").alias("flexiblerequesting"),
    lit("").alias("deductionquantity"),
    lit("").alias("starttime"),
    lit("").alias("endtime"),
    lit("FALSE").alias("undeterminedenddate"),
    lit("").alias("recurrencegroup"),
    lit("").alias("displayquantity"),
    lit("").alias("physicalstartdate"),
    lit("").alias("physicalenddate"),
    lit("").alias("externalcode")
)

# Mapeamento de colunas com suas respectivas tipagens e tamanhos máximos, baseado na especificação do SAP SuccessFactors
df_with_types = df_result \
    .withColumn("userid", col("userid").cast(StringType())) \
    .withColumn("userid", substring(col("userid"), 1, 40)) \
    .withColumn("timeType_externalCode", col("timeType_externalCode").cast(StringType())) \
    .withColumn("timeType_externalCode", substring(col("timeType_externalCode"), 1, 38)) \
    .withColumn("startDate", col("startDate").cast(StringType())) \
    .withColumn("endDate", col("endDate").cast(StringType())) \
    .withColumn("approvalStatus", substring(col("approvalStatus"), 1, 128)) \
    .withColumn("quantityInDays", 
                when(col("quantityInDays") == "", lit(None))
                 .otherwise(col("quantityInDays").cast(DecimalType(22, 2)))) \
    .withColumn("quantityInHours", 
                when(col("quantityInHours") == "", lit(None))
                 .otherwise(col("quantityInHours").cast(DecimalType(22, 2)))) \
    .withColumn("workflowRequestId", 
                when(col("workflowRequestId") == "", lit(None))
                 .otherwise(col("workflowRequestId").cast(LongType()))) \
    .withColumn("cancellationWorkflowRequestId", 
                when(col("cancellationWorkflowRequestId") == "", lit(None))
                 .otherwise(col("cancellationWorkflowRequestId").cast(LongType()))) \
    .withColumn("fractionQuantity", col("fractionQuantity").cast(DecimalType(22, 2))) \
    .withColumn("editable", 
                when(upper(col("editable")) == "TRUE", lit(True))
                 .when(upper(col("editable")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("loaStartJobInfoId", 
                when(col("loaStartJobInfoId") == "", lit(None))
                 .otherwise(col("loaStartJobInfoId").cast(LongType()))) \
    .withColumn("loaEndJobInfoId", 
                when(col("loaEndJobInfoId") == "", lit(None))
                 .otherwise(col("loaEndJobInfoId").cast(LongType()))) \
    .withColumn("loaExpectedReturnDate", col("loaExpectedReturnDate").cast(StringType())) \
    .withColumn("loaActualReturnDate", col("loaActualReturnDate").cast(StringType())) \
    .withColumn("flexibleRequesting", 
                when(upper(col("flexibleRequesting")) == "TRUE", lit(True))
                 .when(upper(col("flexibleRequesting")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("deductionQuantity", 
                when(col("deductionQuantity") == "", lit(None))
                 .otherwise(col("deductionQuantity").cast(DecimalType(22, 2)))) \
    .withColumn("startTime", substring(col("startTime"), 1, 21)) \
    .withColumn("endTime", substring(col("endTime"), 1, 21)) \
    .withColumn("undeterminedEndDate", 
                when(upper(col("undeterminedEndDate")) == "TRUE", lit(True))
                 .when(upper(col("undeterminedEndDate")) == "FALSE", lit(False))
                 .otherwise(lit(None)).cast(BooleanType())) \
    .withColumn("recurrenceGroup", substring(col("recurrenceGroup"), 1, 38)) \
    .withColumn("displayQuantity", 
                when(col("displayQuantity") == "", lit(None))
                 .otherwise(col("displayQuantity").cast(DecimalType(22, 2)))) \
    .withColumn("physicalStartDate", 
                when(col("physicalStartDate") == "", lit(None))
                 .otherwise(col("physicalStartDate").cast(DecimalType(22, 2)))) \
    .withColumn("physicalEndDate", 
                when(col("physicalEndDate") == "", lit(None))
                 .otherwise(col("physicalEndDate").cast(DecimalType(22, 2)))) \
    .withColumn("externalCode", substring(col("externalCode"), 1, 128)) \
    .withColumn("hash_key", md5(concat_ws("||", *[coalesce(col(c).cast(StringType()), lit("")) for c in df_result.columns])))

# Selecionar colunas finais e ordernar
df_output = df_with_types.select(
    "userid",
    "timeType_externalCode",
    "startDate",
    "endDate",
    "approvalStatus",
    "quantityInDays",
    "quantityInHours",
    "workflowRequestId",
    "cancellationWorkflowRequestId",
    "fractionQuantity",
    "editable",
    "loaStartJobInfoId",
    "loaEndJobInfoId",
    "loaExpectedReturnDate",
    "loaActualReturnDate",
    "flexibleRequesting",
    "deductionQuantity",
    "startTime",
    "endTime",
    "undeterminedEndDate",
    "recurrenceGroup",
    "displayQuantity",
    "physicalStartDate",
    "physicalEndDate",
    "externalCode",
    "hash_key"
).distinct() \
 .orderBy(
     lpad(col("userid"), 15, "0"),
     to_date(col("startDate"), "dd/MM/yyyy")
 )

print(f"Total de registros: {df_output.count()}")

display(df_output)
# df_output.write.mode("overwrite").saveAsTable("silver.extrator_loa")

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS ptp_silver.extrator_loa (
# MAGIC     user_id STRING,
# MAGIC     timeType_externalCode STRING,
# MAGIC     startDate STRING,
# MAGIC     endDate STRING,
# MAGIC     approvalStatus STRING,
# MAGIC     quantityInDays DECIMAL(22,2),
# MAGIC     quantityInHours DECIMAL(22,2),
# MAGIC     workflowRequestId LONG,
# MAGIC     cancellationWorkflowRequestId LONG,
# MAGIC     fractionQuantity DECIMAL(22,2),
# MAGIC     editable BOOLEAN,
# MAGIC     loaStartJobInfoId LONG,
# MAGIC     loaEndJobInfoId LONG,
# MAGIC     loaExpectedReturnDate STRING,
# MAGIC     loaActualReturnDate STRING,
# MAGIC     flexibleRequesting BOOLEAN,
# MAGIC     deductionQuantity DECIMAL(22,2),
# MAGIC     startTime STRING,
# MAGIC     endTime STRING,
# MAGIC     undeterminedEndDate BOOLEAN,
# MAGIC     recurrenceGroup STRING,
# MAGIC     displayQuantity DECIMAL(22,2),
# MAGIC     physicalStartDate DECIMAL(22,2),
# MAGIC     physicalEndDate DECIMAL(22,2),
# MAGIC     externalCode STRING,
# MAGIC     hash_key STRING
# MAGIC )
# MAGIC USING DELTA;