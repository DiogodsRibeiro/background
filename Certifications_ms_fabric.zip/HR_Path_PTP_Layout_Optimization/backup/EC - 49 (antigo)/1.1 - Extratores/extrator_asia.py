# Databricks notebook source
# Importações
from pyspark.sql import functions as F
from pyspark.sql import Window
from pyspark.sql.types import *

# COMMAND ----------

# CARGA DAS TABELAS BASE COM ALIAS ORIGINAIS

# Arquivos de controle
df_strings = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_strings_tbl.txt", header=True, inferSchema=True, sep=";").alias("s")
df_region = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_reg_region_tbl.txt", header=True, inferSchema=True, sep=";").alias("rr")
df_conv = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_v_ptp_conv_tbl.txt", header=True, inferSchema=True, sep=";").alias("v")


# Arquivos principais
df_job = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_job.txt", header=True, inferSchema=True, sep=";").alias("j")
df_pers_data = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_pers_data_effdt.txt", header=True, inferSchema=True, sep=";").alias("ef")
df_employment = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_employment.txt", header=True, inferSchema=True, sep=";").alias("e")
df_tmp_dat = spark.read.csv("/Volumes/humanresources_insight/ptp_acquisition/ec_49/raw_files/ps_v_ptp_tmp_dat2.txt", header=True, inferSchema=True, sep=";").alias("x")

# COMMAND ----------

# PREPARAÇÃO: FILTROS E BROADCASTS

# Filtrar strings_tbl antecipadamente
df_date_ptp = df_strings.filter(
    (F.col("s.string_id") == "DATE_PTP")
).select(
    F.to_date(F.col("s.string_text"), "dd/MM/yyyy").alias("date_ptp")
).first()

date_ptp_value = df_date_ptp["date_ptp"]

df_ini_mov = df_strings.filter(
    (F.col("s.string_id") == "PTP_INI_MOV")
).select(
    F.to_date(F.col("s.string_text"), "dd/MM/yyyy").alias("ptp_ini_mov")
)

# Broadcast de tabelas pequenas
df_region_filtered = F.broadcast(
    df_region.filter(
        F.col("rr.country").isin(['MYS', 'SGP', 'ARE', 'IND', 'IDN', 'OMN', 'AUS'])
    )
)

# Filtrar conversion table para ABSENCE_ASIA
df_conv_asia = F.broadcast(
    df_conv.filter(F.col("v.v_convert_id") == "ABSENCE_ASIA")
    .withColumn(
        "action_reason_key",
        F.substring(F.col("v.descr100"), 1, 11)
    )
    .withColumn(
        "sex_indicator",
        F.when(F.substring(F.col("v.descr100"), 12, 1) == "|", F.lit(""))
        .otherwise(F.substring(F.col("v.descr100"), 12, 1))
    )
    .withColumn(
        "end_action_key",
        F.when(
            F.substring(F.col("v.descr100"), 12, 1) == "|",
            F.substring(F.col("v.descr100"), 17, 7)
        ).otherwise(
            F.substring(F.col("v.descr100"), 18, 7)
        )
    )
)

# PREPARAÇÃO: DADOS DE PESSOA COM SEX NORMALIZADO

# Window para pegar a maior data efetiva de pessoa
w_pers = Window.partitionBy("ef.emplid").orderBy(F.col("ef.effdt").desc())

df_pers_enriched = df_pers_data.withColumn(
    "rn",
    F.row_number().over(w_pers)
).filter(
    F.col("rn") == 1
).withColumn(
    "sex_normalized",
    F.when(F.trim(F.col("ef.sex")) == "F", F.lit("F"))
    .when(F.trim(F.col("ef.sex")) == "M", F.lit("M"))
    .otherwise(F.lit("X"))
).select(
    F.col("ef.emplid"),
    F.col("ef.effdt"),
    F.col("ef.sex"),
    F.col("sex_normalized")
).alias("ef")

# PREPARAÇÃO: FILTRAR TMP_DAT PARA GO_LIVE

df_tmp_filtered = df_tmp_dat.filter(
    F.col("x.processtype") == "GO_LIVE"
).select(
    F.col("x.oprid").alias("user_id"),
    F.col("x.vp_emplid"),
    F.col("x.empl_rcd")
).alias("x")

# JOIN PRINCIPAL: JOB + REGION + CONVERSION + PERSON + TMP

df_job_filtered = df_job.filter(
    F.col("j.effdt") <= F.lit(date_ptp_value)
).alias("j")

# Join job com region
df_job_region = df_job_filtered.join(
    df_region_filtered,
    F.col("j.reg_region") == F.col("rr.reg_region"),
    "inner"
)

# Join com tmp_dat
df_job_tmp = df_job_region.join(
    df_tmp_filtered,
    (F.col("j.emplid") == F.col("x.vp_emplid")) &
    (F.col("j.empl_rcd") == F.col("x.empl_rcd")),
    "inner"
)

# Join com person data
df_job_person = df_job_tmp.join(
    df_pers_enriched,
    F.col("j.emplid") == F.col("ef.emplid"),
    "inner"
)

# Criar chave de action para join com conversion
df_job_enriched = df_job_person.withColumn(
    "action_key",
    F.concat(F.lit("INI|"), F.col("j.action"), F.lit("|"), F.col("j.action_reason"))
)

# Join com conversion table
df_main = df_job_enriched.join(
    df_conv_asia,
    (F.col("action_key") == F.col("action_reason_key")) &
    (
        (F.col("sex_indicator") == "") |
        (F.col("sex_indicator") == F.col("sex_normalized"))
    ),
    "inner"
)

# Selecionar colunas importantes para os próximos passos
df_main = df_main.select(
    F.col("user_id"),
    F.col("v.v_char_to").alias("timeType_externalCode"),
    F.col("j.emplid").alias("emplid"),
    F.col("j.empl_rcd").alias("empl_rcd"),
    F.col("j.effdt").alias("effdt"),
    F.col("j.effseq").alias("effseq"),
    F.col("j.action").alias("action"),
    F.col("j.action_reason").alias("action_reason"),
    F.col("sex_normalized"),
    F.col("end_action_key")
)

# ENCONTRAR MAIOR EFFDT/EFFSEQ POR EMPLID

# Criar coluna composta para ordenação
df_main = df_main.withColumn(
    "effdt_seq_key",
    F.concat(
        F.date_format(F.col("effdt"), "yyyyMMdd"),
        F.lpad(F.col("effseq"), 4, "0")
    )
)

# Window para encontrar max effdt/seq
w_max = Window.partitionBy(
    F.col("emplid"),
    F.col("empl_rcd")
).orderBy(F.col("effdt_seq_key").desc())

df_main = df_main.withColumn(
    "max_effdt_seq",
    F.first(F.col("effdt_seq_key")).over(w_max)
).filter(
    F.col("effdt_seq_key") == F.col("max_effdt_seq")
)

# ENCONTRAR DATA DE FIM (PRÓXIMA ACTION)

# Preparar segunda conversion table para end actions
df_conv_end = df_conv_asia.select(
    F.col("end_action_key"),
    F.col("sex_indicator").alias("sex_ind_end")
).alias("cv2")

# Self-join de job para encontrar próxima action
df_job_next = df_job.select(
    F.col("j.emplid").alias("next_emplid"),
    F.col("j.empl_rcd").alias("next_empl_rcd"),
    F.col("j.effdt").alias("next_effdt"),
    F.col("j.effseq").alias("next_effseq"),
    F.col("j.action").alias("next_action"),
    F.col("j.action_reason").alias("next_action_reason"),
    F.concat(
        F.date_format(F.col("j.effdt"), "yyyyMMdd"),
        F.lpad(F.col("j.effseq"), 4, "0")
    ).alias("next_effdt_seq_key")
).alias("r")

# Join para encontrar próximas actions
df_with_next = df_main.join(
    df_job_next,
    (F.col("emplid") == F.col("next_emplid")) &
    (F.col("empl_rcd") == F.col("next_empl_rcd")) &
    (F.col("next_effdt_seq_key") > F.col("effdt_seq_key")),
    "left"
)

# Criar chave para validar se é action de fim
df_with_next = df_with_next.withColumn(
    "next_action_key",
    F.concat(F.col("next_action"), F.lit("|"), F.col("next_action_reason"))
)

# Join com conversion end para validar
df_with_end_validated = df_with_next.join(
    df_conv_end,
    (F.col("next_action_key") == F.col("cv2.end_action_key")) &
    (
        (F.col("cv2.sex_ind_end") == "") |
        (F.col("cv2.sex_ind_end") == F.col("sex_normalized"))
    ),
    "left"
)

# Window para pegar a menor data de fim válida
w_min_end = Window.partitionBy(
    F.col("emplid"),
    F.col("empl_rcd"),
    F.col("effdt_seq_key")
).orderBy(F.col("next_effdt").asc())

df_with_end_date = df_with_end_validated.withColumn(
    "rn_end",
    F.row_number().over(w_min_end)
).filter(
    (F.col("rn_end") == 1) | F.col("next_effdt").isNull()
).withColumn(
    "endDate_calc",
    F.when(
        F.col("next_effdt").isNotNull(),
        F.when(
            F.col("next_effdt") == F.col("effdt"),
            F.date_add(F.col("next_effdt"), 1)
        ).otherwise(F.col("next_effdt"))
    )
)

# VERIFICAÇÃO: NÃO PODE HAVER OUTRA ACTION APÓS

df_job_after = df_job.filter(
    F.col("j.effdt") <= F.lit(date_ptp_value)
).select(
    F.col("j.emplid").alias("after_emplid"),
    F.col("j.empl_rcd").alias("after_empl_rcd"),
    F.col("j.action").alias("after_action"),
    F.col("j.action_reason").alias("after_action_reason"),
    F.concat(
        F.date_format(F.col("j.effdt"), "yyyyMMdd"),
        F.lpad(F.col("j.effseq"), 4, "0")
    ).alias("after_effdt_seq_key")
).alias("b")

# Join para verificar se existe action posterior
df_check_after = df_with_end_date.join(
    df_job_after,
    (F.col("emplid") == F.col("after_emplid")) &
    (F.col("empl_rcd") == F.col("after_empl_rcd")) &
    (F.col("after_effdt_seq_key") > F.col("effdt_seq_key")) &
    (F.col("after_effdt_seq_key") <= 
     F.concat(F.date_format(F.lit(date_ptp_value), "yyyyMMdd"), F.lit("9999"))),
    "left"
).withColumn(
    "after_action_key",
    F.concat(F.lit("INI|"), F.col("after_action"), F.lit("|"), F.col("after_action_reason"))
)

# Join com conversion para validar action posterior
df_conv_after = df_conv_asia.select(
    F.col("action_reason_key").alias("after_conv_key"),
    F.col("sex_indicator").alias("sex_ind_after")
).alias("cv3")

df_final_check = df_check_after.join(
    df_conv_after,
    (F.col("after_action_key") == F.col("cv3.after_conv_key")) &
    (
        (F.col("cv3.sex_ind_after") == "") |
        (F.col("cv3.sex_ind_after") == F.col("sex_normalized"))
    ),
    "left"
).filter(
    F.col("cv3.after_conv_key").isNull()  # Não deve existir action posterior válida
)

# SELEÇÃO FINAL E CÁLCULOS

df_base_result = df_final_check.select(
    F.col("user_id"),
    F.col("timeType_externalCode"),
    F.date_format(F.col("effdt"), "dd/MM/yyyy").alias("startDate"),
    F.coalesce(
        F.date_format(F.date_sub(F.col("endDate_calc"), 1), "dd/MM/yyyy"),
        F.lit("")
    ).alias("endDate"),
    F.col("emplid"),
    F.col("empl_rcd")
).distinct()

# Join com employment
df_with_employment = df_base_result.join(
    df_employment.select(
        F.col("e.emplid").alias("e_emplid"),
        F.col("e.hire_dt"),
        F.col("e.rehire_dt")
    ),
    F.col("emplid") == F.col("e_emplid"),
    "inner"
)

# Join com ini_mov para filtro final
df_final_filtered = df_with_employment.crossJoin(df_ini_mov).filter(
    (
        F.coalesce(
            F.to_date(F.col("endDate"), "dd/MM/yyyy"),
            F.col("ptp_ini_mov")
        ) >= F.col("ptp_ini_mov")
    ) &
    (
        F.coalesce(
            F.col("e.rehire_dt"),
            F.coalesce(
                F.col("e.hire_dt"),
                F.to_date(F.col("startDate"), "dd/MM/yyyy")
            )
        ) <= F.to_date(F.col("startDate"), "dd/MM/yyyy")
    )
)

# CÁLCULOS FINAIS E FORMATAÇÃO

df_result = df_final_filtered.select(
    F.col("user_id"),
    F.col("timeType_externalCode"),
    F.col("startDate"),
    F.col("endDate"),
    F.lit("APPROVED").alias("approvalStatus"),
    F.lit("").alias("quantityInDays"),
    F.lit("").alias("quantityInHours"),
    F.lit("").alias("workflowRequestId"),
    F.lit("").alias("cancellationWorkflowRequestId"),
    F.coalesce(
        F.datediff(
            F.to_date(F.col("endDate"), "dd/MM/yyyy"),
            F.to_date(F.col("startDate"), "dd/MM/yyyy")
        ) + 1,
        F.lit(0)
    ).alias("fractionQuantity"),
    F.lit("TRUE").alias("editable"),
    F.lit("").alias("loaStartJobInfoId"),
    F.lit("").alias("loaEndJobInfoId"),
    F.coalesce(
        F.date_format(
            F.date_add(F.to_date(F.col("endDate"), "dd/MM/yyyy"), 1),
            "dd/MM/yyyy"
        ),
        F.date_format(
            F.add_months(F.to_date(F.col("startDate"), "dd/MM/yyyy"), 24),
            "dd/MM/yyyy"
        )
    ).alias("loaExpectedReturnDate"),
    F.coalesce(F.trim(F.col("endDate")), F.lit("")).alias("loaActualReturnDate"),
    F.lit("FALSE").alias("flexibleRequesting"),
    F.lit("").alias("deductionQuantity"),
    F.lit("").alias("startTime"),
    F.lit("").alias("endTime"),
    F.lit("FALSE").alias("undeterminedEndDate"),
    F.lit("").alias("recurrenceGroup"),
    F.lit("").alias("displayQuantity"),
    F.lit("").alias("physicalStartDate"),
    F.lit("").alias("physicalEndDate"),
    F.lit("").alias("externalCode")
).orderBy(
    F.lpad(F.col("user_id"), 15, "0"),
    F.to_date(F.col("startDate"), "dd/MM/yyyy")
)

# Mapeamento de colunas com suas respectivas tipagens e tamanhos máximos, baseado na especificação do SAP SuccessFactors
df_with_types = df_result \
    .withColumn("user_id", F.col("user_id").cast(StringType())) \
    .withColumn("user_id", F.substring(F.col("user_id"), 1, 40)) \
    .withColumn("timeType_externalCode", F.col("timeType_externalCode").cast(StringType())) \
    .withColumn("timeType_externalCode", F.substring(F.col("timeType_externalCode"), 1, 38)) \
    .withColumn("startDate", F.col("startDate").cast(StringType())) \
    .withColumn("endDate", F.col("endDate").cast(StringType())) \
    .withColumn("approvalStatus", F.substring(F.col("approvalStatus"), 1, 128)) \
    .withColumn("quantityInDays", 
                F.when(F.col("quantityInDays") == "", F.lit(None))
                 .otherwise(F.col("quantityInDays").cast(DecimalType(22, 2)))) \
    .withColumn("quantityInHours", 
                F.when(F.col("quantityInHours") == "", F.lit(None))
                 .otherwise(F.col("quantityInHours").cast(DecimalType(22, 2)))) \
    .withColumn("workflowRequestId", 
                F.when(F.col("workflowRequestId") == "", F.lit(None))
                 .otherwise(F.col("workflowRequestId").cast(LongType()))) \
    .withColumn("cancellationWorkflowRequestId", 
                F.when(F.col("cancellationWorkflowRequestId") == "", F.lit(None))
                 .otherwise(F.col("cancellationWorkflowRequestId").cast(LongType()))) \
    .withColumn("fractionQuantity", F.col("fractionQuantity").cast(DecimalType(22, 2))) \
    .withColumn("editable", 
                F.when(F.upper(F.col("editable")) == "TRUE", F.lit(True))
                 .when(F.upper(F.col("editable")) == "FALSE", F.lit(False))
                 .otherwise(F.lit(None)).cast(BooleanType())) \
    .withColumn("loaStartJobInfoId", 
                F.when(F.col("loaStartJobInfoId") == "", F.lit(None))
                 .otherwise(F.col("loaStartJobInfoId").cast(LongType()))) \
    .withColumn("loaEndJobInfoId", 
                F.when(F.col("loaEndJobInfoId") == "", F.lit(None))
                 .otherwise(F.col("loaEndJobInfoId").cast(LongType()))) \
    .withColumn("loaExpectedReturnDate", F.col("loaExpectedReturnDate").cast(StringType())) \
    .withColumn("loaActualReturnDate", F.col("loaActualReturnDate").cast(StringType())) \
    .withColumn("flexibleRequesting", 
                F.when(F.upper(F.col("flexibleRequesting")) == "TRUE", F.lit(True))
                 .when(F.upper(F.col("flexibleRequesting")) == "FALSE", F.lit(False))
                 .otherwise(F.lit(None)).cast(BooleanType())) \
    .withColumn("deductionQuantity", 
                F.when(F.col("deductionQuantity") == "", F.lit(None))
                 .otherwise(F.col("deductionQuantity").cast(DecimalType(22, 2)))) \
    .withColumn("startTime", F.substring(F.col("startTime"), 1, 21)) \
    .withColumn("endTime", F.substring(F.col("endTime"), 1, 21)) \
    .withColumn("undeterminedEndDate", 
                F.when(F.upper(F.col("undeterminedEndDate")) == "TRUE", F.lit(True))
                 .when(F.upper(F.col("undeterminedEndDate")) == "FALSE", F.lit(False))
                 .otherwise(F.lit(None)).cast(BooleanType())) \
    .withColumn("recurrenceGroup", F.substring(F.col("recurrenceGroup"), 1, 38)) \
    .withColumn("displayQuantity", 
                F.when(F.col("displayQuantity") == "", F.lit(None))
                 .otherwise(F.col("displayQuantity").cast(DecimalType(22, 2)))) \
    .withColumn("physicalStartDate", 
                F.when(F.col("physicalStartDate") == "", F.lit(None))
                 .otherwise(F.col("physicalStartDate").cast(DecimalType(22, 2)))) \
    .withColumn("physicalEndDate", 
                F.when(F.col("physicalEndDate") == "", F.lit(None))
                 .otherwise(F.col("physicalEndDate").cast(DecimalType(22, 2)))) \
    .withColumn("externalCode", F.substring(F.col("externalCode"), 1, 128)) \
    .withColumn("hash_key", F.md5(F.concat_ws("||", *[F.coalesce(F.col(c).cast(StringType()), F.lit("")) for c in df_result.columns])))

# Selecionar colunas finais e ordernar
df_output = df_with_types.select(
    "user_id",
    "timeType_externalCode",
    "startDate",
    "endDate",
    "approvalStatus",
    "quantityInDays",
    "quantityInHours",
    "workflowRequestId",
    "cancellationWorkflowRequestId",
    "fractionQuantity",
    "editable",
    "loaStartJobInfoId",
    "loaEndJobInfoId",
    "loaExpectedReturnDate",
    "loaActualReturnDate",
    "flexibleRequesting",
    "deductionQuantity",
    "startTime",
    "endTime",
    "undeterminedEndDate",
    "recurrenceGroup",
    "displayQuantity",
    "physicalStartDate",
    "physicalEndDate",
    "externalCode",
    "hash_key"
).distinct() \
 .orderBy(
     F.lpad(F.col("user_id"), 15, "0"),
     F.to_date(F.col("startDate"), "dd/MM/yyyy")
 )

display(df_output)
# df_output.write.mode("overwrite").saveAsTable("silver.extrator_asia")