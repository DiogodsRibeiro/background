# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Agrupador/utils/utils"

# COMMAND ----------

# Importações
import os
import requests
import pandas as pd
import unicodedata
import re
import matplotlib.pyplot as plt
from pyspark.sql import *
from pyspark.sql.types import *
from pyspark.sql.functions import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output gerado pela HR Path

# COMMAND ----------

df_consolidado = spark.table(SILVER_CONSOLIDADO)

final_col_order = [
    "Descricao_Atividade_Agrupador",
    "Tipo_Atividade_Agrupador",
    "ID_Externo_Agrupador_VALE"
]

df_hash = df_consolidado.withColumn(
    "hash_key", 
    F.md5(F.concat_ws("||", *[
        F.coalesce(F.col(c).cast(StringType()), F.lit("")) 
        for c in final_col_order
    ]))
)

print(df_hash.count())
display(df_hash)
df_hash.createOrReplaceTempView("df_hr_path")


# COMMAND ----------

# MAGIC %md
# MAGIC ### Output gerado pela VALE

# COMMAND ----------

path = "/Volumes/humanresources_insight/acqu_pcehsagrupador/acqu_pcehsagrupador/layout_agrupador/validation_files/"
xlsm_files = [os.path.join(path, f) for f in os.listdir(path) if f.endswith(".xlsm")]

dfs = []
colunas_padrao = None

for file in xlsm_files:
    df = pd.read_excel(file, sheet_name="Arquivo_Layout_SAP", header=0)
    if "GHRM" in file:
      if "Column1" in df.columns:
          df = df.drop(columns=["Column1"])
      if colunas_padrao is None:
          # Pega o padrão do primeiro arquivo não GHRM
          for f2 in xlsm_files:
              if "GHRM" not in f2:
                  df_tmp = pd.read_excel(f2, sheet_name="Arquivo_Layout_SAP", header=0)
                  colunas_padrao = df_tmp.columns
                  break
        # Renomeia as colunas para o padrão
          df.columns = colunas_padrao
    dfs.append(df)

df_validacao = pd.concat(dfs, ignore_index=True)

# Função para normalizar nomes de colunas
def normalize_col(col):
    col = unicodedata.normalize('NFKD', col).encode('ASCII', 'ignore').decode('ASCII')
    col = re.sub(r'[()\[\]]', '', col)
    col = col.replace(' ', '_')
    return col

# Renomear as colunas para os nomes especificados
df_validacao.columns = [
    "Descricao_Atividade_Agrupador",
    "Tipo_Atividade_Agrupador",
    "ID_Externo_Agrupador_VALE"
]

hash_columns = [
    "Descricao_Atividade_Agrupador",
    "Tipo_Atividade_Agrupador",
    "ID_Externo_Agrupador_VALE"
]

# Converter pandas DataFrame para Spark DataFrame
df_validacao = spark.createDataFrame(df_validacao)

df_hash_validacao = df_validacao.withColumn(
    "hash_key", 
    F.md5(F.concat_ws("||", *[
        F.coalesce(F.col(c), F.lit("")) 
        for c in hash_columns if c in df_validacao.columns
    ]))
)

print(df_hash_validacao.count())
display(df_hash_validacao)
df_hash_validacao.createOrReplaceTempView("df_vale")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validação

# COMMAND ----------

validador_agrupadores = spark.sql(
  """
  SELECT
    'VALE' AS responsavel_output,
    Tipo_Atividade_Agrupador,
    count(*) AS qtd
  FROM df_vale
  GROUP BY Tipo_Atividade_Agrupador
  UNION ALL
  SELECT
    'HR Path' AS responsavel_output,
    Tipo_Atividade_Agrupador,
    count(*) AS qtd
  FROM df_hr_path
  GROUP BY Tipo_Atividade_Agrupador
  ORDER BY responsavel_output, Tipo_Atividade_Agrupador
  """
)

df_plot = validador_agrupadores.toPandas()

plt.figure(figsize=(12, 6))
bar_positions = []
bar_labels = []
bar_heights = []
for responsavel in df_plot['responsavel_output'].unique():
    subset = df_plot[df_plot['responsavel_output'] == responsavel]
    labels = subset['Tipo_Atividade_Agrupador'] + " (" + responsavel + ")"
    heights = subset['qtd']
    bars = plt.bar(labels, heights, label=responsavel)
    bar_positions.extend(bars)
    bar_labels.extend(labels)
    bar_heights.extend(heights)

# Adicionar valores exatos acima das barras
for bar, height in zip(bar_positions, bar_heights):
    plt.text(bar.get_x() + bar.get_width()/2, height, f'{int(height)}', ha='center', va='bottom', fontsize=11, fontweight='bold')

plt.ylabel('Quantidade', fontsize=12)
plt.xlabel('Tipo Atividade Agrupador', fontsize=12)
plt.title('Quantidade por Tipo de Atividade Agrupador e Responsável', fontsize=14, fontweight='bold')
plt.xticks(rotation=45, ha='right')
plt.legend(title='Responsável')
plt.tight_layout()
plt.show()

# COMMAND ----------

# Queries corrigidas
result_null = spark.sql(
  """
  SELECT
    COUNT(*) AS count
  FROM df_vale vl
  LEFT JOIN df_hr_path hr
    ON vl.ID_Externo_Agrupador_VALE = hr.ID_Externo_Agrupador_VALE
  WHERE hr.hash_key IS NULL
  """
)

result_match = spark.sql(
  """
  SELECT
    COUNT(*) AS count
  FROM df_vale vl
  LEFT JOIN df_hr_path hr
    ON vl.ID_Externo_Agrupador_VALE = hr.ID_Externo_Agrupador_VALE
  WHERE hr.hash_key IS NOT NULL
  """
)

# Converter para Pandas
df_null = result_null.toPandas()
df_match = result_match.toPandas()

# Extrair valores
sem_match = df_null['count'].iloc[0]
com_match = df_match['count'].iloc[0]
total = sem_match + com_match

# Calcular porcentagens
pct_sem = (sem_match / total) * 100
pct_com = (com_match / total) * 100

# Criar gráfico
import matplotlib.pyplot as plt

categorias = ['Sem Match', 'Com Match']
valores = [sem_match, com_match]
cores = ['#e74c3c', '#2ecc71']

plt.figure(figsize=(10, 6))
barras = plt.bar(categorias, valores, color=cores, edgecolor='black', linewidth=1.2)

# Adicionar valores e porcentagens nas barras
for i, (barra, valor, pct) in enumerate(zip(barras, valores, [pct_sem, pct_com])):
    altura = barra.get_height()
    plt.text(barra.get_x() + barra.get_width()/2., altura/2,
             f'{valor:,}\n({pct:.1f}%)',
             ha='center', va='center', fontsize=12, fontweight='bold', color='white')

plt.ylabel('Quantidade', fontsize=12)
plt.title('Análise de Matches (Agrupadores)', fontsize=14, fontweight='bold')
plt.grid(axis='y', alpha=0.3, linestyle='--')
plt.tight_layout()
plt.show()

# Imprimir resumo
print(f"\n{'='*50}")
print(f"Total de registros: {total:,}")
print(f"Com Match: {com_match:,} ({pct_com:.2f}%)")
print(f"Sem Match: {sem_match:,} ({pct_sem:.2f}%)")
print(f"{'='*50}")

# COMMAND ----------

# Configurações
DATABRICKS_INSTANCE = "https://adb-1155906991732329.9.azuredatabricks.net"
TOKEN = "dapi62975ed2df9e07035b3a9de25038b7ee"
JOB_ID = 362436461326627

headers = {
    "Authorization": f"Bearer {TOKEN}"
}

# 1. Buscar a última run do job
runs_url = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/list"
params = {
    "job_id": JOB_ID,
    "limit": 1,
    "active_only": False
}
runs_resp = requests.get(runs_url, headers=headers, params=params)
run_data = runs_resp.json()
latest_run = run_data["runs"][0]
run_id = latest_run["run_id"]

# 2. Buscar detalhes da run (incluindo tasks)
run_detail_url = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/get"
run_detail_resp = requests.get(run_detail_url, headers=headers, params={"run_id": run_id})
run_detail = run_detail_resp.json()

# 3. Extrair duração de cada notebook (task)
tasks = run_detail.get("tasks", [])
task_data = []
for t in tasks:
    if t.get("not") or t.get("notebook_task"):
        name = t.get("task_key", t.get("notebook_task", {}).get("notebook_path", ""))
        duration = (t["end_time"] - t["start_time"]) / 1000 if t.get("end_time") and t.get("start_time") else 0
        task_data.append({"notebook": name, "duration_sec": duration})

df_tasks = pd.DataFrame(task_data)
df_tasks = df_tasks.sort_values("duration_sec", ascending=False)

# 4. Calcular tempo total em minutos considerando paralelismo em dois momentos
parallel_notebooks_1 = [
    "01_GERE_bronze",
    "03_GHRM_bronze",
    "05_GHP_bronze",
    "07_GHE_bronze"
]

parallel_notebooks_2 = [
    "02_GERE_silver",
    "04_GHRM_silver",
    "06_GHP_silver",
    "08_GHE_silver"
]

df_parallel_1 = df_tasks[df_tasks["notebook"].isin(parallel_notebooks_1)]
df_parallel_2 = df_tasks[df_tasks["notebook"].isin(parallel_notebooks_2)]
df_non_parallel = df_tasks[~df_tasks["notebook"].isin(parallel_notebooks_1 + parallel_notebooks_2)]

parallel_duration_1 = df_parallel_1["duration_sec"].max() if not df_parallel_1.empty else 0
parallel_duration_2 = df_parallel_2["duration_sec"].max() if not df_parallel_2.empty else 0
non_parallel_duration = df_non_parallel["duration_sec"].sum()
total_duration_sec = parallel_duration_1 + parallel_duration_2 + non_parallel_duration
total_duration_min = total_duration_sec / 60

# Tempo total no formato mm:ss
total_min = int(total_duration_sec // 60)
total_sec = int(total_duration_sec % 60)
total_time_str = f"{total_min}m {total_sec}s"

# 5. Gráfico
import matplotlib.patches as mpatches
import matplotlib.lines as mlines

def get_color(nb):
    if nb in parallel_notebooks_1:
        return "#FFD580"
    elif nb in parallel_notebooks_2:
        return "#E89DFA"
    else:
        return "skyblue"

colors = [get_color(nb) for nb in df_tasks["notebook"]]

plt.figure(figsize=(10, 6))
bars = plt.barh(df_tasks["notebook"], df_tasks["duration_sec"], color=colors)

for bar, duration in zip(bars, df_tasks["duration_sec"]):
    plt.text(bar.get_width() + 1, bar.get_y() + bar.get_height()/2, f"{duration:.1f}s", va='center')

plt.axvline(total_duration_sec, color="#FFD580", linestyle="--")

# Legenda customizada com espaçamento aumentado
orange_patch = mpatches.Patch(color='#FFD580', label='Notebooks em paralelo (Momento 1)')
purple_patch = mpatches.Patch(color='#E89DFA', label='Notebooks em paralelo (Momento 2)')
blue_patch = mpatches.Patch(color='skyblue', label='Notebooks sequenciais')
total_line = mlines.Line2D([], [], color='#FFD580', linestyle='--', label=f'Total: {total_time_str}')

plt.legend(
    handles=[orange_patch, purple_patch, blue_patch, total_line],
    loc='lower right',
    borderpad=1.5,      # aumenta o espaçamento interno da legenda
    labelspacing=1.5,   # aumenta o espaçamento entre as linhas da legenda
    handletextpad=1.5,  # aumenta o espaçamento entre o símbolo e o texto
    borderaxespad=7     # aumenta o espaçamento da legenda em relação ao gráfico
)
plt.xlabel("Duração (segundos)")
plt.title("Tempo de execução por notebook - Agrupadores")
plt.tight_layout()
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ![image_1773085298472.png](./image_1773085298472.png "image_1773085298472.png")