# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Agrupador/config/config"

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

# DBTITLE 1,Cell 1
# Utilitários — Layout SAP Agrupador

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.window import Window
import pandas as pd
import os
import io
import openpyxl

def read_excel(path: str, sheet_name: str) -> DataFrame:
    """
    Lê um arquivo Excel do Volume e retorna um DataFrame Spark.
    Todos os campos são lidos como string.
    """
    pdf = pd.read_excel(path, sheet_name=sheet_name, dtype=str, header=0)
    pdf.columns = [c.strip() for c in pdf.columns]
    return spark.createDataFrame(pdf.fillna(""))

def save_table(df: DataFrame, table: str) -> None:
    """Grava um DataFrame como tabela Delta com overwrite."""
    (
        df.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(table)
    )
    print(f"✅ Gravado: {table} ({df.count()} registros)")

def make_chave(df: DataFrame, source_col: str, prefix: str, max_len: int, result_col: str) -> DataFrame:
    """
    Gera chave truncada com prefixo, substituindo '|' por '/'.
    Equivale ao Text.Start("PREFIX" & Text.Replace([col],"|","/"), N) das Power Queries.

    Args:
        source_col: coluna fonte (ex: "GERE")
        prefix:     prefixo a concatenar (ex: "GERE_", "GEREQL_")
        max_len:    57 para agrupador 60 chars, 37 para agrupador 40 chars
        result_col: nome da coluna gerada
    """
    return df.withColumn(
        result_col,
        F.substring(
            F.concat(F.lit(prefix), F.regexp_replace(F.col(source_col), r"\|", "/")),
            1, max_len
        )
    )

def add_upper(df: DataFrame, source_col: str, result_col: str) -> DataFrame:
    """Adiciona coluna UPPER substituindo '|' por '/'."""
    return df.withColumn(
        result_col,
        F.upper(F.regexp_replace(F.col(source_col), r"\|", "/"))
    )

def add_agrupador_index(df: DataFrame, key_upper_col: str, order_col: str, index_col: str) -> DataFrame:
    """
    Adiciona índice 0-based dentro de cada grupo via Window Function.
    Equivale ao Table.AddIndexColumn das Power Queries.

    Args:
        key_upper_col: coluna UPPER usada como chave de partição
        order_col:     coluna de ordenação secundária dentro do grupo
        index_col:     nome da coluna de índice a ser criada
    """
    window = Window.partitionBy(key_upper_col).orderBy(key_upper_col, order_col)
    return df.withColumn(index_col, (F.row_number().over(window) - 1).cast("long"))

def build_agrupador(df: DataFrame, base_col: str, index_col: str, result_col: str) -> DataFrame:
    """
    Constrói a coluna de agrupador final:
    - índice = 0 → valor sem sufixo
    - índice > 0 → valor + " " + índice
    """
    return df.withColumn(
        result_col,
        F.when(
            F.col(index_col) > 0,
            F.concat(F.col(base_col), F.lit(" "), F.col(index_col).cast("string"))
        ).otherwise(F.col(base_col))
    )

def select_final(df: DataFrame, descricao_col: str, tipo_valor: str, id_externo_col: str) -> DataFrame:
    """
    Seleciona as 3 colunas finais do Arquivo_Layout_SAP, filtra nulos e deduplica.
    Usa as constantes COL_DESCRICAO, COL_TIPO e COL_ID_EXTERNO do config.
    """
    return (
        df
        .select(
            F.col(descricao_col).alias(COL_DESCRICAO),
            F.lit(tipo_valor).alias(COL_TIPO),
            F.col(id_externo_col).alias(COL_ID_EXTERNO),
        )
        .filter(F.col(COL_DESCRICAO).isNotNull() & (F.col(COL_DESCRICAO) != ""))
        .dropDuplicates()
        .orderBy(COL_DESCRICAO)
    )

def export_df_to_csv_excel(df: DataFrame, volume_path: str, file_base: str) -> None:
    """
    Exporta um DataFrame para arquivos CSV e Excel em um volume.
    Args:
        df: DataFrame Spark a ser exportado
        volume_path: caminho do volume (ex: '/Volumes/meu_volume/pasta')
        file_base: nome base do arquivo (ex: 'export_agrupador')
    """

    # Remove barra final se houver e monta os caminhos manualmente
    base = volume_path.rstrip("/")
    final_csv   = f"{base}/{file_base}.csv"
    final_excel = f"{base}/{file_base}.xlsx"

    # Garante que o diretório existe
    dbutils.fs.mkdirs(base)

    # Converte Spark -> Pandas uma única vez
    pdf = df.toPandas()

    # --- CSV ---
    with open(final_csv, "w", encoding="utf-8-sig") as f:
        pdf.to_csv(f, index=False)
    print(f"CSV exportado: {final_csv}")

    # --- Excel ---
    buffer = io.BytesIO()
    pdf.to_excel(buffer, index=False, engine="openpyxl")
    buffer.seek(0)
    with open(final_excel, "wb") as f:
        f.write(buffer.read())
    print(f"Excel exportado: {final_excel}")

print("Utilitários carregados.")