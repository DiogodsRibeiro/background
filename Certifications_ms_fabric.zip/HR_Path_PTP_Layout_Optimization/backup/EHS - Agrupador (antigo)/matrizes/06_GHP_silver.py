# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Agrupador/utils/utils"

# COMMAND ----------

# GHP — Camada Silver

df = spark.table(BRONZE_GHP)

# 1) Seleção e Deduplicação por DESCRICAO DO GHP 02

df = (
    df
    .select(
        F.col("`DESCRICAO DO GHP 02`").alias("DESC_GHP_02"),
        F.col("CD_EMPRESA"), F.col("DS_EMPRESA"),
        F.col("COD_LOCAL_FISICO"), F.col("DES_LOCAL_FISICO"),
        F.col("COD_FUNCAO"), F.col("DES_FUNCAO"),
    )
    .dropDuplicates(["DESC_GHP_02"])
    .orderBy("DESC_GHP_02")
)

print(f"Registros únicos por GHP 02: {df.count()}")

# 2) Codigo GHP (ID Externo base, 26 chars)

df = df.withColumn(
    "Codigo_GHP",
    F.substring(F.regexp_replace(F.col("DESC_GHP_02"), r"\|", "/"), 1, 26)
)

# 3) Agrupador 60 Caracteres (IndexA)

df = make_chave(df, "DESC_GHP_02", "", 57, "GHP_60")
df = add_upper(df, "GHP_60", "GHP_60_UPPER")
df = add_agrupador_index(df, "GHP_60_UPPER", "DESC_GHP_02", "IndexA")
df = build_agrupador(df, "GHP_60", "IndexA", "Agrupador_60_Caracteres")

# display(df.select("DESC_GHP_02", "GHP_60", "IndexA", "Agrupador_60_Caracteres").limit(10))

# 4) Agrupador Quali 40 Caracteres (IndexB)
# Substitui `"GHP"` por `"GHPQL"` antes de truncar.

df = df.withColumn("DESC_GHP_ql", F.regexp_replace(F.col("DESC_GHP_02"), "GHP", "GHPQL"))
df = make_chave(df, "DESC_GHP_ql", "", 37, "GHP_40_QL")
df = add_upper(df, "GHP_40_QL", "GHP_40_QL_UPPER")
df = add_agrupador_index(df, "GHP_40_QL_UPPER", "DESC_GHP_02", "IndexB")
df = build_agrupador(df, "GHP_40_QL", "IndexB", "Agrupador_Quali_40_Caracteres")

df_formata = df.select(
    F.col('Agrupador_60_Caracteres').alias('Agrupador 60 Caracteres'),
    F.lit('ZGHP').alias('Tipo Agrupador'),
    F.col('Codigo_GHP').alias('Agrupador Externo Vale'),
    F.lit('').alias('DELIMITADOR COLUNA'),
    F.col('DESC_GHP_02').alias('DESCRICAO DO GHP 02'),
    F.col('CD_EMPRESA'),
    F.col('DS_EMPRESA'),
    F.col('COD_LOCAL_FISICO'),
    F.col('DES_LOCAL_FISICO'),
    F.col('COD_FUNCAO'),
    F.col('DES_FUNCAO')
)

# 5) Seleção Final e Gravação Silver

df_silver = select_final(df, "Agrupador_60_Caracteres", "ZGHP", "Codigo_GHP")

print(f"Registros Formata GHP: {df_formata.count()}")
print(f"Registros Silver GHP: {df_silver.count()}")
# display(df_silver)

# COMMAND ----------

spark.sql("""TRUNCATE TABLE humanresources_insight.silv_pcehsagrupador.arquivo_layout_sap_ghp""")
df_silver.write.insertInto("humanresources_insight.silv_pcehsagrupador.arquivo_layout_sap_ghp")

# COMMAND ----------

export_df_to_csv_excel(df_formata, '/Volumes/humanresources_insight/acqu_pcehsagrupador/acqu_pcehsagrupador/layout_agrupador/output/', 'Formata_Agrupador_GHP')