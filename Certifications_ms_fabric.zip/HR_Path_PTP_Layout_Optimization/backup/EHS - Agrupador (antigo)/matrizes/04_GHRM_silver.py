# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Agrupador/utils/utils"

# COMMAND ----------

# GHRM — Camada Silver

df = spark.table(BRONZE_GHRM)

df = (
    df
    .select(
        F.trim(F.col("COD_UNIDADE")).alias("COD_UNIDADE"),
        F.trim(F.col("DS_UNIDADE")).alias("DS_UNIDADE"),
        F.trim(F.col("COD_LOCAL_FISICO")).alias("COD_LOCAL_FISICO"),
        F.trim(F.col("DS_LOCAL_FISICO")).alias("DS_LOCAL_FISICO"),
        F.trim(F.col("`Desc GHRM Full`")).alias("Desc_GHRM_Full"),
        F.trim(F.col("`EC.Código`")).alias("EC_Codigo"),
    )
    .dropDuplicates()
    .drop("EC_Codigo")
)

print(f"Registros únicos: {df.count()}")


# 2) Agrupador 60 Caracteres  (IndexA)
# M: GHRM 60 = Text.Start( replace(replace(Desc GHRM Full, "|", "/"), "GHRM-", "GHRM_"), 57 )
# Índice: 0-based, por grupo GHRM_60_UPPER; sufixo " N" (espaço + número, sem padding)

df = df.withColumn(
    "GHRM_60",
    F.substring(
        F.regexp_replace(
            F.regexp_replace(F.col("Desc_GHRM_Full"), r"\|", "/"),
            "GHRM-", "GHRM_"
        ),
        1, 57
    )
)
df = df.withColumn("GHRM_60_UPPER", F.upper(F.col("GHRM_60")))

df = add_agrupador_index(df, "GHRM_60_UPPER", "Desc_GHRM_Full", "IndexA")

df = df.withColumn(
    "Agrupador_60_Caracteres",
    F.when(F.col("IndexA") > 0,
        F.concat(F.col("GHRM_60"), F.lit(" "), F.col("IndexA").cast("string"))
    ).otherwise(F.col("GHRM_60"))
)

# 3) Agrupador Quali 40 Caracteres  (IndexB)
# M: GHRM 40 = Text.Start( replace(replace(Desc GHRM Full, "|", "/"), "GHRM-", "GHRMQL_"), 37 )
# Sufixo " N" (espaço + número, sem padding)

df = df.withColumn(
    "GHRM_40",
    F.substring(
        F.regexp_replace(
            F.regexp_replace(F.col("Desc_GHRM_Full"), r"\|", "/"),
            "GHRM-", "GHRMQL_"
        ),
        1, 37
    )
)
df = df.withColumn("GHRM_40_UPPER", F.upper(F.col("GHRM_40")))

df = add_agrupador_index(df, "GHRM_40_UPPER", "Desc_GHRM_Full", "IndexB")

df = df.withColumn(
    "Agrupador_Quali_40_Caracteres",
    F.when(F.col("IndexB") > 0,
        F.concat(F.col("GHRM_40"), F.lit(" "), F.col("IndexB").cast("string"))
    ).otherwise(F.col("GHRM_40"))
)


# 4) Cod GHRM e ID Externo Vale  (Index001)

df = df.withColumn(
    "Cod_GHRM",
    F.concat(F.col("COD_UNIDADE"), F.lit("_"), F.col("COD_LOCAL_FISICO"))
)

df = add_agrupador_index(df, "Cod_GHRM", "Desc_GHRM_Full", "Index001")

df = df.withColumn(
    "Agrupador_Externo_Vale",
    F.when(F.col("Index001") > 0,
        F.concat(F.lit("GHRM_"), F.col("Cod_GHRM"), F.lit("_"), F.col("Index001").cast("string"))
    ).otherwise(F.concat(F.lit("GHRM_"), F.col("Cod_GHRM")))
)


# 5) Montar df_formata e df_silver

df_formata = df.select(
    F.col("Agrupador_60_Caracteres").alias("Agrupador 60 Caracteres"),
    F.lit("ZGHRM").alias("Tipo Agrupador"),
    F.col("Agrupador_Externo_Vale").alias("Agrupador Externo Vale"),
    F.lit("").alias("DELIMITADOR COLUNA"),
    F.col("COD_UNIDADE"),
    F.col("DS_UNIDADE"),
    F.col("COD_LOCAL_FISICO"),
    F.col("DS_LOCAL_FISICO"),
    F.col("Cod_GHRM").alias("Cod GHRM"),
    F.col("Desc_GHRM_Full").alias("Desc GHRM Full"),
)

df_silver = select_final(df, "Agrupador_60_Caracteres", "ZGHRM", "Agrupador_Externo_Vale")

print(f"Registros Formata GHRM: {df_formata.count()}")
print(f"Registros Silver GHRM:  {df_silver.count()}")
# display(df_silver)

# COMMAND ----------

spark.sql("""TRUNCATE TABLE humanresources_insight.silv_pcehsagrupador.arquivo_layout_sap_ghrm""")
df_silver.write.insertInto("humanresources_insight.silv_pcehsagrupador.arquivo_layout_sap_ghrm")

# COMMAND ----------

export_df_to_csv_excel(df_formata, '/Volumes/humanresources_insight/acqu_pcehsagrupador/acqu_pcehsagrupador/layout_agrupador/output/', 'Formata_Agrupador_GHRM')