# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Agrupador/utils/utils"

# COMMAND ----------

# Lê o Excel bruto do Volume e grava na tabela Bronze sem transformações.
df_bronze = read_excel(GHRM_INPUT_PATH, GHRM_SHEET_NAME)

print(f"Registros lidos: {df_bronze.count()}")
print(f"Colunas: {df_bronze.columns}")
# display(df_bronze)

# COMMAND ----------

spark.sql("""TRUNCATE TABLE humanresources_insight.bron_pcehsagrupador.ghrm_raw""")
df_bronze.write.insertInto("humanresources_insight.bron_pcehsagrupador.ghrm_raw")