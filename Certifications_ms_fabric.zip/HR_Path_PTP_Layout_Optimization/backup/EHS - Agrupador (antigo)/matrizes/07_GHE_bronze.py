# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Agrupador/utils/utils"

# COMMAND ----------

# GHE — Camada Bronze
# Lê o Excel bruto do Volume e grava na tabela Bronze sem transformações.

df_bronze = read_excel(GHE_INPUT_PATH, GHE_SHEET_NAME)

print(f"Registros lidos: {df_bronze.count()}")
print(f"Colunas: {df_bronze.columns}")
# display(df_bronze)

# COMMAND ----------

spark.sql("""TRUNCATE TABLE humanresources_insight.bron_pcehsagrupador.ghe_raw""")
df_bronze.write.insertInto("humanresources_insight.bron_pcehsagrupador.ghe_raw")