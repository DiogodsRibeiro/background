# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Agrupador/utils/utils"

# COMMAND ----------

# GHE — Camada Silver

df = spark.table(BRONZE_GHE)

# ═══════════════════════════════════════════════════════════════
# Step 1 — Limpeza (espelhando exatamente o Power Query M)
#
# O código M do Excel faz, nesta ordem:
#   1. Text.Trim em CD_GHE e DS_GHE  →  F.trim() em ambas as colunas
#      (trim completo: esquerda E direita — diferente de lstrip usado antes)
#   2. Selecionar apenas CD_GHE e DS_GHE
#   3. Table.Distinct({'DS_GHE'})  →  dropDuplicates(['DS_GHE'])
#      ATENÇÃO: o dedup é SOMENTE por DS_GHE, não por CD+DS.
#      DS_GHE iguais em CDs diferentes geram apenas 1 linha (o primeiro CD encontrado).
#   4. Replace '|' → '/' em DS_GHE
# ═══════════════════════════════════════════════════════════════

df = (
    df
    .select(
        F.trim(F.col("CD_GHE")).alias("CD_GHE"),
        F.trim(F.col("DS_GHE")).alias("DS_GHE"),     # trim completo (não só lstrip)
    )
    .dropDuplicates(["DS_GHE"])                       # dedup SOMENTE por DS_GHE — igual ao Power Query
)

df = df.withColumn("DS_GHE_clean", F.regexp_replace(F.col("DS_GHE"), r"\|", "/"))

print(f"Registros únicos: {df.count()}")  # esperado: 4697


# 2) IndexG -> ID Externo VALE (zero-padding 3 dígitos)
# Este índice é especial: o sufixo usa `_001`, `_002`... em vez de ` 1`, ` 2`...

df = add_agrupador_index(df, "CD_GHE", "DS_GHE_clean", "IndexG")

df = df.withColumn(
    "ID_Externo_Vale",
    F.when(
        F.col("IndexG") > 0,
        F.concat(
            F.lit("GHE_"), F.col("CD_GHE"), F.lit("_"),
            F.lpad(F.col("IndexG").cast("string"), 3, "0")
        )
    ).otherwise(F.concat(F.lit("GHE_"), F.col("CD_GHE")))
)

# display(df.select("CD_GHE", "DS_GHE", "IndexG", "ID_Externo_Vale").limit(10))

# 3) Index60 -> Agrupador 60 Caracteres

df = make_chave(df, "DS_GHE_clean", "GHE_", 57, "base_60")
df = add_upper(df, "base_60", "chave_60")
df = add_agrupador_index(df, "chave_60", "DS_GHE_clean", "Index60")
df = build_agrupador(df, "base_60", "Index60", "Agrupador_60_Caracteres")

# 4) Index40QL -> Agrupador Quali 40 Caracteres

df = make_chave(df, "DS_GHE_clean", "GHEQL_", 37, "base_40ql")
df = add_upper(df, "base_40ql", "chave_40ql")
df = add_agrupador_index(df, "chave_40ql", "DS_GHE_clean", "Index40QL")
df = build_agrupador(df, "base_40ql", "Index40QL", "Agrupador_Quali_40_Caracteres")

# 5) Index60QT -> Agrupador Quant 60 Caracteres

df = make_chave(df, "DS_GHE_clean", "GHEQT_", 57, "base_60qt")
df = add_upper(df, "base_60qt", "chave_60qt")
df = add_agrupador_index(df, "chave_60qt", "DS_GHE_clean", "Index60QT")
df = build_agrupador(df, "base_60qt", "Index60QT", "Agrupador_Quant_60_Caracteres")

df_formata = df.select(
    F.col('Agrupador_60_Caracteres').alias('Descrição da Atividade (Agrupador)'),
    F.lit('ZGHE').alias('Tipo da Atividade (Agrupador)'),
    F.col('ID_Externo_Vale').alias('ID Externo (Agrupador) VALE'),
    F.lit('').alias('DELIMITADOR COLUNA'),
    F.col('CD_GHE'),
    F.col('DS_GHE')
)

# 6) Seleção Final e Gravação Silver

df_silver = select_final(df, "Agrupador_60_Caracteres", "ZGHE", "ID_Externo_Vale")

print(f"Registros Formata GHE: {df_formata.count()}")
print(f"Registros Silver GHE: {df_silver.count()}")
display(df_silver)


# COMMAND ----------

spark.sql("""TRUNCATE TABLE humanresources_insight.silv_pcehsagrupador.arquivo_layout_sap_ghe""")
df_silver.write.insertInto("humanresources_insight.silv_pcehsagrupador.arquivo_layout_sap_ghe")

# COMMAND ----------

export_df_to_csv_excel(df_formata, '/Volumes/humanresources_insight/acqu_pcehsagrupador/acqu_pcehsagrupador/layout_agrupador/output/', 'Formata_Agrupador_GHE')