# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Matriz Agrupadores/utils/utils"

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

import requests
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.lines as mlines
from pyspark.sql.types import StringType

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output gerado pela HR Path

# COMMAND ----------

df_hr_path = spark.table(SILVER_CONSOLIDADO)

df_hash = df_hr_path.withColumn(
    "hash_key",
    F.md5(F.concat_ws("||", *[
        F.coalesce(F.col(c).cast(StringType()), F.lit(""))
        for c in FINAL_COL_ORDER if c in df_hr_path.columns
    ]))
)

print(f"Total HR Path: {df_hash.count():,}")
display(df_hash)
df_hash.createOrReplaceTempView("df_hr_path")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output gerado pela VALE

# COMMAND ----------

VALIDATION_PATH = (
    "/Volumes/humanresources_insight/acqu_pcehsmatriz/acqu_pcehsmatriz"
    "/matriz_agrupadores/validation_files/"
    "Template_Layout_Matriz_Agrupadores_GHE_GERE_GHP_GHRM_V3(Arquivo_Layout_SAP).csv"
)

df_vale = (
    spark.read
    .format("csv")
    .option("delimiter", ";")
    .option("header", True)
    .option("inferSchema", False)
    .load(VALIDATION_PATH)
)

# Garante tipo string em todas as colunas
for c in df_vale.columns:
    df_vale = df_vale.withColumn(c, F.col(c).cast(StringType()))

# Substitui NULL e 'null' por string vazia
df_vale = null_to_empty(df_vale, FINAL_COL_ORDER)

df_hash_vale = df_vale.withColumn(
    "hash_key",
    F.md5(F.concat_ws("||", *[
        F.coalesce(F.col(c), F.lit(""))
        for c in FINAL_COL_ORDER if c in df_vale.columns
    ]))
)

print(f"Total VALE: {df_hash_vale.count():,}")
display(df_hash_vale)
df_hash_vale.createOrReplaceTempView("df_vale")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validação

# COMMAND ----------

result = spark.sql("""
SELECT
    s.hash_key AS hash_hr_path,
    p.hash_key AS hash_vale,
    CASE WHEN p.hash_key IS NOT NULL THEN '✅ Match' ELSE '❌ Sem match' END AS status,
    s.*
FROM df_hr_path s
LEFT JOIN df_vale p
    ON s.hash_key = p.hash_key
""")

total     = result.count()
matches   = result.filter(F.col("status") == "✅ Match").count()
no_match  = total - matches
pct_com   = (matches  / total * 100) if total > 0 else 0
pct_sem   = (no_match / total * 100) if total > 0 else 0

# Gráfico
labels = ["Com Match", "Sem Match"]
values = [matches, no_match]
colors = ["#2ecc71", "#e74c3c"]

plt.figure(figsize=(8, 5))
bars = plt.bar(labels, values, color=colors, edgecolor="black", linewidth=1.2)

for bar, val, pct in zip(bars, values, [pct_com, pct_sem]):
    plt.text(
        bar.get_x() + bar.get_width() / 2, bar.get_height() / 2,
        f"{val:,}\n({pct:.1f}%)",
        ha="center", va="center", fontsize=12, fontweight="bold", color="white"
    )

plt.ylabel("Quantidade", fontsize=12)
plt.title("Análise de Matches (Matriz Agrupadores) — Output VALE vs Output HR Path",
          fontsize=13, fontweight="bold")
plt.grid(axis="y", alpha=0.3, linestyle="--")
plt.tight_layout()
plt.show()

print(f"\n{'='*55}")
print(f"Total de registros : {total:,}")
print(f"Com Match          : {matches:,}  ({pct_com:.2f}%)")
print(f"Sem Match          : {no_match:,}  ({pct_sem:.2f}%)")
print(f"{'='*55}")

display(result)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tempo de execução do Job

# COMMAND ----------

DATABRICKS_INSTANCE = "https://adb-1155906991732329.9.azuredatabricks.net"
TOKEN    = "dapi62975ed2df9e07035b3a9de25038b7ee"
JOB_ID   = 129565416159133

headers = {"Authorization": f"Bearer {TOKEN}"}

# 1) Última run do job
runs_resp = requests.get(
    f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/list",
    headers=headers,
    params={"job_id": JOB_ID, "limit": 1, "active_only": False}
)
run_id = runs_resp.json()["runs"][0]["run_id"]

# 2) Detalhes da run (tasks)
run_detail = requests.get(
    f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/get",
    headers=headers,
    params={"run_id": run_id}
).json()

# 3) Duração de cada notebook
task_data = []
for t in run_detail.get("tasks", []):
    if t.get("notebook_task"):
        name     = t.get("task_key", t.get("notebook_task", {}).get("notebook_path", ""))
        duration = (t["end_time"] - t["start_time"]) / 1000 if t.get("end_time") and t.get("start_time") else 0
        task_data.append({"notebook": name, "duration_sec": duration})

df_tasks = pd.DataFrame(task_data).sort_values("duration_sec", ascending=False)

# 4) Notebooks que rodam em paralelo (camada Bronze) vs sequenciais
parallel_notebooks = [
    "ec_bronze",
    "ghe_bronze",
    "ghrm_bronze",
    "ghp_bronze",
    "gere_bronze",
]

df_parallel     = df_tasks[df_tasks["notebook"].isin(parallel_notebooks)]
df_non_parallel = df_tasks[~df_tasks["notebook"].isin(parallel_notebooks)]

parallel_duration     = df_parallel["duration_sec"].max() if not df_parallel.empty else 0
non_parallel_duration = df_non_parallel["duration_sec"].sum()
total_duration_sec    = parallel_duration + non_parallel_duration

total_min = int(total_duration_sec // 60)
total_sec = int(total_duration_sec % 60)
total_time_str = f"{total_min}m {total_sec}s"

# 5) Gráfico
colors = ["#FFD580" if nb in parallel_notebooks else "skyblue" for nb in df_tasks["notebook"]]

plt.figure(figsize=(10, 6))
bars = plt.barh(df_tasks["notebook"], df_tasks["duration_sec"], color=colors)

for bar, dur in zip(bars, df_tasks["duration_sec"]):
    plt.text(bar.get_width() + 1, bar.get_y() + bar.get_height() / 2, f"{dur:.1f}s", va="center")

plt.axvline(total_duration_sec, color="#FFD580", linestyle="--")

orange_patch = mpatches.Patch(color="#FFD580", label="Notebooks em paralelo (Bronze)")
blue_patch   = mpatches.Patch(color="skyblue", label="Notebooks sequenciais")
total_line   = mlines.Line2D([], [], color="#FFD580", linestyle="--", label=f"Total: {total_time_str}")

plt.legend(
    handles=[orange_patch, blue_patch, total_line],
    loc="lower right",
    borderpad=1.5,
    labelspacing=1.5,
    handletextpad=1.5,
    borderaxespad=7
)
plt.xlabel("Duração (segundos)")
plt.title("Tempo de execução por notebook — Matriz Agrupadores")
plt.tight_layout()
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ![image_1773259932933.png](./image_1773259932933.png "image_1773259932933.png")