# Databricks notebook source
# Configurações Globais — Layout SAP Matriz Agrupadores

# Volume de entrada
RAW_BASE = "/Volumes/humanresources_insight/acqu_pcehsmatriz/acqu_pcehsmatriz/matriz_agrupadores/raw_files"

EC_INPUT_PATH           = f"{RAW_BASE}/ec_33_03_brasil_EHS_20251215.csv"
DE_PARA_INPUT_PATH      = f"{RAW_BASE}/LOCAL_T_NAO_T_MOCK4.XLSX"
MATRIZ_GHE_INPUT_PATH   = f"{RAW_BASE}/Matriz_Dados_GHE__20251219.csv"
MATRIZ_GERE_INPUT_PATH  = f"{RAW_BASE}/Matriz_Dados_GERE__20251219.csv"
MATRIZ_GHRM_INPUT_PATH  = f"{RAW_BASE}/Matriz_Dados_GHRM__20251215.csv"
MATRIZ_GHP_INPUT_PATH   = f"{RAW_BASE}/Matriz_Dados_GHP_20251215.csv"

# Schemas
BRONZE_SCHEMA = "humanresources_insight.bron_pcehsmatriz"
SILVER_SCHEMA  = "humanresources_insight.silv_pcehsmatriz"

# Tabelas Bronze
BRONZE_EC               = f"{BRONZE_SCHEMA}.ec_33_03_brasil_ehs"
BRONZE_DE_PARA          = f"{BRONZE_SCHEMA}.de_para_local_fisico_t"
BRONZE_MATRIZ_GHE       = f"{BRONZE_SCHEMA}.matriz_dados_ghe"
BRONZE_MATRIZ_GERE      = f"{BRONZE_SCHEMA}.matriz_dados_gere"
BRONZE_MATRIZ_GHRM      = f"{BRONZE_SCHEMA}.matriz_dados_ghrm"
BRONZE_MATRIZ_GHP       = f"{BRONZE_SCHEMA}.matriz_dados_ghp"

# Tabelas Silver
SILVER_FORMATA_MATRIZ   = f"{SILVER_SCHEMA}.formata_matriz"
SILVER_CONSOLIDADO      = f"{SILVER_SCHEMA}.matriz_agrup_arquivo_layout_sap"

# Nomes das abas (Excel)
DE_PARA_SHEET_NAME      = "DE_PARA_Local_Fisico_T"

# Colunas finais do layout SAP
FINAL_COL_ORDER = [
    "Cargo EC", "CARGA_HORARIA", "TURNO", "Modalidade", "Tarefa EC",
    "Estabelecimento", "Local SSO", "Local Físico", "GHE", "GERE", "GHRM", "GHP",
    "ID Externo Estabelecimento VALE", "ID Externo Local SSO VALE",
    "ID Externo Local Físico VALE", "ID Externo GHE VALE",
    "ID Externo GERE VALE", "ID Externo GHRM VALE", "ID Externo GHP VALE",
]

print("Configurações carregadas.")