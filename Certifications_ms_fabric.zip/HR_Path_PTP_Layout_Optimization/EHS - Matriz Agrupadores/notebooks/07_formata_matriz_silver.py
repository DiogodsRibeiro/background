# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Matriz Agrupadores/utils/utils"

# COMMAND ----------

# Formata Matriz — Camada Silver
# Une EC com as quatro matrizes (GHE, GERE, GHRM, GHP) via LEFT JOINs sequenciais.
# Depende de: 01_ec_bronze, 03_ghe_bronze, 04_ghrm_bronze, 05_ghp_bronze, 06_gere_bronze.

# Leitura das fontes Bronze
df_ec   = spark.table(BRONZE_EC)
df_ghe  = spark.table(BRONZE_MATRIZ_GHE)
df_gere = spark.table(BRONZE_MATRIZ_GERE)
df_ghrm = spark.table(BRONZE_MATRIZ_GHRM)
df_ghp  = spark.table(BRONZE_MATRIZ_GHP)

print("Contagem por fonte:")
print(f"  EC:   {df_ec.count():>8} registros")
print(f"  GHE:  {df_ghe.count():>8} registros")
print(f"  GERE: {df_gere.count():>8} registros")
print(f"  GHRM: {df_ghrm.count():>8} registros")
print(f"  GHP:  {df_ghp.count():>8} registros")

# Prefixação das tabelas filhas (chaves de join já com _ conforme Databricks)
df_ghe_j  = prefix_df(df_ghe,  "Matriz_Dados_GHE",  "MATRICULA", "_join_ghe")
df_gere_j = prefix_df(df_gere, "Matriz_Dados_GERE", "MATRICULA", "_join_gere")
df_ghrm_j = prefix_df(df_ghrm, "Matriz_Dados_GHRM", "ID_do_Usuario_EC", "_join_ghrm")
df_ghp_j  = prefix_df(df_ghp,  "Matriz_Dados_GHP",  "MATRICULA", "_join_ghp")

# Cache da base EC
df_ec.cache()

#  JOINs sequenciais
# JOIN 1: EC ← GHE
df_formata = df_ec.join(
    df_ghe_j,
    df_ec["ID_do_Usuario_EC"] == df_ghe_j["_join_ghe"],
    "left"
).drop("_join_ghe")

# JOIN 2: + GERE
df_formata = df_formata.join(
    df_gere_j,
    df_formata["ID_do_Usuario_EC"] == df_gere_j["_join_gere"],
    "left"
).drop("_join_gere")

# JOIN 3: + GHRM
df_formata = df_formata.join(
    df_ghrm_j,
    df_formata["ID_do_Usuario_EC"] == df_ghrm_j["_join_ghrm"],
    "left"
).drop("_join_ghrm")

# JOIN 4: + GHP
df_formata = df_formata.join(
    df_ghp_j,
    df_formata["ID_do_Usuario_EC"] == df_ghp_j["_join_ghp"],
    "left"
).drop("_join_ghp")

# Libera cache após os joins
df_ec.unpersist()

# ── Filtro de IDs Externos não nulos ─────────────────────────────────────────
df_formata = df_formata.filter(
    F.col("`Matriz_Dados_GHE.ID_Externo_Agrupador_VALE`").isNotNull() &
    F.col("`Matriz_Dados_GERE.ID_Externo_Agrupador_VALE`").isNotNull() &
    F.col("`Matriz_Dados_GHRM.Agrupador_Externo_Vale`").isNotNull()
)

# ── Deduplicação ──────────────────────────────────────────────────────────────
# 1) Global — remove linhas completamente idênticas
df_formata = df_formata.dropDuplicates()

# 2) Por subset de colunas-chave de negócio
key_subset = [
    "position",
    "Cargo_EC",
    "Cargo_People",
    "Cargo",
    "CARGA_HORARIA",
    "TURNO",
    "Modalidade",
    "Tarefa_EC",
    "Estabelecimento_EC",
    "Estabelecimento_People",
    "Local_SSO_EC",
    "Local_SSO_SDWeb",
    "Local_Fisico_EC",
    "Local_Fisico_People",
    "Matriz_Dados_GHE.ID_Externo_Agrupador_VALE",
    "Matriz_Dados_GERE.ID_Externo_Agrupador_VALE",
    "Matriz_Dados_GHRM.Agrupador_Externo_Vale",
    "Matriz_Dados_GHP.ID_Externo_Agrupador_VALE",
    "ID_do_Usuario_EC",
]

# Garante segurança: usa apenas colunas que existam no DataFrame
key_subset = [c for c in key_subset if c in df_formata.columns]

df_formata = df_formata.dropDuplicates(key_subset)

print(f"Total de registros após joins e deduplicação: {df_formata.count()}")
# display(df_formata)

# COMMAND ----------

save_table(df_formata, SILVER_FORMATA_MATRIZ)

# COMMAND ----------

export_df_to_csv_excel(
    df_formata,
    "/Volumes/humanresources_insight/acqu_pcehsmatriz/acqu_pcehsmatriz/matriz_agrupadores/output/",
    "Formata_Matriz"
)