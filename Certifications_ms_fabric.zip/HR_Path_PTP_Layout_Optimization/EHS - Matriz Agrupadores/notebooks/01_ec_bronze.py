# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Matriz Agrupadores/utils/utils"

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

# EC 33_03 Brasil EHS — Camada Bronze
# Lê o CSV bruto do Volume e grava na tabela Bronze sem transformações.

df_bronze = read_csv_semicolon(EC_INPUT_PATH)
df_bronze = rename_cols(df_bronze)

print(f"Registros lidos: {df_bronze.count()}")
print(f"Colunas: {df_bronze.columns}")
# display(df_bronze)

# COMMAND ----------

save_table(df_bronze, BRONZE_EC)