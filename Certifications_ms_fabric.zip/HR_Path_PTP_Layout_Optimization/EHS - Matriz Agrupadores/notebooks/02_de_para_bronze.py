# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Matriz Agrupadores/utils/utils"

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

# DE_PARA Local Físico T — Camada Bronze
# Lê o Excel bruto do Volume (cabeçalho na linha 2) e grava na tabela Bronze.

df_bronze = read_excel_with_header(DE_PARA_INPUT_PATH, DE_PARA_SHEET_NAME, header_row=1)

# Renomeia colunas para os nomes finais do Power Query
df_bronze = df_bronze.toDF("LOCATION", "DESCR", "CD_Local_Nao_T", "DESCR_Local_Nao_T")

# Normaliza nomes de coluna (remove espaços residuais)
df_bronze = rename_cols(df_bronze)

print(f"Registros lidos: {df_bronze.count()}")
print(f"Colunas: {df_bronze.columns}")
# display(df_bronze)

# COMMAND ----------

save_table(df_bronze, BRONZE_DE_PARA)