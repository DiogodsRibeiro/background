# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Matriz Agrupadores/utils/utils"

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

# Arquivo Layout SAP — Consolidação Final Silver
# Formata o DataFrame da camada formata_matriz para o layout final exigido pelo SAP.
# Depende de: 07_formata_matriz_silver.

from pyspark.sql.types import StringType

df = spark.table(SILVER_FORMATA_MATRIZ)

# 1) Remoção de colunas de diagnóstico e intermediárias
cols_to_drop = [
    "position", "Cargo_People", "Cargo",
    "Estabelecimento_People", "Local_SSO_SDWeb", "Local_Fisico_People",
    "ID_do_Usuario_EC",
    # GHE
    "Matriz_Dados_GHE_COD_CARGO", "Matriz_Dados_GHE_DES_CARGO",
    "Matriz_Dados_GHE_COD_CARGA_HOR", "Matriz_Dados_GHE_COD_TURNO",
    "Matriz_Dados_GHE_COD_FUNCAO", "Matriz_Dados_GHE_DES_FUNCAO",
    "Matriz_Dados_GHE_CD_ESTABELECIMENTO", "Matriz_Dados_GHE_DS_ESTABELECIMENTO",
    "Matriz_Dados_GHE_CD_UNIDADE",
    "Matriz_Dados_GHE_DE_PARA_LOCAL_SSO_CD", "Matriz_Dados_GHE_LOCAL_SSO_X_DE_PARA",
    "Matriz_Dados_GHE_COD_LOCAL_FISICO", "Matriz_Dados_GHE_DE_PARA_LOCAL_FISICO_T_CD",
    "Matriz_Dados_GHE_LOCAL_FISICO_X_NAO_T",
    "Matriz_Dados_GHE_NOME",
    "Matriz_Dados_GHE_DT_ADMISSAO", "Matriz_Dados_GHE_DT_DEMISSAO",
    "Matriz_Dados_GHE_SITUACAO", "Matriz_Dados_GHE_NU_MATRIZ_GHE",
    "Matriz_Dados_GHE_STATUS", "Matriz_Dados_GHE_DATA_HIST_GHE",
    "Matriz_Dados_GHE_CD_GHE", "Matriz_Dados_GHE_DS_GHE",
    # GERE
    "Matriz_Dados_GERE_COD_EMPRESA", "Matriz_Dados_GERE_EMPRESA",
    "Matriz_Dados_GERE_COD_LOCAL_SSO", "Matriz_Dados_GERE_LOCAL_SSO",
    "Matriz_Dados_GERE_NOME",
    "Matriz_Dados_GERE_COD_CARGO", "Matriz_Dados_GERE_CARGO",
    "Matriz_Dados_GERE_COD_FUNCAO", "Matriz_Dados_GERE_FUNCAO",
    "Matriz_Dados_GERE_COD_LOCAL_DE_TRABALHO", "Matriz_Dados_GERE_LOCAL_DE_TRABALHO",
    "Matriz_Dados_GERE_TURNO", "Matriz_Dados_GERE_CODIGO_GERE", "Matriz_Dados_GERE_GERE",
    "Matriz_Dados_GERE_CD_LOCAL_FISICO_NAO_T", "Matriz_Dados_GERE_DESC_LOCAL_FISICO_NAO_T",
    # GHRM
    "Matriz_Dados_GHRM_Cargo_People", "Matriz_Dados_GHRM_Cargo",
    "Matriz_Dados_GHRM_CARGA_HORARIA", "Matriz_Dados_GHRM_TURNO",
    "Matriz_Dados_GHRM_Tarefa_EC", "Matriz_Dados_GHRM_Estabelecimento_EC",
    "Matriz_Dados_GHRM_Estabelecimento_People", "Matriz_Dados_GHRM_Local_SSO_EC",
    "Matriz_Dados_GHRM_Local_SSO_SDWeb", "Matriz_Dados_GHRM_Local_Fisico_EC",
    "Matriz_Dados_GHRM_Local_Fisico_People",
    "Matriz_Dados_GHRM_Codigo_GHRM", "Matriz_Dados_GHRM_Desc_GHRM_Full",
    # GHP
    "Matriz_Dados_GHP_CD_EMPRESA", "Matriz_Dados_GHP_DS_EMPRESA",
    "Matriz_Dados_GHP_COD_CARGO", "Matriz_Dados_GHP_COD_CARGA_HOR",
    "Matriz_Dados_GHP_COD_TURNO", "Matriz_Dados_GHP_COD_FUNCAO",
    "Matriz_Dados_GHP_COD_ESTABELECIMENTO", "Matriz_Dados_GHP_DS_ESTABELECIMENTO",
    "Matriz_Dados_GHP_COD_LOCAL_SSO", "Matriz_Dados_GHP_DES_LOCAL_SSO",
    "Matriz_Dados_GHP_COD_LOCAL_FISICO", "Matriz_Dados_GHP_DES_LOCAL_FISICO",
    "Matriz_Dados_GHP_DESCRICAO_DO_GHP_02",
]
existing_cols = set(df.columns)
df = df.drop(*[c for c in cols_to_drop if c in existing_cols])

# 2) Normalização de Modalidade
df = df.withColumn(
    "Modalidade",
    F.when(F.trim(F.col("Modalidade")) == "Remoto frequente", "RF")
     .when(F.trim(F.col("Modalidade")) == "On-Site",          "OS")
     .when(F.trim(F.col("Modalidade")) == "Remoto eventual",  "RE")
     .otherwise(F.trim(F.col("Modalidade")))
)

# 3) Colunas de lookup vazias (preenchidas no SAP / sistema destino)
for col_name in ["Estabelecimento", "Local SSO", "Local Físico", "GHE", "GERE", "GHRM", "GHP"]:
    df = df.withColumn(col_name, F.lit("").cast(StringType()))

# 4) Renomeação para nomes de negócio do layout SAP
rename_map = {
    "Estabelecimento_EC":                           "ID Externo Estabelecimento VALE",
    "Local_SSO_EC":                                 "ID Externo Local SSO VALE",
    "Local_Fisico_EC":                              "ID Externo Local Físico VALE",
    "Matriz_Dados_GHE_ID_Externo_Agrupador_VALE":  "ID Externo GHE VALE",
    "Matriz_Dados_GERE_ID_EXTERNO_AGRUPADOR_VALE": "ID Externo GERE VALE",
    "Matriz_Dados_GHRM_Agrupador_Externo_Vale":    "ID Externo GHRM VALE",
    "Matriz_Dados_GHP_ID_Externo_Agrupador_VALE":  "ID Externo GHP VALE",
    "Cargo_EC":  "Cargo EC",
    "Tarefa_EC": "Tarefa EC",
}
for old, new in rename_map.items():
    if old in df.columns:
        df = df.withColumnRenamed(old, new)

# 5) Reordenação para o layout final SAP (usa a constante do config)
safe_col_order = [c for c in FINAL_COL_ORDER if c in df.columns]
df = df.select(safe_col_order)

# 6) Filtro final + deduplicação
df = df.filter(
    F.col("ID Externo GHE VALE").isNotNull()  &
    F.col("ID Externo GERE VALE").isNotNull() &
    F.col("ID Externo GHRM VALE").isNotNull()
).dropDuplicates()

# 7) Substitui NULL e 'null' por string vazia nas colunas finais
df = null_to_empty(df, FINAL_COL_ORDER)

print(f"Total de registros no layout final: {df.count()}")
# display(df)

# COMMAND ----------

save_table(df, SILVER_CONSOLIDADO)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Gerar arquivo do layout final no volume

# COMMAND ----------

export_df_to_csv_excel(
    df,
    "/Volumes/humanresources_insight/acqu_pcehsmatriz/acqu_pcehsmatriz/matriz_agrupadores/output/",
    "Template_Layout_Matriz_Agrupadores"
)