# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Matriz Agrupadores/utils/utils"

# COMMAND ----------

# Matriz Dados GERE — Camada Bronze
# Particularidade: enriquece os dados com o DE_PARA de Local Físico T antes de gravar.
# Depende de: 01_ec_bronze (BRONZE_EC) e 02_de_para_bronze (BRONZE_DE_PARA).

BASE_PATH = "/Volumes/humanresources_insight/acqu_pcehsmatriz/acqu_pcehsmatriz/matriz_agrupadores/raw_files/"
PATH_SOURCE_GERE = f"{BASE_PATH}/Matriz_Dados_GERE__20251219.csv"

# Leitura do CSV GERE
df_gere = (
    spark.read
    .option("sep", ";")
    .option("encoding", "UTF-8")
    .option("header", "true")
    .option("inferSchema", "false")
    .csv(PATH_SOURCE_GERE)
)

# Leitura da tabela DE_PARA já persistida no Delta
df_de_para = spark.table(BRONZE_DE_PARA)

# Seleciona e renomeia colunas do DE_PARA para evitar ambiguidade no join
df_de_para_sel = (
    df_de_para
    .select("LOCATION", "CD_Local_Nao_T", "DESCR_Local_Nao_T")
    .withColumnRenamed("CD_Local_Nao_T", "CD_Local_Nao_T_join")
    .withColumnRenamed("DESCR_Local_Nao_T", "DESCR_Local_Nao_T_join")
)


# LEFT JOIN com broadcast na tabela pequena DE_PARA
df_gere = df_gere.join(
    F.broadcast(df_de_para_sel),
    df_gere["`Cód. Local de Trabalho`"] == df_de_para_sel["LOCATION"],
    "left"
).drop("LOCATION")

# Colunas derivadas pós-join
df_bronze = (
    df_gere
    .withColumn(
        "CD LOCAL FISICO NAO T",
        F.when(F.col("CD_Local_Nao_T_join").isNull(), F.col("`Cód. Local de Trabalho`"))
         .otherwise(F.col("CD_Local_Nao_T_join"))
    )
    .withColumn(
        "DESC LOCAL FISICO NAO T",
        F.when(F.col("DESCR_Local_Nao_T_join").isNull(), F.col("`Local de Trabalho`"))
         .otherwise(F.col("DESCR_Local_Nao_T_join"))
    )
    .drop("CD_Local_Nao_T_join", "DESCR_Local_Nao_T_join")
)

# Normaliza colunas: remove acentos, espaços → _, maiúsculas
df_bronze = rename_cols(df_bronze, to_upper=True)

print(f"Registros lidos: {df_bronze.count()}")
print(f"Colunas ({len(df_bronze.columns)}): {df_bronze.columns}")
display(df_bronze)

# COMMAND ----------

save_table(df_bronze, BRONZE_MATRIZ_GERE)