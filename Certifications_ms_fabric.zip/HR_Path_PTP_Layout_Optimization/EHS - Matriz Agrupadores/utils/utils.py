# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Matriz Agrupadores/config/config"

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

# DBTITLE 1,Cell 1
# Utilitários — Layout SAP Matriz Agrupadores

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import StringType
import pandas as pd
import unicodedata
import io
import openpyxl


def read_csv_semicolon(path: str) -> DataFrame:
    """
    Lê um arquivo CSV separado por ponto-e-vírgula do Volume e retorna um DataFrame Spark.
    Todos os campos são lidos como string. Aplica trim em todas as colunas.
    """
    df = (
        spark.read
        .option("sep", ";")
        .option("encoding", "UTF-8")
        .option("header", "true")
        .option("inferSchema", "false")
        .csv(path)
    )
    str_cols = [c for c, t in df.dtypes if t == "string"]
    df = df.select(
        *[F.trim(F.col(c)).alias(c) if c in str_cols else F.col(c) for c in df.columns]
    )
    return df


def read_excel_with_header(path: str, sheet_name: str, header_row: int = 0) -> DataFrame:
    """
    Lê um arquivo Excel do Volume e retorna um DataFrame Spark.
    Permite especificar a linha do cabeçalho (0-based). Todos os campos são lidos como string.
    """
    pdf = pd.read_excel(path, sheet_name=sheet_name, dtype=str, header=header_row)
    pdf = pdf.applymap(lambda x: x.strip() if isinstance(x, str) and x != "nan" else None)
    return spark.createDataFrame(pdf)


def normalize_col(col_name: str, to_upper: bool = False) -> str:
    """
    Normaliza nome de coluna: strip, substitui espaços por '_', remove parênteses e pontos.
    Se to_upper=True, remove acentos e converte para maiúsculas (usado em GERE).
    """
    col_name = col_name.strip().replace(" ", "_").replace(")", "").replace("(", "").replace(".", "")
    if to_upper:
        col_name = unicodedata.normalize("NFKD", col_name).encode("ASCII", "ignore").decode("ASCII")
        col_name = col_name.upper()
    return col_name


def rename_cols(df: DataFrame, to_upper: bool = False) -> DataFrame:
    """Aplica normalize_col em todas as colunas de um DataFrame."""
    new_names = [normalize_col(c, to_upper=to_upper) for c in df.columns]
    return df.toDF(*new_names)


def save_table(df: DataFrame, table: str) -> None:
    """Trunca e reinsere um DataFrame como tabela Delta."""
    spark.sql(f"TRUNCATE TABLE {table}")
    df.write.insertInto(table)
    print(f"✅ Gravado: {table} ({df.count()} registros)")


def prefix_df(df: DataFrame, prefix: str, join_col: str, join_alias: str) -> DataFrame:
    """
    Renomeia todas as colunas de `df` com `prefix.coluna`,
    exceto a coluna de join que recebe o alias `join_alias`.
    """
    exprs = []
    for c in df.columns:
        if c == join_col:
            exprs.append(F.col(c).alias(join_alias))
        else:
            exprs.append(F.col(c).alias(f"{prefix}.{c}"))
    return df.select(exprs)


def null_to_empty(df: DataFrame, cols: list) -> DataFrame:
    """Substitui NULL e a string 'null' por string vazia nas colunas informadas."""
    for c in cols:
        if c in df.columns:
            df = df.withColumn(
                c,
                F.when(F.col(c).isNull() | (F.trim(F.col(c)) == "null"), F.lit(""))
                 .otherwise(F.col(c))
            )
    return df


def export_df_to_csv_excel(df: DataFrame, volume_path: str, file_base: str) -> None:
    """
    Exporta um DataFrame para arquivos CSV e Excel em um volume.
    Args:
        df: DataFrame Spark a ser exportado
        volume_path: caminho do volume (ex: '/Volumes/meu_volume/pasta')
        file_base: nome base do arquivo (ex: 'Template_Layout_Matriz_Agrupadores')
    """
    base = volume_path.rstrip("/")
    final_csv   = f"{base}/{file_base}.csv"
    final_excel = f"{base}/{file_base}.xlsx"

    dbutils.fs.mkdirs(base)

    pdf = df.toPandas()

    # --- CSV ---
    with open(final_csv, "w", encoding="utf-8-sig") as f:
        pdf.to_csv(f, index=False)
    print(f"CSV exportado: {final_csv}")

    # --- Excel ---
    buffer = io.BytesIO()
    pdf.to_excel(buffer, index=False, engine="openpyxl")
    buffer.seek(0)
    with open(final_excel, "wb") as f:
        f.write(buffer.read())
    print(f"Excel exportado: {final_excel}")


print("Utilitários carregados.")