# Databricks notebook source
# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Agrupador/utils/utils"

# COMMAND ----------

# Importações
import os
import requests
import pandas as pd
import unicodedata
import re
import matplotlib.pyplot as plt
from pyspark.sql import *
from pyspark.sql.types import *
from pyspark.sql.functions import *

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output gerado pela HR Path

# COMMAND ----------

df_consolidado = spark.table(SILVER_CONSOLIDADO)

final_col_order = [
    "Descricao_Atividade_Agrupador",
    "Tipo_Atividade_Agrupador",
    "ID_Externo_Agrupador_VALE"
]

df_hash = df_consolidado.withColumn(
    "hash_key", 
    F.md5(F.concat_ws("||", *[
        F.coalesce(F.col(c).cast(StringType()), F.lit("")) 
        for c in final_col_order
    ]))
)

print(df_hash.count())
display(df_hash)
df_hash.createOrReplaceTempView("df_hr_path")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Output gerado pela VALE

# COMMAND ----------

path = "/Volumes/humanresources_insight/acqu_pcehsagrupador/acqu_pcehsagrupador/layout_agrupador/validation_files/"
xlsm_files = [os.path.join(path, f) for f in os.listdir(path) if f.endswith(".xlsm")]

dfs = []
colunas_padrao = None

for file in xlsm_files:
    df = pd.read_excel(file, sheet_name="Arquivo_Layout_SAP", header=0)
    if "GHRM" in file:
      if "Column1" in df.columns:
          df = df.drop(columns=["Column1"])
      if colunas_padrao is None:
          for f2 in xlsm_files:
              if "GHRM" not in f2:
                  df_tmp = pd.read_excel(f2, sheet_name="Arquivo_Layout_SAP", header=0)
                  colunas_padrao = df_tmp.columns
                  break
          df.columns = colunas_padrao
    dfs.append(df)

df_validacao = pd.concat(dfs, ignore_index=True)

df_validacao.columns = [
    "Descricao_Atividade_Agrupador",
    "Tipo_Atividade_Agrupador",
    "ID_Externo_Agrupador_VALE"
]

hash_columns = [
    "Descricao_Atividade_Agrupador",
    "Tipo_Atividade_Agrupador",
    "ID_Externo_Agrupador_VALE"
]

df_validacao = spark.createDataFrame(df_validacao)

df_hash_validacao = df_validacao.withColumn(
    "hash_key", 
    F.md5(F.concat_ws("||", *[
        F.coalesce(F.col(c), F.lit("")) 
        for c in hash_columns if c in df_validacao.columns
    ]))
)

print(df_hash_validacao.count())
display(df_hash_validacao)
df_hash_validacao.createOrReplaceTempView("df_vale")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validação

# COMMAND ----------

validador_agrupadores = spark.sql(
  """
  SELECT
    'VALE' AS responsavel_output,
    Tipo_Atividade_Agrupador,
    count(*) AS qtd
  FROM df_vale
  GROUP BY Tipo_Atividade_Agrupador
  UNION ALL
  SELECT
    'HR Path' AS responsavel_output,
    Tipo_Atividade_Agrupador,
    count(*) AS qtd
  FROM df_hr_path
  GROUP BY Tipo_Atividade_Agrupador
  ORDER BY responsavel_output, Tipo_Atividade_Agrupador
  """
)

df_plot = validador_agrupadores.toPandas()

plt.figure(figsize=(12, 6))
bar_positions = []
bar_labels = []
bar_heights = []
for responsavel in df_plot['responsavel_output'].unique():
    subset = df_plot[df_plot['responsavel_output'] == responsavel]
    labels = subset['Tipo_Atividade_Agrupador'] + " (" + responsavel + ")"
    heights = subset['qtd']
    bars = plt.bar(labels, heights, label=responsavel)
    bar_positions.extend(bars)
    bar_labels.extend(labels)
    bar_heights.extend(heights)

for bar, height in zip(bar_positions, bar_heights):
    plt.text(bar.get_x() + bar.get_width()/2, height, f'{int(height)}', ha='center', va='bottom', fontsize=11, fontweight='bold')

plt.ylabel('Quantidade', fontsize=12)
plt.xlabel('Tipo Atividade Agrupador', fontsize=12)
plt.title('Quantidade por Tipo de Atividade Agrupador e Responsável', fontsize=14, fontweight='bold')
plt.xticks(rotation=45, ha='right')
plt.legend(title='Responsável')
plt.tight_layout()
plt.show()

# COMMAND ----------

result_null = spark.sql(
  """
  SELECT COUNT(*) AS count
  FROM df_vale vl
  LEFT JOIN df_hr_path hr
    ON vl.ID_Externo_Agrupador_VALE = hr.ID_Externo_Agrupador_VALE
  WHERE hr.hash_key IS NULL
  """
)

result_match = spark.sql(
  """
  SELECT COUNT(*) AS count
  FROM df_vale vl
  LEFT JOIN df_hr_path hr
    ON vl.ID_Externo_Agrupador_VALE = hr.ID_Externo_Agrupador_VALE
  WHERE hr.hash_key IS NOT NULL
  """
)

df_null = result_null.toPandas()
df_match = result_match.toPandas()

sem_match = df_null['count'].iloc[0]
com_match = df_match['count'].iloc[0]
total = sem_match + com_match

pct_sem = (sem_match / total) * 100
pct_com = (com_match / total) * 100

categorias = ['Sem Match', 'Com Match']
valores = [sem_match, com_match]
cores = ['#e74c3c', '#2ecc71']

plt.figure(figsize=(10, 6))
barras = plt.bar(categorias, valores, color=cores, edgecolor='black', linewidth=1.2)

for i, (barra, valor, pct) in enumerate(zip(barras, valores, [pct_sem, pct_com])):
    altura = barra.get_height()
    plt.text(barra.get_x() + barra.get_width()/2., altura/2,
             f'{valor:,}\n({pct:.1f}%)',
             ha='center', va='center', fontsize=12, fontweight='bold', color='white')

plt.ylabel('Quantidade', fontsize=12)
plt.title('Análise de Matches (Agrupadores)', fontsize=14, fontweight='bold')
plt.grid(axis='y', alpha=0.3, linestyle='--')
plt.tight_layout()
plt.show()

print(f"\n{'='*50}")
print(f"Total de registros: {total:,}")
print(f"Com Match: {com_match:,} ({pct_com:.2f}%)")
print(f"Sem Match: {sem_match:,} ({pct_sem:.2f}%)")
print(f"{'='*50}")