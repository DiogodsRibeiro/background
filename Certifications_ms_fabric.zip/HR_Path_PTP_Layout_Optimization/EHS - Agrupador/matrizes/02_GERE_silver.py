# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Agrupador/utils/utils"

# COMMAND ----------

# =============================================================================
# GERE — Camada Silver
#
# Equivale às queries Power Query v3:
#   - Agrupador_GERE_Codificado
#   - Formata_Agrupador_GERE
#   - Arquivo_Layout_SAP (GERE)
#   - Local_SSO_Nao_EC
# =============================================================================

df_full = spark.table(BRONZE_GERE)

# =============================================================================
# 1) Agrupador_GERE_Codificado
#    Filtra LOCAL SSO EC não nulo, seleciona colunas-chave,
#    gera índices e codificações de agrupador
# =============================================================================

df_cod = (
    df_full
    .filter(F.col("LOCAL_SSO_EC").isNotNull() & (F.col("LOCAL_SSO_EC") != ""))
    .select(
        F.trim(F.col("Codigo_GERE")).alias("Codigo_GERE"),
        F.trim(F.col("GERE")).alias("GERE"),
        F.trim(F.col("CD_LOCAL_SSO")).alias("CD_LOCAL_SSO"),
        F.trim(F.col("ID_EXTERNO")).alias("ID_EXTERNO"),
        F.trim(F.col("Cod_Empresa")).alias("Cod_Empresa"),
    )
    .dropDuplicates()
    .orderBy("ID_EXTERNO", "GERE")
)

print(f"Agrupador_GERE_Codificado — Registros únicos: {df_cod.count()}")

print(f"Agrupador_GERE_Codificado — Registros únicos: {df_cod.count()}")

# --- GERE_60_UPPER e Index_GERE_60 ---
df_cod = df_cod.withColumn(                          # ← cria ANTES do index
    "GERE_60_UPPER",
    F.upper(F.substring(F.concat(F.lit("GERE_"), F.col("GERE")), 1, 56))
)
df_cod = add_agrupador_index_gere(df_cod, "GERE_60_UPPER", "ID_EXTERNO", "Index_GERE_60", "GERE")

# --- GERE_40_UPPER e Index_GERE_40 ---
df_cod = df_cod.withColumn(                          # ← cria ANTES do index
    "GERE_40_UPPER",
    F.upper(F.substring(F.concat(F.lit("GEREQL_"), F.col("GERE")), 1, 36))
)
df_cod = add_agrupador_index_gere(df_cod, "GERE_40_UPPER", "ID_EXTERNO", "Index_GERE_40", "GERE")

# --- Index_GERE_ID (particiona por Codigo_GERE, sem UPPER necessário) ---
df_cod = add_agrupador_index_gere(df_cod, "Codigo_GERE", "ID_EXTERNO", "Index_GERE_ID", "GERE")

# --- Agrupador 60 Caracteres ---
df_cod = df_cod.withColumn(
    "GERE_60_base",
    F.substring(F.concat(F.lit("GERE_"), F.col("GERE")), 1, 56)
)
df_cod = build_agrupador(df_cod, "GERE_60_base", "Index_GERE_60", "Agrupador_60_Caracteres")

# --- Agrupador Quali 40 Caracteres ---
df_cod = df_cod.withColumn(
    "GERE_40_base",
    F.substring(F.concat(F.lit("GEREQL_"), F.col("GERE")), 1, 36)
)
df_cod = build_agrupador(df_cod, "GERE_40_base", "Index_GERE_40", "Agrupador_Quali_40_Caracteres")

# --- ID Externo (Agrupador) VALE ---
df_cod = df_cod.withColumn(
    "ID_Externo_Agrupador_VALE",
    F.when(
        F.col("Index_GERE_ID") > 0,
        F.concat(
            F.lit("GERE_"), F.col("Codigo_GERE"), F.lit("_"),
            F.lpad(F.col("Index_GERE_ID").cast("string"), 3, "0")
        )
    ).otherwise(F.concat(F.lit("GERE_"), F.col("Codigo_GERE")))
)

df_cod_final = df_cod.select(
    "Cod_Empresa", "Codigo_GERE", "GERE",
    "Agrupador_60_Caracteres", "Agrupador_Quali_40_Caracteres",
    "ID_Externo_Agrupador_VALE",
    "CD_LOCAL_SSO", "ID_EXTERNO"
)

# COMMAND ----------

export_df_to_excel(
    df_cod_final,
    '/Volumes/humanresources_insight/acqu_pcehsagrupador/acqu_pcehsagrupador/layout_agrupador/output/',
    'Agrupador_GERE_Codificado'
)

# COMMAND ----------

# =============================================================================
# 2) Formata_Agrupador_GERE
# =============================================================================

df_formata_base = (
    df_full
    .filter(F.col("LOCAL_SSO_EC").isNotNull() & (F.col("LOCAL_SSO_EC") != ""))
    .dropDuplicates()
)

# Trim
for c in df_formata_base.columns:
    df_formata_base = df_formata_base.withColumn(c, F.trim(F.col(f"`{c}`")))

# Join com Agrupador_GERE_Codificado
df_formata = df_formata_base.join(
    df_cod_final.select(
        F.col("ID_EXTERNO").alias("_cod_id_ext"),
        F.col("GERE").alias("_cod_gere"),
        "Agrupador_60_Caracteres",
        "ID_Externo_Agrupador_VALE",
    ),
    (df_formata_base["ID_EXTERNO"] == F.col("_cod_id_ext")) &
    (df_formata_base["GERE"] == F.col("_cod_gere")),
    "left"
).drop("_cod_id_ext", "_cod_gere")

# Adicionar colunas fixas
df_formata = df_formata.withColumn("DELIMITADOR_COLUNA", F.lit(""))
df_formata = df_formata.withColumn("Tipo_Atividade_Agrupador", F.lit("ZGERE"))

# Renomear para output do Formata
df_formata_output = df_formata.select(
    F.col("Agrupador_60_Caracteres").alias("Descrição da Atividade (Agrupador)"),
    F.col("Tipo_Atividade_Agrupador").alias("Tipo da Atividade (Agrupador)"),
    F.col("ID_Externo_Agrupador_VALE").alias("ID Externo (Agrupador) VALE"),
    F.col("DELIMITADOR_COLUNA").alias("DELIMITADOR COLUNA"),
    F.col("ID_Matriz").alias("ID Matriz"),
    F.col("Cod_Empresa").alias("Cód. Empresa"),
    F.col("Empresa"),
    F.col("Cod_Local_SSO_Orig").alias("Cód. Local SSO"),
    F.col("Local_SSO_Orig").alias("Local SSO"),
    F.col("SSO_CD_UNIDADE_PARA").alias("Local SSO_ DE X PARA.CD_UNIDADE (PARA)"),
    F.col("SSO_DS_UNIDADE_NEW").alias("Local SSO_ DE X PARA.DS_UNIDADE_NEW"),
    F.col("CD_LOCAL_SSO").alias("CD LOCAL SSO"),
    F.col("DS_LOCAL_SSO").alias("DS LOCAL SSO"),
    F.col("Matricula"),
    F.col("Nome"),
    F.col("Cod_Cargo").alias("Cód. Cargo"),
    F.col("Cargo"),
    F.col("Cod_Funcao").alias("Cód. Função"),
    F.col("Funcao").alias("Função"),
    F.col("Cod_Local_Trabalho").alias("Cód. Local de Trabalho"),
    F.col("Local_Trabalho").alias("Local de Trabalho"),
    F.col("DE_PARA_LOCATION_1").alias("DE_PARA_Local_Fisico_T.LOCAL NÃO-T"),
    F.col("DE_PARA_DESCR_2").alias("DE_PARA_Local_Fisico_T.DESCR_1"),
    F.col("CD_LOCAL_FISICO_NAO_T").alias("CD LOCAL FISICO NAO T"),
    F.col("DS_LOCAL_FISICO_NAO_T").alias("DS LOCAL FISICO NAO T"),
    F.col("Turno"),
    F.col("Codigo_GHE_SDWEB").alias("Código GHE (SDWEB)"),
    F.col("GHE_SDWEB").alias("GHE (SDWEB)"),
    F.col("Codigo_GERE").alias("Código GERE"),
    F.col("GERE"),
    F.col("Fator_Risco").alias("Fator de Risco"),
    F.col("Fator_Risco_Para").alias("FATOR DE RISCO: PARA"),
    F.col("Exigencias_Ergonomicas").alias("Exigências Ergonômicas"),
    F.col("Exigencias_Ergonomicas_Para").alias("Exigências Ergonômicas: PARA"),
    F.col("Exigencia_Tempo").alias("Exigência de tempo"),
    F.col("Exigencia_Intensidade").alias("Exgência de Intensidade"),
    F.col("Severidade"),
    F.col("Categoria_Risco").alias("Categoria Risco"),
    F.col("Natureza_Atividade").alias("Natureza Atividade"),
    F.col("Perfil_GERE").alias("Perfil do GERE"),
    F.col("Data_Reconhecimento").alias("Data Reconhecimento"),
    F.col("Data_Validade_Reconhecimento").alias("Data Validade do Reconhecimento"),
    F.col("Aprov_1_DE").alias("1.DE"),
    F.col("Aprov_2_DI_GE").alias("2.DI/GE"),
    F.col("Aprov_3_GE_GA_COORD").alias("3.GE/GA/COORD"),
    F.col("Aprov_4_GA_COORD_SUP").alias("4.GA/COORD/SUP"),
    F.col("Aprov_5_COORD_SUP").alias("5.COORD/SUP"),
    F.col("Aprov_6_COORD_SUP").alias("6.COORD/SUP"),
).dropDuplicates().orderBy("ID Externo (Agrupador) VALE", "GERE")

# Substituir o dropDuplicates() genérico por um baseado nas colunas originais
# (sem Agrupador_60_Caracteres e ID_Externo_Agrupador_VALE que vêm do join)
_cols_dedup = [
    c for c in df_formata_output.columns
    if c not in ("Descrição da Atividade (Agrupador)", "ID Externo (Agrupador) VALE")
]
df_formata_output = df_formata_output.dropDuplicates(_cols_dedup)

# Remover colunas LOCAL FISICO EC, LOCAL SSO EC, ID EXTERNO do Formata (conforme PQ v3)
print(f"Formata_Agrupador_GERE — Registros: {df_formata_output.count()}")

# COMMAND ----------

# =============================================================================
# 3) Arquivo_Layout_SAP (GERE)
# =============================================================================

df_silver = (
    df_formata_output
    .select(
        F.col("Descrição da Atividade (Agrupador)").alias(COL_DESCRICAO),
        F.col("Tipo da Atividade (Agrupador)").alias(COL_TIPO),
        F.col("ID Externo (Agrupador) VALE").alias(COL_ID_EXTERNO),
    )
    .filter(F.col(COL_DESCRICAO).isNotNull() & (F.col(COL_DESCRICAO) != ""))
    .dropDuplicates()
    .orderBy(COL_DESCRICAO)
)

print(f"Arquivo_Layout_SAP GERE — Registros: {df_silver.count()}")

# COMMAND ----------

spark.sql(f"""TRUNCATE TABLE {SILVER_GERE}""")
df_silver.write.insertInto(SILVER_GERE)

# COMMAND ----------

export_df_to_excel(
    df_formata_output,
    '/Volumes/humanresources_insight/acqu_pcehsagrupador/acqu_pcehsagrupador/layout_agrupador/output/',
    'Formata_Agrupador_GERE'
)

# COMMAND ----------

# =============================================================================
# 4) Local_SSO_Nao_EC
# =============================================================================

df_nao_ec = (
    df_full
    .filter(F.col("LOCAL_SSO_EC").isNull() | (F.col("LOCAL_SSO_EC") == ""))
    .select(
        "Cod_Empresa", "Empresa",
        "Cod_Local_SSO_Orig", "Local_SSO_Orig",
        "SSO_CD_UNIDADE_PARA", "SSO_DS_UNIDADE_NEW",
        "CD_LOCAL_SSO", "DS_LOCAL_SSO",
        "Matricula", "Nome",
        "Cod_Cargo", "Cargo",
        "Cod_Funcao", "Funcao",
        "Cod_Local_Trabalho", "Local_Trabalho",
        "DE_PARA_LOCATION_1", "DE_PARA_DESCR_2",
        "CD_LOCAL_FISICO_NAO_T", "DS_LOCAL_FISICO_NAO_T",
        "Turno", "Codigo_GHE_SDWEB", "GHE_SDWEB",
        "Codigo_GERE", "GERE",
        "Fator_Risco", "Fator_Risco_Para",
        "Exigencias_Ergonomicas", "Exigencias_Ergonomicas_Para",
        "Exigencia_Tempo", "Exigencia_Intensidade",
        "Severidade", "Categoria_Risco", "Natureza_Atividade",
        "Perfil_GERE", "Data_Reconhecimento", "Data_Validade_Reconhecimento",
        "Aprov_1_DE", "Aprov_2_DI_GE", "Aprov_3_GE_GA_COORD",
        "Aprov_4_GA_COORD_SUP", "Aprov_5_COORD_SUP", "Aprov_6_COORD_SUP",
        "ID_EXTERNO",
    )
    .dropDuplicates()
)

print(f"Local_SSO_Nao_EC — Registros: {df_nao_ec.count()}")

# COMMAND ----------

export_df_to_csv_excel(
    df_nao_ec,
    '/Volumes/humanresources_insight/acqu_pcehsagrupador/acqu_pcehsagrupador/layout_agrupador/output/',
    'Local_SSO_Nao_EC_GERE'
)