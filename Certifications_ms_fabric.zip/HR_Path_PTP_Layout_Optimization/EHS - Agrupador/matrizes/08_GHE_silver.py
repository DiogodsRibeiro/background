# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Agrupador/utils/utils"

# COMMAND ----------

# =============================================================================
# GHE — Camada Silver
# =============================================================================
df_full = spark.table(BRONZE_GHE)
print(f"DATA BASE GHE FULL — Registros: {df_full.count()}")

# COMMAND ----------

# =============================================================================
# 1) Dados_GHE — remove colunas de rastreio + Distinct
# Equivale à query "Dados_GHE" do Power Query
# =============================================================================
cols_remove = ["Source_Name", "id_matriz", "status", "DESC_STATUS_MATRIZ"]
df_dados = df_full
for c in cols_remove:
    if c in df_dados.columns:
        df_dados = df_dados.drop(c)

for c in df_dados.columns:
    df_dados = df_dados.withColumn(c, F.trim(F.col(f"`{c}`")))

df_dados = df_dados.dropDuplicates()
print(f"Dados_GHE — Registros: {df_dados.count()}")

# COMMAND ----------

# =============================================================================
# 2) Agrupador_GHE_Codificado
#    Equivale à query "Agrupador_GHE_Codificado" do Power Query
# =============================================================================

# FIX: verificar nomes reais das colunas no Bronze sanitizado
print("Colunas disponíveis em df_dados:")
print([c for c in df_dados.columns if "LOCAL_FISICO_EC" in c or "GHE" in c or "EXT" in c or "LOCAL_SSO" in c])

df_cod = (
    df_dados
    .filter(
        F.col("COD_LOCAL_FISICO_EC").isNotNull() &
        (F.col("COD_LOCAL_FISICO_EC") != "")
    )
    .select(
        F.col("COD_GHE"),
        F.col("DESC_GHE"),
        F.col("ID_Externo__Agrupador__VALE_Primario").alias("ID_EXT_PRIM"),
    )
    .dropDuplicates()
)

# DESC GHE - 60 chars: Text.Middle(Text.Upper("GHE_" & DESC GHE), 0, 56)
# PQ usa índice 0-based, Spark substring usa 1-based → mesma semântica com pos=1, len=56
df_cod = df_cod.withColumn("COD_GHE",  F.regexp_replace(F.trim(F.col("COD_GHE")),  r"\s+", " "))
df_cod = df_cod.withColumn("DESC_GHE", F.regexp_replace(F.trim(F.col("DESC_GHE")), r"\s+", " "))
df_cod = df_cod.withColumn("ID_EXT_PRIM", F.regexp_replace(F.trim(F.col("ID_EXT_PRIM")), r"\s+", " "))
df_cod = df_cod.withColumn("DESC_GHE_60", F.upper(F.substring(F.concat(F.lit("GHE_"),   F.col("DESC_GHE")), 1, 56)))
df_cod = df_cod.withColumn("GHEQL_40",    F.upper(F.substring(F.concat(F.lit("GHEQL_"), F.col("DESC_GHE")), 1, 36)))
df_cod = df_cod.withColumn("GHEQT_60",    F.upper(F.substring(F.concat(F.lit("GHEQT_"), F.col("DESC_GHE")), 1, 56)))

# Indexes (0-based, por grupo)
df_cod = add_agrupador_index(df_cod, "DESC_GHE_60", "DESC_GHE", "Index_GHE_60")
df_cod = add_agrupador_index(df_cod, "GHEQL_40",    "DESC_GHE", "Index_GHEQL_40")
df_cod = add_agrupador_index(df_cod, "GHEQT_60",    "DESC_GHE", "Index_GHEQT_60")

# Bases truncadas
df_cod = df_cod.withColumn("base_60",   F.substring(F.concat(F.lit("GHE_"),   F.col("DESC_GHE")), 1, 56))
df_cod = df_cod.withColumn("base_40ql", F.substring(F.concat(F.lit("GHEQL_"), F.col("DESC_GHE")), 1, 36))
# PQ: GHEQT usa prefixo "GHEQL_" no texto final (comportamento original preservado)
df_cod = df_cod.withColumn("base_60qt", F.substring(F.concat(F.lit("GHEQL_"), F.col("DESC_GHE")), 1, 56))

df_cod = build_agrupador(df_cod, "base_60",   "Index_GHE_60",    "Agrupador_60_Caracteres")
df_cod = build_agrupador(df_cod, "base_40ql", "Index_GHEQL_40",  "Agrupador_Quali_40")
df_cod = build_agrupador(df_cod, "base_60qt", "Index_GHEQT_60",  "Agrupador_Quant_60")

# Sort + Index por ID Externo Primario (para ID_Ext_Vale_1 com _001, _002...)
df_cod = df_cod.orderBy("DESC_GHE_60")
df_cod = add_agrupador_index(df_cod, "ID_EXT_PRIM", "DESC_GHE_60", "Index_GHE_ID_EXTERNO")

# ID Externo (Agrupador) VALE.2 — baseado em ID_EXT_PRIM + index  
df_cod = df_cod.withColumn(
    "ID_Ext_Vale_2",
    F.when(
        F.col("Index_GHE_ID_EXTERNO") > 0,
        F.concat(F.lit("GHE_"), F.col("ID_EXT_PRIM"), F.lit(" "), F.col("Index_GHE_ID_EXTERNO").cast("string"))
    ).otherwise(F.concat(F.lit("GHE_"), F.col("ID_EXT_PRIM")))
)

# Index por COD_GHE (para ID_Ext_Vale_1 = GHE_<COD> ou GHE_<COD>_001)
df_cod = add_agrupador_index(df_cod, "COD_GHE", "DESC_GHE_60", "Index_ALL_GHE")
df_cod = df_cod.withColumn(
    "ID_Ext_Vale_1",
    F.when(
        F.col("Index_ALL_GHE") > 0,
        F.concat(
            F.lit("GHE_"), F.col("COD_GHE"), F.lit("_"),
            F.lpad(F.col("Index_ALL_GHE").cast("string"), 3, "0")
        )
    ).otherwise(F.concat(F.lit("GHE_"), F.col("COD_GHE")))
)

# Reordenar + renomear para espelhar exatamente o PQ "Agrupador_GHE_Codificado"
# COD LOCAL SSO é extraído de ID_EXT_PRIM (formato: "COD_GHE_COD_LOCAL_SSO")
# O PQ faz SplitColumn por "_" e pega a segunda parte
df_cod = df_cod.withColumn(
    "COD_LOCAL_SSO_AGR",
    F.element_at(F.split(F.col("ID_EXT_PRIM"), "_"), -1)  # último segmento após split
)

df_cod_final = df_cod.select(
    F.col("COD_GHE").alias("COD GHE"),
    F.col("DESC_GHE").alias("DESC GHE"),
    F.col("Agrupador_60_Caracteres").alias("Agrupador 60 Caracteres"),
    F.col("Agrupador_Quali_40").alias("Agrupador Quali 40 Caracteres"),
    F.col("Agrupador_Quant_60").alias("Agrupador Quant 60 Caracteres"),
    F.col("ID_Ext_Vale_1").alias("ID Externo (Agrupador) VALE.1"),
    F.col("ID_Ext_Vale_2").alias("ID Externo (Agrupador) VALE.2"),
    F.col("ID_EXT_PRIM").alias("ID Externo (Agrupador) VALE Primario"),
    F.col("COD_LOCAL_SSO_AGR").alias("COD LOCAL SSO"),
).dropDuplicates()

print(f"Agrupador_GHE_Codificado — Registros: {df_cod_final.count()}")

# COMMAND ----------

export_df_to_csv_excel(
    df_cod_final,
    '/Volumes/humanresources_insight/acqu_pcehsagrupador/acqu_pcehsagrupador/layout_agrupador/output/',
    'Agrupador_GHE_Codificado'
)

# COMMAND ----------

# =============================================================================
# 3) Formata_Agrupador_GHE
#    Equivale à query "Formata_Agrupador_GHE" do Power Query
# =============================================================================

df_formata = (
    df_dados
    .filter(
        F.col("COD_LOCAL_FISICO_EC").isNotNull() &
        (F.col("COD_LOCAL_FISICO_EC") != "")
    )
)

df_formata = df_formata.join(
    df_cod_final.select(
        F.col("ID_EXT_PRIM").alias("_cod_id_ext"),
        F.col("DESC_GHE").alias("_cod_desc"),
        F.col("Agrupador_60_Caracteres").alias("Descrição_Atividade_Agrupador"),
        F.col("ID_Ext_Vale_1").alias("ID_Externo_Agrupador_VALE"),
    ).dropDuplicates(["_cod_id_ext", "_cod_desc"]),
    (F.trim(df_formata["ID_Externo__Agrupador__VALE_Primario"]) == F.col("_cod_id_ext")) &
    (F.trim(df_formata["DESC_GHE"])                             == F.col("_cod_desc")),
    "left"
).drop("_cod_id_ext", "_cod_desc")

df_formata = df_formata.withColumn("Tipo_Atividade_Agrupador", F.lit("ZGHE"))
df_formata = df_formata.withColumn("DELIMITADOR_COLUNA", F.lit(""))

# Reordenar + renomear para espelhar exatamente o PQ "Formata_Agrupador_GHE"
# Os nomes sanitizados pelo sanitize_columns do Bronze são mapeados de volta
# aos nomes originais do Power Query (cod_local_sso_orig e cod_local_fisico_orig
# existem porque o sanitize detectou colisão com COD_LOCAL_SSO e COD_LOCAL_FISICO)
df_formata = df_formata.select(
    F.col("Descrição_Atividade_Agrupador").alias("Descrição da Atividade (Agrupador)"),
    F.col("Tipo_Atividade_Agrupador").alias("Tipo da Atividade (Agrupador)"),
    F.col("ID_Externo_Agrupador_VALE").alias("ID Externo (Agrupador) VALE"),
    F.col("DELIMITADOR_COLUNA").alias("DELIMITADOR COLUNA"),
    F.col("cod_empresa"),
    F.col("ds_empresa"),
    F.col("cd_estabelecimento"),
    F.col("ds_estabelecimento"),
    F.col("cod_local_sso_orig").alias("cod_local_sso"),
    F.col("ds_local_sso"),
    F.col("SSO_CD_UNIDADE_PARA").alias("Local SSO_ DE X PARA.CD_UNIDADE (PARA)"),
    F.col("SSO_DS_UNIDADE_NEW").alias("Local SSO_ DE X PARA.DS_UNIDADE_NEW"),
    F.col("COD_LOCAL_SSO").alias("COD LOCAL SSO"),
    F.col("DESC_LOCAL_SSO").alias("DESC LOCAL SSO"),
    F.col("cod_local_fisico_orig").alias("cod_local_fisico"),
    F.col("ds_local_fisico"),
    F.col("DE_PARA_LOCAL_NAO_T").alias("DE_PARA_Local_Fisico_T.LOCAL NÃO-T"),
    F.col("DE_PARA_DESCR_1").alias("DE_PARA_Local_Fisico_T.DESCR_1"),
    F.col("COD_LOCAL_FISICO").alias("COD LOCAL FISICO"),
    F.col("DESC_LOCAL_FISICO").alias("DESC LOCAL FISICO"),
    F.col("cd_ghe"),
    F.col("ds_ghe"),
    F.col("COD_GHE").alias("COD GHE"),
    F.col("DESC_GHE").alias("DESC GHE"),
)

df_formata = df_formata.dropDuplicates()
df_formata = df_formata.orderBy("Descrição da Atividade (Agrupador)")

print(f"Formata_Agrupador_GHE — Registros: {df_formata.count()}")

# COMMAND ----------

# =============================================================================
# 4) Arquivo_Layout_SAP (GHE) — 3 colunas finais
# =============================================================================
df_silver = (
    df_formata
    .select(
        F.col("Descrição da Atividade (Agrupador)").alias(COL_DESCRICAO),
        F.col("Tipo da Atividade (Agrupador)").alias(COL_TIPO),
        F.col("ID Externo (Agrupador) VALE").alias(COL_ID_EXTERNO),
    )
    .filter(F.col(COL_DESCRICAO).isNotNull() & (F.col(COL_DESCRICAO) != ""))
    .dropDuplicates()
    .orderBy(COL_DESCRICAO)
)
print(f"Arquivo_Layout_SAP GHE — Registros: {df_silver.count()}")

# COMMAND ----------

spark.sql(f"""TRUNCATE TABLE {SILVER_GHE}""")
df_silver.write.insertInto(SILVER_GHE)

# COMMAND ----------

export_df_to_csv_excel(
    df_formata,
    '/Volumes/humanresources_insight/acqu_pcehsagrupador/acqu_pcehsagrupador/layout_agrupador/output/',
    'Formata_Agrupador_GHE'
)

# COMMAND ----------

# =============================================================================
# 5) LSSO_ou_LFisico_Nao_EC — registros sem match na EC
# =============================================================================

df_nao_ec = (
    df_dados
    .filter(
        F.col("COD_LOCAL_FISICO_EC").isNull() |
        (F.col("COD_LOCAL_FISICO_EC") == "")
    )
)

print(f"LSSO_ou_LFisico_Nao_EC — Registros: {df_nao_ec.count()}")

# COMMAND ----------

export_df_to_csv_excel(
    df_nao_ec,
    '/Volumes/humanresources_insight/acqu_pcehsagrupador/acqu_pcehsagrupador/layout_agrupador/output/',
    'LSSO_ou_LFisico_Nao_EC_GHE'
)