# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Agrupador/utils/utils"

# COMMAND ----------

df_full = spark.table(BRONZE_GHP)
print(f"FULL_Dados_GHP — Registros: {df_full.count()}")
print(f"Colunas: {df_full.columns}")

# COMMAND ----------

# 1) Dados_GHP — remove colunas de controle + trim em todas as colunas

df_full = trim_all_columns(df_full)

cols_remove = ["CD_EMPRESA MATRICULA", "COD_EMPRESA COD_LOCAL_FISICO DES_FUNCAO", "DESCRICAO DO GHP 01"]
df_dados = df_full
for c in cols_remove:
    if c in df_dados.columns:
        df_dados = df_dados.drop(c)

print(f"Dados_GHP — Registros: {df_dados.count()}")

# 2) AgrupadorGHP_Codificado

df_cod = (
    df_full
    .filter(
        F.col("arvore_localizacao_ec_codigo").isNotNull() &
        (F.col("arvore_localizacao_ec_codigo") != "")
    )
    .select(F.trim(F.col("descricao_do_ghp_02")).alias("DESC_GHP_02"))  # ← trim aqui
    .dropDuplicates()
    .orderBy("DESC_GHP_02")
)

print(f"AgrupadorGHP_Codificado — Base única: {df_cod.count()}")

df_cod = df_cod.withColumn("GHP_60", F.upper(F.substring(F.col("DESC_GHP_02"), 1, 56)))
df_cod = df_cod.withColumn("GHPQL_40", F.upper(F.substring(F.col("DESC_GHP_02"), 1, 36)))
df_cod = df_cod.withColumn("ID_GHP", F.substring(F.col("DESC_GHP_02"), 1, 26))

df_cod = add_agrupador_index(df_cod, "GHP_60",   "DESC_GHP_02", "Index_GHP_60")
df_cod = add_agrupador_index(df_cod, "GHPQL_40", "DESC_GHP_02", "Index_GHPQL_40")
df_cod = add_agrupador_index(df_cod, "ID_GHP",   "DESC_GHP_02", "Index_ID_GHP")

df_cod = df_cod.withColumn("GHP_60_base", F.substring(F.col("DESC_GHP_02"), 1, 56))
df_cod = build_agrupador(df_cod, "GHP_60_base", "Index_GHP_60", "Agrupador_60_Caracteres")

df_cod = df_cod.withColumn("GHP_40_base", F.substring(F.col("DESC_GHP_02"), 1, 36))
df_cod = build_agrupador(df_cod, "GHP_40_base", "Index_GHPQL_40", "Agrupador_Quali_40_Caracteres")

df_cod = df_cod.withColumn(
    "ID_Externo_Vale",
    F.when(
        F.col("Index_ID_GHP") > 0,
        F.concat(F.col("ID_GHP"), F.lit("_"), F.lpad(F.col("Index_ID_GHP").cast("string"), 3, "0"))
    ).otherwise(F.col("ID_GHP"))
)

df_cod_final = df_cod.select(
    "DESC_GHP_02",
    "Agrupador_60_Caracteres",
    "Agrupador_Quali_40_Caracteres",
    "ID_Externo_Vale",
)

print(f"AgrupadorGHP_Codificado — Registros: {df_cod_final.count()}")

# 3) Formata_Agrupador_GHP

df_formata = (
    df_dados
    .filter(
        F.col("arvore_localizacao_ec_codigo").isNotNull() &
        (F.col("arvore_localizacao_ec_codigo") != "")
    )
)

# Remover colunas EC
for c in ["arvore_localizacao_ec_codigo", "arvore_localizacao_ec_local_sso_codigo"]:
    if c in df_formata.columns:
        df_formata = df_formata.drop(c)

# Adicionar colunas fixas
df_formata = df_formata.withColumn("DELIMITADOR_COLUNA", F.lit(""))
df_formata = df_formata.withColumn("Tipo_Atividade_Agrupador", F.lit("ZGHP"))

# Join com codificado — chave: descricao_do_ghp_02
df_formata = df_formata.join(
    df_cod_final.select(
        F.col("DESC_GHP_02").alias("_cod_desc"),
        F.col("Agrupador_60_Caracteres").alias("Descrição da Atividade (Agrupador)"),
        F.col("ID_Externo_Vale").alias("ID Externo (Agrupador) VALE"),
    ),
    F.trim(df_formata["descricao_do_ghp_02"]) == F.col("_cod_desc"),
    "left"
).drop("_cod_desc")

# [CORREÇÃO] trim_all_columns após o join — limpa espaços trailing
# gerados pelo substring/concat no codificado
df_formata = trim_all_columns(df_formata)

# Reordenar e formatar output — 31 colunas conforme template V9
df_formata_output = df_formata.select(
    F.col("Descrição da Atividade (Agrupador)"),
    F.col("Tipo_Atividade_Agrupador").alias("Tipo da Atividade (Agrupador)"),
    F.col("ID Externo (Agrupador) VALE"),
    F.col("DELIMITADOR_COLUNA").alias("DELIMITADOR COLUNA"),
    F.col("descricao_do_ghp_02"),
    F.col("cd_empresa"),
    F.col("ds_empresa"),
    F.col("matricula"),
    F.col("nome"),
    F.col("dt_admissao"),
    F.col("dt_demissao"),
    F.col("ds_situacao"),
    F.col("cod_cargo"),
    F.col("des_cargo"),
    F.col("cod_carga_hor"),
    F.col("cod_turno"),
    F.col("cod_funcao"),
    F.col("des_funcao"),
    F.col("cod_estabelecimento"),
    F.col("ds_estabelecimento"),
    F.col("cd_local_sso"),
    F.col("ds_local_sso"),
    F.col("cd_local_fisico"),
    F.col("ds_local_fisico"),
    F.col("id_matriz_rac_peric_ghrm"),
    F.col("periculoso"),
    F.col("percent_periculosidade"),
    F.col("tipo_periculosidade"),
    F.col("nu_matriz_ghe"),
    F.col("cd_ghe"),
    F.col("ds_ghe"),
).dropDuplicates()

print(f"Formata_Agrupador_GHP — Registros: {df_formata_output.count()}")

# 4) Arquivo_Layout_SAP (GHP) — 3 colunas finais + distinct

df_silver = (
    df_formata_output
    .select(
        F.col("Descrição da Atividade (Agrupador)").alias(COL_DESCRICAO),
        F.col("Tipo da Atividade (Agrupador)").alias(COL_TIPO),
        F.col("ID Externo (Agrupador) VALE").alias(COL_ID_EXTERNO),
    )
    .filter(F.col(COL_DESCRICAO).isNotNull() & (F.col(COL_DESCRICAO) != ""))
    .dropDuplicates()
    .orderBy(COL_DESCRICAO)
)

print(f"Arquivo_Layout_SAP GHP — Registros: {df_silver.count()}")

# spark.sql(f"""TRUNCATE TABLE {SILVER_GHP}""")
# df_silver.write.insertInto(SILVER_GHP)

# COMMAND ----------

export_df_to_csv_excel(
    df_cod_final,
    '/Volumes/humanresources_insight/acqu_pcehsagrupador/acqu_pcehsagrupador/layout_agrupador/output/',
    'Agrupador_GHP_Codificado'
)

# COMMAND ----------

export_df_to_csv_excel(
    df_formata_output,
    '/Volumes/humanresources_insight/acqu_pcehsagrupador/acqu_pcehsagrupador/layout_agrupador/output/',
    'Formata_Agrupador_GHP'
)

# COMMAND ----------

# 5) Local_SSO_e_Local_Fisico_Não_EC — registros sem match na EC

# df_nao_ec = (
#     df_full
#     .filter(
#         F.col("`Arvore Localizacao EC.Código`").isNull() |
#         (F.col("`Arvore Localizacao EC.Código`") == "")
#     )
# )

# print(f"Local_SSO_e_Local_Fisico_Não_EC — Registros: {df_nao_ec.count()}")

# export_df_to_csv_excel(
#     df_nao_ec,
#     '/Volumes/humanresources_insight/acqu_pcehsagrupador/acqu_pcehsagrupador/layout_agrupador/output/',
#     'Local_SSO_e_Local_Fisico_Nao_EC_GHP'
# )

# COMMAND ----------

# from pyspark.sql.functions import md5, concat_ws, col, coalesce, lit
# from pyspark.sql.types import StringType
# from pyspark.sql import functions as F
# import pandas as pd
# import unicodedata
# import matplotlib.pyplot as plt

# VAL_BASE = "/Volumes/humanresources_insight/acqu_pcehsagrupador/acqu_pcehsagrupador/layout_agrupador/validation_files"

# def normalize_pandas_columns(pdf):
#     new_cols = []
#     for column in pdf.columns:
#         new_column = unicodedata.normalize('NFKD', column).encode('ASCII', 'ignore').decode('ASCII')
#         new_column = (new_column
#             .replace(" ", "_").replace("/", "_").replace("(", "")
#             .replace(".", "_").replace(")", "").replace(":", "").replace("-", "_")
#             .lower()
#         )
#         new_cols.append(new_column)
#     pdf.columns = new_cols
#     return pdf

# def plot_match(title, total, com_match, sem_match, pct_com, pct_sem):
#     plt.figure(figsize=(10, 6))
#     barras = plt.bar(['Sem Match', 'Com Match'], [sem_match, com_match],
#                      color=['#e74c3c', '#2ecc71'], edgecolor='black', linewidth=1.2)
#     for barra, valor, pct in zip(barras, [sem_match, com_match], [pct_sem, pct_com]):
#         plt.text(barra.get_x() + barra.get_width()/2, barra.get_height()/2,
#                  f'{valor:,}\n({pct:.1f}%)', ha='center', va='center',
#                  fontsize=12, fontweight='bold', color='white')
#     plt.ylabel('Quantidade', fontsize=12)
#     plt.title(title, fontsize=14, fontweight='bold')
#     plt.grid(axis='y', alpha=0.3, linestyle='--')
#     plt.tight_layout()
#     plt.show()
#     print(f"\n{'='*60}")
#     print(f"Total PQ (esperado):   {total:,}")
#     print(f"Com Match:             {com_match:,} ({pct_com:.2f}%)")
#     print(f"Sem Match:             {sem_match:,} ({pct_sem:.2f}%)")
#     print(f"{'='*60}\n")

# # ══════════════════════════════════════════════════════════════
# # VALIDAÇÃO 1 — Formata_Agrupador_GHP
# # ══════════════════════════════════════════════════════════════

# pdf_formata = pd.read_excel(
#     f"{VAL_BASE}/Template_Agrupador_Cadastro-GHP-V9.xlsm",
#     sheet_name="Formata_Agrupador_GHP", dtype=str, engine="openpyxl"
# ).fillna("")
# pdf_formata.columns = [c.strip() for c in pdf_formata.columns]
# pdf_formata = normalize_pandas_columns(pdf_formata)
# for c in pdf_formata.columns:
#     pdf_formata[c] = pdf_formata[c].astype(str).str.strip()

# df_pq_formata = spark.createDataFrame(pdf_formata)
# COLS_HASH_FORMATA = [c for c in df_pq_formata.columns if c != "hash_key"]

# # Normaliza nomes do Silver
# pdf_cols = pd.DataFrame(columns=df_formata_output.columns)
# pdf_cols = normalize_pandas_columns(pdf_cols)
# df_silver_formata = df_formata_output
# for old, new in zip(df_formata_output.columns, pdf_cols.columns):
#     if old != new:
#         df_silver_formata = df_silver_formata.withColumnRenamed(old, new)

# cols_em_comum_formata = [c for c in COLS_HASH_FORMATA if c in df_silver_formata.columns and c != "hash_key"]

# # 1. Normaliza datas nos dois lados
# for c in ["dt_admissao", "dt_demissao"]:
#     df_pq_formata = df_pq_formata.withColumn(
#         c, F.date_format(F.to_date(F.col(c), "dd/MM/yyyy"), "dd/MM/yyyy")
#     )
#     df_silver_formata = df_silver_formata.withColumn(
#         c, F.date_format(F.to_date(F.col(c)), "dd/MM/yyyy")
#     )

# df_pq_formata = df_pq_formata.withColumn(
#     "percent_periculosidade",
#     F.date_format(F.to_date(F.col("percent_periculosidade"), "dd/MM/yyyy"), "dd/MM/yyyy")
# )
# df_silver_formata = df_silver_formata.withColumn(
#     "percent_periculosidade",
#     F.date_format(F.to_date(F.col("percent_periculosidade")), "dd/MM/yyyy")
# )

# # 2. Coalesce null → vazio em todas as colunas (após datas)
# for c in cols_em_comum_formata:
#     df_pq_formata = df_pq_formata.withColumn(
#         c, F.coalesce(F.col(c).cast(StringType()), F.lit(""))
#     )
#     df_silver_formata = df_silver_formata.withColumn(
#         c, F.coalesce(F.col(c).cast(StringType()), F.lit(""))
#     )

# # 3. Hash
# df_pq_formata = df_pq_formata.withColumn(
#     "hash_key",
#     md5(concat_ws("||", *[col(c) for c in cols_em_comum_formata]))
# )
# df_silver_formata = df_silver_formata.withColumn(
#     "hash_key",
#     md5(concat_ws("||", *[col(c) for c in cols_em_comum_formata]))
# )

# total     = df_pq_formata.count()
# sem_match = df_pq_formata.join(df_silver_formata.select("hash_key"), "hash_key", "left_anti").count()
# com_match = total - sem_match
# pct_sem   = (sem_match / total * 100) if total > 0 else 0
# pct_com   = (com_match / total * 100) if total > 0 else 0

# plot_match("Análise de Match — GHP (Formata_Agrupador_GHP)", total, com_match, sem_match, pct_com, pct_sem)

# # ══════════════════════════════════════════════════════════════
# # VALIDAÇÃO 2 — Arquivo_Layout_SAP
# # ══════════════════════════════════════════════════════════════

# pdf_layout = pd.read_excel(
#     f"{VAL_BASE}/Template_Agrupador_Cadastro-GHP-V9.xlsm",
#     sheet_name="Arquivo_Layout_SAP", dtype=str, engine="openpyxl"
# ).fillna("")
# pdf_layout.columns = [c.strip() for c in pdf_layout.columns]
# pdf_layout = normalize_pandas_columns(pdf_layout)
# for c in pdf_layout.columns:
#     pdf_layout[c] = pdf_layout[c].astype(str).str.strip()

# df_pq_layout = spark.createDataFrame(pdf_layout)
# COLS_HASH_LAYOUT = [c for c in df_pq_layout.columns if c != "hash_key"]

# # Normaliza nomes do df_silver
# pdf_cols_f = pd.DataFrame(columns=df_silver.columns)
# pdf_cols_f = normalize_pandas_columns(pdf_cols_f)
# df_silver_layout = df_silver
# for old, new in zip(df_silver.columns, pdf_cols_f.columns):
#     if old != new:
#         df_silver_layout = df_silver_layout.withColumnRenamed(old, new)

# cols_em_comum_layout = [c for c in COLS_HASH_LAYOUT if c in df_silver_layout.columns and c != "hash_key"]

# # 1. Coalesce null → vazio
# for c in cols_em_comum_layout:
#     df_pq_layout = df_pq_layout.withColumn(
#         c, F.coalesce(F.col(c).cast(StringType()), F.lit(""))
#     )
#     df_silver_layout = df_silver_layout.withColumn(
#         c, F.coalesce(F.col(c).cast(StringType()), F.lit(""))
#     )

# # 2. Hash
# df_pq_layout = df_pq_layout.withColumn(
#     "hash_key",
#     md5(concat_ws("||", *[col(c) for c in cols_em_comum_layout]))
# )
# df_silver_layout = df_silver_layout.withColumn(
#     "hash_key",
#     md5(concat_ws("||", *[col(c) for c in cols_em_comum_layout]))
# )

# total_l     = df_pq_layout.count()
# sem_match_l = df_pq_layout.join(df_silver_layout.select("hash_key"), "hash_key", "left_anti").count()
# com_match_l = total_l - sem_match_l
# pct_sem_l   = (sem_match_l / total_l * 100) if total_l > 0 else 0
# pct_com_l   = (com_match_l / total_l * 100) if total_l > 0 else 0

# plot_match("Análise de Match — GHP (Arquivo_Layout_SAP)", total_l, com_match_l, sem_match_l, pct_com_l, pct_sem_l)