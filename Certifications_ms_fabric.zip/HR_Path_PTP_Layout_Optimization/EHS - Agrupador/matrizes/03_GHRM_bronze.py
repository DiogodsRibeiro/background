# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Agrupador/utils/utils"

# COMMAND ----------

# =============================================================================
# GHRM — Camada Bronze (Dados_GHRM_FULL)
#
# Equivale às queries Power Query v3:
#   1. Arvore_Localizacao_EC (leitura do Excel com aba LOCATION)
#   2. Dados_GHRM_FULL:
#      - Remove colunas: Geozone, País/Região, País_ORIG, País, UF_ORIG,
#        UF, Cidade_ORIG, Cidade, Endereço, CEP, Email, SETID PEOPLESOFT, Descrição
#      - Renomeia: Empresa Peoplesoft_1→DS_EMPRESA, Nome Local SSO SDWEB→DS_UNIDADE,
#        Nome Estabelecimento Peoplesoft→DS_ESTABELECIMENTO
#      - Renomeia: Empresa→Empresa EC, Código→Codigo Local Fisico EC,
#        Estabelecimento→Estabelecimento EC, Local SSO (Código)→Codigo Local SSO EC
#      - Distinct, Trim
#      - Codigo GHRM = [Local SSO SDWEB] & "_" & [LOCAL PEOPLESOFT]
#      - Desc GHRM Full = "GHRM-" & [DS_UNIDADE] & " " & [Nome]
# =============================================================================

# --- Leitura do Excel Arvore_Localizacao_EC ---
df_raw = read_excel(GHRM_INPUT_PATH, GHRM_SHEET_NAME)

print(f"Registros brutos lidos: {df_raw.count()}")
print(f"Colunas: {df_raw.columns}")

# COMMAND ----------

# --- Trim em todas as colunas ---
for c in df_raw.columns:
    df_raw = df_raw.withColumn(c, F.trim(F.col(f"`{c}`")))

# --- Remover colunas não usadas ---
cols_remover = ["Geozone", "País/Região", "País_ORIG", "País", "UF_ORIG", "UF",
                "Cidade_ORIG", "Cidade", "Endereço", "CEP", "Email",
                "SETID PEOPLESOFT", "Descrição"]
existing_cols = df_raw.columns
cols_to_drop = [c for c in cols_remover if c in existing_cols]
df = df_raw
for c in cols_to_drop:
    df = df.drop(c)

print(f"Colunas após remoção: {df.columns}")

# COMMAND ----------

# --- Renomear colunas conforme Power Query v3 ---
# Nota: A planilha da Arvore pode ter variações nos nomes.
# Mapeamento das renomeações do Power Query:
rename_map = {}

# Verificar e renomear colunas existentes
col_list = df.columns

# Renomeações do Dados_GHRM_FULL
# "Empresa Peoplesoft_1" → "DS_EMPRESA" (ou "Empresa Peoplesoft" se não houver _1)
# "Nome Local SSO SDWEB" → "DS_UNIDADE" (pode não existir, usar "Local SSO SDWEB" como campo de join)
# "Nome Estabelecimento Peoplesoft" → "DS_ESTABELECIMENTO"
# "Empresa" → "Empresa EC"
# "Código" → "Codigo Local Fisico EC"
# "Estabelecimento" → "Estabelecimento EC"
# "Local SSO (Código)" → "Codigo Local SSO EC"

# Aplicar renomeações de forma segura
safe_renames = {
    "Empresa": "Empresa EC",
    "Código": "Codigo Local Fisico EC",
    "Estabelecimento": "Estabelecimento EC",
    "Local SSO (Código)": "Codigo Local SSO EC",
}

for old_name, new_name in safe_renames.items():
    if old_name in df.columns:
        df = df.withColumnRenamed(old_name, new_name)

# Verificar colunas com nomes que podem variar
# DS_EMPRESA pode vir de "Empresa Peoplesoft_1" ou similar
# DS_UNIDADE pode vir de "Nome Local SSO SDWEB" ou similar
# DS_ESTABELECIMENTO pode vir de "Nome Estabelecimento Peoplesoft" ou similar

# Se existir "Empresa Peoplesoft_1", renomear para DS_EMPRESA
for c in df.columns:
    if "Empresa Peoplesoft" in c and c != "Empresa Peoplesoft" and "DS_EMPRESA" not in df.columns:
        df = df.withColumnRenamed(c, "DS_EMPRESA")
    if "Nome Local SSO" in c and "DS_UNIDADE" not in df.columns:
        df = df.withColumnRenamed(c, "DS_UNIDADE")
    if "Nome Estabelecimento" in c and "DS_ESTABELECIMENTO" not in df.columns:
        df = df.withColumnRenamed(c, "DS_ESTABELECIMENTO")

# Distinct e Trim
df = df.dropDuplicates()
for c in df.columns:
    df = df.withColumn(c, F.trim(F.col(f"`{c}`")))

print(f"Colunas após renomeação: {df.columns}")

# COMMAND ----------

# --- Gerar Codigo GHRM e Desc GHRM Full ---
# Codigo GHRM = [Local SSO SDWEB] & "_" & [LOCAL PEOPLESOFT]
df = df.withColumn(
    "Codigo GHRM",
    F.concat(F.col("`Local SSO SDWEB`"), F.lit("_"), F.col("`LOCAL PEOPLESOFT`"))
)

# Desc GHRM Full = "GHRM-" & [DS_UNIDADE] & " " & [Nome]
df = df.withColumn(
    "Desc GHRM Full",
    F.concat(F.lit("GHRM-"), F.col("DS_UNIDADE"), F.lit(" "), F.col("Nome"))
)

# Trim nas colunas geradas
df = df.withColumn("Codigo GHRM", F.trim(F.col("`Codigo GHRM`")))
df = df.withColumn("Desc GHRM Full", F.trim(F.col("`Desc GHRM Full`")))

print(f"Dados_GHRM_FULL — Registros finais: {df.count()}")
print(f"Colunas: {df.columns}")
# display(df)

# COMMAND ----------

save_table(df, BRONZE_GHRM)