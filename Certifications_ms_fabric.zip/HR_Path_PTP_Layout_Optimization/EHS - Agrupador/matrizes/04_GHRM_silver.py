# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Agrupador/utils/utils"

# COMMAND ----------

# =============================================================================
# GHRM — Camada Silver
#
# Equivale às queries Power Query v3:
#   - Agrupador_GHRM_Codificado
#   - Formata_Agrupador_GHRM
#   - Arquivo_Layout_SAP (GHRM)
# =============================================================================

df_full = spark.table(BRONZE_GHRM)

# =============================================================================
# 1) Dados_GHRM (remove colunas EC e Status)
# =============================================================================
cols_to_remove_ghrm = ["Empresa EC", "Estabelecimento EC", "Codigo Local SSO EC",
                        "Codigo Local Fisico EC", "Status"]
df_dados_ghrm = df_full
for c in cols_to_remove_ghrm:
    if c in df_dados_ghrm.columns:
        df_dados_ghrm = df_dados_ghrm.drop(c)

print(f"Dados_GHRM — Registros: {df_dados_ghrm.count()}")

# COMMAND ----------

# =============================================================================
# 2) Agrupador_GHRM_Codificado
#    - Seleciona {Codigo GHRM, Desc GHRM Full}
#    - GHRM 60 UPPER = Text.Middle(Text.Upper([Desc GHRM Full]), 0, 56)
#    - GHRM 40 UPPER = Text.Middle(Text.Upper([Desc GHRM Full]), 0, 36)
#    - GroupBy + Index para cada agrupador
#    - ID Externo: se Index > 0 → "GHRM_" & Codigo GHRM & "_" & PadStart(Index, 8, "0")
#                  senão         → "GHRM_" & Codigo GHRM
# =============================================================================

df_cod = (
    df_full
    .select(
        F.trim(F.col("`Codigo GHRM`")).alias("Codigo_GHRM"),
        F.trim(F.col("`Desc GHRM Full`")).alias("Desc_GHRM_Full"),
    )
    .dropDuplicates()
)

# GHRM 60 UPPER = Text.Middle(Text.Upper([Desc GHRM Full]), 0, 56)
df_cod = df_cod.withColumn(
    "GHRM_60_UPPER",
    F.upper(F.substring(F.col("Desc_GHRM_Full"), 1, 56))
)

# GHRM 40 UPPER = Text.Middle(Text.Upper([Desc GHRM Full]), 0, 36)
df_cod = df_cod.withColumn(
    "GHRM_40_UPPER",
    F.upper(F.substring(F.col("Desc_GHRM_Full"), 1, 36))
)

# Index_GHRM_ID (por Codigo GHRM)
df_cod = add_agrupador_index(df_cod, "Codigo_GHRM", "Desc_GHRM_Full", "Index_GHRM_ID")

# Index_GHRM_60 (por GHRM_60_UPPER)
df_cod = add_agrupador_index(df_cod, "GHRM_60_UPPER", "Desc_GHRM_Full", "Index_GHRM_60")

# Index_GHRM_40 (por GHRM_40_UPPER)
df_cod = add_agrupador_index(df_cod, "GHRM_40_UPPER", "Desc_GHRM_Full", "Index_GHRM_40")

# --- Descrição da Atividade (Agrupador) = Agrupador 60 Caracteres ---
# base = Text.Middle([Desc GHRM Full], 0, 56)
df_cod = df_cod.withColumn(
    "GHRM_60_base",
    F.substring(F.col("Desc_GHRM_Full"), 1, 56)
)
df_cod = build_agrupador(df_cod, "GHRM_60_base", "Index_GHRM_60", "Descricao_Atividade")

# --- Agrupador Quali 40 Caracteres ---
df_cod = df_cod.withColumn(
    "GHRM_40_base",
    F.substring(F.col("Desc_GHRM_Full"), 1, 36)
)
df_cod = build_agrupador(df_cod, "GHRM_40_base", "Index_GHRM_40", "Agrupador_Quali_40")

# --- ID Externo Agrupador VALE ---
# Padding de 8 dígitos (conforme PQ v3)
df_cod = df_cod.withColumn(
    "ID_Externo_Agrupador_VALE",
    F.when(
        F.col("Index_GHRM_ID") > 0,
        F.concat(
            F.lit("GHRM_"), F.col("Codigo_GHRM"), F.lit("_"),
            F.lpad(F.col("Index_GHRM_ID").cast("string"), 8, "0")
        )
    ).otherwise(F.concat(F.lit("GHRM_"), F.col("Codigo_GHRM")))
)

df_cod_final = df_cod.select(
    "Codigo_GHRM", "Desc_GHRM_Full",
    "Descricao_Atividade", "Agrupador_Quali_40",
    "ID_Externo_Agrupador_VALE"
)

print(f"Agrupador_GHRM_Codificado — Registros: {df_cod_final.count()}")
# display(df_cod_final)

# COMMAND ----------

# =============================================================================
# 3) Formata_Agrupador_GHRM
#    Join Dados_GHRM com Agrupador_GHRM_Codificado por {Codigo GHRM, Desc GHRM Full}
# =============================================================================

# Adicionar colunas fixas
df_formata = df_dados_ghrm.withColumn("DELIMITADOR_COLUNA", F.lit(""))
df_formata = df_formata.withColumn("Tipo_Atividade_Agrupador", F.lit("ZGHRM"))

# Join com Agrupador codificado
df_formata = df_formata.join(
    df_cod_final.select(
        F.col("Codigo_GHRM").alias("_cod_ghrm"),
        F.col("Desc_GHRM_Full").alias("_cod_desc"),
        "Descricao_Atividade",
        "ID_Externo_Agrupador_VALE",
    ),
    (F.trim(df_formata["`Codigo GHRM`"]) == F.col("_cod_ghrm")) &
    (F.trim(df_formata["`Desc GHRM Full`"]) == F.col("_cod_desc")),
    "left"
).drop("_cod_ghrm", "_cod_desc")

# Trim e distinct
for c in df_formata.columns:
    df_formata = df_formata.withColumn(c, F.trim(F.col(f"`{c}`")))
df_formata = df_formata.dropDuplicates()

# Selecionar colunas do Formata na ordem do PQ v3
df_formata_output = df_formata.select(
    F.col("Descricao_Atividade").alias("Descrição da Atividade (Agrupador)"),
    F.col("Tipo_Atividade_Agrupador").alias("Tipo da Atividade (Agrupador)"),
    F.col("ID_Externo_Agrupador_VALE").alias("ID Externo Agrupador VALE"),
    F.col("DELIMITADOR_COLUNA").alias("DELIMITADOR COLUNA"),
    F.col("`Empresa Peoplesoft`"),
    F.col("DS_EMPRESA"),
    F.col("`Estabelecimento Peoplesoft`"),
    F.col("DS_ESTABELECIMENTO"),
    F.col("`Local SSO SDWEB`"),
    F.col("DS_UNIDADE"),
    F.col("`LOCAL PEOPLESOFT`"),
    F.col("Nome"),
    F.col("`Codigo GHRM`"),
    F.col("`Desc GHRM Full`"),
).dropDuplicates()

print(f"Formata_Agrupador_GHRM — Registros: {df_formata_output.count()}")
# display(df_formata_output)

# COMMAND ----------

# =============================================================================
# 4) Arquivo_Layout_SAP (GHRM) — 3 colunas finais
# =============================================================================

df_silver = (
    df_formata_output
    .select(
        F.col("Descrição da Atividade (Agrupador)").alias(COL_DESCRICAO),
        F.col("Tipo da Atividade (Agrupador)").alias(COL_TIPO),
        F.col("ID Externo Agrupador VALE").alias(COL_ID_EXTERNO),
    )
    .filter(F.col(COL_DESCRICAO).isNotNull() & (F.col(COL_DESCRICAO) != ""))
    .dropDuplicates()
    .orderBy(COL_DESCRICAO)
)

print(f"Arquivo_Layout_SAP GHRM — Registros: {df_silver.count()}")

# COMMAND ----------

spark.sql(f"""TRUNCATE TABLE {SILVER_GHRM}""")
df_silver.write.insertInto(SILVER_GHRM)

# COMMAND ----------

export_df_to_csv_excel(
    df_cod_final,
    '/Volumes/humanresources_insight/acqu_pcehsagrupador/acqu_pcehsagrupador/layout_agrupador/output/',
    'Agrupador_GHRM_Codificado'
)

export_df_to_csv_excel(
    df_formata_output,
    '/Volumes/humanresources_insight/acqu_pcehsagrupador/acqu_pcehsagrupador/layout_agrupador/output/',
    'Formata_Agrupador_GHRM'
)