# Databricks notebook source
# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Agrupador/utils/utils"

# COMMAND ----------

# Importações
import os
import pandas as pd
import unicodedata
import re
import matplotlib.pyplot as plt
from pyspark.sql import *
from pyspark.sql.types import *
from pyspark.sql.functions import *

# COMMAND ----------

# Consolidação Final — Arquivo_Layout_SAP
# Une GERE + GHRM + GHP + GHE na tabela Silver consolidada.

df_gere = spark.table(SILVER_GERE)
df_ghrm = spark.table(SILVER_GHRM)
df_ghp  = spark.table(SILVER_GHP)
df_ghe  = spark.table(SILVER_GHE)

print("Contagem por template:")
print(f"GERE: {df_gere.count():>6} registros")
print(f"GHRM: {df_ghrm.count():>6} registros")
print(f"GHP: {df_ghp.count():>6} registros")
print(f"GHE: {df_ghe.count():>6} registros")

df_final = (
    df_gere
    .unionByName(df_ghrm)
    .unionByName(df_ghp)
    .unionByName(df_ghe)
    .filter(F.col(COL_DESCRICAO).isNotNull() & (F.col(COL_DESCRICAO) != ""))
    .dropDuplicates()
    .orderBy(COL_DESCRICAO)
)

print(f"Total consolidado: {df_final.count()} registros")

# Validação: IDs Externos duplicados
duplicados = (
    df_final
    .groupBy(COL_ID_EXTERNO)
    .count()
    .filter(F.col("count") > 1)
)

n_dup = duplicados.count()
if n_dup > 0:
    print(f"⚠️  ATENÇÃO: {n_dup} IDs Externos duplicados!")
else:
    print("✅ Nenhum ID Externo duplicado — integridade OK.")

# COMMAND ----------

spark.sql(f"""TRUNCATE TABLE {SILVER_CONSOLIDADO}""")
df_final.write.insertInto(f"{SILVER_CONSOLIDADO}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Gerar arquivo do layout final no volume

# COMMAND ----------

df_consolidado = (
    spark.table(SILVER_CONSOLIDADO)
    .withColumnsRenamed({
        "Descricao_Atividade_Agrupador": "Descrição da Atividade (Agrupador)",
        "Tipo_Atividade_Agrupador": "Tipo da Atividade (Agrupador)",
        "ID_Externo_Agrupador_VALE": "ID Externo (Agrupador) VALE"
    })
)

export_df_to_csv_excel(
    df_consolidado,
    '/Volumes/humanresources_insight/acqu_pcehsagrupador/acqu_pcehsagrupador/layout_agrupador/output/',
    'Template_Agrupador_Cadastro'
)