# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Agrupador/utils/utils"

# COMMAND ----------

# =============================================================================
# GHE — Camada Bronze (DATA BASE GHE FULL)
# Equivale à query Power Query "DATA BASE GHE FULL"
# =============================================================================

# --- Leitura dos CSVs ---
df_raw = read_csv_folder(GHE_INPUT_FOLDER, delimiter=";", encoding="utf-8")
print(f"Registros brutos lidos: {df_raw.count()}")
print(f"Colunas: {df_raw.columns}")

# COMMAND ----------

# --- Filtrar por empresas ---
df = df_raw.filter(F.col("cod_empresa").isin(GHE_EMPRESAS_FILTRO))

# --- Replace '""' → '' em id_matriz e cd_ghe ---
df = df.withColumn("id_matriz", F.regexp_replace(F.col("id_matriz"), '"', ''))
df = df.withColumn("cd_ghe",    F.regexp_replace(F.col("cd_ghe"),    '"', ''))

# --- Trim em todas as colunas ---
for c in df.columns:
    df = df.withColumn(c, F.trim(F.col(f"`{c}`")))

# --- Sort ---
df = df.orderBy("cd_ghe", "cod_local_sso")

# --- Filtrar cd_ghe não nulo/vazio ---
df = df.filter(F.col("cd_ghe").isNotNull() & (F.col("cd_ghe") != ""))

# --- DESC STATUS MATRIZ ---
df = df.withColumn(
    "DESC STATUS MATRIZ",
    F.when(F.col("status") == "A", "APROVADA")
    .when(F.col("status") == "E", "EXCLUIDA")
    .when(F.col("status") == "I", "APROVADA")
    .when(F.col("status") == "P", "PENDENTE")
    .when(F.col("status") == "R", "REPROVADA")
    .otherwise("")
)

print(f"Registros após filtros: {df.count()}")

# COMMAND ----------

# --- Carregar tabelas DE_PARA ---
df_local_t = _read_depara(DE_PARA_LOCAL_FISICO_T_PATH, DE_PARA_LOCAL_T_SHEET)
last_col = df_local_t.columns[-1]
if last_col != "DESCR_1":
    df_local_t = df_local_t.withColumnRenamed(last_col, "DESCR_1")
df_local_t = df_local_t.dropDuplicates()

df_local_sso = _read_depara(DE_PARA_LOCAL_SSO_PATH, DE_PARA_LOCAL_SSO_SHEET)

# FIX: Deduplicar df_local_sso pela chave do join antes de unir.
# O PQ faz Table.Distinct após Expand; aqui garantimos que a chave 4-campo
# seja única para evitar fanout (multiplicação de linhas) no join PySpark.
# Colunas relevantes selecionadas: apenas as que serão usadas no join + expand.
df_local_sso = (
    df_local_sso
    .select(
        F.col("CD_EMPRESA"),
        F.col("CD_ESTABELECIMENTO"),
        F.col("`CD_UNIDADE(DE)`").alias("_sso_unidade_de"),
        F.col("CD_LOCAL_FISICO"),
        F.col("`CD_UNIDADE (PARA)`").alias("SSO_CD_UNIDADE_PARA"),
        F.col("DS_UNIDADE_NEW").alias("SSO_DS_UNIDADE_NEW"),
    )
    .dropDuplicates(["CD_EMPRESA", "CD_ESTABELECIMENTO", "_sso_unidade_de", "CD_LOCAL_FISICO"])
)

df_arvore_ec = _read_depara(DE_PARA_ARVORE_EC_PATH, ARVORE_EC_SHEET)
df_arvore_ec = df_arvore_ec.dropDuplicates()

# =============================================================================
# Join 1: DE_PARA_Local_Fisico_T
# Chave: cod_local_fisico = LOCAL-T
# Gera: COD LOCAL FISICO, DESC LOCAL FISICO
# =============================================================================
df = df.join(
    df_local_t.select(
        F.col("`LOCAL-T`").alias("_join_local_t"),
        F.col("`LOCAL NÃO-T`").alias("DE_PARA_LOCAL_NAO_T"),
        F.col("DESCR_1").alias("DE_PARA_DESCR_1"),
    ),
    df["cod_local_fisico"] == F.col("_join_local_t"),
    "left"
).drop("_join_local_t")

df = df.withColumn(
    "COD LOCAL FISICO",
    F.when(
        F.col("DE_PARA_LOCAL_NAO_T").isNull() | (F.col("DE_PARA_LOCAL_NAO_T") == ""),
        F.col("cod_local_fisico")
    ).otherwise(F.col("DE_PARA_LOCAL_NAO_T"))
)
df = df.withColumn(
    "DESC LOCAL FISICO",
    F.when(
        F.col("DE_PARA_DESCR_1").isNull() | (F.col("DE_PARA_DESCR_1") == ""),
        F.col("ds_local_fisico")
    ).otherwise(F.col("DE_PARA_DESCR_1"))
)

# COMMAND ----------

# =============================================================================
# Join 2: Local SSO_ DE X PARA
# Chave: cod_empresa + cd_estabelecimento + cod_local_sso + COD LOCAL FISICO
# Gera: COD LOCAL SSO, DESC LOCAL SSO
# FIX: dropDuplicates() imediatamente após o join — espelha o "Removed Duplicates"
#      que o Power Query faz logo após "Expanded Local SSO_ DE X PARA".
# =============================================================================
df = df.join(
    df_local_sso.withColumnRenamed("CD_EMPRESA",        "_sso_empresa")
                .withColumnRenamed("CD_ESTABELECIMENTO", "_sso_estab")
                .withColumnRenamed("CD_LOCAL_FISICO",    "_sso_local_fisico"),
    (df["cod_empresa"]        == F.col("_sso_empresa"))     &
    (df["cd_estabelecimento"] == F.col("_sso_estab"))       &
    (df["cod_local_sso"]      == F.col("_sso_unidade_de"))  &
    (df["COD LOCAL FISICO"]   == F.col("_sso_local_fisico")),
    "left"
).drop("_sso_empresa", "_sso_estab", "_sso_unidade_de", "_sso_local_fisico")

df = df.withColumn(
    "COD LOCAL SSO",
    F.when(
        F.col("SSO_CD_UNIDADE_PARA").isNull() | (F.col("SSO_CD_UNIDADE_PARA") == ""),
        F.col("cod_local_sso")
    ).otherwise(F.col("SSO_CD_UNIDADE_PARA"))
)
df = df.withColumn(
    "DESC LOCAL SSO",
    F.when(
        F.col("SSO_DS_UNIDADE_NEW").isNull() | (F.col("SSO_DS_UNIDADE_NEW") == ""),
        F.col("ds_local_sso")
    ).otherwise(F.col("SSO_DS_UNIDADE_NEW"))
)

# FIX: Distinct após Join 2 — equivalente ao "Removed Duplicates" do PQ
df = df.dropDuplicates()
print(f"Após Join 2 (SSO) + Distinct: {df.count()}")

# COMMAND ----------

# =============================================================================
# Gerar COD GHE, DESC GHE, ID Externo (Agrupador) VALE Primario
# =============================================================================
# Antes de gerar COD GHE / DESC GHE, normalizar ds_ghe
# F.trim() só remove leading/trailing. regexp_replace colapsa whitespace interno também.
df = df.withColumn(
    "ds_ghe",
    F.regexp_replace(F.trim(F.col("ds_ghe")), r"\s+", " ")
)

df = df.withColumn(
    "COD GHE",
    F.when(
        F.col("cd_ghe") == "A000000",
        F.concat(F.col("`COD LOCAL FISICO`"), F.lit("_"), F.col("DESC STATUS MATRIZ"))
    ).otherwise(F.col("cd_ghe"))
)
df = df.withColumn(
    "DESC GHE",
    F.when(
        F.col("cd_ghe") == "A000000",
        F.concat(F.col("`COD LOCAL FISICO`"), F.lit("_DUMMY_"), F.col("DESC STATUS MATRIZ"))
    ).when(
        (F.col("cd_ghe") != "A000000") & (F.col("ds_ghe") == "."),
        F.concat(F.col("cd_ghe"), F.lit(" - ."))
    ).otherwise(F.col("ds_ghe"))
)

# Distinct após COD/DESC GHE
df = df.dropDuplicates()

# ID Externo (Agrupador) VALE Primario
df = df.withColumn(
    "ID Externo (Agrupador) VALE Primario",
    F.concat(F.col("`COD GHE`"), F.lit("_"), F.col("`COD LOCAL SSO`"))
)

# COMMAND ----------

# =============================================================================
# Join 3: Arvore_Localizacao_EC
# Chave: cd_estabelecimento + COD LOCAL SSO + COD LOCAL FISICO
# Gera: COD LOCAL FISICO EC, COD LOCAL SSO EC
# FIX: dropDuplicates() após join — espelha "Removed Duplicates1" do PQ
# =============================================================================
df = df.join(
    df_arvore_ec.select(
        F.col("`Estabelecimento Peoplesoft`").alias("_ec_estab"),
        F.col("`Local SSO SDWEB`").alias("_ec_sso_sdweb"),
        F.col("`LOCAL PEOPLESOFT`").alias("_ec_local_ps"),
        F.col("`Código`").alias("COD LOCAL FISICO EC"),
        F.col("`Local SSO (Código)`").alias("COD LOCAL SSO EC"),
    ),
    (df["cd_estabelecimento"] == F.col("_ec_estab"))     &
    (df["COD LOCAL SSO"]      == F.col("_ec_sso_sdweb")) &
    (df["COD LOCAL FISICO"]   == F.col("_ec_local_ps")),
    "left"
).drop("_ec_estab", "_ec_sso_sdweb", "_ec_local_ps")

# FIX: Distinct após Join 3 — equivalente ao "Removed Duplicates1" do PQ
df = df.dropDuplicates()

# Replace '|' → '/' em DESC GHE
df = df.withColumn("DESC GHE", F.regexp_replace(F.col("`DESC GHE`"), r"\|", "/"))

# Trim final
for c in df.columns:
    df = df.withColumn(c, F.trim(F.col(f"`{c}`")))

print(f"DATA BASE GHE FULL — Registros finais: {df.count()}")
print(f"Colunas: {df.columns}")

# COMMAND ----------

import re

def sanitize_columns(df):
    seen = {}
    final_names = []
    for col in df.columns:
        sanitized = re.sub(r"[ ,;{}()\n\t=]", "_", col)
        key = sanitized.lower()
        if key in seen:
            prev_idx = next(i for i, n in enumerate(final_names) if n.lower() == key)
            final_names[prev_idx] = final_names[prev_idx] + "_orig"
            seen[key + "_orig"] = final_names[prev_idx]
            final_names.append(sanitized)
            seen[key] = sanitized
        else:
            seen[key] = sanitized
            final_names.append(sanitized)
    print("Mapeamento:")
    for orig, final in zip(df.columns, final_names):
        if orig != final:
            print(f"  {orig!r:35s} → {final!r}")
    return df.toDF(*final_names)

df = sanitize_columns(df)

cols_lower = [c.lower() for c in df.columns]
dupes = [c for c in cols_lower if cols_lower.count(c) > 1]
if dupes:
    print(f"⚠️ Ainda há colisões: {set(dupes)}")
else:
    print("✅ Sem colisões")
    save_table(df, BRONZE_GHE)