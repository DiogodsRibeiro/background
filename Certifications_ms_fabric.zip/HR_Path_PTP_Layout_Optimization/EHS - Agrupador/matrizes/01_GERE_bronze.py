# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Agrupador/utils/utils"

# COMMAND ----------

# =============================================================================
# GERE — Camada Bronze (FULL_Dados_GERE)
#
# Equivale à query Power Query v3 "FULL_Dados_GERE":
#   1. Lê CSVs da pasta (Folder.Files, delimiter=";", 36 colunas, UTF-8)
#   2. Trim em todas as colunas
#   3. Remove Source.Name
#   4. PadStart em Cód. Empresa (5 dígitos)
#   5. Join com DE_PARA_Local_Fisico_T  → CD/DS LOCAL FISICO NAO T
#   6. Join com Local SSO_DE X PARA     → CD/DS LOCAL SSO
#   7. Join com Arvore de Localizacao EC → LOCAL FISICO EC
#   8. Join com Arvore de Localizacao EC → LOCAL SSO EC
#   9. Gera ID EXTERNO = Código GERE + "_" + CD LOCAL SSO + "_" + Cód. Empresa
#  10. Filtra Código GERE não vazio, Remove duplicatas
# =============================================================================

# --- Leitura dos CSVs ---
df_raw = read_csv_folder(GERE_INPUT_FOLDER, delimiter=";", encoding="utf-8")

if "Unnamed: 6" in df_raw.columns:
    df_raw = df_raw.drop("Unnamed: 6")

print(f"Registros brutos lidos: {df_raw.count()}")
print(f"Colunas: {df_raw.columns}")

# COMMAND ----------

# --- Trim em todas as colunas ---
for c in df_raw.columns:
    df_raw = df_raw.withColumn(c, F.trim(F.col(f"`{c}`")))

# --- Normalizar nomes de colunas para compatibilidade Delta ---
df = df_raw.select(
    F.col("`ID Matriz`").alias("ID_Matriz"),
    F.col("`Cód. Empresa`").alias("Cod_Empresa_Orig"),
    F.col("Empresa"),
    F.col("`Cód. Local SSO`").alias("Cod_Local_SSO_Orig"),
    F.col("`Local SSO`").alias("Local_SSO_Orig"),
    F.col("Matricula"),
    F.col("Nome"),
    F.col("`Cód. Cargo`").alias("Cod_Cargo"),
    F.col("Cargo"),
    F.col("`Cód. Função`").alias("Cod_Funcao"),
    F.col("`Função`").alias("Funcao"),
    F.col("`Cód. Local de Trabalho`").alias("Cod_Local_Trabalho"),
    F.col("`Local de Trabalho`").alias("Local_Trabalho"),
    F.col("Turno"),
    F.col("`Código GHE (SDWEB)`").alias("Codigo_GHE_SDWEB"),
    F.col("`GHE (SDWEB)`").alias("GHE_SDWEB"),
    F.col("`Código GERE`").alias("Codigo_GERE"),
    F.col("GERE"),
    F.col("`Fator de Risco`").alias("Fator_Risco"),
    F.col("`FATOR DE RISCO: PARA`").alias("Fator_Risco_Para"),
    F.col("`Exigências Ergonômicas`").alias("Exigencias_Ergonomicas"),
    F.col("`Exigências Ergonômicas: PARA`").alias("Exigencias_Ergonomicas_Para"),
    F.col("`Exigência de tempo`").alias("Exigencia_Tempo"),
    F.col("`Exgência de Intensidade`").alias("Exigencia_Intensidade"),
    F.col("Severidade"),
    F.col("`Categoria Risco`").alias("Categoria_Risco"),
    F.col("`Natureza Atividade`").alias("Natureza_Atividade"),
    F.col("`Perfil do GERE`").alias("Perfil_GERE"),
    F.col("`Data Reconhecimento`").alias("Data_Reconhecimento"),
    F.col("`Data Validade do Reconhecimento`").alias("Data_Validade_Reconhecimento"),
    F.col("`1.DE`").alias("Aprov_1_DE"),
    F.col("`2.DI/GE`").alias("Aprov_2_DI_GE"),
    F.col("`3.GE/GA/COORD`").alias("Aprov_3_GE_GA_COORD"),
    F.col("`4.GA/COORD/SUP`").alias("Aprov_4_GA_COORD_SUP"),
    F.col("`5.COORD/SUP`").alias("Aprov_5_COORD_SUP"),
    F.col("`6.COORD/SUP`").alias("Aprov_6_COORD_SUP"),
)

# --- PadStart em Cód. Empresa para 5 dígitos ---
df = df.withColumn(
    "Cod_Empresa",
    F.lpad(F.col("Cod_Empresa_Orig"), 5, "0")
)

# COMMAND ----------

# --- Carregar DE_PARA ---
df_local_t = _read_depara(DE_PARA_LOCAL_FISICO_T_PATH_GERE, DE_PARA_LOCAL_T_SHEET)
last_col = df_local_t.columns[-1]
if last_col != "DESCR_1":
    df_local_t = df_local_t.withColumnRenamed(last_col, "DESCR_1")

df_local_sso_depara = _read_depara(DE_PARA_LOCAL_SSO_PATH, DE_PARA_LOCAL_SSO_SHEET)
df_arvore_ec = _read_depara(DE_PARA_ARVORE_EC_PATH, ARVORE_EC_SHEET)

print(f"DE_PARA_Local_Fisico_T: {df_local_t.count()} registros")
print(f"Local SSO DE X PARA:    {df_local_sso_depara.count()} registros")
print(f"Arvore Localizacao EC:  {df_arvore_ec.count()} registros")

# COMMAND ----------

# =============================================================================
# Join 1: DE_PARA_Local_Fisico_T
# Chave: Cód. Local de Trabalho = LOCAL-T
# =============================================================================

df = df.join(
    df_local_t.select(
        F.col("`LOCAL-T`").alias("_join_local_t"),
        F.col("`LOCAL NÃO-T`").alias("DE_PARA_LOCATION_1"),
        F.col("DESCR_1").alias("DE_PARA_DESCR_2"),
    ),
    df["Cod_Local_Trabalho"] == F.col("_join_local_t"),
    "left"
).drop("_join_local_t")

df = df.withColumn(
    "CD_LOCAL_FISICO_NAO_T",
    F.when(
        F.col("DE_PARA_LOCATION_1").isNull() | (F.col("DE_PARA_LOCATION_1") == ""),
        F.col("Cod_Local_Trabalho")
    ).otherwise(F.col("DE_PARA_LOCATION_1"))
)

df = df.withColumn(
    "DS_LOCAL_FISICO_NAO_T",
    F.when(
        F.col("DE_PARA_DESCR_2").isNull() | (F.col("DE_PARA_DESCR_2") == ""),
        F.col("Local_Trabalho")
    ).otherwise(F.col("DE_PARA_DESCR_2"))
)

# COMMAND ----------

# =============================================================================
# Join 2: Local SSO_DE X PARA
# Chave: Cód. Empresa + Cód. Local SSO + CD LOCAL FISICO NAO T
#       = CD_EMPRESA + CD_UNIDADE(DE) + CD_LOCAL_FISICO
# =============================================================================

df = df.join(
    df_local_sso_depara.select(
        F.col("CD_EMPRESA").alias("_sso_empresa"),
        F.col("`CD_UNIDADE(DE)`").alias("_sso_unidade_de"),
        F.col("CD_LOCAL_FISICO").alias("_sso_local_fisico"),
        F.col("`CD_UNIDADE (PARA)`").alias("SSO_CD_UNIDADE_PARA"),
        F.col("DS_UNIDADE_NEW").alias("SSO_DS_UNIDADE_NEW"),
    ),
    (df["Cod_Empresa"] == F.col("_sso_empresa")) &
    (df["Cod_Local_SSO_Orig"] == F.col("_sso_unidade_de")) &
    (df["CD_LOCAL_FISICO_NAO_T"] == F.col("_sso_local_fisico")),
    "left"
).drop("_sso_empresa", "_sso_unidade_de", "_sso_local_fisico")

df = df.withColumn(
    "CD_LOCAL_SSO",
    F.when(
        F.col("SSO_CD_UNIDADE_PARA").isNull() | (F.col("SSO_CD_UNIDADE_PARA") == ""),
        F.col("Cod_Local_SSO_Orig")
    ).otherwise(F.col("SSO_CD_UNIDADE_PARA"))
)

df = df.withColumn(
    "DS_LOCAL_SSO",
    F.when(
        F.col("SSO_DS_UNIDADE_NEW").isNull() | (F.col("SSO_DS_UNIDADE_NEW") == ""),
        F.col("Local_SSO_Orig")
    ).otherwise(F.col("SSO_DS_UNIDADE_NEW"))
)

# COMMAND ----------

# =============================================================================
# Join 3: LOCAL FISICO EC
# Chave PQ: Empresa Peoplesoft + Local SSO SDWEB + LOCAL PEOPLESOFT
#           = Cod_Empresa + CD_LOCAL_SSO + CD_LOCAL_FISICO_NAO_T
# =============================================================================
df = df.join(
    df_arvore_ec.select(
        F.col("`Empresa Peoplesoft`").alias("_ec_empresa_1"),
        F.col("`Local SSO SDWEB`").alias("_ec_sso_sdweb_1"),   # ← adicionado
        F.col("`LOCAL PEOPLESOFT`").alias("_ec_local_ps_1"),
        F.col("`Código`").alias("LOCAL_FISICO_EC"),
    ),
    (df["Cod_Empresa"] == F.col("_ec_empresa_1")) &
    (df["CD_LOCAL_SSO"] == F.col("_ec_sso_sdweb_1")) &         # ← adicionado
    (df["CD_LOCAL_FISICO_NAO_T"] == F.col("_ec_local_ps_1")),
    "left"
).drop("_ec_empresa_1", "_ec_sso_sdweb_1", "_ec_local_ps_1")

# =============================================================================
# Join 4: LOCAL SSO EC
# Chave PQ: Empresa Peoplesoft + Local SSO SDWEB + LOCAL PEOPLESOFT
#           = Cod_Empresa + CD_LOCAL_SSO + CD_LOCAL_FISICO_NAO_T
# =============================================================================
df = df.join(
    df_arvore_ec.select(
        F.col("`Empresa Peoplesoft`").alias("_ec_empresa_2"),
        F.col("`Local SSO SDWEB`").alias("_ec_sso_sdweb_2"),
        F.col("`LOCAL PEOPLESOFT`").alias("_ec_local_ps_2"),    # ← adicionado
        F.col("`Local SSO (Código)`").alias("LOCAL_SSO_EC"),
    ),
    (df["Cod_Empresa"] == F.col("_ec_empresa_2")) &
    (df["CD_LOCAL_SSO"] == F.col("_ec_sso_sdweb_2")) &
    (df["CD_LOCAL_FISICO_NAO_T"] == F.col("_ec_local_ps_2")),   # ← adicionado
    "left"
).drop("_ec_empresa_2", "_ec_sso_sdweb_2", "_ec_local_ps_2")

# COMMAND ----------

# =============================================================================
# ID EXTERNO = Código GERE + "_" + CD LOCAL SSO + "_" + Cód. Empresa
# Filtro: Código GERE não vazio
# Remove duplicatas
# =============================================================================

df = df.withColumn(
    "ID_EXTERNO",
    F.concat(F.col("Codigo_GERE"), F.lit("_"), F.col("CD_LOCAL_SSO"), F.lit("_"), F.col("Cod_Empresa"))
)

df = df.filter(
    F.col("Codigo_GERE").isNotNull() & (F.col("Codigo_GERE") != "")
)

df = df.dropDuplicates()

print(f"FULL_Dados_GERE — Registros finais: {df.count()}")
print(f"Colunas: {df.columns}")

# COMMAND ----------

display(df)

# COMMAND ----------

save_table(df, BRONZE_GERE)