# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Agrupador/utils/utils"

# COMMAND ----------

# --- Leitura do Excel bruto ---
df_raw = read_excel(GHP_INPUT_PATH, GHP_SHEET_NAME)
print(f"Registros brutos lidos: {df_raw.count()}")
print(f"Colunas: {df_raw.columns}")

# COMMAND ----------

# --- Trim em todas as colunas ---
for c in df_raw.columns:
    df_raw = df_raw.withColumn(c, F.trim(F.col(f"`{c}`")))

# --- Carregar tabelas DE_PARA ---
df_local_t = _read_depara(DE_PARA_LOCAL_FISICO_T_V2_PATH, DE_PARA_LOCAL_T_V2_SHEET)
# A planilha v2 tem colunas: LOCATION, DESCR, LOCATION_1, DESCR_2
# Renomear para padronizar
col_names = df_local_t.columns
if len(col_names) >= 4:
    df_local_t = df_local_t.toDF("LOCATION", "DESCR", "LOCATION_1", "DESCR_2")

df_local_sso = _read_depara(DE_PARA_LOCAL_SSO_PATH, DE_PARA_LOCAL_SSO_SHEET)
df_arvore_ec = _read_depara(DE_PARA_ARVORE_EC_PATH, ARVORE_EC_SHEET)

print(f"DE_PARA_Local_Fisico_T (v2): {df_local_t.count()} registros")
print(f"Local SSO DE X PARA:         {df_local_sso.count()} registros")
print(f"Arvore Localizacao EC:       {df_arvore_ec.count()} registros")

# COMMAND ----------

# =============================================================================
# Join 1: DE_PARA_Local_Fisico_T (v2)
# Chave: COD_LOCAL_FISICO = LOCATION
# Expande: LOCATION_1, DESCR_2
# Gera: CD LOCAL FISICO, DS LOCAL FISICO
# =============================================================================

df = df_raw.join(
    df_local_t.select(
        F.col("LOCATION").alias("_join_loc"),
        F.col("LOCATION_1").alias("DE_PARA_LOCATION_1"),
        F.col("DESCR_2").alias("DE_PARA_DESCR_2"),
    ),
    df_raw["COD_LOCAL_FISICO"] == F.col("_join_loc"),
    "left"
).drop("_join_loc")

# CD LOCAL FISICO: se DE_PARA vazio/null, usa COD_LOCAL_FISICO original
df = df.withColumn(
    "CD LOCAL FISICO",
    F.when(
        F.col("DE_PARA_LOCATION_1").isNull() | (F.col("DE_PARA_LOCATION_1") == ""),
        F.col("COD_LOCAL_FISICO")
    ).otherwise(F.col("DE_PARA_LOCATION_1"))
)

# DS LOCAL FISICO: se DE_PARA vazio/null, usa DES_LOCAL_FISICO original
df = df.withColumn(
    "DS LOCAL FISICO",
    F.when(
        F.col("DE_PARA_DESCR_2").isNull() | (F.col("DE_PARA_DESCR_2") == ""),
        F.col("DES_LOCAL_FISICO")
    ).otherwise(F.col("DE_PARA_DESCR_2"))
)

# COMMAND ----------

# =============================================================================
# Join 2: Local SSO_ DE X PARA
# Chave: CD_EMPRESA + COD_ESTABELECIMENTO + COD_LOCAL_SSO + CD LOCAL FISICO
#       = CD_EMPRESA + CD_ESTABELECIMENTO + CD_UNIDADE(DE) + CD_LOCAL_FISICO
# Expande: CD_UNIDADE (PARA), DS_UNIDADE
# Gera: CD LOCAL SSO, DS LOCAL SSO
# =============================================================================

df = df.join(
    df_local_sso.select(
        F.col("CD_EMPRESA").alias("_sso_empresa"),
        F.col("CD_ESTABELECIMENTO").alias("_sso_estab"),
        F.col("`CD_UNIDADE(DE)`").alias("_sso_unidade_de"),
        F.col("CD_LOCAL_FISICO").alias("_sso_local_fisico"),
        F.col("`CD_UNIDADE (PARA)`").alias("SSO_CD_UNIDADE_PARA"),
        F.col("DS_UNIDADE").alias("SSO_DS_UNIDADE"),
    ),
    (df["CD_EMPRESA"] == F.col("_sso_empresa")) &
    (df["COD_ESTABELECIMENTO"] == F.col("_sso_estab")) &
    (df["COD_LOCAL_SSO"] == F.col("_sso_unidade_de")) &
    (df["`CD LOCAL FISICO`"] == F.col("_sso_local_fisico")),
    "left"
).drop("_sso_empresa", "_sso_estab", "_sso_unidade_de", "_sso_local_fisico")

df = df.withColumn(
    "CD LOCAL SSO",
    F.when(
        F.col("SSO_CD_UNIDADE_PARA").isNull() | (F.col("SSO_CD_UNIDADE_PARA") == ""),
        F.col("COD_LOCAL_SSO")
    ).otherwise(F.col("SSO_CD_UNIDADE_PARA"))
)

df = df.withColumn(
    "DS LOCAL SSO",
    F.when(
        F.col("SSO_DS_UNIDADE").isNull() | (F.col("SSO_DS_UNIDADE") == ""),
        F.col("DES_LOCAL_SSO")
    ).otherwise(F.col("SSO_DS_UNIDADE"))
)

# COMMAND ----------

# =============================================================================
# Join 3: Arvore_Localizacao_EC
# Chave: CD_EMPRESA + CD LOCAL SSO + CD LOCAL FISICO
#       = Empresa Peoplesoft + Local SSO SDWEB + LOCAL PEOPLESOFT
# Expande: Código, Local SSO (Código)
# =============================================================================

df = df.join(
    df_arvore_ec.select(
        F.col("`Empresa Peoplesoft`").alias("_ec_empresa"),
        F.col("`Local SSO SDWEB`").alias("_ec_sso_sdweb"),
        F.col("`LOCAL PEOPLESOFT`").alias("_ec_local_ps"),
        F.col("`Código`").alias("Arvore Localizacao EC.Código"),
        F.col("`Local SSO (Código)`").alias("Arvore Localizacao EC.Local SSO (Código)"),
    ),
    (df["CD_EMPRESA"] == F.col("_ec_empresa")) &
    (df["`CD LOCAL SSO`"] == F.col("_ec_sso_sdweb")) &
    (df["`CD LOCAL FISICO`"] == F.col("_ec_local_ps")),
    "left"
).drop("_ec_empresa", "_ec_sso_sdweb", "_ec_local_ps")

# Distinct
df = df.dropDuplicates()

# Remover colunas intermediárias que não vão para o output final
# (conforme PQ v3: remove COD_LOCAL_SSO, DES_LOCAL_SSO, COD_LOCAL_FISICO, DES_LOCAL_FISICO,
#  DE_PARA cols intermediárias)
cols_remove_intermediate = ["COD_LOCAL_SSO", "DES_LOCAL_SSO",
                            "DE_PARA_LOCATION_1", "DE_PARA_DESCR_2",
                            "SSO_CD_UNIDADE_PARA", "SSO_DS_UNIDADE"]
for c in cols_remove_intermediate:
    if c in df.columns:
        df = df.drop(c)

# Remover colunas COD_LOCAL_FISICO e DES_LOCAL_FISICO originais (conforme PQ v3)
for c in ["COD_LOCAL_FISICO", "DES_LOCAL_FISICO"]:
    if c in df.columns:
        df = df.drop(c)

# Distinct final
df = df.dropDuplicates()

# Trim
for c in df.columns:
    df = df.withColumn(c, F.trim(F.col(f"`{c}`")))

print(f"FULL_Dados_GHP — Registros finais: {df.count()}")
print(f"Colunas: {df.columns}")
# display(df)

# COMMAND ----------

df = normalize_column_names(df)
save_table(df, BRONZE_GHP)