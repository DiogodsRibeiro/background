# Databricks notebook source
# Databricks notebook source
# Configurações Globais — Layout SAP Agrupador

# Volume de entrada
RAW_BASE = "/Volumes/humanresources_insight/acqu_pcehsagrupador/acqu_pcehsagrupador/layout_agrupador/raw_files"

# Arquivos de entrada GERE (agora via CSV em pasta)
GERE_INPUT_FOLDER = f"{RAW_BASE}/gere_csv"

# Arquivos de entrada individuais
GHRM_INPUT_PATH = f"{RAW_BASE}/Arvore_Localizacao_EC_20260317.xlsx"
GHP_INPUT_PATH = f"{RAW_BASE}/GHP_20260313.xlsm"
GHE_INPUT_FOLDER = f"{RAW_BASE}/ghe_csv"

# Arquivos DE_PARA (tabelas de referência para joins)
DE_PARA_BASE = f"{RAW_BASE}/de_para"
DE_PARA_LOCAL_FISICO_T_PATH = f"{DE_PARA_BASE}/LOCAL_T_NAO_T_20260310.XLSX"
DE_PARA_LOCAL_FISICO_T_PATH_GERE = f"{DE_PARA_BASE}/LOCAL_T_NAO_T_20260316.XLSX"
DE_PARA_LOCAL_SSO_PATH = f"{DE_PARA_BASE}/Local SSO_ DE X PARA_20260316.xlsx"
DE_PARA_ARVORE_EC_PATH = f"{DE_PARA_BASE}/Arvore_Localizacao_EC_20260323.xlsx"
DE_PARA_LOCAL_FISICO_T_V2_PATH = f"{DE_PARA_BASE}/De para dos Locais fisicos T_v2.xlsx"

# Schemas
BRONZE_SCHEMA = "humanresources_insight.bron_pcehsagrupador"
SILVER_SCHEMA = "humanresources_insight.silv_pcehsagrupador"

# Tabelas Bronze
BRONZE_GERE = f"{BRONZE_SCHEMA}.gere_raw"
BRONZE_GHRM = f"{BRONZE_SCHEMA}.ghrm_raw"
BRONZE_GHP = f"{BRONZE_SCHEMA}.ghp_raw"
BRONZE_GHE = f"{BRONZE_SCHEMA}.ghe_raw"

# Tabelas Silver
SILVER_GERE = f"{SILVER_SCHEMA}.arquivo_layout_sap_gere"
SILVER_GHRM = f"{SILVER_SCHEMA}.arquivo_layout_sap_ghrm"
SILVER_GHP = f"{SILVER_SCHEMA}.arquivo_layout_sap_ghp"
SILVER_GHE = f"{SILVER_SCHEMA}.arquivo_layout_sap_ghe"
SILVER_CONSOLIDADO = f"{SILVER_SCHEMA}.agrup_arquivo_layout_sap"

# Nomes das abas
GHRM_SHEET_NAME = "LOCATION"
GHP_SHEET_NAME  = "Agrupador_Cadastro"
GHE_SHEET_NAME  = "GHE"

DE_PARA_LOCAL_T_SHEET = "DE_PARA_Local_Fisico_T"
DE_PARA_LOCAL_SSO_SHEET = "Local SSO_ DE X PARA"
ARVORE_EC_SHEET = "Arvore_Localizacao_EC"
DE_PARA_LOCAL_T_V2_SHEET = "DE_PARA_Local_Fisico_T"

# Empresas filtradas no GHE
GHE_EMPRESAS_FILTRO = ["00001", "00064", "00068", "00112", "00284", "00360", "00632", "00646"]

# Colunas finais padronizadas
COL_DESCRICAO  = "Descricao_Atividade_Agrupador"
COL_TIPO = "Tipo_Atividade_Agrupador"
COL_ID_EXTERNO = "ID_Externo_Agrupador_VALE"

print("Configurações carregadas.")