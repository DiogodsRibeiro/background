# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Agrupador/config/config"

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

# Utilitários — Layout SAP Agrupador

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.window import Window
import pandas as pd
import os
import io
import openpyxl

def add_agrupador_index_gere(
    df: DataFrame,
    key_upper_col: str,
    order_col: str,
    index_col: str,
    secondary_order_col: str = None
) -> DataFrame:
    order_cols = [key_upper_col, order_col]
    if secondary_order_col:
        order_cols.append(secondary_order_col)
    window = Window.partitionBy(key_upper_col).orderBy(*order_cols)
    return df.withColumn(index_col, (F.row_number().over(window) - 1).cast("long"))

def read_excel(path: str, sheet_name: str) -> DataFrame:
    """
    Lê um arquivo Excel do Volume e retorna um DataFrame Spark.
    Todos os campos são lidos como string.
    """
    pdf = pd.read_excel(path, sheet_name=sheet_name, dtype=str, header=0)
    pdf.columns = [c.strip() for c in pdf.columns]
    return spark.createDataFrame(pdf.fillna(""))

def read_csv_folder(folder_path: str, delimiter: str = ";", encoding: str = "utf-8") -> DataFrame:
    """
    Lê todos os arquivos CSV de uma pasta e retorna um DataFrame Spark unificado.
    Equivale ao Folder.Files + Transform File do Power Query.
    """
    all_dfs = []
    for fname in os.listdir(folder_path):
        if fname.endswith(".csv"):
            fpath = os.path.join(folder_path, fname)
            pdf = pd.read_csv(fpath, sep=delimiter, dtype=str, encoding=encoding)
            pdf.columns = [c.strip() for c in pdf.columns]
            pdf = pdf.fillna("")
            all_dfs.append(pdf)
    if not all_dfs:
        raise ValueError(f"Nenhum CSV encontrado em {folder_path}")
    combined = pd.concat(all_dfs, ignore_index=True)
    return spark.createDataFrame(combined)

def save_table(df: DataFrame, table: str) -> None:
    """Grava um DataFrame como tabela Delta com overwrite."""
    (
        df.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(table)
    )
    print(f"✅ Gravado: {table} ({df.count()} registros)")

def make_chave(df: DataFrame, source_col: str, prefix: str, max_len: int, result_col: str) -> DataFrame:
    """
    Gera chave truncada com prefixo, substituindo '|' por '/'.
    Equivale ao Text.Start("PREFIX" & Text.Replace([col],"|","/"), N) das Power Queries.
    """
    return df.withColumn(
        result_col,
        F.substring(
            F.concat(F.lit(prefix), F.regexp_replace(F.col(source_col), r"\|", "/")),
            1, max_len
        )
    )

def add_upper(df: DataFrame, source_col: str, result_col: str) -> DataFrame:
    """Adiciona coluna UPPER substituindo '|' por '/'."""
    return df.withColumn(
        result_col,
        F.upper(F.regexp_replace(F.col(source_col), r"\|", "/"))
    )

def add_agrupador_index(df: DataFrame, key_upper_col: str, order_col: str, index_col: str) -> DataFrame:
    """
    Adiciona índice 0-based dentro de cada grupo via Window Function.
    Equivale ao Table.AddIndexColumn das Power Queries.
    """
    window = Window.partitionBy(key_upper_col).orderBy(key_upper_col, order_col)
    return df.withColumn(index_col, (F.row_number().over(window) - 1).cast("long"))

def build_agrupador(df: DataFrame, base_col: str, index_col: str, result_col: str) -> DataFrame:
    """
    Constrói a coluna de agrupador final:
    - índice = 0 → valor sem sufixo
    - índice > 0 → valor + " " + índice
    """
    return df.withColumn(
        result_col,
        F.when(
            F.col(index_col) > 0,
            F.concat(F.col(base_col), F.lit(" "), F.col(index_col).cast("string"))
        ).otherwise(F.col(base_col))
    )

def select_final(df: DataFrame, descricao_col: str, tipo_valor: str, id_externo_col: str) -> DataFrame:
    """
    Seleciona as 3 colunas finais do Arquivo_Layout_SAP, filtra nulos e deduplica.
    """
    return (
        df
        .select(
            F.col(descricao_col).alias(COL_DESCRICAO),
            F.lit(tipo_valor).alias(COL_TIPO),
            F.col(id_externo_col).alias(COL_ID_EXTERNO),
        )
        .filter(F.col(COL_DESCRICAO).isNotNull() & (F.col(COL_DESCRICAO) != ""))
        .dropDuplicates()
        .orderBy(COL_DESCRICAO)
    )

def export_df_to_csv_excel(df: DataFrame, volume_path: str, file_base: str) -> None:
    """Exporta um DataFrame para CSV e Excel em um volume."""
    base = volume_path.rstrip("/")
    final_csv   = f"{base}/{file_base}.csv"
    final_excel = f"{base}/{file_base}.xlsx"
    dbutils.fs.mkdirs(base)
    pdf = df.toPandas()
    with open(final_csv, "w", encoding="utf-8-sig") as f:
        pdf.to_csv(f, index=False)
    print(f"CSV exportado: {final_csv}")
    buffer = io.BytesIO()
    pdf.to_excel(buffer, index=False, engine="openpyxl")
    buffer.seek(0)
    with open(final_excel, "wb") as f:
        f.write(buffer.read())
    print(f"Excel exportado: {final_excel}")

def export_df_to_excel(df: DataFrame, volume_path: str, file_base: str) -> None:
    """Exporta um DataFrame para Excel em um volume."""
    base = volume_path.rstrip("/")
    final_excel = f"{base}/{file_base}.xlsx"
    dbutils.fs.mkdirs(base)
    pdf = df.toPandas()
    buffer = io.BytesIO()
    pdf.to_excel(buffer, index=False, engine="openpyxl")
    buffer.seek(0)
    with open(final_excel, "wb") as f:
        f.write(buffer.read())
    print(f"Excel exportado: {final_excel}")

def _read_depara(path, sheet):
    """Lê um Excel DE_PARA e aplica trim em todas as colunas."""
    _df = read_excel(path, sheet)
    for _c in _df.columns:
        _df = _df.withColumn(_c, F.trim(F.col(f"`{_c}`")))
    return _df

# Como está hoje — sem backtick, quebra em nomes especiais
def trim_all_columns(df):
    for c in df.columns:
        df = df.withColumn(
            c,
            F.trim(F.regexp_replace(F.col(f"`{c}`"), r"[\t\xa0\u00a0]", ""))
        )
    return df

def normalize_column_names(df):
    """Remove caracteres inválidos dos nomes das colunas e converte para minúsculas"""
    import unicodedata
    for column in df.columns:
        new_column = unicodedata.normalize('NFKD', column).encode('ASCII', 'ignore').decode('ASCII')
        new_column = (new_column
            .replace(" ", "_")
            .replace("/", "_")
            .replace("(", "")
            .replace(".", "_")    
            .replace(")", "")
            .replace(":", "")
            .replace("-", "_")
            .lower() 
        )
        df = df.withColumnRenamed(column, new_column)
    return df

print("Utilitários carregados.")