# Databricks notebook source
# Databricks notebook source

# ── Conexão Oracle ─────────────────────────────────────────────────────────────
ORACLE_JDBC_URL = "jdbc:oracle:thin:@//10.53.106.148:1521/pcl017"
ORACLE_DRIVER   = "oracle.jdbc.driver.OracleDriver"
ORACLE_SCHEMA   = "SDWEB"

# ORACLE_USER     = dbutils.secrets.get(scope="oracle-ptp", key="user")
# ORACLE_PASSWORD = dbutils.secrets.get(scope="oracle-ptp", key="password")

ORACLE_USER     = "c0721609"
ORACLE_PASSWORD = "!JoGuBi021601#"

# ── Paths de entrada ───────────────────────────────────────────────────────────
ABFSS_BASE         = "abfss://insight@usazu1valesa001.dfs.core.windows.net"

GP_INPUT_PATH      = f"{ABFSS_BASE}/LandingZone/HumanResources/PTP/EHS/Medicina/GP/EHS_GP_01_Layout_Gestao_Previdenciaria_V8.CSV"

EC_29_00_BASE_PATH = f"{ABFSS_BASE}/LandingZone/HumanResources/PTP/EC/M4/01_pre_tec/EC_29_00/"

OUTPUT_BASE = '/Volumes/humanresources_insight/acqu_pcehsgestaoprev/acqu_pcehsgestaoprev/gestao_previdenciaria/output/'

# ── Raw Files ───────────────────────────────────────────────────────────
RAW_FILES_BASE = '/Volumes/humanresources_insight/acqu_pcehsgestaoprev/acqu_pcehsgestaoprev/gestao_previdenciaria/raw_files'

ARVORE_EC_PATH = f'{RAW_FILES_BASE}/Arvore_Localizacao_EC_Medicina_20260411.xlsx'
ARVORE_SHEET = 'Arvore_Localizacao_EC'

EC_33 = f'{RAW_FILES_BASE}/EC_33_03_JobInfo_Brasil_Golive_06042026.xlsx'
EC_33_SHEET = 'DAT_EC_Para_EHS_v2'

DE_PARA_EC_MATRICULAS_MODIFICADAS  = f'{RAW_FILES_BASE}/EC_Matriculas_Modificadas_11042026.xlsx'
DE_PARA_EC_MATR_MOD_SHEET = 'Planilha1'

# ── Schemas Unity Catalog ──────────────────────────────────────────────────────
CATALOG       = "humanresources_insight"
BRONZE_SCHEMA = f"{CATALOG}.bron_pcehsgestaoprev"
SILVER_SCHEMA = f"{CATALOG}.silv_pcehsgestaoprev"


# ── Tabelas Bronze ─────────────────────────────────────────────────────────────
BRONZE_GP   = f"{BRONZE_SCHEMA}.gp_sdweb_raw"
BRONZE_EC29 = f"{BRONZE_SCHEMA}.ec_29_00_raw"


# ── Tabelas Silver ─────────────────────────────────────────────────────────────
SILVER_GP = f"{SILVER_SCHEMA}.gestao_previdenciaria"


# ── Parâmetros de extração Oracle ──────────────────────────────────────────────
DT_LICENCA_INICIO = "01/03/2018"   # Data início do período de licença (dd/mm/yyyy)
DT_LICENCA_FIM    = "23/03/2026"   # Data fim do período de licença (dd/mm/yyyy)
DT_VINCULO_FIM    = "23/03/2026"   # Data corte do vínculo ativo (dd/mm/yyyy)
DT_VINCULO_INICIO = "01/06/2021"   # Data mínima de demissão aceita (dd/mm/yyyy)

EMPRESAS_PERMITIDAS = [
    '00001', '00004', '00046', '00064', '00068',
    '00112', '00284', '00360', '00632', '00646'
]


# ── Colunas finais do layout Silver (Gestão Previdenciária) ────────────────────
SILVER_COL_ORDER = [
    "PERNR", "ID_ATEST", "BEGDA_ATEST", "ENDDA_ATEST",
    "NDIAS_AFAST", "D_SEXTO_DIA", "DUR_AUSEN", "STATUS_ESOC",
    "ENTREG_REG", "DUPLIC_ATEST", "CID1", "CID2",
    "NOME_EMIT", "NUM_OC", "CRM", "UF_OC",
    "COD_ESOC", "TP_ACID", "HV_CONV", "CONV_BEN",
    "DT_CONV", "ORIG_RETIF", "TP_PROCE", "NUM_PROC_PREV",
    "ATEST_ANTE", "DIAS_ANTE", "MOT_ANTE", "RESP_ANTE",
    "REAFAST_MESMO_MOT", "ATEST_RELA", "RESP_ANTE_TEXT", "INFO_ADD1",
    "REC_ESOC", "REC_ESOC_2", "OBS_ATEST",
    "MODIF_USER", "MODIF_DATE", "REG_LOCL",
    "MODIF_USER_2", "MODIF_DATE_2", "MODIF_LOCL_2",
    "PERNR_PERI", "ID", "SEQ_GESTAO", "STATUS_GESTAO",
    "ID_ATEST_REL", "BEGDA_PREV", "ENDDA_PREV",
    "DUPLIC_GEST", "MOT_AFAST", "DATE_INICAFAST", "DT_PERI",
    "RESULTADO", "OBS_PER1", "ENC_INSS", "SIT_INSS",
    "DT_REQ", "NUM_REQ", "NUM_BEN", "TPBEN",
    "DT_INI_BENE", "DIAS_BENE", "BEN_CESS", "INAPTO",
    "DT_CESS_BEN", "DT_ALTA", "CONC_API",
    "DT_IN_API", "DT_FIM_API", "DT_REC", "NUM_REQREC",
    "DT_LIM", "DT_FIM_LIMBO", "REAB_CERT", "DT_REAB",
    "CAN_BEN", "DT_CAN_BEN", "DT_TRANS_NEXO", "DT_CONV_BEN",
    "TP_NEXO", "HV_CONT", "DT_CONTEST_NEXO", "NUM_OF_CONTEST",
    "CONT_PRAZO", "STATUS_CONT", "NEC_CONTEST", "DT_NOT_JUR",
    "OBS", "MODIF_USER_GEST88", "MODIF_DATE_GEST", "REG_LOCL_GEST",
    "MODIF_USER_GEST91", "MODIF_DATE_GEST_1", "MODIF_LOCL_GEST",
]


# ── Registros a excluir (hardcoded no VBA original) ──────────────────────────
# Formato: (PERNR, BEGDA_ATEST_ddmmyyyy, ENDDA_ATEST_ddmmyyyy)
GP_EXCLUSIONS = [
    ("81044098", "17102024", "09122024"),
    ("81044098", "10122024", "28022025"),
    ("81044620", "12052024", "09082024"),
    ("81044666", "21052024", "21062024"),
    ("493383",   "12022015", "26032015"),
    ("81022633", "30012025", "28022025"),
    ("81045659", "31012025", "10032025"),
    ("81040276", "17102024", "05062025"),
    ("81036802", "18092023", "04102023"),
    ("81036802", "23092024", "09022025"),
    ("81025707", "22102024", "09032025"),
    ("81035758", "17122024", "10012025"),
    ("482846",   "05102010", "15042011"),
    ("521201",   "03012015", "15022016"),
    ("81026093", "19102021", "14122021"),
    ("81044411", "18022025", "20042025"),
    ("81032318", "12082022", "04112022"),
    ("520109",   "08012013", "30042013"),
    ("81036610", "01012022", "28022023"),
    ("524896",   "01062015", "30062015"),
]


# ── Paths de Validação ─────────────────────────────────────────────────────────
PICKLIST_BASE_PATH = f"{ABFSS_BASE}/LandingZone/HumanResources/PTP/EHS/M4/01_pre_tec/EHS_PICKLIST_MEDICINA/"
VALIDATION_OUTPUT  = f"{ABFSS_BASE}/LandingZone/HumanResources/PTP/EHS/Medicina/GP/validacao/"

TEMPLATE_NAME = "EHS_GP_01"


# ── Campos obrigatórios (NOT NULL) ────────────────────────────────────────────
CAMPOS_OBRIGATORIOS = [
    "PERNR", "ID_ATEST", "BEGDA_ATEST", "ENDDA_ATEST",
    "NDIAS_AFAST", "DUR_AUSEN", "STATUS_ESOC", "ENTREG_REG",
    "CID1", "NOME_EMIT", "NUM_OC", "CRM", "UF_OC", "COD_ESOC",
    "HV_CONV", "ATEST_ANTE", "REAFAST_MESMO_MOT", "REC_ESOC",
    "MODIF_USER", "MODIF_DATE", "REG_LOCL_GEST", "REG_LOCL",
]


# ── Campos que devem ser vazios (regra 1.3) ──────────────────────────────────
CAMPOS_DEVEM_SER_VAZIOS = [
    "DUPLIC_GEST", "DIAS_ANTE", "DT_CONV", "MOT_ANTE", "RESP_ANTE",
    "REC_ESOC", "REC_ESOC_2", "OBS_ATEST", "DUPLIC_ATEST",
    "RESP_ANTE_TEXT", "STATUS_GESTAO", "SIT_INSS",
]


# ── Mapa de picklists por campo ──────────────────────────────────────────────
VALIDAR_PICKLIST = {
    "UF_OC":             {"picklist": "EHS_GP_01__PicKlist UF.csv",                      "campo": "CODIGO"},
    "STATUS_ESOC":       {"picklist": "EHS_GP_01_PicKlist Status_E_SOC.csv",             "campo": "CODIGO"},
    "ENTREG_REG":        {"picklist": "EHS_GP_01_PicKlist ENTREG_ATEST_EHS_GP_01.csv",   "campo": "CODIGO"},
    "DUPLIC_ATEST":      {"picklist": "EHS_GP_01_picklist MOTIVO_DUPLIC_ATEST.csv",      "campo": "CODIGO"},
    "CID1":              {"picklist": "EHS_GP_01_Piclist CID.csv",                       "campo": "Código"},
    "CRM":               {"picklist": "EHS_GP_01_PicKlist ORGAO_CLASSE.csv",             "campo": "CODIGO"},
    "COD_ESOC":          {"picklist": "EHS_GP_01_PicKlist COD_ESoC_EHS_GP_01.csv",       "campo": "CODIGO"},
    "TP_ACID":           {"picklist": "EHS_GP_01_PicKlist TP_ACID.csv",                  "campo": "CODIGO"},
    "HV_CONV":           {"picklist": "EHS_GP_01_PicKlist HV_CONV.csv",                  "campo": "CODIGO"},
    "CONV_BEN":          {"picklist": "EHS_GP_01_PicKlist CONV_BEN.csv",                 "campo": "CODIGO"},
    "ORIG_RETIF":        {"picklist": "EHS_GP_01_PicKlist ORIGEM_RETIF.csv",             "campo": "CODIGO"},
    "TP_PROCE":          {"picklist": "EHS_GP_01_PicKlist TP_PROCE.csv",                 "campo": "CODIGO"},
    "ATEST_ANTE":        {"picklist": "EHS_GP_01_PicKlist S_N_M.csv",                    "campo": "CODIGO"},
    "REAFAST_MESMO_MOT": {"picklist": "EHS_GP_01_PicKlist S__N_ EHS_GP_01.csv",          "campo": "CODIGO"},
    "DUPLIC_GEST":       {"picklist": "EHS_GP_01_PicKlist MOTIVO_DUPLIC_GEST_.csv",      "campo": "CODIGO"},
    "MOT_AFAST":         {"picklist": "EHS_GP_01_PicKlist COD_ESoC_EHS_GP_01.csv",       "campo": "CODIGO"},
    "RESULTADO":         {"picklist": "EHS_GP_01_PicKlist RESULT_PERI.csv",              "campo": "CODIGO"},
    "SIT_INSS":          {"picklist": "EHS_GP_01_ PicKlist SIT_INSS.csv",                "campo": "CODIGO"},
    "TPBEN":             {"picklist": "EHS_GP_01_PicKlist TPBEN.csv",                    "campo": "CODIGO"},
    "BEN_CESS":          {"picklist": "EHS_GP_01_PicKlist S__N_ EHS_GP_01.csv",          "campo": "CODIGO"},
    "INAPTO":            {"picklist": "EHS_GP_01_PicKlist S__N_ EHS_GP_01.csv",          "campo": "CODIGO"},
    "REAB_CERT":         {"picklist": "EHS_GP_01_PicKlist S__N_ EHS_GP_01.csv",          "campo": "CODIGO"},
    "CAN_BEN":           {"picklist": "EHS_GP_01_PicKlist S__N_ EHS_GP_01.csv",          "campo": "CODIGO"},
    "TP_NEXO":           {"picklist": "EHS_GP_01_PicKlist TP_NEXOTEC.csv",               "campo": "CODIGO"},
    "HV_CONT":           {"picklist": "EHS_GP_01_PicKlist S__N_ EHS_GP_01.csv",          "campo": "CODIGO"},
    "CONT_PRAZO":        {"picklist": "EHS_GP_01_PicKlist S__N_ EHS_GP_01.csv",          "campo": "CODIGO"},
    "STATUS_CONT":       {"picklist": "EHS_GP_01_PicKlist Status_E_SOC.csv",             "campo": "CODIGO"},
    "NEC_CONTEST":       {"picklist": "EHS_GP_01_PicKlist S__N_ EHS_GP_01.csv",          "campo": "CODIGO"},
}


# ── Campos dependentes de BEGDA_PREV ─────────────────────────────────────────
BEGDA_PREV_DEPENDENTES = [
    "DUPLIC_GEST", "SIT_INSS", "DIAS_BENE", "DT_CESS_BEN", "DT_ALTA",
    "DT_IN_API", "DT_FIM_API", "DT_REC", "NUM_REQREC", "DT_LIM",
    "DT_FIM_LIMBO", "REAB_CERT", "DT_REAB", "DT_CAN_BEN", "DT_TRANS_NEXO",
    "DT_CONV_BEN", "TP_NEXO", "DT_CONTEST_NEXO", "NUM_OF_CONTEST",
    "CONT_PRAZO", "STATUS_CONT", "DT_NOT_JUR", "ENDDA_PREV", "MOT_AFAST",
    "DATE_INICAFAST", "DT_PERI", "RESULTADO", "ENC_INSS", "DT_REQ",
    "NUM_REQ", "NUM_BEN", "TPBEN", "DT_INI_BENE", "BEN_CESS", "INAPTO",
    "CONC_API", "CAN_BEN", "HV_CONT", "NEC_CONTEST", "REG_LOCL",
    "PERNR_PERI", "ID", "ID_ATEST_REL", "OBS_PER1",
]


# ── Campos dependentes de PERNR_PERI ─────────────────────────────────────────
PERNR_PERI_DEPENDENTES = ["ID", "SEQ_GESTAO", "STATUS_GESTAO", "ID_ATEST_REL"]


# ── Mapa de tamanhos/formatos (regra 1.1) ────────────────────────────────────
CAMPOS_TAMANHOS = {
    "STATUS_ESOC": {"tipo": "fixo", "tamanho": 1, "formato": "alfanumerico"},
    "COD_ESOC": {"tipo": "fixo", "tamanho": 1, "formato": "alfanumerico"},
    "HV_CONV": {"tipo": "fixo", "tamanho": 1, "formato": "alfanumerico"},
    "ATEST_ANTE": {"tipo": "fixo", "tamanho": 1, "formato": "alfanumerico"},
    "REAFAST_MESMO_MOT": {"tipo": "fixo", "tamanho": 1, "formato": "alfanumerico"},
    "ENC_INSS": {"tipo": "fixo", "tamanho": 1, "formato": "alfanumerico"},
    "SIT_INSS": {"tipo": "fixo", "tamanho": 1, "formato": "alfanumerico"},
    "BEN_CESS": {"tipo": "fixo", "tamanho": 1, "formato": "alfanumerico"},
    "INAPTO": {"tipo": "fixo", "tamanho": 1, "formato": "alfanumerico"},
    "CONC_API": {"tipo": "fixo", "tamanho": 1, "formato": "alfanumerico"},
    "REAB_CERT": {"tipo": "fixo", "tamanho": 1, "formato": "alfanumerico"},
    "CAN_BEN": {"tipo": "fixo", "tamanho": 1, "formato": "alfanumerico"},
    "HV_CONT": {"tipo": "fixo", "tamanho": 1, "formato": "alfanumerico"},
    "CONT_PRAZO": {"tipo": "fixo", "tamanho": 1, "formato": "alfanumerico"},
    "STATUS_CONT": {"tipo": "fixo", "tamanho": 1, "formato": "alfanumerico"},
    "NEC_CONTEST": {"tipo": "fixo", "tamanho": 1, "formato": "alfanumerico"},
    "DUPLIC_ATEST": {"tipo": "fixo", "tamanho": 2, "formato": "alfanumerico"},
    "UF_OC": {"tipo": "max", "tamanho": 2, "formato": "alfanumerico"},
    "DUPLIC_GEST": {"tipo": "fixo", "tamanho": 2, "formato": "alfanumerico"},
    "RESULTADO": {"tipo": "max", "tamanho": 2, "formato": "alfanumerico"},
    "CRM": {"tipo": "max", "tamanho": 3, "formato": "alfanumerico"},
    "CONV_BEN": {"tipo": "fixo", "tamanho": 3, "formato": "alfanumerico"},
    "TPBEN": {"tipo": "max", "tamanho": 3, "formato": "alfanumerico"},
    "NUM_PROC_PREV": {"tipo": "max", "tamanho": 25, "formato": "numerico"},
    "PERNR": {"tipo": "max", "tamanho": 8, "formato": "numerico"},
    "ID_ATEST": {"tipo": "max", "tamanho": 8, "formato": "numerico"},
    "NDIAS_AFAST": {"tipo": "max", "tamanho": 8, "formato": "numerico"},
    "DUR_AUSEN": {"tipo": "max", "tamanho": 8, "formato": "numerico"},
    "PERNR_PERI": {"tipo": "max", "tamanho": 8, "formato": "numerico"},
    "ENDDA_ATEST": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "D_SEXTO_DIA": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "DT_CONV": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "MODIF_DATE": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "MODIF_DATE_2": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "BEGDA_PREV": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "ENDDA_PREV": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "DATE_INICAFAST": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "DT_PERI": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "DT_REQ": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "DT_INI_BENE": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "DT_CESS_BEN": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "DT_ALTA": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "DT_IN_API": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "DT_FIM_API": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "DT_REC": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "DT_LIM": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "DT_FIM_LIMBO": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "DT_REAB": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "DT_CAN_BEN": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "DT_TRANS_NEXO": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "DT_CONV_BEN": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "DT_CONTEST_NEXO": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "DT_NOT_JUR": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "MODIF_DATE_GEST": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "BEGDA_ATEST": {"tipo": "fixo", "tamanho": 8, "formato": "data", "excecao": "01010001"},
    "MODIF_USER": {"tipo": "max", "tamanho": 100, "formato": "letra_especial"},
    "MODIF_USER_2": {"tipo": "max", "tamanho": 100, "formato": "letra_especial"},
    "MODIF_LOCL_2": {"tipo": "max", "tamanho": 100, "formato": "texto"},
    "MODIF_USER_GEST88": {"tipo": "max", "tamanho": 100, "formato": "letra_especial"},
    "DIAS_ANTE": {"tipo": "max", "tamanho": 5, "formato": "numerico"},
    "DIAS_BENE": {"tipo": "max", "tamanho": 5, "formato": "numerico"},
    "MOT_AFAST": {"tipo": "fixo", "tamanho": 1, "formato": "numerico"},
    "ID": {"tipo": "max", "tamanho": 20, "formato": "alfanumerico"},
    "REC_ESOC": {"tipo": "fixo", "tamanho": 30, "formato": "alfanumerico"},
    "REC_ESOC_2": {"tipo": "fixo", "tamanho": 30, "formato": "alfanumerico"},
    "STATUS_GESTAO": {"tipo": "fixo", "tamanho": 30, "formato": "alfanumerico"},
    "NUM_OF_CONTEST": {"tipo": "max", "tamanho": 30, "formato": "alfanumerico"},
    "ID_ATEST_REL": {"tipo": "max", "tamanho": 200, "formato": "texto"},
    "NOME_EMIT": {"tipo": "max", "tamanho": 255, "formato": "letra"},
    "RESP_ANTE": {"tipo": "fixo", "tamanho": 255, "formato": "texto"},
    "RESP_ANTE_TEXT": {"tipo": "max", "tamanho": 255, "formato": "texto"},
    "NUM_OC": {"tipo": "max", "tamanho": 14, "formato": "numero_decimal"},
    "MOT_ANTE": {"tipo": "max", "tamanho": 100, "formato": "texto"},
    "REG_LOCL": {"tipo": "max", "tamanho": 100, "formato": "letra_especial"},
    "REG_LOCL_GEST": {"tipo": "max", "tamanho": 100, "formato": "texto"},
    "ENTREG_REG": {"tipo": "max", "tamanho": 1, "formato": "numerico"},
    "TP_ACID": {"tipo": "max", "tamanho": 1, "formato": "numerico"},
    "ORIG_RETIF": {"tipo": "max", "tamanho": 1, "formato": "numerico"},
    "TP_PROCE": {"tipo": "max", "tamanho": 1, "formato": "numerico"},
    "TP_NEXO": {"tipo": "max", "tamanho": 1, "formato": "numerico"},
    "NUM_REQ": {"tipo": "max", "tamanho": 30, "formato": "numerico"},
    "NUM_BEN": {"tipo": "max", "tamanho": 30, "formato": "numerico"},
    "NUM_REQREC": {"tipo": "max", "tamanho": 30, "formato": "numerico"},
    "INFO_ADD1": {"tipo": "max", "tamanho": 5000, "formato": "texto"},
    "OBS_ATEST": {"tipo": "max", "tamanho": 2000, "formato": "texto"},
    "OBS_PER1": {"tipo": "max", "tamanho": 5000, "formato": "texto"},
    "OBS": {"tipo": "max", "tamanho": 2000, "formato": "texto"},
    "SEQ_GESTAO": {"tipo": "max", "tamanho": 2000, "formato": "texto"},
}


print("Configurações carregadas com sucesso.")
print(f"   Bronze       : {BRONZE_SCHEMA}")
print(f"   Silver       : {SILVER_SCHEMA}")
print(f"   Empresas     : {EMPRESAS_PERMITIDAS}")
print(f"   Período      : {DT_LICENCA_INICIO} → {DT_LICENCA_FIM}")
print(f"   GP Input     : {GP_INPUT_PATH}")
print(f"   EC29 Input   : {EC_29_00_BASE_PATH}")
print(f"   Silver cols  : {len(SILVER_COL_ORDER)} colunas")
print(f"   Exclusões    : {len(GP_EXCLUSIONS)} registros")