# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Gestão Previdenciária/utils/utils"

# COMMAND ----------

# ─────────────────────────────────────────────────────────────────────────────
# 02_gp_silver.py — Camada Silver: Gestão Previdenciária
# ─────────────────────────────────────────────────────────────────────────────
# Depende de: 01_gp_sdweb_bronze (BRONZE_GP deve estar gravada antes)
#
# Lógica traduzida do VBA (MOCK4_GP_VBA.txt):
#   1. Ordenação por PERNR, BEGDA_ATEST, ENDDA_ATEST, DT_PERI, DIAS_BENE
#   2. Remoção de duplicatas
#   3. Exclusão de registros específicos (hardcoded no VBA)
#   4. Formatação de CID (inserção de ponto)
#   5. Limpeza de datas (remoção de "/")
#   6. Limpeza de textos (caracteres de controle)
#   7. Defaults por coluna (null → valor padrão conforme VBA)
#   8. Recalculo de ID_ATEST sequencial
#   9. Lógica de REAFAST_MESMO_MOT / ATEST_RELA / ID_ATEST_REL (correlação)
#  10. Colunas derivadas: ID, SEQ_GESTAO, ENC_INSS, STATUS_GESTAO
#  11. Flags API_Ativo_Inativo (CONC_API) e Reabilitado (REAB_CERT)
#  12. Mapeamento/reordenação de colunas para layout silver
# ─────────────────────────────────────────────────────────────────────────────

import time
from pyspark.sql import functions as F, Window
from pyspark.sql.types import StringType, IntegerType
import pandas as pd

t0 = time.time()

def _fmt(s):
    if s < 60:   return f"{s:.1f}s"
    if s < 3600: return f"{int(s//60)}min {s%60:.1f}s"
    return f"{int(s//3600)}h {int((s%3600)//60)}min {s%60:.0f}s"

print("🔄 Iniciando transformação Silver - Gestão Previdenciária...")

# COMMAND ----------

# ── 1. Leitura da Bronze ──────────────────────────────────────────────────────

df = spark.table(BRONZE_GP)
print(f"Bronze lida: {df.count():,} registros | {_fmt(time.time()-t0)}")

# ── EC_33: Filtrar apenas PERNRs que existem no EC_33 ────────────────────────
# Lê EC_33 com header na segunda linha (ignorando a primeira)
pdf_ec33 = pd.read_excel(EC_33, header=1, dtype=str)
pdf_ec33 = pdf_ec33.fillna("")
df_ec33 = spark.createDataFrame(pdf_ec33)

# Coluna "ID do usuário" do EC_33 faz match com PERNR
ec33_pernrs = df_ec33.select(
    F.trim(F.col("`ID do usuário`")).alias("PERNR_EC33")
).distinct()

rows_before_ec33 = df.count()
df = df.join(
    ec33_pernrs,
    F.trim(F.col("PERNR")) == F.col("PERNR_EC33"),
    "inner"
).drop("PERNR_EC33")

print(f"Filtro EC_33 aplicado: {rows_before_ec33} → {df.count():,} registros | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 2. Exclusão de registros específicos (hardcoded no VBA) ───────────────────
# O VBA contém ElseIf's que pulam registros com combinações específicas de
# PERNR + BEGDA_ATEST + ENDDA_ATEST. Traduzimos como filtro de exclusão.

exclusions = GP_EXCLUSIONS  # definido em config.py

# Normaliza as datas bronze (remove "/") para comparação
df = df.withColumn("_begda_norm", F.regexp_replace(F.col("BEGDA_ATEST"), "/", ""))
df = df.withColumn("_endda_norm", F.regexp_replace(F.col("ENDDA_ATEST"), "/", ""))

# Constroi condição de exclusão usando utils
excl_cond = build_exclusion_filter(exclusions)

rows_before = df.count()
df = df.filter(~excl_cond)
rows_after = df.count()
print(f"Exclusões aplicadas: {rows_before - rows_after} registros removidos | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 3. Remoção de duplicatas ──────────────────────────────────────────────────
# O VBA faz RemoveDuplicates em todas as 104 colunas originais.
# Aqui usamos dropDuplicates com as colunas de negócio (sem auxiliares).

cols_dedup = [c for c in df.columns if not c.startswith("_") and c != "ID_HASH"]
df = df.dropDuplicates(cols_dedup)
print(f"Pós deduplicação: {df.count():,} registros | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 4. Ordenação (conforme VBA) ───────────────────────────────────────────────
# PERNR (asc, text as numbers), BEGDA_ATEST (asc), ENDDA_ATEST (asc),
# DT_PERI (asc), DIAS_BENE (asc)
#
# Ordenação cronológica: converte string "dd/MM/yyyy" para date apenas para
# comparação (to_date é só chave de ordenação — não altera as colunas no DF).
# Equivalente ao Sort.Apply do VBA, que trata datas nativamente no Excel.

df = df.orderBy(
    F.col("PERNR").cast(IntegerType()).asc_nulls_last(),
    F.to_date(F.col("BEGDA_ATEST"), "dd/MM/yyyy").asc_nulls_last(),
    F.to_date(F.col("ENDDA_ATEST"), "dd/MM/yyyy").asc_nulls_last(),
    F.to_date(F.col("DT_PERI"), "dd/MM/yyyy").asc_nulls_last(),
    F.col("DIAS_BENE").cast(IntegerType()).asc_nulls_last(),
)

# COMMAND ----------

# ── 5. Formatação de datas ────────────────────────────────────────────────────
# Remove "/" das datas. Conforme mapeamento, datas nulas ficam VAZIAS (não "01010001").

DATE_COLS = [
    "BEGDA_ATEST", "ENDDA_ATEST", "D_SEXTO_DIA", "DT_CONV",
    "MODIF_DATE", "MODIF_DATE_2", "BEGDA_PREV", "ENDDA_PREV",
    "DATE_INICAFAST", "DT_PERI", "DT_REQ", "DT_INI_BENE",
    "DT_CESS_BEN", "DT_ALTA", "DT_IN_API", "DT_FIM_API",
    "DT_REC", "DT_LIM", "DT_FIM_LIMBO", "DT_REAB",
    "DT_CAN_BEN", "DT_TRANS_NEXO", "DT_CONV_BEN",
    "DT_CONTEST_NEXO", "DT_NOT_JUR",
    "MODIF_DATE_GEST", "MODIF_DATE_GEST_2",
]

for c in DATE_COLS:
    if c in df.columns:
        df = df.withColumn(c, F.regexp_replace(F.col(c), "/", ""))

# COMMAND ----------

# ── 6. Formatação de CID ─────────────────────────────────────────────────────
# CID1: 3 chars → mantém; 4 chars → insere ponto (ex: "M541" → "M54.1")
#        null/empty → "S/H"
# CID2: mesma lógica, aplicada a cada item separado por "|"

df = df.withColumn(
    "CID1",
    F.when(
        F.trim(F.col("CID1")).isNull() | (F.trim(F.col("CID1")) == "") | (F.trim(F.col("CID1")) == "null"),
        F.lit("S/H")
    ).when(
        F.length(F.trim(F.col("CID1"))) == F.lit(3),
        F.trim(F.col("CID1"))
    ).when(
        F.length(F.trim(F.col("CID1"))) == F.lit(4),
        F.concat(F.substring(F.trim(F.col("CID1")), 1, 3), F.lit("."), F.substring(F.trim(F.col("CID1")), 4, 1))
    ).otherwise(F.trim(F.col("CID1")))
)

from pyspark.sql.functions import udf

@udf(StringType())
def format_cid2(val):
    if val is None or str(val).strip() == "" or str(val).strip() == "null":
        return ""
    items = str(val).replace("|", ";").split(";")
    result = []
    for item in items:
        item = item.strip()
        if not item:
            continue
        if len(item) == 3:
            result.append(item)
        elif len(item) == 4:
            result.append(item[:3] + "." + item[3])
        else:
            result.append(item)
    formatted = ";".join(result)
    if len(formatted) > 255:
        formatted = formatted[:255]
    if formatted.endswith(";"):
        formatted = formatted[:-1]
    return formatted

df = df.withColumn("CID2", format_cid2(F.col("CID2")))

print(f"CID formatado (com ponto) | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 7. Limpeza de textos ──────────────────────────────────────────────────────
# O VBA remove Chr(13), Chr(10), Chr(9), Chr(0) e substitui "|" por "/"
# nos campos INFO_ADD, OBS_ATEST e OBS_PER

TEXT_CLEAN_COLS = ["INFO_ADD1", "OBS_ATEST", "OBS_PER1"]
df = clean_control_chars(df, TEXT_CLEAN_COLS)

# NUM_PROC_PREV: remove ".", "-", "/"
if "NUM_PROC_PREV" in df.columns:
    df = df.withColumn(
        "NUM_PROC_PREV",
        F.regexp_replace(
            F.regexp_replace(
                F.regexp_replace(F.col("NUM_PROC_PREV"), "\\.", ""),
                "-", ""
            ),
            "/", ""
        )
    )

# NOME_EMIT: truncar em 255 chars; default "SEM HISTORICO"
df = df.withColumn(
    "NOME_EMIT",
    F.when(
        F.trim(F.col("NOME_EMIT")).isNull() | (F.trim(F.col("NOME_EMIT")) == "") | (F.trim(F.col("NOME_EMIT")) == "M"),
        F.lit("SEM HISTORICO")
    ).otherwise(F.substring(F.col("NOME_EMIT"), 1, 255))
)

# NUM_BEN: remove "." e "-" (conforme VBA)
if "NUM_BEN" in df.columns:
    df = df.withColumn(
        "NUM_BEN",
        F.regexp_replace(F.regexp_replace(F.col("NUM_BEN"), "\\.", ""), "-", "")
    )

print(f"Limpeza de textos concluída | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 8. Defaults por coluna (conforme regras VBA) ─────────────────────────────

# Colunas com default específico quando nulo/vazio
defaults_map = {
    # Numéricos com default "0"
    "NDIAS_AFAST":       "0",
    "DUR_AUSEN":         "0",
    "ENTREG_ATEST":      "0",
    "NUM_OC":            "0",
    "REC_ESOC":          "0",
    "NUM_REQ":           "0",
    "DIAS_BENE":         "0",
    "NUM_OF_CONTEST":    "0",
    # Texto com default "M"
    "STATUS_ESOC":       "M",
    "CRM":               "M",
    "UF_OC":             "M",
    "COD_ESOC":          "M",
    "TPBEN":             "M",
    "RESULTADO":         "M",
    "MOT_AFAST":         "M",
    "ATEST_ANTE":        "M",
    "HV_CONT":           "M",
    "NEC_CONTEST":       "M",
    # Flags com default "N"
    "REAFAST_MESMO_MOT": "N",
    "BEN_CESS":          "N",
    "INAPTO":            "N",
    "CONC_API":          "N",
    "CAN_BEN":           "N",
    "REAB_CERT":         "N",
    # Texto com default "SEM HISTORICO"
    "REG_LOCL":          "SEM HISTORICO",
}

df = apply_defaults(df, defaults_map)

# ── HV_CONV: regra condicional baseada nos campos processuais ────────────────
# HV_CONV = 'S' somente quando ORIG_RETIF, TP_PROCE e NUM_PROC_PREV estão
# TODOS preenchidos. Caso contrário, HV_CONV = 'M'.
df = df.withColumn(
    "HV_CONV",
    F.when(
        (F.trim(F.col("ORIG_RETIF")).isNotNull() & (F.trim(F.col("ORIG_RETIF")) != "")) &
        (F.trim(F.col("TP_PROCE")).isNotNull() & (F.trim(F.col("TP_PROCE")) != "")) &
        (F.trim(F.col("NUM_PROC_PREV")).isNotNull() & (F.trim(F.col("NUM_PROC_PREV")) != "")),
        F.lit("S")
    ).otherwise(F.lit("M"))
)

# Datas: conforme mapeamento, campos de data nulos devem ficar VAZIOS (""),
# NÃO devem receber "01010001" como default.
# A remoção de "/" já foi feita na célula anterior.
# Nulos serão convertidos para "" no null_to_empty final.

# EXCEÇÃO: ENDDA_ATEST — mapeamento diz:
# "Caso não exista uma data fim (Até), a mesma deverá ser preenchida com: 31129999"
# ENDDA_PREV: se for "31129999" ou vazio, deve ficar vazio.
if "ENDDA_ATEST" in df.columns:
    df = df.withColumn(
        "ENDDA_ATEST",
        F.when(
            F.trim(F.col("ENDDA_ATEST")).isNull() | (F.trim(F.col("ENDDA_ATEST")) == ""),
            F.lit("31129999")
        ).otherwise(F.col("ENDDA_ATEST"))
    )

if "ENDDA_PREV" in df.columns:
    df = df.withColumn(
        "ENDDA_PREV",
        F.when(
            F.trim(F.col("ENDDA_PREV")).isNull() | F.trim(F.col("ENDDA_PREV")).isin("", "31129999"),
            F.lit("")
        ).otherwise(F.col("ENDDA_PREV"))
    )

# Colunas de data com default NULO no mapeamento: se vieram com "01010001" da bronze,
# substituir por "" (vazio). Essas colunas não devem ter valor padrão de data.
DATE_COLS_DEFAULT_NULO = [
    "DT_IN_API", "DT_FIM_API", "DT_REC", "DT_LIM", "DT_FIM_LIMBO",
    "DT_REAB", "DT_CAN_BEN", "DT_TRANS_NEXO", "DT_CONV_BEN",
    "DT_CONTEST_NEXO", "DT_NOT_JUR", "DT_CONV",
]
for c in DATE_COLS_DEFAULT_NULO:
    if c in df.columns:
        df = df.withColumn(
            c,
            F.when(
                F.trim(F.col(c)).isin("01010001", "") | F.trim(F.col(c)).isNull(),
                F.lit("")
            ).otherwise(F.col(c))
        )

# Truncar campos de texto nos tamanhos do VBA
TRUNCATE_MAP = {
    "MODIF_USER": 100, "MOT_ANTE": 100, "RESP_ANTE": 255,
    "REG_LOCL": 100, "MODIF_USER_2": 100, "MODIF_LOCL_2": 100,
    "NUM_OF_CONTEST": 30,
    "MODIF_USER_GEST": 100, "REG_LOCL_GEST": 100,
    "MODIF_USER_GEST_2": 100, "MODIF_LOCL_GEST": 100,
}
for col_name, max_len in TRUNCATE_MAP.items():
    if col_name in df.columns:
        df = df.withColumn(col_name, F.substring(F.col(col_name), 1, max_len))

print(f"Defaults aplicados | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 9. Recalcular ID_ATEST conforme lógica VBA ──────────────────────────────
# No VBA, COUNT_ID_ATEST é um contador GLOBAL sequencial (não reseta por PERNR).
# Incrementa +1 cada vez que o par (PERNR, BEGDA_ATEST) muda.
#
# IMPORTANTE: O VBA faz um Sort.Apply (linhas 245-275) que materializa
# fisicamente a ordem na planilha. No Spark, orderBy é lazy e pode ser
# reordenado pelo Catalyst. Por isso usamos row_number() em vez de
# monotonically_increasing_id() — garante que _row_idx respeite a sequência
# cronológica (PERNR, BEGDA_ATEST, ENDDA_ATEST, DT_PERI, DIAS_BENE).
#
# Ordenação cronológica: converte string "ddMMyyyy" para date apenas para
# comparação (to_date é só chave de ordenação — não altera as colunas no DF).
# Na tabela final, BEGDA_ATEST/ENDDA_ATEST/DT_PERI continuam como string ddmmyyyy.

w_order = Window.orderBy(
    F.col("PERNR").cast(IntegerType()).asc_nulls_last(),
    F.to_date(F.col("BEGDA_ATEST"), "ddMMyyyy").asc_nulls_last(),
    F.to_date(F.col("ENDDA_ATEST"), "ddMMyyyy").asc_nulls_last(),
    F.to_date(F.col("DT_PERI"), "ddMMyyyy").asc_nulls_last(),
    F.col("DIAS_BENE").cast(IntegerType()).asc_nulls_last(),
)

# _row_idx DETERMINÍSTICO — equivalente ao Sort.Apply do VBA
df = df.withColumn("_row_idx", F.row_number().over(w_order))

df = df.withColumn("_prev_pernr", F.lag("PERNR").over(w_order))
df = df.withColumn("_prev_begda", F.lag("_begda_norm").over(w_order))

# Flag: 1 quando muda (PERNR, BEGDA_ATEST); 0 quando repete
df = df.withColumn(
    "_change_flag",
    F.when(
        F.col("_prev_pernr").isNull() |
        (F.col("PERNR") != F.col("_prev_pernr")) |
        (F.col("_begda_norm") != F.col("_prev_begda")),
        F.lit(1)
    ).otherwise(F.lit(0))
)

# ID_ATEST = soma cumulativa GLOBAL (nunca reseta)
df = df.withColumn(
    "ID_ATEST",
    F.sum("_change_flag").over(w_order).cast(StringType())
)

print(f"ID_ATEST recalculado (lógica VBA - contador global) | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 10. Lógica REAFAST_MESMO_MOT / ATEST_RELA / ID_ATEST_REL ────────────────
# Fiel ao VBA:
#   - ATEST_RELA (linhas 549-598, 859-872): acumula IDs dos atestados
#     correlacionados concatenados com ";" enquanto CONT_ATEST_RELA se mantém.
#     Limpa ";" inicial e trunca em 100 chars.
#   - ID_ATEST_REL (linhas 1001-1060, seção `PRESERVAR DAQUI`): lógica
#     condicional baseada em DT_PERI, DUR_AUSEN (>15 ou <=15), CONT_ATEST_RELA
#     e CONCAT_ID_ATEST_REL. Ver comentários inline abaixo.

# Colunas auxiliares para a janela de lag
w_pernr = Window.partitionBy("PERNR").orderBy("_row_idx")

# CID1 truncado nos primeiros 6 chars (conforme VBA: Mid(Trim(...), 1, 6))
df = df.withColumn("_cid_trunc", F.substring(F.trim(F.col("CID1")), 1, 6))
df = df.withColumn("_prev_cid", F.lag("_cid_trunc").over(w_pernr))
df = df.withColumn("_prev_endda", F.lag("_endda_norm").over(w_pernr))
df = df.withColumn("_prev_id_atest", F.lag("ID_ATEST").over(w_pernr))
df = df.withColumn("_prev_dur_ausen", F.lag("DUR_AUSEN").over(w_pernr))

# Calcular diferença em dias entre ENDDA anterior e BEGDA atual
df = df.withColumn("_begda_date", F.to_date(F.col("_begda_norm"), "ddMMyyyy"))
df = df.withColumn("_prev_endda_date", F.to_date(F.col("_prev_endda"), "ddMMyyyy"))
df = df.withColumn("_dias_entre", F.datediff(F.col("_begda_date"), F.col("_prev_endda_date")))

# REAFAST_MESMO_MOT: Se CID mudou e flag original da bronze é "N", sobrescrever "N"
df = df.withColumn(
    "REAFAST_MESMO_MOT",
    F.when(
        F.col("_prev_cid").isNull() |
        ((F.col("_cid_trunc") != F.col("_prev_cid")) & (F.col("REAFAST_MESMO_MOT") == "N")),
        F.lit("N")
    ).otherwise(F.col("REAFAST_MESMO_MOT"))
)

# ─────────────────────────────────────────────────────────────────────────────
# Identificação de linhas correlacionadas (mesma lógica anterior)
# ─────────────────────────────────────────────────────────────────────────────
df = df.withColumn(
    "_is_correlated",
    F.when(
        (F.col("_cid_trunc") == F.col("_prev_cid")) &
        (F.col("REAFAST_MESMO_MOT") == "S") &
        (F.col("_dias_entre").isNotNull()) &
        (F.col("_dias_entre") >= 0) &
        (F.col("_dias_entre") <= 60),
        F.lit(1)
    ).otherwise(F.lit(0))
)

# ─────────────────────────────────────────────────────────────────────────────
# ATEST_RELA — REGRA DE ÂNCORAS
#
# Um atestado é "âncora" (pai de cadeia) quando:
#   (a) REAFAST_MESMO_MOT = "N", OU
#   (b) o mesmo ID_ATEST aparece mais de uma vez no mesmo PERNR
#       (atestado com múltiplas prorrogações/perícias — representa um
#        ciclo previdenciário fechado que inicia nova cadeia à frente)
#
# Para cada linha com _is_correlated = 1:
#   ATEST_RELA = concatenação dos ID_ATEST distintos desde a ÚLTIMA âncora
#   anterior (inclusive) até a linha imediatamente anterior.
# ─────────────────────────────────────────────────────────────────────────────

# (a) Contagem de ocorrências do mesmo ID_ATEST por PERNR
w_pernr_id = Window.partitionBy("PERNR", "ID_ATEST")
df = df.withColumn("_occur_count", F.count(F.lit(1)).over(w_pernr_id))

# (b) Flag de âncora
df = df.withColumn(
    "_is_anchor",
    F.when(
        (F.col("REAFAST_MESMO_MOT") == "N") | (F.col("_occur_count") > 1),
        F.lit(1)
    ).otherwise(F.lit(0))
)

# (c) _row_idx da última âncora ESTRITAMENTE anterior (não inclui a linha atual)
w_pernr_prev = (
    Window.partitionBy("PERNR").orderBy("_row_idx")
          .rowsBetween(Window.unboundedPreceding, -1)
)
df = df.withColumn(
    "_anchor_row",
    F.last(
        F.when(F.col("_is_anchor") == 1, F.col("_row_idx")),
        ignorenulls=True
    ).over(w_pernr_prev)
)

# (d) Coletar pares (row_idx, ID_ATEST) de todas as linhas anteriores do PERNR
df = df.withColumn(
    "_prev_pairs",
    F.collect_list(
        F.struct(F.col("_row_idx").alias("ri"), F.col("ID_ATEST").alias("id"))
    ).over(w_pernr_prev)
)

# (e) Filtrar pares com ri >= _anchor_row (desde a âncora inclusive) e pegar IDs distintos
df = df.withColumn(
    "_prev_ids_from_anchor",
    F.when(
        F.col("_anchor_row").isNotNull(),
        F.expr("transform(filter(_prev_pairs, p -> p.ri >= _anchor_row), p -> p.id)")
    ).otherwise(F.array())
)
df = df.withColumn(
    "_prev_ids_from_anchor",
    F.array_distinct(F.col("_prev_ids_from_anchor"))
)

# (f) Montar ATEST_RELA
df = df.withColumn(
    "ATEST_RELA",
    F.when(
        (F.col("_is_correlated") == 1) & (F.size(F.col("_prev_ids_from_anchor")) > 0),
        F.concat_ws(";", F.col("_prev_ids_from_anchor"))
    ).otherwise(F.lit(""))
)

# Propagação para duplicatas
w_dup_group = Window.partitionBy("PERNR", "_begda_norm", "_endda_norm").orderBy("_row_idx")
df = df.withColumn(
    "ATEST_RELA",
    F.first(
        F.when(F.col("ATEST_RELA") != "", F.col("ATEST_RELA")),
        ignorenulls=True
    ).over(w_dup_group).cast(StringType())
)
df = df.withColumn(
    "ATEST_RELA",
    F.when(F.col("ATEST_RELA").isNull(), F.lit("")).otherwise(F.col("ATEST_RELA"))
)
df = df.withColumn("ATEST_RELA", F.regexp_replace(F.col("ATEST_RELA"), r"^;+", ""))
df = df.withColumn("ATEST_RELA", F.substring(F.col("ATEST_RELA"), 1, 100))

# ─────────────────────────────────────────────────────────────────────────────
# ID_ATEST_REL — Regra validada com o usuário:
#   Um ID QUALIFICA quando TODAS as condições são verdadeiras:
#     1. DT_PERI preenchida
#     2. Soma ACUMULADA de dias na ilha > 15
#        (acumula dentro de mesmo CID + 60 dias entre atestados)
#     3. Mesmo CID que o último qualificado anterior (quando existe)
#     4. Dentro de 60 dias do último qualificado anterior (quando existe)
#
#   Valor:
#     - Primeiro a cruzar os 15 na ilha → só o próprio ID
#     - Demais qualificados subsequentes → cadeia de qualificados + próprio ID
#
#   Atestados curtos (≤15 isolados) NÃO entram na cadeia, mas somam para o
#   acumulado até o primeiro qualificado cruzar os 15.
# ─────────────────────────────────────────────────────────────────────────────

# Normaliza DUR_AUSEN para inteiro
df = df.withColumn(
    "_dur_num",
    F.coalesce(
        F.regexp_extract(F.col("DUR_AUSEN"), r"^(\d+)", 1).cast(IntegerType()),
        F.lit(0)
    )
)

_has_peri = (F.trim(F.col("DT_PERI")).isNotNull()) & (F.trim(F.col("DT_PERI")) != "")

# ─── Ilha de acumulação: mesmo CID + gap ≤ 60 dias ──────────────────────────
# (igual à ilha do ATEST_RELA mas sem exigir REAFAST_MESMO_MOT)
df = df.withColumn(
    "_starts_acum_island",
    F.when(
        F.col("_prev_cid").isNull() |
        (F.col("_cid_trunc") != F.col("_prev_cid")) |
        (F.col("_dias_entre").isNull()) |
        (F.col("_dias_entre") > 60),
        F.lit(1)
    ).otherwise(F.lit(0))
)
df = df.withColumn(
    "_acum_island_id",
    F.sum("_starts_acum_island").over(w_pernr)
)

# Acumulador de dias dentro da ilha (soma cumulativa INCLUINDO a linha atual)
w_acum = (
    Window.partitionBy("PERNR", "_acum_island_id")
          .orderBy("_row_idx")
          .rowsBetween(Window.unboundedPreceding, Window.currentRow)
)
df = df.withColumn(
    "_dias_acumulados",
    F.sum("_dur_num").over(w_acum)
)

# Soma acumulada SEM a linha atual (para saber se já havia cruzado antes)
w_acum_antes = (
    Window.partitionBy("PERNR", "_acum_island_id")
          .orderBy("_row_idx")
          .rowsBetween(Window.unboundedPreceding, -1)
)
df = df.withColumn(
    "_dias_acum_antes",
    F.coalesce(F.sum("_dur_num").over(w_acum_antes), F.lit(0))
)

# Qualificado = DT_PERI preenchida E soma acumulada > 15
df = df.withColumn(
    "_is_qualified",
    F.when(
        _has_peri & (F.col("_dias_acumulados") > 15),
        F.lit(1)
    ).otherwise(F.lit(0))
)

# ─── Ilha de ID_ATEST_REL ───────────────────────────────────────────────────
# Uma ilha de ID_ATEST_REL agrupa qualificados consecutivos dentro de:
#   - mesmo CID
#   - gap ≤ 60 dias entre ENDDA do último qualificado e BEGDA atual
#
# O "primeiro qualificado" de cada ilha não traz os curtos anteriores —
# o ID_ATEST_REL dele é só o próprio ID.

df = df.withColumn(
    "_id_if_qualified",
    F.when(F.col("_is_qualified") == 1, F.col("ID_ATEST")).otherwise(F.lit(None))
)
df = df.withColumn(
    "_endda_if_qualified",
    F.when(F.col("_is_qualified") == 1, F.col("_endda_norm")).otherwise(F.lit(None))
)
df = df.withColumn(
    "_cid_if_qualified",
    F.when(F.col("_is_qualified") == 1, F.col("_cid_trunc")).otherwise(F.lit(None))
)

w_prev_qualified = w_pernr.rowsBetween(Window.unboundedPreceding, -1)

df = df.withColumn(
    "_last_qual_endda",
    F.last(F.col("_endda_if_qualified"), ignorenulls=True).over(w_prev_qualified)
)
df = df.withColumn(
    "_last_qual_cid",
    F.last(F.col("_cid_if_qualified"), ignorenulls=True).over(w_prev_qualified)
)
df = df.withColumn(
    "_last_qual_endda_date",
    F.to_date(F.col("_last_qual_endda"), "ddMMyyyy")
)
df = df.withColumn(
    "_dias_ultimo_qual",
    F.datediff(F.col("_begda_date"), F.col("_last_qual_endda_date"))
)

# Abre nova ilha de ID_ATEST_REL quando:
#   - é o primeiro qualificado do PERNR, OU
#   - CID mudou em relação ao último qualificado, OU
#   - gap > 60 dias desde o último qualificado
df = df.withColumn(
    "_starts_id_rel_island",
    F.when(
        (F.col("_is_qualified") == 1) &
        (
            F.col("_last_qual_endda").isNull() |
            (F.col("_last_qual_cid") != F.col("_cid_trunc")) |
            (F.col("_dias_ultimo_qual") > 60)
        ),
        F.lit(1)
    ).otherwise(F.lit(0))
)

df = df.withColumn(
    "_id_rel_island",
    F.sum("_starts_id_rel_island").over(w_pernr)
)

# Coletar IDs qualificados anteriores dentro da mesma ilha de ID_ATEST_REL
w_id_rel_prev = (
    Window.partitionBy("PERNR", "_id_rel_island")
          .orderBy("_row_idx")
          .rowsBetween(Window.unboundedPreceding, -1)
)

df = df.withColumn(
    "_prev_qualified_ids",
    F.when(
        F.col("_is_qualified") == 1,
        F.array_distinct(
            F.filter(
                F.collect_list(F.col("_id_if_qualified")).over(w_id_rel_prev),
                lambda x: x.isNotNull()
            )
        )
    ).otherwise(F.array())
)

# Montar ID_ATEST_REL
df = df.withColumn(
    "ID_ATEST_REL",
    F.when(
        F.col("_is_qualified") == 1,
        F.when(
            F.size(F.col("_prev_qualified_ids")) > 0,
            F.concat_ws(";",
                F.concat_ws(";", F.col("_prev_qualified_ids")),
                F.col("ID_ATEST")
            )
        ).otherwise(F.col("ID_ATEST"))  # primeiro da ilha → só o próprio ID
    ).otherwise(F.lit(""))
)

# Limpeza de ";" inicial/duplicado
df = df.withColumn("ID_ATEST_REL", F.regexp_replace(F.col("ID_ATEST_REL"), r"^;+", ""))
df = df.withColumn("ID_ATEST_REL", F.regexp_replace(F.col("ID_ATEST_REL"), r";+", ";"))

print(f"Lógica REAFAST/ATEST_RELA/ID_ATEST_REL aplicada | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 11. Colunas derivadas: ID, SEQ_GESTAO, ENC_INSS ─────────────────────────
# O VBA gera a seção de gestão previdenciária apenas quando BEGDA_PREV != ""
# (coluna BE no VBA, que corresponde a BEGDA_PREV na bronze).
# Dentro desse bloco:
#   - ID: contador sequencial ordenado pelo ID_ATEST_REL (asc numérico).
#         Linhas com o MESMO ID_ATEST_REL compartilham o MESMO ID.
#   - SEQ_GESTAO: "GP" + sequência dentro do mesmo (PERNR, BEGDA_PREV)
#   - ENC_INSS: "S" quando BEGDA_PREV preenchido, "N" caso contrário

df = df.withColumn(
    "ENC_INSS",
    F.when(
        (F.trim(F.col("BEGDA_PREV")).isNull()) |
        (F.trim(F.col("BEGDA_PREV")) == ""),
        F.lit("N")
    ).otherwise(F.lit("S"))
)

# PERNR_PERI: conforme VBA — quando BEGDA_PREV preenchido, = PERNR; senão ""
df = df.withColumn(
    "PERNR_PERI",
    F.when(F.col("ENC_INSS") == "S", F.col("PERNR")).otherwise(F.lit(""))
)

# ENDDA_PREV: VBA usa ENDDA_ATEST no lugar de ENDDA_PREV original
# Se ENDDA_ATEST for "31129999" ou vazio, ENDDA_PREV fica vazio
# (calculado ANTES do ID para que a janela de ordenação use o valor correto)
df = df.withColumn(
    "ENDDA_PREV",
    F.when(
        F.col("ENC_INSS") == "S",
        F.when(
            F.trim(F.col("ENDDA_ATEST")).isNull() | F.trim(F.col("ENDDA_ATEST")).isin("", "31129999"),
            F.lit("")
        ).otherwise(F.col("ENDDA_ATEST"))
    ).otherwise(F.col("ENDDA_PREV"))
)

# ── ID: contador GLOBAL ordenado pelo ID_ATEST_REL (asc numérico) ────────────
# Regra: ID só é preenchido quando há gestão previdenciária E ID_ATEST_REL
# está preenchido. Linhas com o MESMO primeiro token de ID_ATEST_REL
# compartilham o MESMO ID (dense_rank).

df = df.withColumn(
    "_id_atest_rel_key",
    F.when(
        (F.col("ENC_INSS") == "S") &
        (F.trim(F.col("ID_ATEST_REL")) != "") &
        F.trim(F.col("ID_ATEST_REL")).isNotNull(),
        F.split(F.trim(F.col("ID_ATEST_REL")), ";").getItem(0).cast(IntegerType())
    ).otherwise(F.lit(None).cast(IntegerType()))
)

# dense_rank sobre a chave numérica (ignorando nulos)
w_id_rank = Window.orderBy(F.col("_id_atest_rel_key").asc_nulls_last())

df = df.withColumn(
    "ID",
    F.when(
        (F.col("ENC_INSS") == "S") & F.col("_id_atest_rel_key").isNotNull(),
        F.dense_rank().over(w_id_rank).cast(StringType())
    ).otherwise(F.lit(""))
)

# SEQ_GESTAO: sequência dentro do mesmo grupo (PERNR, BEGDA_PREV, ENDDA_PREV)
w_seq_gestao = Window.partitionBy("PERNR", "BEGDA_PREV", "ENDDA_PREV").orderBy("_row_idx")

df = df.withColumn(
    "SEQ_GESTAO",
    F.when(
        F.col("ENC_INSS") == "S",
        F.concat(F.lit("GP"), F.row_number().over(w_seq_gestao).cast(StringType()))
    ).otherwise(F.lit(""))
)

# STATUS_GESTAO: vazio por default (VBA deixa vazio)
df = df.withColumn("STATUS_GESTAO", F.lit(""))

# NUM_BEN: quando BEGDA_PREV vazio, limpa NUM_BEN; senão default "0" se vazio
df = df.withColumn(
    "NUM_BEN",
    F.when(F.col("ENC_INSS") == "N", F.lit(""))
    .when(
        F.trim(F.col("NUM_BEN")).isNull() | (F.trim(F.col("NUM_BEN")) == ""),
        F.lit("0")
    ).otherwise(F.col("NUM_BEN"))
)

# CONC_API: será recalculado com lookup da tabela API_Ativo_Inativo (se disponível)
# Por default, já foi setado como "N" nos defaults acima.
# Se a tabela auxiliar existir, o lookup é feito abaixo.

print(f"Colunas derivadas (ID, SEQ_GESTAO, ENC_INSS) aplicadas | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 12. Defaults finais para seção gestão (quando BEGDA_PREV vazio) ──────────
# O VBA só preenche as colunas de gestão (AP–CP) quando BEGDA_PREV != ""
# Para registros sem gestão, zeramos/limpamos essas colunas.

GESTAO_COLS_LIMPAR = [
    "DUPLIC_GEST", "OBS_PER1", "SIT_INSS",
    "DT_REQ", "NUM_REQ", "NUM_BEN", "TPBEN",
    "DT_INI_BENE", "DIAS_BENE", "BEN_CESS", "INAPTO",
    "DT_CESS_BEN", "DT_ALTA", "CONC_API",
    "DT_IN_API", "DT_FIM_API", "DT_REC", "NUM_REQREC",
    "DT_LIM", "DT_FIM_LIMBO", "REAB_CERT", "DT_REAB",
    "CAN_BEN", "DT_CAN_BEN", "DT_TRANS_NEXO", "DT_CONV_BEN",
    "TP_NEXO", "HV_CONT", "DT_CONTEST_NEXO", "NUM_OF_CONTEST",
    "CONT_PRAZO", "STATUS_CONT", "NEC_CONTEST", "DT_NOT_JUR",
    "OBS", "MODIF_USER_GEST", "MODIF_DATE_GEST", "REG_LOCL_GEST",
    "MODIF_USER_GEST91", "MODIF_DATE_GEST_1", "MODIF_LOCL_GEST",
]

# Apenas limpar colunas de gestão quando não há dados de gestão
# (quando ENC_INSS = "N" e a coluna deveria ficar vazia/default).
# O VBA mantém muitas colunas com defaults específicos na seção gestão,
# que já foram configurados acima. Aqui garantimos que colunas de gestão
# fiquem com defaults corretos para seção de gestão preenchida (quando
# BEGDA_PREV preenchido) e default de seção gestão para campos específicos.

# REG_LOCL_GEST: default "SEM HISTORICO" quando BEGDA_PREV preenchido mas campo vazio
df = df.withColumn(
    "REG_LOCL_GEST",
    F.when(
        (F.col("ENC_INSS") == "S") &
        (F.trim(F.col("REG_LOCL_GEST")).isNull() | (F.trim(F.col("REG_LOCL_GEST")) == "")),
        F.lit("SEM HISTORICO")
    ).when(
        F.col("ENC_INSS") == "N",
        F.lit("SEM HISTORICO")
    ).otherwise(F.substring(F.col("REG_LOCL_GEST"), 1, 100))
)

# MODIF_DATE_GEST: conforme mapeamento, "Aceita valor em branco" -> fica vazio quando nulo
df = df.withColumn(
    "MODIF_DATE_GEST",
    F.when(
        F.trim(F.col("MODIF_DATE_GEST")).isNull() | (F.trim(F.col("MODIF_DATE_GEST")) == ""),
        F.lit("")
    ).otherwise(F.col("MODIF_DATE_GEST"))
)

print(f"Defaults finais gestão aplicados | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 13. Limpeza de colunas auxiliares e seleção final ─────────────────────────

# Remove colunas auxiliares internas
aux_cols = [c for c in df.columns if c.startswith("_")]
df = df.drop(*aux_cols)

# ── Layout Silver final (conforme VBA Formata_Gestao_Previdenciaria) ─────────
# Reordenação de colunas conforme cabeçalho P8 do VBA

# Usa SILVER_COL_ORDER definido em config.py

# Garantir que colunas existam (adicionar se ausentes)
for c in SILVER_COL_ORDER:
    if c not in df.columns:
        df = df.withColumn(c, F.lit(""))

# Deixar colunas específicas vazias por padrão
for col_vazia in [
    "DT_CONV", "MODIF_USER_2", "MODIF_DATE_2",
    "MODIF_USER_GEST91", "MODIF_DATE_GEST_1", "MODIF_LOCL_GEST"
]:
    if col_vazia in df.columns:
        df = df.withColumn(col_vazia, F.lit(""))

# Campos que devem estar SEMPRE em branco conforme mapeamento
for col_branco in [
    "DT_IN_API", "DT_FIM_API", "DT_REC", "NUM_REQREC",
    "DT_LIM", "DT_FIM_LIMBO", "DT_REAB", "DT_CAN_BEN", "CAN_BEN"
]:
    if col_branco in df.columns:
        df = df.withColumn(col_branco, F.lit(""))

# HV_CONT e NEC_CONTEST: valor padrão "M"
for col_m in ["HV_CONT", "NEC_CONTEST"]:
    if col_m in df.columns:
        df = df.withColumn(col_m, F.lit("M"))

# ENTREG_REG: quando vazio, default "0"
if "ENTREG_REG" in df.columns:
    df = df.withColumn(
        "ENTREG_REG",
        F.when(
            F.trim(F.col("ENTREG_REG")).isNull() | (F.trim(F.col("ENTREG_REG")) == ""),
            F.lit("0")
        ).otherwise(F.col("ENTREG_REG"))
    )

# NDIAS_AFAST e DUR_AUSEN: transformar "4.00000" em "4", mantendo como string
for col_int_str in ["NDIAS_AFAST", "DUR_AUSEN"]:
    if col_int_str in df.columns:
        df = df.withColumn(
            col_int_str,
            F.regexp_replace(F.col(col_int_str), r"\.\d+$", "")
        )

# null_to_empty em todas as colunas do layout
df = null_to_empty(df, SILVER_COL_ORDER)

# Renomeia colunas para match com SILVER_COL_ORDER (conforme layout de exportação)
rename_map = {
    "ENTREG_ATEST": "ENTREG_REG",
    "ID_GESTAO": "ID",
    "INFO_ADD": "INFO_ADD1",
    "OBS_PER": "OBS_PER1",
    "MODIF_USER_GEST": "MODIF_USER_GEST88",
    "MODIF_USER_GEST91": "MODIF_USER_GEST91",
    "MODIF_DATE_GEST_1": "MODIF_DATE_GEST_1",
}
for old_name, new_name in rename_map.items():
    if old_name in df.columns and new_name not in df.columns:
        df = df.withColumnRenamed(old_name, new_name)

# Selecionar colunas na ordem do layout silver
df_silver = df.select(SILVER_COL_ORDER)

# ── MATRICULAS_READMITIDAS: de/para do arquivo EC_Matriculas_Modificadas ─────
# Join da coluna PERNR com "(DE) Person_ID_External" para trazer "(PARA) userID"
pdf_matr = pd.read_excel(
    DE_PARA_EC_MATRICULAS_MODIFICADAS,
    sheet_name=DE_PARA_EC_MATR_MOD_SHEET,
    dtype=str
)
pdf_matr = pdf_matr.fillna("")
df_matr = spark.createDataFrame(pdf_matr)

df_matr_lookup = df_matr.select(
    F.trim(F.col("`(DE) Person_ID_External`")).alias("_PERNR_DE"),
    F.trim(F.col("`(PARA) userID`")).alias("MATRICULAS_READMITIDAS")
).distinct()

df_silver = df_silver.join(
    df_matr_lookup,
    F.trim(F.col("PERNR")) == F.col("_PERNR_DE"),
    "left"
).drop("_PERNR_DE")

# Preencher com PERNR onde não houve match
df_silver = df_silver.withColumn(
    "MATRICULAS_READMITIDAS",
    F.when(
        F.col("MATRICULAS_READMITIDAS").isNull() | (F.col("MATRICULAS_READMITIDAS") == ""),
        F.col("PERNR")
    ).otherwise(F.col("MATRICULAS_READMITIDAS"))
)

df_silver = df_silver.dropDuplicates()

df_silver.cache()
print(f"Silver preparada: {df_silver.count():,} registros | {_fmt(time.time()-t0)}")

# COMMAND ----------

display(df_silver)

# COMMAND ----------

# ── 14. Gravação na tabela Silver ─────────────────────────────────────────────
save_table(df_silver, SILVER_GP)
df_silver.unpersist()

print(f"✅ Silver GP gravada com sucesso | total: {_fmt(time.time()-t0)}")

# COMMAND ----------

import re
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType

# Regex: remove caracteres de controle exceto \t, \n, \r
_CTRL_CHARS = re.compile(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]')

@udf(StringType())
def clean_ctrl_chars(val):
    if val is None:
        return ""
    return _CTRL_CHARS.sub("", val)

# Colunas de texto livre que podem conter caracteres ilegais
TEXT_COLS = ["OBS", "OBS_PER1", "OBS_ATEST", "INFO_ADD1", "RESP_ANTE_TEXT"]

for col_name in TEXT_COLS:
    if col_name in df_silver.columns:
        df_silver = df_silver.withColumn(col_name, clean_ctrl_chars(F.col(col_name)))

export_df_to_excel(df_silver, OUTPUT_BASE, "Formata_Gestao_Previdenciaria")

# COMMAND ----------

df_silver.createOrReplaceTempView("df_silver")
query = spark.sql("""
  WITH base AS (
    SELECT 
      ID,
      ID_ATEST_REL,
      CAST(SPLIT(ID_ATEST_REL, ';')[0] AS INT) AS _id_rel_key
    FROM df_silver
    WHERE ID <> "" AND ID_ATEST_REL <> ""
  ),
  ranked AS (
    SELECT 
      ID,
      ID_ATEST_REL,
      _id_rel_key,
      DENSE_RANK() OVER (ORDER BY _id_rel_key ASC) AS id_esperado
    FROM base
  )
  SELECT 
    ID,
    id_esperado,
    ID_ATEST_REL,
    _id_rel_key,
    CASE 
      WHEN CAST(ID AS INT) = id_esperado THEN 'OK'
      ELSE 'DIVERGENTE'
    END AS status
  FROM ranked
  ORDER BY _id_rel_key ASC
""")
print(f"Total registros validados: {query.count()}")
display(query)

# COMMAND ----------

df_silver.createOrReplaceTempView("df_silver")
query = spark.sql("""
  SELECT 
    -- Identificação
    PERNR,
    ID_ATEST,
    
    -- Ordenação cronológica e duração (pra conferir ordem + janela 0..60 dias)
    BEGDA_ATEST,
    ENDDA_ATEST,
    DUR_AUSEN,
    
    -- Critérios de correlação
    CID1,
    REAFAST_MESMO_MOT,
    
    -- Campos alvo da validação
    ATEST_RELA,
    ID_ATEST_REL,
    
    -- Contexto perícia/INSS (afeta regras do ID_ATEST_REL)
    BEGDA_PREV,
    DT_PERI,
    ENC_INSS,
    ENDDA_PREV
  FROM df_silver
  WHERE PERNR IN ('514470') -- AND CID1 IN ('M54.5')
""")
display(query)