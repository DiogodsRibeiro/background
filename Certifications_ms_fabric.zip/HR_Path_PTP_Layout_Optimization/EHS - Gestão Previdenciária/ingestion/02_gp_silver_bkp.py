# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Gestão Previdenciária/utils/utils"

# COMMAND ----------

# ─────────────────────────────────────────────────────────────────────────────
# 02_gp_silver.py — Camada Silver: Gestão Previdenciária
# ─────────────────────────────────────────────────────────────────────────────
# Depende de: 01_gp_sdweb_bronze (BRONZE_GP deve estar gravada antes)
#
# Lógica traduzida do VBA (MOCK4_GP_VBA.txt):
#   1. Ordenação por PERNR, BEGDA_ATEST, ENDDA_ATEST, DT_PERI, DIAS_BENE
#   2. Remoção de duplicatas
#   3. Exclusão de registros específicos (hardcoded no VBA)
#   4. Formatação de CID (inserção de ponto)
#   5. Limpeza de datas (remoção de "/", default "01010001")
#   6. Limpeza de textos (caracteres de controle)
#   7. Defaults por coluna (null → valor padrão conforme VBA)
#   8. Recalculo de ID_ATEST sequencial
#   9. Lógica de REAFAST_MESMO_MOT / ATEST_RELA / ID_ATEST_REL (correlação)
#  10. Colunas derivadas: ID, SEQ_GESTAO, ENC_INSS, STATUS_GESTAO
#  11. Flags API_Ativo_Inativo (CONC_API) e Reabilitado (REAB_CERT)
#  12. Mapeamento/reordenação de colunas para layout silver
# ─────────────────────────────────────────────────────────────────────────────

import time
from pyspark.sql import functions as F, Window
from pyspark.sql.types import StringType, IntegerType
import pandas as pd

t0 = time.time()

def _fmt(s):
    if s < 60:   return f"{s:.1f}s"
    if s < 3600: return f"{int(s//60)}min {s%60:.1f}s"
    return f"{int(s//3600)}h {int((s%3600)//60)}min {s%60:.0f}s"

print("🔄 Iniciando transformação Silver - Gestão Previdenciária...")

# COMMAND ----------

# ── 1. Leitura da Bronze ──────────────────────────────────────────────────────

df = spark.table(BRONZE_GP)
print(f"Bronze lida: {df.count():,} registros | {_fmt(time.time()-t0)}")

# ── EC_33: Filtrar apenas PERNRs que existem no EC_33 ────────────────────────
# Lê EC_33 com header na segunda linha (ignorando a primeira)
pdf_ec33 = pd.read_excel(EC_33, header=1, dtype=str)
pdf_ec33 = pdf_ec33.fillna("")
df_ec33 = spark.createDataFrame(pdf_ec33)

# Coluna "ID do usuário" do EC_33 faz match com PERNR
ec33_pernrs = df_ec33.select(
    F.trim(F.col("`ID do usuário`")).alias("PERNR_EC33")
).distinct()

rows_before_ec33 = df.count()
df = df.join(
    ec33_pernrs,
    F.trim(F.col("PERNR")) == F.col("PERNR_EC33"),
    "inner"
).drop("PERNR_EC33")

print(f"Filtro EC_33 aplicado: {rows_before_ec33} → {df.count():,} registros | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 2. Exclusão de registros específicos (hardcoded no VBA) ───────────────────
# O VBA contém ElseIf's que pulam registros com combinações específicas de
# PERNR + BEGDA_ATEST + ENDDA_ATEST. Traduzimos como filtro de exclusão.

exclusions = GP_EXCLUSIONS  # definido em config.py

# Normaliza as datas bronze (remove "/") para comparação
df = df.withColumn("_begda_norm", F.regexp_replace(F.col("BEGDA_ATEST"), "/", ""))
df = df.withColumn("_endda_norm", F.regexp_replace(F.col("ENDDA_ATEST"), "/", ""))

# Constroi condição de exclusão usando utils
excl_cond = build_exclusion_filter(exclusions)

rows_before = df.count()
df = df.filter(~excl_cond)
rows_after = df.count()
print(f"Exclusões aplicadas: {rows_before - rows_after} registros removidos | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 3. Remoção de duplicatas ──────────────────────────────────────────────────
# O VBA faz RemoveDuplicates em todas as 104 colunas originais.
# Aqui usamos dropDuplicates com as colunas de negócio (sem auxiliares).

cols_dedup = [c for c in df.columns if not c.startswith("_") and c != "ID_HASH"]
df = df.dropDuplicates(cols_dedup)
print(f"Pós deduplicação: {df.count():,} registros | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 4. Ordenação (conforme VBA) ───────────────────────────────────────────────
# PERNR (asc, text as numbers), BEGDA_ATEST (asc), ENDDA_ATEST (asc),
# DT_PERI (asc), DIAS_BENE (asc)

df = df.orderBy(
    F.col("PERNR").cast(IntegerType()).asc_nulls_last(),
    F.col("BEGDA_ATEST").asc_nulls_last(),
    F.col("ENDDA_ATEST").asc_nulls_last(),
    F.col("DT_PERI").asc_nulls_last(),
    F.col("DIAS_BENE").asc_nulls_last(),
)

# COMMAND ----------

# ── 5. Formatação de datas ────────────────────────────────────────────────────
# O VBA remove "/" das datas e usa "01010001" como default para nulo.

DATE_COLS_DEFAULT_01010001 = [
    "BEGDA_ATEST", "ENDDA_ATEST", "D_SEXTO_DIA", "DT_CONV",
    "MODIF_DATE", "MODIF_DATE_2", "BEGDA_PREV", "ENDDA_PREV",
    "DATE_INICAFAST", "DT_PERI", "DT_REQ", "DT_INI_BENE",
    "DT_CESS_BEN", "DT_ALTA", "DT_IN_API", "DT_FIM_API",
    "DT_REC", "DT_LIM", "DT_FIM_LIMBO", "DT_REAB",
    "DT_CAN_BEN", "DT_TRANS_NEXO", "DT_CONV_BEN",
    "DT_CONTEST_NEXO", "DT_NOT_JUR",
    "MODIF_DATE_GEST", "MODIF_DATE_GEST_2",
]

for c in DATE_COLS_DEFAULT_01010001:
    if c in df.columns:
        df = df.withColumn(c, F.regexp_replace(F.col(c), "/", ""))

# COMMAND ----------

# ── 6. Formatação de CID ─────────────────────────────────────────────────────
# CID1: 3 chars → mantém; 4 chars → insere ponto (ex: "M541" → "M54.1")
#        null/empty → "S/H"
# CID2: mesma lógica, aplicada a cada item separado por "|"

df = df.withColumn(
    "CID1",
    F.when(
        F.trim(F.col("CID1")).isNull() | (F.trim(F.col("CID1")) == "") | (F.trim(F.col("CID1")) == "null"),
        F.lit("S/H")
    ).when(
        F.length(F.trim(F.col("CID1"))) == F.lit(3),
        F.trim(F.col("CID1"))
    ).when(
        F.length(F.trim(F.col("CID1"))) == F.lit(4),
        F.concat(F.substring(F.trim(F.col("CID1")), 1, 3), F.lit("."), F.substring(F.trim(F.col("CID1")), 4, 1))
    ).otherwise(F.trim(F.col("CID1")))
)

from pyspark.sql.functions import udf

@udf(StringType())
def format_cid2(val):
    if val is None or str(val).strip() == "" or str(val).strip() == "null":
        return ""
    items = str(val).replace("|", ";").split(";")
    result = []
    for item in items:
        item = item.strip()
        if not item:
            continue
        if len(item) == 3:
            result.append(item)
        elif len(item) == 4:
            result.append(item[:3] + "." + item[3])
        else:
            result.append(item)
    formatted = ";".join(result)
    if len(formatted) > 255:
        formatted = formatted[:255]
    if formatted.endswith(";"):
        formatted = formatted[:-1]
    return formatted

df = df.withColumn("CID2", format_cid2(F.col("CID2")))

print(f"CID formatado (com ponto) | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 7. Limpeza de textos ──────────────────────────────────────────────────────
# O VBA remove Chr(13), Chr(10), Chr(9), Chr(0) e substitui "|" por "/"
# nos campos INFO_ADD, OBS_ATEST e OBS_PER

TEXT_CLEAN_COLS = ["INFO_ADD1", "OBS_ATEST", "OBS_PER1"]
df = clean_control_chars(df, TEXT_CLEAN_COLS)

# NUM_PROC_PREV: remove ".", "-", "/"
if "NUM_PROC_PREV" in df.columns:
    df = df.withColumn(
        "NUM_PROC_PREV",
        F.regexp_replace(
            F.regexp_replace(
                F.regexp_replace(F.col("NUM_PROC_PREV"), "\\.", ""),
                "-", ""
            ),
            "/", ""
        )
    )

# NOME_EMIT: truncar em 255 chars; default "SEM HISTORICO"
df = df.withColumn(
    "NOME_EMIT",
    F.when(
        F.trim(F.col("NOME_EMIT")).isNull() | (F.trim(F.col("NOME_EMIT")) == "") | (F.trim(F.col("NOME_EMIT")) == "M"),
        F.lit("SEM HISTORICO")
    ).otherwise(F.substring(F.col("NOME_EMIT"), 1, 255))
)

# NUM_BEN: remove "." e "-" (conforme VBA)
if "NUM_BEN" in df.columns:
    df = df.withColumn(
        "NUM_BEN",
        F.regexp_replace(F.regexp_replace(F.col("NUM_BEN"), "\\.", ""), "-", "")
    )

print(f"Limpeza de textos concluída | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 8. Defaults por coluna (conforme regras VBA) ─────────────────────────────

# Colunas com default específico quando nulo/vazio
defaults_map = {
    # Numéricos com default "0"
    "NDIAS_AFAST":       "0",
    "DUR_AUSEN":         "0",
    "ENTREG_ATEST":      "0",
    "NUM_OC":            "0",
    "REC_ESOC":          "0",
    "NUM_REQ":           "0",
    "DIAS_BENE":         "0",
    "NUM_OF_CONTEST":    "0",
    # Texto com default "M"
    "STATUS_ESOC":       "M",
    "CRM":               "M",
    "UF_OC":             "M",
    "COD_ESOC":          "M",
    "TPBEN":             "M",
    "RESULTADO":         "M",
    "MOT_AFAST":         "M",
    "ATEST_ANTE":        "M",
    # Flags com default "N"
    "HV_CONV":           "N",
    "REAFAST_MESMO_MOT": "N",
    "BEN_CESS":          "N",
    "INAPTO":            "N",
    "CONC_API":          "N",
    "HV_CONT":           "N",
    "NEC_CONTEST":       "N",
    "CAN_BEN":           "N",
    "REAB_CERT":         "N",
    # Texto com default "SEM HISTORICO"
    "REG_LOCL":          "SEM HISTORICO",
}

df = apply_defaults(df, defaults_map)

# Datas com default "01010001" para nulo
date_defaults = {c: "01010001" for c in DATE_COLS_DEFAULT_01010001 if c in df.columns}
df = apply_defaults(df, date_defaults)

# Truncar campos de texto nos tamanhos do VBA
TRUNCATE_MAP = {
    "MODIF_USER": 100, "MOT_ANTE": 100, "RESP_ANTE": 255,
    "REG_LOCL": 100, "MODIF_USER_2": 100, "MODIF_LOCL_2": 100,
    "NUM_OF_CONTEST": 30,
    "MODIF_USER_GEST": 100, "REG_LOCL_GEST": 100,
    "MODIF_USER_GEST_2": 100, "MODIF_LOCL_GEST": 100,
}
for col_name, max_len in TRUNCATE_MAP.items():
    if col_name in df.columns:
        df = df.withColumn(col_name, F.substring(F.col(col_name), 1, max_len))

print(f"Defaults aplicados | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 9. Recalcular ID_ATEST conforme lógica VBA ──────────────────────────────
# No VBA, COUNT_ID_ATEST é um contador GLOBAL sequencial (não reseta por PERNR).
# Incrementa +1 cada vez que o par (PERNR, BEGDA_ATEST) muda.

df = df.withColumn("_row_idx", F.monotonically_increasing_id())

w_order = Window.orderBy(
    F.col("PERNR").cast(IntegerType()).asc_nulls_last(),
    F.col("BEGDA_ATEST").asc_nulls_last(),
    F.col("ENDDA_ATEST").asc_nulls_last(),
    F.col("DT_PERI").asc_nulls_last(),
    F.col("DIAS_BENE").asc_nulls_last(),
    F.col("_row_idx").asc()
)

df = df.withColumn("_prev_pernr", F.lag("PERNR").over(w_order))
df = df.withColumn("_prev_begda", F.lag("_begda_norm").over(w_order))

# Flag: 1 quando muda (PERNR, BEGDA_ATEST); 0 quando repete
df = df.withColumn(
    "_change_flag",
    F.when(
        F.col("_prev_pernr").isNull() |
        (F.col("PERNR") != F.col("_prev_pernr")) |
        (F.col("_begda_norm") != F.col("_prev_begda")),
        F.lit(1)
    ).otherwise(F.lit(0))
)

# ID_ATEST = soma cumulativa GLOBAL (nunca reseta)
df = df.withColumn(
    "ID_ATEST",
    F.sum("_change_flag").over(w_order).cast(StringType())
)

print(f"ID_ATEST recalculado (lógica VBA - contador global) | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 10. Lógica REAFAST_MESMO_MOT / ATEST_RELA / ID_ATEST_REL ────────────────
# Esta é a lógica mais complexa do VBA. Resume-se a:
#   - Comparar CID entre linhas consecutivas do mesmo PERNR
#   - Se CID muda e REAFAST_MESMO_MOT = "N": CID_Sem_Mae = "" → REAFAST = "N"
#   - Se CID igual e REAFAST = "S": verificar janela de 60 dias entre
#     ENDDA_ATEST anterior e BEGDA_ATEST atual para correlacionar atestados
#   - ATEST_RELA = IDs dos atestados correlacionados (concatenados com ";")
#   - ID_ATEST_REL = similar para gestão previdenciária

# Colunas auxiliares para a janela de lag
w_pernr = Window.partitionBy("PERNR").orderBy("_row_idx")

# CID1 truncado nos primeiros 6 chars (conforme VBA: Mid(Trim(...), 1, 6))
df = df.withColumn("_cid_trunc", F.substring(F.trim(F.col("CID1")), 1, 6))
df = df.withColumn("_prev_cid", F.lag("_cid_trunc").over(w_pernr))
df = df.withColumn("_prev_endda", F.lag("_endda_norm").over(w_pernr))
df = df.withColumn("_prev_id_atest", F.lag("ID_ATEST").over(w_pernr))

# Calcular diferença em dias entre ENDDA anterior e BEGDA atual
# As datas estão no formato ddmmyyyy
df = df.withColumn(
    "_begda_date",
    F.to_date(F.col("_begda_norm"), "ddMMyyyy")
)
df = df.withColumn(
    "_prev_endda_date",
    F.to_date(F.col("_prev_endda"), "ddMMyyyy")
)
df = df.withColumn(
    "_dias_entre",
    F.datediff(F.col("_begda_date"), F.col("_prev_endda_date"))
)

# REAFAST_MESMO_MOT: Se CID mudou e flag original da bronze é "N", sobrescrever "N"
# Se CID_Sem_Mae == "" (CID mudou com flag N) → REAFAST = "N"
df = df.withColumn(
    "REAFAST_MESMO_MOT",
    F.when(
        # Primeira linha do PERNR ou CID mudou com flag "N"
        F.col("_prev_cid").isNull() |
        ((F.col("_cid_trunc") != F.col("_prev_cid")) & (F.col("REAFAST_MESMO_MOT") == "N")),
        F.lit("N")
    ).otherwise(F.col("REAFAST_MESMO_MOT"))
)

# ATEST_RELA: correlação de atestados (dentro de 60 dias, mesmo CID, REAFAST=S)
df = df.withColumn(
    "ATEST_RELA",
    F.when(
        (F.col("_cid_trunc") == F.col("_prev_cid")) &
        (F.col("REAFAST_MESMO_MOT") == "S") &
        (F.col("_dias_entre").isNotNull()) &
        (F.col("_dias_entre") >= 0) &
        (F.col("_dias_entre") <= 60),
        F.col("_prev_id_atest")
    ).otherwise(F.lit(""))
)

# ID_ATEST_REL: similar lógica — quando há correlação, registra o ID anterior
df = df.withColumn(
    "ID_ATEST_REL",
    F.when(
        (F.col("ATEST_RELA") != ""),
        F.col("_prev_id_atest")
    ).otherwise(F.lit(""))
)

# Se DUR_AUSEN > 15 e há correlação acumulada, concat com ID atual
df = df.withColumn(
    "ID_ATEST_REL",
    F.when(
        (F.col("DUR_AUSEN").cast(IntegerType()) > 15) &
        (F.col("ATEST_RELA") != ""),
        F.concat_ws(";", F.col("ATEST_RELA"), F.col("ID_ATEST"))
    ).when(
        (F.col("DUR_AUSEN").cast(IntegerType()) > 15) &
        (F.col("ATEST_RELA") == ""),
        F.col("ID_ATEST")
    ).otherwise(F.col("ID_ATEST_REL"))
)

# Para atestados >15 dias sem perícia → ID_ATEST_REL = "0"
df = df.withColumn(
    "ID_ATEST_REL",
    F.when(
        (F.col("DUR_AUSEN").cast(IntegerType()) > 15) &
        (F.trim(F.col("DT_PERI")).isin("", "01010001")),
        F.lit("0")
    ).otherwise(F.col("ID_ATEST_REL"))
)

print(f"Lógica REAFAST/ATEST_RELA aplicada | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 11. Colunas derivadas: ID, SEQ_GESTAO, ENC_INSS ─────────────────────────
# O VBA gera a seção de gestão previdenciária apenas quando BEGDA_PREV != ""
# (coluna BE no VBA, que corresponde a BEGDA_PREV na bronze).
# Dentro desse bloco:
#   - ID_DA_GESTAO: incrementa quando (PERNR, BEGDA_PREV) muda
#   - SEQ_GESTAO: "GP" + sequência dentro do mesmo (PERNR, BEGDA_PREV)
#   - ENC_INSS: "S" quando BEGDA_PREV preenchido, "N" caso contrário

df = df.withColumn(
    "ENC_INSS",
    F.when(
        F.trim(F.col("BEGDA_PREV")).isNull() |
        F.trim(F.col("BEGDA_PREV")).isin("", "01010001"),
        F.lit("N")
    ).otherwise(F.lit("S"))
)

# PERNR_PERI: conforme VBA — quando BEGDA_PREV preenchido, = PERNR; senão "0"
df = df.withColumn(
    "PERNR_PERI",
    F.when(F.col("ENC_INSS") == "S", F.col("PERNR")).otherwise(F.lit(""))
)

# ID_DA_GESTAO (campo "ID" na silver)
df = df.withColumn("_prev_begda_prev", F.lag("BEGDA_PREV").over(w_order))

df = df.withColumn(
    "_gestao_change",
    F.when(
        F.col("ENC_INSS") == "N",
        F.lit(0)
    ).when(
        F.col("_prev_begda_prev").isNull() |
        (F.col("PERNR") != F.col("_prev_pernr")) |
        (F.col("BEGDA_PREV") != F.col("_prev_begda_prev")),
        F.lit(1)
    ).otherwise(F.lit(0))
)

df = df.withColumn(
    "ID",
    F.when(
        F.col("ENC_INSS") == "S",
        F.sum("_gestao_change").over(w_order).cast(StringType())
    ).otherwise(F.lit(""))
)

# SEQ_GESTAO: sequência dentro do mesmo (PERNR, BEGDA_PREV)
w_gestao = Window.partitionBy("PERNR", "BEGDA_PREV").orderBy("_row_idx")

df = df.withColumn(
    "SEQ_GESTAO",
    F.when(
        F.col("ENC_INSS") == "S",
        F.concat(F.lit("GP"), F.row_number().over(w_gestao).cast(StringType()))
    ).otherwise(F.lit(""))
)

# STATUS_GESTAO: vazio por default (VBA deixa vazio)
df = df.withColumn("STATUS_GESTAO", F.lit(""))

# ENDDA_PREV: VBA usa ENDDA_ATEST no lugar de ENDDA_PREV original
# Linha VBA: P8.Range("AV" & Z).Value = Replace(P7.Range("Q" & g).Value, "/", "")
df = df.withColumn(
    "ENDDA_PREV",
    F.when(
        F.col("ENC_INSS") == "S",
        F.when(
            F.trim(F.col("ENDDA_ATEST")).isNull() | (F.trim(F.col("ENDDA_ATEST")) == ""),
            F.lit("01010001")
        ).otherwise(F.col("ENDDA_ATEST"))
    ).otherwise(F.col("ENDDA_PREV"))
)

# NUM_BEN: quando BEGDA_PREV vazio, limpa NUM_BEN; senão default "0" se vazio
df = df.withColumn(
    "NUM_BEN",
    F.when(F.col("ENC_INSS") == "N", F.lit(""))
    .when(
        F.trim(F.col("NUM_BEN")).isNull() | (F.trim(F.col("NUM_BEN")) == ""),
        F.lit("0")
    ).otherwise(F.col("NUM_BEN"))
)

# CONC_API: será recalculado com lookup da tabela API_Ativo_Inativo (se disponível)
# Por default, já foi setado como "N" nos defaults acima.
# Se a tabela auxiliar existir, o lookup é feito abaixo.

print(f"Colunas derivadas (ID, SEQ_GESTAO, ENC_INSS) aplicadas | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 12. Defaults finais para seção gestão (quando BEGDA_PREV vazio) ──────────
# O VBA só preenche as colunas de gestão (AP–CP) quando BEGDA_PREV != ""
# Para registros sem gestão, zeramos/limpamos essas colunas.

GESTAO_COLS_LIMPAR = [
    "DUPLIC_GEST", "OBS_PER1", "SIT_INSS",
    "DT_REQ", "NUM_REQ", "NUM_BEN", "TPBEN",
    "DT_INI_BENE", "DIAS_BENE", "BEN_CESS", "INAPTO",
    "DT_CESS_BEN", "DT_ALTA", "CONC_API",
    "DT_IN_API", "DT_FIM_API", "DT_REC", "NUM_REQREC",
    "DT_LIM", "DT_FIM_LIMBO", "REAB_CERT", "DT_REAB",
    "CAN_BEN", "DT_CAN_BEN", "DT_TRANS_NEXO", "DT_CONV_BEN",
    "TP_NEXO", "HV_CONT", "DT_CONTEST_NEXO", "NUM_OF_CONTEST",
    "CONT_PRAZO", "STATUS_CONT", "NEC_CONTEST", "DT_NOT_JUR",
    "OBS", "MODIF_USER_GEST", "MODIF_DATE_GEST", "REG_LOCL_GEST",
    "MODIF_USER_GEST91", "MODIF_DATE_GEST_1", "MODIF_LOCL_GEST",
]

# Apenas limpar colunas de gestão quando não há dados de gestão
# (quando ENC_INSS = "N" e a coluna deveria ficar vazia/default).
# O VBA mantém muitas colunas com defaults específicos na seção gestão,
# que já foram configurados acima. Aqui garantimos que colunas de gestão
# fiquem com defaults corretos para seção de gestão preenchida (quando
# BEGDA_PREV preenchido) e default de seção gestão para campos específicos.

# REG_LOCL_GEST: default "SEM HISTORICO" quando BEGDA_PREV preenchido mas campo vazio
df = df.withColumn(
    "REG_LOCL_GEST",
    F.when(
        (F.col("ENC_INSS") == "S") &
        (F.trim(F.col("REG_LOCL_GEST")).isNull() | (F.trim(F.col("REG_LOCL_GEST")) == "")),
        F.lit("SEM HISTORICO")
    ).when(
        F.col("ENC_INSS") == "N",
        F.lit("SEM HISTORICO")
    ).otherwise(F.substring(F.col("REG_LOCL_GEST"), 1, 100))
)

# MODIF_DATE_GEST: "01010001" quando BEGDA_PREV preenchido mas campo vazio
df = df.withColumn(
    "MODIF_DATE_GEST",
    F.when(
        (F.col("ENC_INSS") == "S") &
        (F.trim(F.col("MODIF_DATE_GEST")).isNull() | (F.trim(F.col("MODIF_DATE_GEST")) == "")),
        F.lit("01010001")
    ).otherwise(F.col("MODIF_DATE_GEST"))
)

print(f"Defaults finais gestão aplicados | {_fmt(time.time()-t0)}")

# COMMAND ----------

# ── 13. Limpeza de colunas auxiliares e seleção final ─────────────────────────

# Remove colunas auxiliares internas
aux_cols = [c for c in df.columns if c.startswith("_")]
df = df.drop(*aux_cols)

# ── Layout Silver final (conforme VBA Formata_Gestao_Previdenciaria) ─────────
# Reordenação de colunas conforme cabeçalho P8 do VBA

# Usa SILVER_COL_ORDER definido em config.py

# Garantir que colunas existam (adicionar se ausentes)
for c in SILVER_COL_ORDER:
    if c not in df.columns:
        df = df.withColumn(c, F.lit(""))

# Deixar colunas específicas vazias por padrão
for col_vazia in [
    "DT_CONV", "MODIF_USER_2", "MODIF_DATE_2",
    "MODIF_USER_GEST91", "MODIF_DATE_GEST_1", "MODIF_LOCL_GEST"
]:
    if col_vazia in df.columns:
        df = df.withColumn(col_vazia, F.lit(""))

# NDIAS_AFAST e DUR_AUSEN: transformar "4.00000" em "4", mantendo como string
for col_int_str in ["NDIAS_AFAST", "DUR_AUSEN"]:
    if col_int_str in df.columns:
        df = df.withColumn(
            col_int_str,
            F.regexp_replace(F.col(col_int_str), r"\.\d+$", "")
        )

# null_to_empty em todas as colunas do layout
df = null_to_empty(df, SILVER_COL_ORDER)

# Renomeia colunas para match com SILVER_COL_ORDER (conforme layout de exportação)
rename_map = {
    "ENTREG_ATEST": "ENTREG_REG",
    "ID_GESTAO": "ID",
    "INFO_ADD": "INFO_ADD1",
    "OBS_PER": "OBS_PER1",
    "MODIF_USER_GEST": "MODIF_USER_GEST88",
    "MODIF_USER_GEST91": "MODIF_USER_GEST91",
    "MODIF_DATE_GEST_1": "MODIF_DATE_GEST_1",
}
for old_name, new_name in rename_map.items():
    if old_name in df.columns and new_name not in df.columns:
        df = df.withColumnRenamed(old_name, new_name)

# Selecionar colunas na ordem do layout silver
df_silver = df.select(SILVER_COL_ORDER)

df_silver = df_silver.dropDuplicates()

df_silver.cache()
print(f"Silver preparada: {df_silver.count():,} registros | {_fmt(time.time()-t0)}")

# COMMAND ----------

display(df_silver)

# COMMAND ----------

# ── 14. Gravação na tabela Silver ─────────────────────────────────────────────
save_table(df_silver, SILVER_GP)
df_silver.unpersist()

print(f"✅ Silver GP gravada com sucesso | total: {_fmt(time.time()-t0)}")

# COMMAND ----------

import re
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType

# Regex: remove caracteres de controle exceto \t, \n, \r
_CTRL_CHARS = re.compile(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]')

@udf(StringType())
def clean_ctrl_chars(val):
    if val is None:
        return ""
    return _CTRL_CHARS.sub("", val)

# Colunas de texto livre que podem conter caracteres ilegais
TEXT_COLS = ["OBS", "OBS_PER1", "OBS_ATEST", "INFO_ADD1", "RESP_ANTE_TEXT"]

for col_name in TEXT_COLS:
    if col_name in df_silver.columns:
        df_silver = df_silver.withColumn(col_name, clean_ctrl_chars(F.col(col_name)))

export_df_to_excel(df_silver, OUTPUT_BASE, "Formata_Gestao_Previdenciaria")