# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Gestão Previdenciária/utils/utils"

# COMMAND ----------

import re
import time
from pyspark import StorageLevel
from pyspark.sql.types import StringType
from pyspark.sql.functions import col

# COMMAND ----------

def _fmt(s):
    if s < 60:   return f"{s:.1f}s"
    if s < 3600: return f"{int(s//60)}min {s%60:.1f}s"
    return f"{int(s//3600)}h {int((s%3600)//60)}min {s%60:.0f}s"

# ─────────────────────────────────────────────────────────────────
# Helper: converte qualquer JDBC URL Oracle para formato DESCRIPTION
# com ENABLE=BROKEN (mantém TCP keepalive contra firewall/LB)
# ─────────────────────────────────────────────────────────────────
def oracle_url_with_broken(url):
    upper = url.upper()
    if "DESCRIPTION" in upper:
        if "ENABLE=BROKEN" not in upper:
            return url.replace("(DESCRIPTION=", "(DESCRIPTION=(ENABLE=BROKEN)", 1)
        return url

    m = re.search(r'@//([^:/]+):(\d+)/(.+)', url)
    if m:
        host, port, db, db_type = m.group(1), m.group(2), m.group(3), "SERVICE_NAME"
    else:
        m = re.search(r'@([^:/]+):(\d+)/(.+)', url)
        if m:
            host, port, db, db_type = m.group(1), m.group(2), m.group(3), "SERVICE_NAME"
        else:
            m = re.search(r'@([^:/]+):(\d+):(.+)', url)
            if m:
                host, port, db, db_type = m.group(1), m.group(2), m.group(3), "SID"
            else:
                raise ValueError(f"Formato de JDBC URL não reconhecido: {url}")

    return (
        f"jdbc:oracle:thin:@(DESCRIPTION="
        f"(ENABLE=BROKEN)"
        f"(ADDRESS=(PROTOCOL=TCP)(HOST={host})(PORT={port}))"
        f"(CONNECT_DATA=({db_type}={db}))"
        f")"
    )

t0 = time.time()
print("🔄 Iniciando ingestão GP - Oracle SDWEB (push-down)...")

empresas_str = ", ".join([f"'{e}'" for e in EMPRESAS_PERMITIDAS])

# ─────────────────────────────────────────────────────────────────
# Query INTERNA (sem ROWNUM, sem alias Q externo)
# Será usada tanto para COUNT quanto para leitura particionada
# ─────────────────────────────────────────────────────────────────
inner_query = f"""
    SELECT
        empresa.cl05e8106265e7433f96022477ab3a                                                          AS CD_EMPRESA,
        empresa.cl10914d4f3685436282fbbc16f662                                                          AS DS_EMPRESA,
        unidade.clc388c0ffc35b4680aa4ff9da4f39                                                          AS CD_UNIDADE,
        unidade.cl10914d4f3685436282fbbc16f662                                                          AS DS_UNIDADE,
        (SELECT cl000000000000abcd000200000000 FROM TBFF2D8A76B59546C89939908C7239
            WHERE CL000000000000ABCD000000000000 = vinculo.CL833FA07877624A8EAA02C4046FBC)             AS CD_LOCAL_FISICO,
        (SELECT cla95d0dd6fefb4a63a7cc460cf494 FROM TBFB7C40BCD3E2487FBFFD7BC6F98F
            WHERE cl000000000000abcd000000000000 = vinculo.CL611908A8F21A4C47A08645A30F58)             AS CD_ESTABELECIMENTO,
        To_char(vinculo.CL000000000000ABCD004200000000, 'ddmmyyyy')                                     AS DT_ADMISSAO,
        To_char(vinculo.CL000000000000ABCD004000000000, 'ddmmyyyy')                                     AS DT_DEMISSAO,
        FC_VALOR_TAB_TR('TB09656E53FD7F4D478E7D31C25_TR', 'CL000000000000ABCD000200000000',
            vinculo.CL09656E53FD7F4D478E7D31C25AD7)                                                    AS DS_SITUACAO,
        cadastro.CL58284C47272B4729ABF5215F368D                                                         AS NM_NOME,
        FC_VALOR_TAB_TR('TB8CEDAE3175944EFF9E1A05F04_TR', 'CL000000000000ABCD000200000000',
            licenca.CL8CEDAE3175944EFF9E1A05F047F8)                                                    AS CLASSIFICACAO_TIPO_DE_AFAST,
        FC_VALOR_TAB_TR('TB8CEDAE3175944EFF9E1A05F04_TR', 'CL000000000000ABCD000300000000',
            licenca.CL8CEDAE3175944EFF9E1A05F047F8)                                                    AS D_CLASSIFICACAO_TIPO_DE_AFAST,
        FC_VALOR_TAB_TR('TB52FDF856B2BE4015B7C7FBB9B_TR', 'CL000000000000ABCD000200000000',
            licenca.CL52FDF856B2BE4015B7C7FBB9B7D5)                                                    AS CLASSIFICACAO_REAF,
        FC_VALOR_TAB_TR('TB52FDF856B2BE4015B7C7FBB9B_TR', 'CL000000000000ABCD000300000000',
            licenca.CL52FDF856B2BE4015B7C7FBB9B7D5)                                                    AS D_CLASSIFICACAO_REAF,
        CASE WHEN (licenca.CLCEDFFDAFA7664C9DBCD4D426BD70 <= 15
                   AND licenca.CL3E7F9FDEEF2F4786BB419338B82C <= Trunc(SYSDATE))
                OR (pericia.CL027C3F0EB731492EAE1A1EB609DD IS NOT NULL
                   AND licenca.CLCEDFFDAFA7664C9DBCD4D426BD70 > 15)
             THEN 'FECHADO' ELSE 'ABERTO' END                                                           AS STATUS,
        vinculo.cla95d0dd6fefb4a63a7cc460cf494                                                          AS PERNR,
        Row_Number() OVER(
            PARTITION BY unidade.clc388c0ffc35b4680aa4ff9da4f39,
                         vinculo.cla95d0dd6fefb4a63a7cc460cf494
            ORDER BY licenca.CL000000000000ABCD001100000000)                                            AS ID_ATEST,
        To_char(licenca.CL000000000000ABCD001100000000, 'ddmmyyyy')                                     AS BEGDA_ATEST,
        To_char(licenca.CL3E7F9FDEEF2F4786BB419338B82C, 'ddmmyyyy')                                    AS ENDDA_ATEST,
        licenca.CLCEDFFDAFA7664C9DBCD4D426BD70                                                          AS NDIAS_AFAST,
        To_char(licenca.CL000000000000ABCD000400000000, 'ddmmyyyy')                                     AS D_SEXTO_DIA,
        licenca.CLCEDFFDAFA7664C9DBCD4D426BD70                                                          AS DUR_AUSEN,
        'M'                                                                                             AS STATUS_ESOC,
        ''                                                                                              AS ENTREG_REG,
        ''                                                                                              AS ENTREG_ATEST,
        ''                                                                                              AS DUPLIC_ATEST,
        FC_VALOR_TAB_TR('TBFC8AFFE5C76143F0A23F0B8A1_TR', 'CL000000000000ABCD000200000000',
            licenca.CLD36EFA2101504DA7BF954D7C89DB)                                                    AS CID1,
        regexp_replace(Trim(REPLACE(FC_ROWS_TO_LINE_MV('TB48BDBF9662BC496B878F6AFF8_MV',
            'CLFC8AFFE5C76143F0A23F0B8A1EB1', 'TBFC8AFFE5C76143F0A23F0B8A1_TR',
            'CL000000000000ABCD000200000000', licenca.CL000000000000ABCD000000000000,
            NULL), ';', '|')), '.$', '')                                                                AS CID2,
        Nvl(Trim(emitente.CL58284C47272B4729ABF5215F368D), 'M')                                         AS NOME_EMIT,
        emitente.CL000000000000ABCD000200000000                                                         AS NUM_OC,
        Nvl(FC_VALOR_TAB_TR('TB64389BB5F14640AE9DCB5031A_TR', 'CL000000000000ABCD000200000000',
            emitente.CL2A00C8A10E2747A99DE33CC33EB8), 'M')                                             AS CRM,
        FC_VALOR_TAB_TR('TBB432B979EEBE4ECA8A629623E_TR', 'CL000000000000ABCD000200000000',
            emitente.CL8F7A4680DE224C43A948896FD6F1)                                                   AS UF_OC,
        CASE
            WHEN FC_VALOR_TAB_TR('TB8CEDAE3175944EFF9E1A05F04_TR', 'CL000000000000ABCD000200000000',
                licenca.CL8CEDAE3175944EFF9E1A05F047F8) = '1101' THEN '1'
            WHEN FC_VALOR_TAB_TR('TB8CEDAE3175944EFF9E1A05F04_TR', 'CL000000000000ABCD000200000000',
                licenca.CL8CEDAE3175944EFF9E1A05F047F8) = '1201' THEN '2'
            WHEN FC_VALOR_TAB_TR('TB8CEDAE3175944EFF9E1A05F04_TR', 'CL000000000000ABCD000200000000',
                licenca.CL8CEDAE3175944EFF9E1A05F047F8) = '1301' THEN '3'
            WHEN FC_VALOR_TAB_TR('TB8CEDAE3175944EFF9E1A05F04_TR', 'CL000000000000ABCD000200000000',
                licenca.CL8CEDAE3175944EFF9E1A05F047F8) = '1401' THEN '4'
            ELSE ''
        END                                                                                             AS COD_ESOC,
        CASE
            WHEN FC_VALOR_TAB_TR('TB7312B0BC6B984749AA423AFF6_TR', 'CL000000000000ABCD000200000000',
                licenca.CLFA9A1A1C6364432FACF76FA6A016) = '1' THEN '1'
            WHEN FC_VALOR_TAB_TR('TB7312B0BC6B984749AA423AFF6_TR', 'CL000000000000ABCD000200000000',
                licenca.CLFA9A1A1C6364432FACF76FA6A016) = '2' THEN '2'
            WHEN FC_VALOR_TAB_TR('TB7312B0BC6B984749AA423AFF6_TR', 'CL000000000000ABCD000200000000',
                licenca.CLFA9A1A1C6364432FACF76FA6A016) = '3' THEN '3'
            ELSE ''
        END                                                                                             AS TP_ACID,
        'M'                                                                                             AS HV_CONV,
        CASE
            WHEN licenca.CL2CF52E87B6F043FC86F9FA5F2679 IS NOT NULL
                 AND licenca.CL46856CF777194B6588A75C22CCD0 IS NOT NULL
                 AND licenca.CL1F665DA1E9F44BEC814A825DEE1A IS NOT NULL
                 AND FC_VALOR_TAB_TR('TB8CEDAE3175944EFF9E1A05F04_TR', 'CL000000000000ABCD000200000000',
                     licenca.CL8CEDAE3175944EFF9E1A05F047F8) = '1101' THEN 'B31'
            WHEN licenca.CL2CF52E87B6F043FC86F9FA5F2679 IS NOT NULL
                 AND licenca.CL46856CF777194B6588A75C22CCD0 IS NOT NULL
                 AND licenca.CL1F665DA1E9F44BEC814A825DEE1A IS NOT NULL
                 AND FC_VALOR_TAB_TR('TB8CEDAE3175944EFF9E1A05F04_TR', 'CL000000000000ABCD000200000000',
                     licenca.CL8CEDAE3175944EFF9E1A05F047F8) IN ('1201','1301','1401') THEN 'B91'
            ELSE ''
        END                                                                                             AS CONV_BEN,
        ''                                                                                              AS DT_CONV,
        FC_VALOR_TAB_TR('TB90695B75F5E74D78843C6C9C7_TR', 'CL000000000000ABCD000300000000',
            Decode(licenca.CL2CF52E87B6F043FC86F9FA5F2679,
                'a0169bb8-1704-4c94-a379-a4b787e770d8','6591e3ad-1625-4919-afc9-89a37a13fe02',
                licenca.CL2CF52E87B6F043FC86F9FA5F2679))                                               AS ORIG_RETIF,
        FC_VALOR_TAB_TR('TB7CBE5B8481FD4B28AB98D8B8A_TR', 'CL000000000000ABCD000200000000',
            licenca.CL46856CF777194B6588A75C22CCD0)                                                    AS TP_PROCE,
        licenca.CL1F665DA1E9F44BEC814A825DEE1A                                                          AS NUM_PROC_PREV,
        'M'                                                                                             AS ATEST_ANTE,
        ''                                                                                              AS DIAS_ANTE,
        ''                                                                                              AS MOT_ANTE,
        ''                                                                                              AS RESP_ANTE,
        CASE
            WHEN FC_VALOR_TAB_TR('TB52FDF856B2BE4015B7C7FBB9B_TR', 'CL000000000000ABCD000200000000',
                licenca.CL52FDF856B2BE4015B7C7FBB9B7D5) = '4102' THEN 'S'
            WHEN FC_VALOR_TAB_TR('TB52FDF856B2BE4015B7C7FBB9B_TR', 'CL000000000000ABCD000200000000',
                licenca.CL52FDF856B2BE4015B7C7FBB9B7D5) = '4402' THEN 'S'
            ELSE 'N'
        END                                                                                             AS REAFAST_MESMO_MOT,
        ''                                                                                              AS ATEST_RELA,
        ''                                                                                              AS RESP_ANTE_TEXT,
        REPLACE(licenca.CLE7BB6FE2AB6949D899DB2201CE6A, '/', '')                                        AS INFO_ADD1,
        ''                                                                                              AS REC_ESOC,
        ''                                                                                              AS REC_ESOC_2,
        ''                                                                                              AS OBS_ATEST,
        (SELECT CL58284C47272B4729ABF5215F368D FROM TBE63597B2CC4F45AFA0EB8871ABA6
            WHERE cl000000000000abcd000000000000 = licenca.CLE71A57D3889D4C778D70781BAF07)             AS MODIF_USER,
        To_char(licenca.CLF9FC1F2187A4454BAE4D890A52D8, 'ddmmyyyy')                                    AS MODIF_DATE,
        Nvl((SELECT cl000000000000abcd000300000000 FROM TB04F93D9DF5E84B698F581894CA81
            WHERE cl000000000000abcd000000000000 = licenca.CL947A1CAFDE944580817ADE447C02), 'SH')      AS REG_LOCL,
        (SELECT CL58284C47272B4729ABF5215F368D FROM TBE63597B2CC4F45AFA0EB8871ABA6
            WHERE cl000000000000abcd000000000000 = licenca.CLE71A57D3889D4C778D70781BAF07)             AS MODIF_USER_2,
        To_char(licenca.CLF9FC1F2187A4454BAE4D890A52D8, 'ddmmyyyy')                                    AS MODIF_DATE_2,
        ''                                                                                              AS MODIF_LOCL_2,
        CASE WHEN licenca.CLCEDFFDAFA7664C9DBCD4D426BD70 > 15
             THEN vinculo.cla95d0dd6fefb4a63a7cc460cf494 ELSE '' END                                   AS PERNR_PERI,
        ''                                                                                              AS ID,
        ''                                                                                              AS SEQ_GESTAO,
        ''                                                                                              AS STATUS_GESTAO,
        ''                                                                                              AS ID_ATEST_REL,
        To_char(pericia.CL000000000000ABCD000400000000, 'ddmmyyyy')                                     AS BEGDA_PREV,
        To_char(pericia.CLF9FC1F2187A4454BAE4D890A52D8, 'ddmmyyyy')                                    AS ENDDA_PREV,
        ''                                                                                              AS DUPLIC_GEST,
        CASE
            WHEN FC_VALOR_TAB_TR('TB8CEDAE3175944EFF9E1A05F04_TR', 'CL000000000000ABCD000200000000',
                licenca.CL8CEDAE3175944EFF9E1A05F047F8) = '1101' THEN '1'
            WHEN FC_VALOR_TAB_TR('TB8CEDAE3175944EFF9E1A05F04_TR', 'CL000000000000ABCD000200000000',
                licenca.CL8CEDAE3175944EFF9E1A05F047F8) = '1201' THEN '2'
            WHEN FC_VALOR_TAB_TR('TB8CEDAE3175944EFF9E1A05F04_TR', 'CL000000000000ABCD000200000000',
                licenca.CL8CEDAE3175944EFF9E1A05F047F8) = '1301' THEN '3'
            WHEN FC_VALOR_TAB_TR('TB8CEDAE3175944EFF9E1A05F04_TR', 'CL000000000000ABCD000200000000',
                licenca.CL8CEDAE3175944EFF9E1A05F047F8) = '1401' THEN '4'
            ELSE 'M'
        END                                                                                             AS MOT_AFAST,
        CASE WHEN pericia.CL000000000000ABCD000400000000 IS NULL
             THEN To_char(licenca.CL000000000000ABCD001100000000, 'ddmmyyyy')
             ELSE To_char(pericia.CLF28B482EE8944661A18023AA3F74, 'ddmmyyyy')
        END                                                                                             AS DATE_INICAFAST,
        To_char(pericia.CL000000000000ABCD001100000000, 'ddmmyyyy')                                     AS DT_PERI,
        CASE
            WHEN FC_VALOR_TAB_TR('TB24A4F8C763B041459E7C798A6_TR', 'CL000000000000ABCD000200000000',
                pericia.CL24A4F8C763B041459E7C798A622E) = '6' THEN '02'
            WHEN FC_VALOR_TAB_TR('TB24A4F8C763B041459E7C798A6_TR', 'CL000000000000ABCD000200000000',
                pericia.CL24A4F8C763B041459E7C798A622E) = '5' THEN '01'
            WHEN FC_VALOR_TAB_TR('TB24A4F8C763B041459E7C798A6_TR', 'CL000000000000ABCD000200000000',
                pericia.CL24A4F8C763B041459E7C798A622E) = '4' THEN '04'
            WHEN FC_VALOR_TAB_TR('TB24A4F8C763B041459E7C798A6_TR', 'CL000000000000ABCD000200000000',
                pericia.CL24A4F8C763B041459E7C798A622E) = '3' THEN '06'
            WHEN FC_VALOR_TAB_TR('TB24A4F8C763B041459E7C798A6_TR', 'CL000000000000ABCD000200000000',
                pericia.CL24A4F8C763B041459E7C798A622E) = '1' THEN '03'
            ELSE 'M'
        END                                                                                             AS RESULTADO,
        TO_CLOB('JUSTIFICATIVA RESULTADO DA PERICIA:' || pericia.CL68CD3068F95A48F19D699A0FA219) ||
        TO_CLOB(' JUSTIFICATIVA DO INDEFERIMENTO:' || pericia.CLB45B56B532EC412FB8F82015FBFD) ||
        TO_CLOB(' ALTA ANTECIPADA:' || pericia.CLCD1390287A464DBB8EF36BF7F59F) ||
        TO_CLOB(' PARECER MEDICO PERICIA:' || pericia.CL1BD675449F0F41769597DF1D7847) ||
        TO_CLOB(' OBSERVACAO ALTA INSS:' || pericia.CLE7BB6FE2AB6949D899DB2201CE6A) ||
        TO_CLOB(' INFORMACOES PROCESSO JUDICIAL:' || peri_comp.CL1BA3CCE96716406A8CC8F5D5C4A8) ||
        TO_CLOB(' NTEP (SIM OU NAO):' || FC_VALOR_TAB_TR('TB1F8DD1AB8654454F81D9709B4_TR',
            'CL000000000000ABCD000200000000', licenca.CLB5D6D902593C4F50B26E76530BBD)) ||
        TO_CLOB(' ENCAMINHADO RELATORIO DE DESCARACTERIZACAO DE NTEP AO INSS?: ' ||
            licenca.CL628EB1D6788B4B7C8E480F7210C7) ||
        TO_CLOB(' DATA DE ENCAMINHAMENTO DO RELATORIO JUSTIFICATIVA DO INDEFERIMENTO: ' ||
            To_Char(pericia.CL027C3F0EB731492EAE1A1EB609DD, 'dd/mm/yyyy')) ||
        TO_CLOB(' RESULTADO DA PERICIA MEDICA (INSS) RECONHECIDO NTEP? :' ||
            licenca.CLCF4E7C94AC2F42278AB8A96A872B) ||
        TO_CLOB(' ENCAMINHADO RELATORIO DE IMPUGNACAO TECNICA AO INSS? :' ||
            licenca.CLB6966C30E07D4DE58552E5CC4351) ||
        TO_CLOB(' DATA DO RELATORIO DE IMPUGNACAO: ' ||
            to_char(licenca.CLF28B482EE8944661A18023AA3F74, 'dd/mm/yyyy')) ||
        TO_CLOB(' CONTESTACAO ACATADA PELO INSS?: ' ||
            licenca.CLFFB12EA794AC49BD81120C2DDCC7) ||
        TO_CLOB(' DATA DO ACEITE: ' ||
            to_char(licenca.CL87D7774B59354F85B46E9E7B1CB8, 'dd/mm/yyyy')) ||
        TO_CLOB(' ENCAMINHADO RECURSO DE IMPUGNACAO?: ' ||
            licenca.CL67AC7170211B48A4840791037367) ||
        TO_CLOB(' DATA DE ENCAMINHAMENTO DO RECURSO: ' ||
            to_char(licenca.CL8D6995B1AF7F45D8B59ABFF456CE, 'dd/mm/yyyy')) ||
        TO_CLOB(' PERICIA REGISTRADA: DATA - ' ||
            to_char(pericia.CLA44C2E7CE352439FAC15C3142899, 'dd/mm/yyyy') ||
        TO_CLOB(' REGISTRO PROFISSIONAL :' || (SELECT cld71e82da3fe94e6993408f732a72 || ' ' ||
            cl58284c47272b4729abf5215f368d FROM TBE63597B2CC4F45AFA0EB8871ABA6
            WHERE cl000000000000abcd000000000000 = licenca.CLFFB12EA794AC49BD81120C2DDCC7)))
                                                                                                        AS OBS_PER1,
        ''                                                                                              AS ENC_INSS,
        ''                                                                                              AS SIT_INSS,
        To_Char(pericia.CL2BA464BCA2A845C2981E9742150F, 'ddmmyyyy')                                     AS DT_REQ,
        ''                                                                                              AS NUM_REQ,
        pericia.CL62AABAA7E68F49DEBE737DDDB97E                                                          AS NUM_BEN,
        FC_VALOR_TAB_TR('TB1E021F2F8EDC4B52BD1673EEE_TR', 'CL000000000000ABCD000200000000',
            pericia.CL8F7A4680DE224C43A948896FD6F1)                                                    AS TPBEN,
        To_Char(pericia.CL000000000000ABCD000400000000, 'ddmmyyyy')                                     AS DT_INI_BENE,
        TO_CHAR((pericia.CL0058362ACFBC45C281EE4B129E77
            - licenca.CL000000000000ABCD000400000000) + 1)                                             AS DIAS_BENE,
        FC_VALOR_TAB_TR('TB1F8DD1AB8654454F81D9709B4_TR', 'CL000000000000ABCD000200000000',
            pericia.CL34FF18F0597E4842AA5AD6FCE93F)                                                    AS BEN_CESS,
        CASE
            WHEN peri_comp.CLED5F06A024B34A6C8565889926DB = '0' THEN 'N'
            WHEN peri_comp.CLED5F06A024B34A6C8565889926DB = '1' THEN 'S'
            ELSE 'N'
        END                                                                                             AS INAPTO,
        To_Char(pericia.CL0058362ACFBC45C281EE4B129E77, 'ddmmyyyy')                                     AS DT_CESS_BEN,
        To_Char(pericia.CL027C3F0EB731492EAE1A1EB609DD, 'ddmmyyyy')                                     AS DT_ALTA,
        'M'                                                                                             AS CONC_API,
        '01010001'                                                                                      AS DT_IN_API,
        '01010001'                                                                                      AS DT_FIM_API,
        '01010001'                                                                                      AS DT_REC,
        ''                                                                                              AS NUM_REQREC,
        '01010001'                                                                                      AS DT_LIM,
        '01010001'                                                                                      AS DT_FIM_LIMBO,
        'N'                                                                                             AS REAB_CERT,
        '01010001'                                                                                      AS DT_REAB,
        ''                                                                                              AS CAN_BEN,
        '01010001'                                                                                      AS DT_CAN_BEN,
        '01010001'                                                                                      AS DT_TRANS_NEXO,
        '01010001'                                                                                      AS DT_CONV_BEN,
        ''                                                                                              AS TP_NEXO,
        ''                                                                                              AS HV_CONT,
        '01010001'                                                                                      AS DT_CONTEST_NEXO,
        '0'                                                                                             AS NUM_OF_CONTEST,
        ''                                                                                              AS CONT_PRAZO,
        ''                                                                                              AS STATUS_CONT,
        ''                                                                                              AS NEC_CONTEST,
        '01010001'                                                                                      AS DT_NOT_JUR,
        ''                                                                                              AS OBS,
        (SELECT CL58284C47272B4729ABF5215F368D FROM TBE63597B2CC4F45AFA0EB8871ABA6
            WHERE cl000000000000abcd000000000000 = pericia.CL43B29DF5E0F14F2E82884564F85A)             AS MODIF_USER_GEST88,
        To_Char(pericia.CL017FABD96263414D8A6EEFBBD034, 'ddmmyyyy')                                     AS MODIF_DATE_GEST,
        (SELECT cl000000000000abcd000300000000 FROM TB04F93D9DF5E84B698F581894CA81
            WHERE cl000000000000abcd000000000000 = pericia.CL947A1CAFDE944580817ADE447C02)             AS REG_LOCL_GEST,
        ''                                                                                              AS MODIF_USER_GEST91,
        '01010001'                                                                                      AS MODIF_DATE_GEST_1,
        ''                                                                                              AS MODIF_LOCL_GEST
    FROM {ORACLE_SCHEMA}.TB48BDBF9662BC496B878F6AFF86C5 licenca
        INNER JOIN {ORACLE_SCHEMA}.TB831F15D403654FCE84691FE856D2  vinculo   ON licenca.CL7563C61EA9BB4ABD8E9FA60A4559   = vinculo.CL000000000000ABCD000000000000
        INNER JOIN {ORACLE_SCHEMA}.TB81F753A75F3B415CAB2037E094BA  cadastro  ON vinculo.CL81F753A75F3B415CAB2037E094BA  = cadastro.CL000000000000ABCD000000000000
        INNER JOIN {ORACLE_SCHEMA}.TB000000000000ABCD003400000000  empresa   ON vinculo.CL000000000000ABCD003400000000  = empresa.CL000000000000ABCD000000000000
        INNER JOIN {ORACLE_SCHEMA}.TB000000000000ABCD003500000000  unidade   ON vinculo.CL000000000000ABCD003500000000  = unidade.CL000000000000ABCD000000000000
        LEFT JOIN  {ORACLE_SCHEMA}.TB713BFCED083A4135AC22A9EA21E9  pericia   ON pericia.CL000000000000ABCD001000000000  = licenca.CL000000000000ABCD000000000000
        LEFT JOIN  {ORACLE_SCHEMA}.TB54366031C63C49BBBA7D03F9D7C9  peri_comp ON peri_comp.CL000000000000ABCD001700000000 = pericia.CL000000000000ABCD000000000000
        LEFT JOIN  {ORACLE_SCHEMA}.TBE63597B2CC4F45AFA0EB8871ABA6  ass       ON licenca.CLE71A57D3889D4C778D70781BAF07  = ass.cl000000000000abcd000000000000
        LEFT JOIN  {ORACLE_SCHEMA}.TB084C21CAB94849CC9C1FE9C16C9F  emitente  ON licenca.CL084C21CAB94849CC9C1FE9C16C9F = emitente.cl000000000000abcd000000000000
    WHERE
        FC_VALOR_TAB_TR('TB8CEDAE3175944EFF9E1A05F04_TR', 'CL000000000000ABCD000200000000',
            licenca.CL8CEDAE3175944EFF9E1A05F047F8) NOT IN ('2800', '2801', '2810', '2830')
        AND SubStr(vinculo.CLA95D0DD6FEFB4A63A7CC460CF494, 1, 1) NOT IN ('.','A','C','H','J','M',']')
        AND length(vinculo.CLA95D0DD6FEFB4A63A7CC460CF494) <= 9
        AND NOT REGEXP_LIKE(vinculo.CLA95D0DD6FEFB4A63A7CC460CF494, '-')
        AND empresa.cl05e8106265e7433f96022477ab3a IN ({empresas_str})
        AND VINCULO.CLA95D0DD6FEFB4A63A7CC460CF494 NOT LIKE '%APAGAR%'
        AND VINCULO.CLA95D0DD6FEFB4A63A7CC460CF494 NOT LIKE '%-%'
        AND VINCULO.CLA95D0DD6FEFB4A63A7CC460CF494 NOT LIKE '%CONV%'
        AND Length(VINCULO.CLA95D0DD6FEFB4A63A7CC460CF494) < 11
        -- Filtro de vínculo removido conforme Query_Gest_Prev_v4.sql
        AND licenca.CL000000000000ABCD001100000000 >= To_Date('{DT_LICENCA_INICIO}','dd/mm/yyyy')
        AND licenca.CL000000000000ABCD001100000000 < To_Date('{DT_LICENCA_FIM}','dd/mm/yyyy')
"""

# ─────────────────────────────────────────────────────────────────
# Aplica os replaces de schema (mesma lógica do original)
# ─────────────────────────────────────────────────────────────────
inner_query = inner_query.replace("FC_VALOR_TAB_TR(", "SDWEB.FC_VALOR_TAB_TR(")
inner_query = inner_query.replace("FC_ROWS_TO_LINE_MV(", "SDWEB.FC_ROWS_TO_LINE_MV(")

tabelas_sem_schema = [
    "TBFF2D8A76B59546C89939908C7239",
    "TBFB7C40BCD3E2487FBFFD7BC6F98F",
    "TBE63597B2CC4F45AFA0EB8871ABA6",
    "TB04F93D9DF5E84B698F581894CA81",
]
for tb in tabelas_sem_schema:
    inner_query = inner_query.replace(f"FROM {tb}", f"FROM SDWEB.{tb}")

# ─────────────────────────────────────────────────────────────────
# JDBC URL com ENABLE=BROKEN
# ─────────────────────────────────────────────────────────────────
ORACLE_JDBC_URL_SAFE = oracle_url_with_broken(ORACLE_JDBC_URL)
print(f"📡 JDBC URL: {ORACLE_JDBC_URL_SAFE[:80]}...")

# ─────────────────────────────────────────────────────────────────
# Opções JDBC comuns (reutilizadas em count e leitura)
# ─────────────────────────────────────────────────────────────────
jdbc_opts = {
    "url":                          ORACLE_JDBC_URL_SAFE,
    "user":                         ORACLE_USER,
    "password":                     ORACLE_PASSWORD,
    "driver":                       ORACLE_DRIVER,
    "oracle.net.CONNECT_TIMEOUT":   "10000",
    "oracle.jdbc.ReadTimeout":      "3600000",
    "oracle.net.READ_TIMEOUT":      "3600000",
    "oracle.net.keepAlive":         "true",
    "fetchsize":                    "10000",
}

# ─────────────────────────────────────────────────────────────────
# PASSO 1: Conta o total de linhas (query leve no Oracle)
# ─────────────────────────────────────────────────────────────────
count_query = f"(SELECT COUNT(*) AS CNT FROM ({inner_query})) Q"

t_count = time.time()
total = int(
    spark.read.format("jdbc")
    .options(**jdbc_opts)
    .option("dbtable", count_query)
    .load()
    .collect()[0]["CNT"]
)
print(f"📊 Total de registros no Oracle: {total:,} | {_fmt(time.time()-t_count)}")

if total == 0:
    print("⏭ Nenhum registro encontrado. Encerrando.")
    df_jdbc = spark.createDataFrame([], spark.table(BRONZE_GP).schema)
else:
    # ─────────────────────────────────────────────────────────────
    # PASSO 2: Lê com paralelismo via ROWNUM
    #   - Injeta ROWNUM como coluna particionável
    #   - Spark abre N conexões JDBC em paralelo, cada uma lendo
    #     uma faixa de ROWNUM (ex: 1-2500, 2501-5000, ...)
    # ─────────────────────────────────────────────────────────────
    NUM_PARTITIONS = 4   # ajuste conforme capacidade do Oracle/cluster

    query_rn = f"""
    (SELECT CAST(ROWNUM AS INTEGER) AS RN, T.*
     FROM ({inner_query}) T) Q
    """

    t_read = time.time()
    df_jdbc = (
        spark.read.format("jdbc")
        .options(**jdbc_opts)
        .option("dbtable",         query_rn)
        .option("partitionColumn", "RN")
        .option("lowerBound",      "1")
        .option("upperBound",      str(total))
        .option("numPartitions",   str(NUM_PARTITIONS))
        .load()
        .drop("RN")
    )

    # Cast para string e reordena colunas (lazy — não toca Oracle)
    df_jdbc = df_jdbc.select([col(c).cast(StringType()).alias(c) for c in df_jdbc.columns])
    
    # ─────────────────────────────────────────────────────────────
    # PASSO 3: Materializa em disco/memória do Spark ANTES de
    # escrever no Delta. Encerra conexões JDBC.
    # ─────────────────────────────────────────────────────────────
    df_jdbc.persist(StorageLevel.MEMORY_AND_DISK)
    row_count = df_jdbc.count()   # força leitura completa
    print(f"✅ Leitura Oracle concluída: {row_count:,} linhas | {_fmt(time.time()-t0)}")

# COMMAND ----------

BRONZE_STAGING = f"{BRONZE_GP}_staging"

# Escreve a partir do cache — zero dependência de Oracle
df_jdbc.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .saveAsTable(BRONZE_STAGING)

# Libera o cache (dados já estão no Delta)
df_jdbc.unpersist()

# Daqui pra baixo: zero Oracle, só Delta
df_staged = spark.table(BRONZE_STAGING)
print(f"Staging gravado: {df_staged.count():,} linhas | {_fmt(time.time()-t0)}")

save_table(df_staged, BRONZE_GP)

spark.sql(f"TRUNCATE TABLE {BRONZE_STAGING}")
print(f"✅ Bronze GP gravada | total: {_fmt(time.time()-t0)}")

# COMMAND ----------

import re
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType

df_export = spark.table(BRONZE_GP)

# Regex: remove caracteres de controle exceto \t, \n, \r
_CTRL_CHARS = re.compile(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]')

@udf(StringType())
def clean_ctrl_chars(val):
    if val is None:
        return ""
    return _CTRL_CHARS.sub("", val)

# Colunas de texto livre que podem conter caracteres ilegais
TEXT_COLS = ["OBS", "OBS_PER1", "OBS_ATEST", "INFO_ADD1", "RESP_ANTE_TEXT"]

for col_name in TEXT_COLS:
    if col_name in df_export.columns:
        df_export = df_export.withColumn(col_name, clean_ctrl_chars(F.col(col_name)))

export_df_to_excel(df_export, OUTPUT_BASE, "Export_Gestao_Previdenciaria")