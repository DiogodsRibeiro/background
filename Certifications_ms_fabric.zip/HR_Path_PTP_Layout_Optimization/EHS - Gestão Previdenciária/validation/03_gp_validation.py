# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Gestão Previdenciária/utils/utils"

# COMMAND ----------

# ─────────────────────────────────────────────────────────────────────────────
# 03_gp_validation.py — Validação de Qualidade: Gestão Previdenciária
# ─────────────────────────────────────────────────────────────────────────────
# Depende de: 02_gp_silver (SILVER_GP deve estar gravada antes)
#
# Lê da tabela Silver (Delta) em vez de CSV direto.
# Funções genéricas ficam em utils.py; regras específicas ficam aqui.
# O motor executar_validacoes() orquestra tudo com cache e log.
# ─────────────────────────────────────────────────────────────────────────────

import time
t0 = time.time()

# COMMAND ----------

# ── 1. Leitura da Silver (Delta) + Cache ──────────────────────────────────────

GP = spark.table(SILVER_GP)
GP.cache()
total = GP.count()
print(f"Silver GP lida: {total:,} registros")

# EC_29_00 para comparação de PERNR (regra 1.4)
EC_29_00_1 = ler_arquivo_csv(f"{EC_29_00_BASE_PATH}EC_29_00_1.csv", sep=",")
EC_29_00_2 = ler_arquivo_csv(f"{EC_29_00_BASE_PATH}EC_29_00_2.csv", sep=",")
EC_29_00_3 = ler_arquivo_csv(f"{EC_29_00_BASE_PATH}EC_29_00_3.csv", sep=",")
EC_29_00_4 = ler_arquivo_csv(f"{EC_29_00_BASE_PATH}EC_29_00_4.csv", sep=",")

# COMMAND ----------

# ── 2. Regras 1.0, 1.1, 1.2 (executadas separadamente — lógica própria) ──────

execucao = datetime.now().strftime("%Y%m%d%H%M")
print(f"GP_01.00 — {total:,} registros — execução {execucao}")
print("=" * 60)

# Regra 1.0 — Campos obrigatórios
print("🔗 Regra 1.0 — Campos obrigatórios NOT NULL")
validar_arquivo_csv(GP, execucao, CAMPOS_OBRIGATORIOS)
print("-" * 60)

# Regra 1.1 — Tamanho e formato
print("🔗 Regra 1.1 — Tamanho e formato de campos")
validar_tamanho_formato(GP, CAMPOS_TAMANHOS, TEMPLATE_NAME)
print("-" * 60)

# Regra 1.2 — Picklists
print("🔗 Regra 1.2 — Validação contra picklists")
validar_picklists(GP, VALIDAR_PICKLIST, PICKLIST_BASE_PATH, TEMPLATE_NAME)
print("-" * 60)

# COMMAND ----------

# ═══════════════════════════════════════════════════════════════════════════════
# 3. REGRAS ESPECÍFICAS DE NEGÓCIO (funções locais ao notebook)
# ═══════════════════════════════════════════════════════════════════════════════

# Regra 2 — ID_ATEST: sequência contínua, repetição apenas quando PERNR+BEGDA iguais
def validar_ID_ATEST(df):
    df_group = df.groupBy("ID_ATEST").agg(
        F.collect_set("BEGDA_ATEST").alias("_begdas"),
        F.collect_set("PERNR").alias("_pernrs")
    )
    df_erro_dup = df_group.filter((F.size("_begdas") > 1) | (F.size("_pernrs") > 1))
    df_erro_dup = df.join(df_erro_dup.select("ID_ATEST"), "ID_ATEST", "inner")

    w = Window.partitionBy("PERNR","BEGDA_ATEST").orderBy(col("ID_ATEST").cast(IntegerType()))
    df_seq = df.withColumn("_prev", lag(col("ID_ATEST").cast(IntegerType())).over(w))
    df_erro_seq = df_seq.filter(col("_prev").isNotNull() & ((col("ID_ATEST").cast(IntegerType()) - col("_prev")) > 1)).drop("_prev")
    return df_erro_dup.unionByName(df_erro_seq, allowMissingColumns=True)

# COMMAND ----------

# Regra 3 — BEGDA_ATEST: não pode ser futura nem fora do intervalo
def validar_BEGDA_ATEST(df):
    dt = to_date_ddmmyyyy("BEGDA_ATEST")
    return df.filter(
        (dt > current_date()) |
        (dt < F.to_date(lit("2021-10-13"))) |
        (dt > F.to_date(lit("2025-05-31")))
    )

# Regra 3.1 — Não permitir 2+ atestados diferentes com mesma data para mesma matrícula
def valida_BEGDA_ATEST_dist(df):
    w = Window.partitionBy("PERNR","ID_ATEST","BEGDA_ATEST").orderBy("ENDDA_ATEST")
    return df.withColumn("_rn", row_number().over(w)).filter(col("_rn") >= 2).drop("_rn")

# COMMAND ----------

# Regra 5 — NDIAS_AFAST = ENDDA - BEGDA + 1
def valida_NDIAS_AFAST(df):
    return df.filter(
        _is_filled("ENDDA_ATEST") & _is_filled("BEGDA_ATEST") &
        (datediff(to_date_ddmmyyyy("ENDDA_ATEST"), to_date_ddmmyyyy("BEGDA_ATEST")) + 1 != col("NDIAS_AFAST").cast(IntegerType()))
    )

# COMMAND ----------

# Regra 6 — D_SEXTO_DIA
def validar_D_sexto_dia(df):
    cond_a = (col("NDIAS_AFAST").cast(IntegerType()) > 15) & _is_empty("D_SEXTO_DIA")
    cond_b = (col("NDIAS_AFAST").cast(IntegerType()) <= 15) & (col("REAFAST_MESMO_MOT") == "N") & _is_filled("D_SEXTO_DIA")
    cond_c = _is_filled("BEGDA_PREV") & ~((col("D_SEXTO_DIA") == col("BEGDA_PREV")) & (col("DT_INI_BENE") == col("BEGDA_PREV")))
    return df.filter(cond_a | cond_b | cond_c)

# COMMAND ----------

# Regra 7 — DUR_AUSEN == NDIAS_AFAST == (ENDDA-BEGDA+1)
def validar_regra_7(df):
    begda = to_date_ddmmyyyy("BEGDA_ATEST")
    endda = to_date_ddmmyyyy("ENDDA_ATEST")
    return df.filter(
        (col("DUR_AUSEN") != col("NDIAS_AFAST")) |
        (col("DUR_AUSEN").cast(IntegerType()) != (datediff(endda, begda) + 1))
    )

# Regra 8 — STATUS_ESOC = '5' → datas preenchidas e válidas
def valida_regra_8(df):
    begda = to_date_ddmmyyyy("BEGDA_ATEST")
    endda = to_date_ddmmyyyy("ENDDA_ATEST")
    return df.filter(
        (col("STATUS_ESOC") == "5") &
        (begda.isNull() | endda.isNull() | (endda < begda) | (endda > current_date()))
    )

# COMMAND ----------

# Regra 9 — CID1 formato
def valida_cid1(df):
    return df.filter(
        (length(col("CID1")) > 6) |
        (~col("CID1").rlike(r"^[A-Z]\d{2}$") & ~col("CID1").rlike(r"^[A-Z]\d{2}\.\d{1}$"))
    )

# Regra 10 — CID2 contra picklist
def valida_cid2(df):
    pkl = ler_arquivo_csv(f"{PICKLIST_BASE_PATH}EHS_GP_01_Piclist CID.csv", ";", 1)
    df_exp = df.withColumn("_cid2_arr", split(col("CID2"), ";")).withColumn("_cid2_item", explode("_cid2_arr"))
    df_j = df_exp.join(pkl.alias("p"), col("_cid2_item") == col("p.Código"), "left")
    invalid = df_j.filter(_is_filled("_cid2_item") & col("p.Código").isNull())
    return invalid.select(*df.columns).distinct()

# COMMAND ----------

# Regra 11 — REAFAST_MESMO_MOT ↔ ATEST_RELA
def validar_reafast_atest_relacao(df):
    ok_N = (col("REAFAST_MESMO_MOT") == "N") & col("ATEST_RELA").isNull()
    ok_S = (col("REAFAST_MESMO_MOT") == "S") & _is_filled("ATEST_RELA")
    return df.filter(~(ok_N | ok_S))

# Regra 12 — COD_ESOC == MOT_AFAST (quando BEGDA_PREV preenchido)
def valida_CODESOC_MOTAFAST(df):
    return df.filter(_is_filled("BEGDA_PREV") & (col("COD_ESOC") != col("MOT_AFAST")))

# COMMAND ----------

# Regra 13 — CONV_BEN conforme HV_CONV
def valida_CONV_BEN_HV_CONV(df):
    return df.filter(
        ((col("HV_CONV") == "S") & ~col("CONV_BEN").isin("B31","B91")) |
        ((col("HV_CONV") == "S") & col("COD_ESOC").isin("2","3","4") & (col("CONV_BEN") != "B91")) |
        ((col("HV_CONV") == "S") & (col("COD_ESOC") == "1") & (col("CONV_BEN") != "B31")) |
        ((col("HV_CONV") == "M") & col("CONV_BEN").isNotNull())
    )

# Regra 14 — ORIG_RETIF + TP_PROCE + NUM_PROC_PREV
def valida_ORIG_RETIF(df):
    return df.filter(
        col("ORIG_RETIF").isin("2","3") & (
            (col("TP_PROCE").isNull() | ~col("TP_PROCE").isin("1","2","3")) |
            ((col("TP_PROCE") == "1") & ~length(col("NUM_PROC_PREV")).isin(17,21)) |
            ((col("TP_PROCE") == "2") & (length(col("NUM_PROC_PREV")) != 20)) |
            ((col("TP_PROCE") == "3") & (length(col("NUM_PROC_PREV")) != 10))
        )
    )

# COMMAND ----------

# Regra 15 — ATEST_ANTE = 'S' → DIAS_ANTE, MOT_ANTE, RESP_ANTE preenchidos
def valida_ATEST_ANTE(df):
    return df.filter(
        (col("ATEST_ANTE") == "S") &
        (_is_empty("DIAS_ANTE") | _is_empty("MOT_ANTE") | _is_empty("RESP_ANTE") |
         (col("DIAS_ANTE").cast(IntegerType()) <= col("DUR_AUSEN").cast(IntegerType())))
    )

# Regra 16 — ENC_INSS ↔ BEGDA_PREV
def validar_encinss(df):
    return df.filter(
        (_is_filled("BEGDA_PREV") & (col("ENC_INSS") != "S")) |
        (_is_empty("BEGDA_PREV") & _is_filled("ENC_INSS"))
    )

# COMMAND ----------

# Regra 17 — REAFAST correlação 60 dias
def valida_REAFAST_MESMO_MOT_correl(df):
    df2 = df.withColumn("_b", to_date_ddmmyyyy("BEGDA_ATEST")).withColumn("_e", to_date_ddmmyyyy("ENDDA_ATEST"))
    return df2.filter(
        col("REAFAST_MESMO_MOT").isin("S","N") & (col("HV_CONV") == "S") &
        (datediff(col("_e"), col("_b")) > 60)
    ).drop("_b","_e")

# Regra 18 — REAFAST_MESMO_MOT ↔ ATEST_RELA (preenchimento)
def validar_regra_18(df):
    return df.filter(
        ((col("REAFAST_MESMO_MOT") == "S") & _is_empty("ATEST_RELA")) |
        ((col("REAFAST_MESMO_MOT") != "S") & _is_filled("ATEST_RELA"))
    )

# COMMAND ----------

# Regra 18.1 — ATEST_RELA calculado vs real
def validar_regra_18_1(df):
    df_idx = df.withColumn("_idx", F.monotonically_increasing_id())
    w = Window.orderBy("_idx")
    is_N = F.when(col("REAFAST_MESMO_MOT") == "N", 1).otherwise(0)
    df_blk = df_idx.withColumn("_blk", F.sum(is_N).over(w))
    w_prev = Window.partitionBy("_blk").orderBy("_idx").rowsBetween(Window.unboundedPreceding, -1)
    df_comp = df_blk.withColumn("_acc", F.collect_list("ID_ATEST").over(w_prev))
    df_comp = df_comp.withColumn("_acc_d", F.array_distinct(col("_acc")))
    df_comp = df_comp.withColumn("_acc_f", F.expr("filter(_acc_d, x -> x != ID_ATEST)"))
    df_comp = df_comp.withColumn("_calc",
        F.when(col("REAFAST_MESMO_MOT") == "N", lit("")).otherwise(F.concat_ws(";", "_acc_f")))
    df_comp = df_comp.withColumn("_norm",
        F.when(col("ATEST_RELA").isNull(), lit("")).otherwise(trim(col("ATEST_RELA"))))
    return df_comp.filter(col("_calc") != col("_norm")).drop("_idx","_blk","_acc","_acc_d","_acc_f","_calc","_norm")

# COMMAND ----------

# Regra 19 — ID global: único por (PERNR_PERI, BEGDA_PREV)
def validar_id_global(df):
    por_par = df.groupBy("PERNR_PERI","BEGDA_PREV").agg(countDistinct("ID_GESTAO").alias("_cnt"))
    inv_A = df.join(por_par.filter(col("_cnt") > 1).select("PERNR_PERI","BEGDA_PREV"), ["PERNR_PERI","BEGDA_PREV"], "inner")
    por_id = df.groupBy("ID_GESTAO").agg(countDistinct(F.struct("PERNR_PERI","BEGDA_PREV")).alias("_cnt2"))
    inv_B = df.join(por_id.filter(col("_cnt2") > 1).select("ID_GESTAO"), "ID_GESTAO", "inner")
    return inv_A.select(df.columns).unionByName(inv_B.select(df.columns)).dropDuplicates()

# Regra 20 — INFO_ADD não pode conter "/"
def valida_INFO_ADD(df):
    return df.filter(col("INFO_ADD").contains("/"))

# COMMAND ----------

# Regra 21 — BEGDA_PREV ↔ PERNR_PERI
def validar_regra_21(df):
    erro_a = df.filter(_is_empty("BEGDA_PREV") & _is_filled("PERNR_PERI"))
    erro_b = df.filter(_is_filled("BEGDA_PREV") & _is_filled("PERNR_PERI") & (col("PERNR_PERI") != col("PERNR")))
    return erro_a.unionByName(erro_b)

# Regra 22 — ID preenchido, sequencial, sem duplicatas
def validar_regra_22(df):
    erro_prench = df.filter(_is_filled("BEGDA_PREV") & (col("NDIAS_AFAST").cast(IntegerType()) > 15) & _is_empty("ID_GESTAO"))
    df_seq = df.withColumn("_id_n", col("ID_GESTAO").cast("long"))
    w = Window.orderBy("_id_n")
    df_seq = df_seq.withColumn("_prev", lag("_id_n").over(w))
    erro_seq = df_seq.filter(col("_prev").isNotNull() & ((col("_id_n") - col("_prev")) != 1)).drop("_id_n","_prev")
    return erro_prench.unionByName(erro_seq, allowMissingColumns=True)

# COMMAND ----------

# Regra 23 — SEQ_GESTAO formato GP + sequência
def validar_regra_23(df):
    df2 = df.withColumn("_match", regexp_extract("SEQ_GESTAO", r"^GP\d+$", 0))
    df2 = df2.withColumn("_num", when(col("_match") != "", regexp_extract("SEQ_GESTAO", r"GP(\d+)", 1).cast("int")))
    w = Window.partitionBy("PERNR","BEGDA_PREV").orderBy("_num")
    df2 = df2.withColumn("_exp", row_number().over(w))
    cond = (col("_match") == "") | ((col("_match") != "") & (col("_num") != col("_exp")))
    return df2.filter(cond).drop("_match","_num","_exp")

# COMMAND ----------

# Regra 24 — ID_ATEST_REL correto por grupo
def validar_regra_24(df):
    grp = df.groupBy("PERNR","BEGDA_ATEST","BEGDA_PREV").agg(
        F.count("*").alias("_qtd"),
        F.array_distinct(F.collect_list(trim(col("ID_ATEST")))).alias("_ids_grp")
    )
    df_j = df.join(grp, ["PERNR","BEGDA_ATEST","BEGDA_PREV"], "left")
    df_j = df_j.withColumn("_ids_rel",
        F.array_distinct(F.expr("filter(transform(split(coalesce(trim(ID_ATEST_REL),''),';'), x -> trim(x)), x -> x is not null and x <> '')")))
    cond_1 = (col("_qtd") == 1) & (trim(col("ID_ATEST")) != trim(col("ID_ATEST_REL")))
    cond_n = (col("_qtd") > 1) & (
        (F.size("_ids_rel") != F.size("_ids_grp")) |
        F.expr("exists(_ids_grp, x -> NOT array_contains(_ids_rel, x))"))
    return df_j.filter(cond_1 | cond_n).select(*df.columns)

# COMMAND ----------

# Regra 25 — Campos dependentes de BEGDA_PREV
def valida_begda_prev(df):
    return valida_dependentes_preenchidos(df, "BEGDA_PREV", BEGDA_PREV_DEPENDENTES)

# Regra 25b — Campos dependentes de PERNR_PERI
def valida_pernr_peri_dependentes(df):
    return valida_dependentes_preenchidos(df, "PERNR_PERI", PERNR_PERI_DEPENDENTES)

# Regra 26 — ENDDA_PREV ↔ BEGDA_PREV
def valida_ENDDA_PREV_BEGDA_PREV(df):
    return df.filter(
        (_is_filled("ENDDA_PREV") & _is_empty("BEGDA_PREV")) |
        ((col("ENDDA_PREV") == "31129999") & (col("BEN_CESS") != "N")) |
        (_is_filled("ENDDA_PREV") & _is_filled("BEGDA_PREV") & (col("BEGDA_PREV") > col("ENDDA_PREV")))
    )

# COMMAND ----------

# Regra 27 — MOT_AFAST ↔ TPBEN
def valida_regra_27(df):
    return df.filter(
        ((col("MOT_AFAST") == "1") & ~col("TPBEN").isin("B31","B32")) |
        (col("MOT_AFAST").isin("2","3","4") & ~col("TPBEN").isin("B91","B92","B94"))
    )

# Regra 28 — DATE_INICAFAST
def validar_date_inicafast(df):
    return df.filter(
        (col("NDIAS_AFAST").cast("int") > 15) & _is_filled("BEGDA_PREV") &
        (col("DATE_INICAFAST") != col("BEGDA_ATEST"))
    )

# Regra 29 — DT_PERI ordenação por PERNR
def validar_regra_DT_PERI(df):
    df2 = df.withColumn("_dt", to_date_ddmmyyyy("DT_PERI"))
    w = Window.partitionBy("PERNR").orderBy("_dt")
    df2 = df2.withColumn("_prev", lag("_dt").over(w))
    return df2.filter(col("_dt").isNotNull() & col("_prev").isNotNull() & (col("_dt") < col("_prev"))).drop("_dt","_prev")

# COMMAND ----------

# Regra 30 — OBS_PER contém strings obrigatórias
def validar_regra_OBS_PER(df):
    obrig = ["JUSTIFICATIVA RESULTADO DA PERÍCIA","JUSTIFICATIVA DO INDEFERIMENTO",
             "ALTA ANTECIPADA","PARECER MÉDICO PERÍCIA","OBSERVAÇÃO ALTA INSS",
             "INFORMAÇÕES PROCESSO JUDICIAL","NTEP (SIM OU NÃO)",
             "PERÍCIA REGISTRADA","REGISTRO PROFISSIONAL"]
    regex = "(?i)(" + "|".join(obrig) + ")"
    return df.filter(_is_filled("OBS_PER") & ~col("OBS_PER").rlike(regex))

# Regra 31 — NUM_REQ = "0" quando BEGDA_PREV vazio
def validar_regra_49(df):
    return df.filter(_is_empty("BEGDA_PREV") & (col("NUM_REQ") != "0"))

# COMMAND ----------

# Regra 32 — DT_INI_BENE ↔ BEGDA_PREV
def validar_regra_32(df):
    erro_a = df.filter(_is_empty("BEGDA_PREV") & _is_filled("DT_INI_BENE"))
    erro_b = df.filter(_is_filled("BEGDA_PREV") & _is_empty("DT_INI_BENE"))
    erro_c = df.filter(_is_filled("BEGDA_PREV") & _is_filled("DT_INI_BENE") & (col("DT_INI_BENE") != col("BEGDA_PREV")))
    return erro_a.unionByName(erro_b).unionByName(erro_c)

# Regra 33 — DIAS_BENE ↔ BEN_CESS
def validar_regra_53(df):
    dt_cess = to_date_ddmmyyyy("DT_CESS_BEN"); dt_ini = to_date_ddmmyyyy("DT_INI_BENE")
    erro_b = df.filter((col("BEN_CESS") == "S") & _is_empty("DIAS_BENE"))
    erro_c = df.filter(_is_filled("DIAS_BENE") & dt_ini.isNotNull() & dt_cess.isNotNull() &
                        (col("DIAS_BENE").cast("int") != datediff(dt_cess, dt_ini)))
    erro_d = df.filter((col("BEN_CESS") == "N") & _is_filled("DIAS_BENE"))
    return erro_b.unionByName(erro_c, allowMissingColumns=True).unionByName(erro_d, allowMissingColumns=True)

# COMMAND ----------

# Regra 34 — BEN_CESS ↔ DT_ALTA
def validar_regra_54_1(df):
    erro_a = df.filter((col("BEN_CESS") == "S") & (_is_empty("DT_ALTA") | to_date_ddmmyyyy("DT_ALTA").isNull()))
    erro_b = df.filter((col("BEN_CESS") == "N") & _is_filled("DT_ALTA"))
    return erro_a.unionByName(erro_b, allowMissingColumns=True)

# Regra 35 — DT_CESS_BEN ↔ DT_ALTA
def validar_regra_59(df):
    df2 = df.withColumn("_cess", to_date_ddmmyyyy("DT_CESS_BEN")).withColumn("_alta", to_date_ddmmyyyy("DT_ALTA"))
    erro_a = df2.filter(_is_empty("BEGDA_PREV") & (_is_filled("DT_CESS_BEN") | _is_filled("DT_ALTA")))
    erro_b = df2.filter(col("_cess").isNotNull() & col("_alta").isNotNull() & (col("_alta") != F.date_add(col("_cess"), 1)))
    return erro_a.unionByName(erro_b, allowMissingColumns=True).drop("_cess","_alta")

# COMMAND ----------

# Regra 36 — CONC_API = 'M' quando BEGDA_PREV preenchido
def validar_campo_so_M(df):
    return df.filter(_is_filled("BEGDA_PREV") & (col("CONC_API") != "M"))

# Regra 37 — Datas API ↔ BEGDA_PREV
def validar_regra_56(df):
    campos_api = ["DT_IN_API","DT_FIM_API","DT_REC","DT_LIM","DT_FIM_LIMBO"]
    cond_a_parts = [col(c) != "01010001" for c in campos_api]
    cond_a = _is_empty("BEGDA_PREV") & reduce(lambda a, b: a | b, cond_a_parts)
    cond_b_parts = [~col(c).rlike(r"^[0-9]{8}$") for c in campos_api]
    cond_b = _is_filled("BEGDA_PREV") & reduce(lambda a, b: a | b, cond_b_parts)
    return df.filter(cond_a | cond_b)

# COMMAND ----------

# Regra 38 — NUM_OF_CONTEST=0, HV_CONT='N', NEC_CONTEST='N'
def validar_regra_38(df):
    return df.filter((col("NUM_OF_CONTEST") != "0") | (col("HV_CONT") != "N") | (col("NEC_CONTEST") != "N"))

# Regra 39 — NUM_REQREC formato
def validar_regra_56_1(df):
    return df.filter(
        _is_filled("BEGDA_PREV") & _is_filled("NUM_REQREC") &
        ~col("NUM_REQREC").rlike(r"^[0-9]{1,30}$")
    )

# Regra 40 — DIAS_BENE = DT_CESS_BEN - D_SEXTO_DIA + 1
def validar_regra_41(df):
    return df.filter(
        _is_filled("DIAS_BENE") &
        to_date_ddmmyyyy("D_SEXTO_DIA").isNotNull() &
        to_date_ddmmyyyy("DT_CESS_BEN").isNotNull() &
        (col("DIAS_BENE").cast("int") !=
         datediff(to_date_ddmmyyyy("DT_CESS_BEN"), to_date_ddmmyyyy("D_SEXTO_DIA")) + 1)
    )

# COMMAND ----------

# Regra 42 — HV_CONV='S' se ORIG_RETIF+TP_PROCE+NUM_PROC_PREV todos preenchidos
def HV_CONV_S_DEPENDENCIA(df):
    todos = _is_filled("NUM_PROC_PREV") & _is_filled("TP_PROCE") & _is_filled("ORIG_RETIF")
    esperado = F.when(todos, lit("S")).otherwise(lit("M"))
    return df.filter(col("HV_CONV") != esperado)

# Regra 43 — Campos dependentes de BEGDA_PREV (NUM_REQREC, DT_LIM, etc)
def validar_regra_57(df):
    campos = ["NUM_REQREC","DT_LIM","DT_FIM_LIMBO"]
    cond_a_parts = [_is_filled(c) for c in campos]
    cond_a = _is_empty("BEGDA_PREV") & reduce(lambda a, b: a | b, cond_a_parts)
    cond_b_parts = [_is_empty(c) for c in campos]
    cond_b = (col("BEN_CESS") == "S") & (col("INAPTO") == "S") & _is_filled("DT_REC") & reduce(lambda a, b: a | b, cond_b_parts)
    return df.filter(cond_a | cond_b)

# COMMAND ----------

# Regra 44 — ATEST_RELA calculado (60 dias, mesmo PERNR+CID1)
def valida_atest_rela(df):
    df2 = (df
        .withColumn("_b_dt", to_date_ddmmyyyy("BEGDA_ATEST"))
        .withColumn("_e_dt", to_date_ddmmyyyy("ENDDA_ATEST"))
        .withColumn("_b_d", datediff(col("_b_dt"), lit("1970-01-01")))
        .withColumn("_e_d", datediff(col("_e_dt"), lit("1970-01-01")))
        .withColumn("_rid", F.monotonically_increasing_id())
    )
    a = df2.alias("a"); b = df2.alias("b")
    prev = a.join(b, (col("a.PERNR") == col("b.PERNR")) & (col("a.CID1") == col("b.CID1")) &
                      col("b._e_d").between(col("a._b_d") - 60, col("a._b_d") - 1) &
                      (col("b._b_d") <= col("a._b_d") - 1), "left"
    ).select(col("a._rid").alias("_rid"), col("b.ID_ATEST").alias("_prev_id"))
    agg = prev.groupBy("_rid").agg(
        F.concat_ws(";", F.sort_array(F.array_distinct(F.collect_list(col("_prev_id"))))).alias("_expected"))
    df3 = df2.join(agg, "_rid", "left").withColumn("_expected", F.coalesce(col("_expected"), lit("")))
    def _norm(c):
        arr = F.split(F.coalesce(F.col(c), lit("")), ";")
        return F.sort_array(F.array_distinct(F.expr(f"filter(transform({c}_arr, x -> trim(x)), x -> x is not null and x <> '')")))
    df3 = df3.withColumn("ATEST_RELA_arr", F.split(F.coalesce(trim(col("ATEST_RELA")), lit("")), ";"))
    df3 = df3.withColumn("_a_norm", F.sort_array(F.array_distinct(F.expr("filter(transform(ATEST_RELA_arr, x -> trim(x)), x -> x is not null and x <> '')"))))
    df3 = df3.withColumn("_e_arr", F.split(col("_expected"), ";"))
    df3 = df3.withColumn("_e_norm", F.sort_array(F.array_distinct(F.expr("filter(transform(_e_arr, x -> trim(x)), x -> x is not null and x <> '')"))))
    erros = df3.filter((F.upper(col("REAFAST_MESMO_MOT")) == "S") & ((_is_empty("ATEST_RELA")) | (col("_a_norm") != col("_e_norm"))))
    return erros.select(*df.columns, col("_expected").alias("ATEST_RELA_ESPERADO"))

# COMMAND ----------

# Regra 45 — ID e SEQ_GESTAO (validação completa)
def valida_id_seq_gestao(df):
    orig = df.columns
    base = (df.withColumn("_rid", F.monotonically_increasing_id())
        .withColumn("_bp_trim", trim(col("BEGDA_PREV")))
        .withColumn("_has_bp", col("_bp_trim") != "")
        .withColumn("_bp_dt", F.to_date(col("_bp_trim"), "ddMMyyyy"))
        .withColumn("_id_n", col("ID_GESTAO").cast("long")))
    v = base.filter(col("_has_bp"))
    v = v.withColumn("ERR_BP_INV", col("_bp_dt").isNull())
    v = v.withColumn("ERR_ID_VAZIO", col("_id_n").isNull())
    v = v.withColumn("ERR_SEQ_VAZIO", _is_empty("SEQ_GESTAO"))
    w_grp = Window.partitionBy("PERNR","_bp_dt")
    v = v.withColumn("_id_min", F.min("_id_n").over(w_grp)).withColumn("_id_max", F.max("_id_n").over(w_grp))
    v = v.withColumn("ERR_ID_INCONS", ~col("ERR_ID_VAZIO") & ~col("ERR_BP_INV") & (col("_id_min") != col("_id_max")))
    w_seq = Window.partitionBy("PERNR","_bp_dt").orderBy("_rid")
    v = v.withColumn("_seq_exp", F.concat(lit("GP"), row_number().over(w_seq).cast("string")))
    v = v.withColumn("ERR_SEQ_DIV", ~col("ERR_SEQ_VAZIO") & ~col("ERR_BP_INV") & (trim(col("SEQ_GESTAO")) != col("_seq_exp")))
    return v.filter(col("ERR_BP_INV") | col("ERR_ID_VAZIO") | col("ERR_SEQ_VAZIO") | col("ERR_ID_INCONS") | col("ERR_SEQ_DIV")).select(*orig, "_seq_exp")

# COMMAND ----------

# ═══════════════════════════════════════════════════════════════════════════════
# 4. MONTAGEM DO DICIONÁRIO DE VALIDAÇÕES
# ═══════════════════════════════════════════════════════════════════════════════

validacoes = [
    {"numero": "1.3",  "funcao": lambda df: valida_campos_devem_ser_vazios(df, CAMPOS_DEVEM_SER_VAZIOS),                     "regra": "Campos que devem ser vazios",                                         "nome_log": "campos_vazios_com_dados"},
    {"numero": "1.4",  "funcao": comparar_chaves_varios(GP, [EC_29_00_1,EC_29_00_2,EC_29_00_3,EC_29_00_4], ["PERNR"], ["user_id"]), "regra": "PERNR conforme EC_29_00",  "nome_log": "PERNR_nao_existe_EC29"},
    {"numero": "2",    "funcao": validar_ID_ATEST,         "regra": "Sequência ID_ATEST",                                    "nome_log": "ID_ATEST_seq"},
    {"numero": "3",    "funcao": validar_BEGDA_ATEST,      "regra": "BEGDA_ATEST intervalo válido",                           "nome_log": "BEGDA_ATEST_intervalo"},
    {"numero": "3.1",  "funcao": valida_BEGDA_ATEST_dist,  "regra": "BEGDA_ATEST duplicada por matrícula",                    "nome_log": "BEGDA_ATEST_dist"},
    {"numero": "4",    "funcao": valida_data_operador(GP, "ENDDA_ATEST", ["BEGDA_ATEST"], ">="),                              "regra": "ENDDA_ATEST >= BEGDA_ATEST", "nome_log": "ENDDA_menor_BEGDA"},
    {"numero": "5",    "funcao": valida_NDIAS_AFAST,       "regra": "NDIAS_AFAST = ENDDA-BEGDA+1",                            "nome_log": "NDIAS_AFAST"},
    {"numero": "6",    "funcao": validar_D_sexto_dia,      "regra": "D_SEXTO_DIA consistência",                               "nome_log": "D_SEXTO_DIA"},
    {"numero": "7",    "funcao": validar_regra_7,          "regra": "DUR_AUSEN == NDIAS_AFAST",                               "nome_log": "DUR_AUSEN"},
    {"numero": "8",    "funcao": valida_regra_8,           "regra": "STATUS_ESOC=5 consistência",                             "nome_log": "STATUS_ESOC"},
    {"numero": "9",    "funcao": valida_cid1,              "regra": "CID1 formato",                                           "nome_log": "CID1"},
    {"numero": "10",   "funcao": valida_cid2,              "regra": "CID2 contra picklist",                                   "nome_log": "CID2"},
    {"numero": "11",   "funcao": validar_reafast_atest_relacao, "regra": "REAFAST ↔ ATEST_RELA",                              "nome_log": "REAFAST_ATEST_RELA"},
    {"numero": "12",   "funcao": valida_CODESOC_MOTAFAST,  "regra": "COD_ESOC == MOT_AFAST",                                  "nome_log": "CODESOC_MOTAFAST"},
    {"numero": "13",   "funcao": valida_CONV_BEN_HV_CONV,  "regra": "CONV_BEN conforme HV_CONV",                              "nome_log": "CONV_BEN_HV_CONV"},
    {"numero": "14",   "funcao": valida_ORIG_RETIF,        "regra": "ORIG_RETIF + TP_PROCE + NUM_PROC_PREV",                  "nome_log": "ORIG_RETIF"},
    {"numero": "15",   "funcao": valida_ATEST_ANTE,        "regra": "ATEST_ANTE=S dependências",                              "nome_log": "ATEST_ANTE"},
    {"numero": "16",   "funcao": validar_encinss,          "regra": "ENC_INSS ↔ BEGDA_PREV",                                  "nome_log": "ENC_INSS"},
    {"numero": "17",   "funcao": valida_REAFAST_MESMO_MOT_correl, "regra": "REAFAST correlação 60d",                          "nome_log": "REAFAST_correl"},
    {"numero": "18",   "funcao": validar_regra_18,         "regra": "REAFAST ↔ ATEST_RELA preenchimento",                     "nome_log": "REAFAST_ATEST"},
    {"numero": "18.1", "funcao": validar_regra_18_1,       "regra": "ATEST_RELA calculado vs real",                           "nome_log": "ATEST_RELA_calc"},
    {"numero": "19",   "funcao": validar_id_global,        "regra": "ID global único por (PERNR_PERI, BEGDA_PREV)",            "nome_log": "ID_global"},
    {"numero": "20",   "funcao": valida_INFO_ADD,          "regra": "INFO_ADD sem barra",                                     "nome_log": "INFO_ADD"},
    {"numero": "21",   "funcao": validar_regra_21,         "regra": "BEGDA_PREV ↔ PERNR_PERI",                                "nome_log": "BEGDA_PERNR"},
    {"numero": "22",   "funcao": validar_regra_22,         "regra": "ID preenchido/sequencial",                               "nome_log": "ID_seq"},
    {"numero": "23",   "funcao": validar_regra_23,         "regra": "SEQ_GESTAO formato/sequência",                           "nome_log": "SEQ_GESTAO"},
    {"numero": "24",   "funcao": validar_regra_24,         "regra": "ID_ATEST_REL por grupo",                                 "nome_log": "ID_ATEST_REL"},
    {"numero": "25",   "funcao": valida_begda_prev,        "regra": "Campos dependentes BEGDA_PREV",                          "nome_log": "BEGDA_PREV_deps"},
    {"numero": "26",   "funcao": valida_ENDDA_PREV_BEGDA_PREV, "regra": "ENDDA_PREV ↔ BEGDA_PREV",                           "nome_log": "ENDDA_BEGDA"},
    {"numero": "27",   "funcao": valida_regra_27,          "regra": "MOT_AFAST ↔ TPBEN",                                     "nome_log": "MOT_TPBEN"},
    {"numero": "28",   "funcao": validar_date_inicafast,   "regra": "DATE_INICAFAST == BEGDA_ATEST",                          "nome_log": "DATE_INICAFAST"},
    {"numero": "29",   "funcao": validar_regra_DT_PERI,    "regra": "DT_PERI ordenação",                                     "nome_log": "DT_PERI"},
    {"numero": "30",   "funcao": validar_regra_OBS_PER,    "regra": "OBS_PER strings obrigatórias",                           "nome_log": "OBS_PER"},
    {"numero": "31",   "funcao": validar_regra_49,         "regra": "NUM_REQ=0 sem BEGDA_PREV",                               "nome_log": "NUM_REQ"},
    {"numero": "32",   "funcao": validar_regra_32,         "regra": "DT_INI_BENE ↔ BEGDA_PREV",                               "nome_log": "DT_INI_BENE"},
    {"numero": "33",   "funcao": validar_regra_53,         "regra": "DIAS_BENE ↔ BEN_CESS",                                  "nome_log": "DIAS_BENE"},
    {"numero": "34",   "funcao": validar_regra_54_1,       "regra": "BEN_CESS ↔ DT_ALTA",                                    "nome_log": "BEN_CESS_DT_ALTA"},
    {"numero": "35",   "funcao": validar_regra_59,         "regra": "DT_CESS_BEN ↔ DT_ALTA",                                 "nome_log": "CESS_ALTA"},
    {"numero": "36",   "funcao": validar_campo_so_M,       "regra": "CONC_API = M",                                          "nome_log": "CONC_API"},
    {"numero": "37",   "funcao": validar_regra_56,         "regra": "Datas API ↔ BEGDA_PREV",                                "nome_log": "datas_API"},
    {"numero": "38",   "funcao": validar_regra_38,         "regra": "NUM_OF_CONTEST/HV_CONT/NEC_CONTEST fixos",              "nome_log": "campos_fixos"},
    {"numero": "39",   "funcao": validar_regra_56_1,       "regra": "NUM_REQREC formato",                                    "nome_log": "NUM_REQREC"},
    {"numero": "40",   "funcao": validar_regra_41,         "regra": "DIAS_BENE = DT_CESS_BEN - D_SEXTO_DIA + 1",             "nome_log": "DIAS_BENE_calc"},
    {"numero": "42",   "funcao": HV_CONV_S_DEPENDENCIA,    "regra": "HV_CONV S/M conforme dependências",                     "nome_log": "HV_CONV_dep"},
    {"numero": "43",   "funcao": validar_regra_57,         "regra": "BEGDA_PREV ↔ NUM_REQREC/DT_LIM/DT_FIM_LIMBO",          "nome_log": "BEGDA_limbo"},
    {"numero": "43b",  "funcao": valida_pernr_peri_dependentes, "regra": "Campos dependentes PERNR_PERI",                    "nome_log": "PERNR_PERI_deps"},
    {"numero": "44",   "funcao": valida_atest_rela,        "regra": "ATEST_RELA correlação 60 dias",                         "nome_log": "ATEST_RELA_60d"},
    {"numero": "45",   "funcao": valida_id_seq_gestao,     "regra": "ID e SEQ_GESTAO consistência",                          "nome_log": "ID_SEQ_GESTAO"},
]

# COMMAND ----------

# ═══════════════════════════════════════════════════════════════════════════════
# 5. EXECUÇÃO
# ═══════════════════════════════════════════════════════════════════════════════

resultados = executar_validacoes(GP, validacoes, TEMPLATE_NAME)

# COMMAND ----------

GP.unpersist()
print(f"\n✅ Validação concluída em {time.time()-t0:.1f}s")