# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Gestão Previdenciária/config/config"

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

from datetime import datetime
from functools import reduce
from typing import List
import operator

from pyspark.sql import DataFrame, Window
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, IntegerType
from pyspark.sql.functions import (
    md5, concat_ws, coalesce, col, lit, trim, length, to_date,
    datediff, current_date, lag, row_number, collect_set, split,
    explode, countDistinct, regexp_extract, when
)

# COMMAND ----------

# ── Exportação ────────────────────────────────────────────────────────────────
def export_df_to_excel(df, output_base: str, sheet_name: str, chunk_size: int = 10_000):
    import os, shutil, re
    from openpyxl import Workbook
    from openpyxl.cell import WriteOnlyCell
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter

    _ILLEGAL_XML_CHARS = re.compile(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]')

    def _safe_val(val):
        if val is None:
            return ""
        if isinstance(val, str):
            return _ILLEGAL_XML_CHARS.sub("", val)
        return str(val)

    tmp_file  = f"/tmp/{sheet_name}.xlsx"
    dest_file = os.path.join(output_base.rstrip("/"), f"{sheet_name}.xlsx")

    # ── Estilos ───────────────────────────────────────────────────────────────
    header_font  = Font(name="Calibri", bold=True, color="FFFFFF", size=11)
    header_fill  = PatternFill("solid", fgColor="203864")
    header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
    thin_side    = Side(style="thin", color="BFBFBF")
    thin_border  = Border(left=thin_side, right=thin_side,
                          top=thin_side,  bottom=thin_side)
    cell_font    = Font(name="Calibri", size=10)
    cell_align   = Alignment(horizontal="left", vertical="center")

    wb = Workbook(write_only=True)
    ws = wb.create_sheet(title=sheet_name)

    # ── Cabeçalho ─────────────────────────────────────────────────────────────
    columns = df.columns
    header_row = []
    for col_name in columns:
        cell           = WriteOnlyCell(ws, value=col_name)
        cell.font      = header_font
        cell.fill      = header_fill
        cell.alignment = header_align
        cell.border    = thin_border
        header_row.append(cell)
    ws.append(header_row)

    # ── Coleta e escreve ──────────────────────────────────────────────────────
    print("  Coletando dados do Spark para o driver...")
    pdf = df.toPandas()
    total = len(pdf)
    print(f"  {total:,} registros coletados. Escrevendo Excel...")

    for i, row in enumerate(pdf.itertuples(index=False), start=1):
        data_row = []
        for val in row:
            cell           = WriteOnlyCell(ws, value=_safe_val(val))
            cell.font      = cell_font
            cell.alignment = cell_align
            cell.border    = thin_border
            data_row.append(cell)
        ws.append(data_row)
        if i % chunk_size == 0:
            print(f"  ... {i:,} linhas escritas")

    # ── Largura das colunas ───────────────────────────────────────────────────
    for col_idx, col_name in enumerate(columns, start=1):
        ws.column_dimensions[get_column_letter(col_idx)].width = min(max(len(col_name), 8), 60) + 2

    # ── Salva em /tmp → copia para o Volume ───────────────────────────────────
    wb.save(tmp_file)
    wb.close()

    shutil.copy2(tmp_file, dest_file)
    os.remove(tmp_file)

    print(f"\n✅ Excel exportado: {dest_file} ({total:,} linhas | {len(columns)} colunas)")
 
def export_df_to_csv(df: DataFrame, volume_path: str, file_base: str,
                     delimiter: str = "|") -> None:
    """Exporta DataFrame para CSV via streaming direto no Volume."""
    import os, shutil
 
    base = volume_path.rstrip("/")
    tmp_csv = f"/tmp/{file_base}.csv"
    final_csv = f"{base}/{file_base}.csv"
 
    cols = df.columns
 
    with open(tmp_csv, "w", encoding="utf-8") as f:
        f.write(delimiter.join(cols) + "\n")
        count = 0
        for row in df.toLocalIterator():
            vals = [str(row[c]) if row[c] is not None else "" for c in cols]
            f.write(delimiter.join(vals) + "\n")
            count += 1
 
    shutil.copy2(tmp_csv, final_csv)
    os.remove(tmp_csv)
 
    print(f"✅ CSV exportado: {final_csv} ({count} linhas)")


def export_df_to_excel_with_counts(
    df: DataFrame,
    volume_path: str,
    file_base: str,
    counts: dict,
    sheet_name: str = None,
) -> None:
    """Exporta DataFrame para Excel com aba extra de contagem.

    Args:
        df: DataFrame principal.
        volume_path: Caminho do Volume de saída.
        file_base: Nome base do arquivo (sem extensão).
        counts: Dict com métricas, ex:
                {"Matriculas antes do filtro": 5234,
                 "Matriculas depois do filtro": 3863}
        sheet_name: Nome da aba de dados (default: file_base).
    """
    import os, shutil
    from openpyxl import Workbook

    base = volume_path.rstrip("/")
    tmp_xlsx = f"/tmp/{file_base}.xlsx"
    final_xlsx = f"{base}/{file_base}.xlsx"
    ws_name = sheet_name or file_base

    cols = df.columns

    wb = Workbook(write_only=True)

    # ── Aba 1: dados (nome customizado) ──
    ws_dados = wb.create_sheet(ws_name)
    ws_dados.append(cols)

    count = 0
    for row in df.toLocalIterator():
        ws_dados.append([str(row[c]) if row[c] is not None else "" for c in cols])
        count += 1
        if count % 10_000 == 0:
            print(f"  ... {count} linhas escritas")

    # ── Aba 2: Contagem ──
    ws_contagem = wb.create_sheet("Contagem")
    ws_contagem.append(list(counts.keys()))
    ws_contagem.append([str(v) for v in counts.values()])

    wb.save(tmp_xlsx)
    wb.close()

    shutil.copy2(tmp_xlsx, final_xlsx)
    os.remove(tmp_xlsx)

    print(f"✅ Excel exportado: {final_xlsx} ({count} linhas, aba Contagem incluída)")
 
 
# Compatibilidade
def export_df_to_csv_excel(df: DataFrame, volume_path: str, file_base: str) -> None:
    """Exporta DataFrame para CSV (|) e Excel."""
    export_df_to_csv(df, volume_path, file_base, delimiter="|")
    export_df_to_excel(df, volume_path, file_base)

# COMMAND ----------

# ═══════════════════════════════════════════════════════════════════════════════
#  SEÇÃO 1 — Funções da _LIB (recriadas)
# ═══════════════════════════════════════════════════════════════════════════════

def ler_arquivo_csv(path: str, sep: str = ";", header_row: int = 1,
                    infer_schema: bool = True) -> DataFrame:
    """Lê CSV do ABFSS. header_row=1 → primeira linha é cabeçalho."""
    return (
        spark.read.format("csv")
        .option("delimiter", sep)
        .option("header", str(header_row == 1).lower())
        .option("inferSchema", str(infer_schema).lower())
        .option("encoding", "UTF-8")
        .load(path)
    )


def salvar_arquivo(df: DataFrame, nome: str, template: str,
                   execucao: str) -> str:
    """Salva DF como CSV no Volume de validação. Retorna caminho."""
    caminho = f"{VALIDATION_OUTPUT}{template}/{execucao}/{nome}"
    df.coalesce(1).write.mode("overwrite").option("header", True).csv(caminho)
    return caminho


def salvar_log(template: str, regra: str, tipo: str,
               execucao: str, caminho: str) -> None:
    """Imprime log formatado."""
    print(f"   📝 [{tipo}] {template} | {regra} | {execucao} → {caminho}")


log_erro = "ERRO"
log_ok   = "OK"


def validar_arquivo_csv(df: DataFrame, execucao: str,
                        campos_obrigatorios: list) -> bool:
    """Regra 1: Valida campos obrigatórios (NOT NULL). Retorna True se OK."""
    erros = 0
    for campo in campos_obrigatorios:
        if campo not in df.columns:
            print(f"  ⚠️  Coluna {campo} ausente no DataFrame!")
            erros += 1
            continue
        nulos = df.filter(col(campo).isNull() | (trim(col(campo)) == "")).count()
        if nulos > 0:
            print(f"  ❌ {campo}: {nulos} registros nulos/vazios")
            erros += 1
        else:
            print(f"  ✅ {campo}: OK")
    return erros == 0


def comparar_chaves_varios(df_base: DataFrame, dfs_ref: list,
                           chaves_base: list, chaves_ref: list) -> DataFrame:
    """Retorna linhas de df_base cujas chaves NÃO existem em nenhum df_ref."""
    df_encontrados = None
    for df_r in dfs_ref:
        cond = [col(f"b.{cr}") == col(f"a.{cb}")
                for cb, cr in zip(chaves_base, chaves_ref)]
        joined = (
            df_base.alias("a")
            .join(df_r.alias("b"), reduce(operator.and_, cond), "inner")
            .select([col(f"a.{c}") for c in df_base.columns])
        )
        df_encontrados = joined if df_encontrados is None else df_encontrados.unionByName(joined)
    if df_encontrados is None:
        return df_base
    return df_base.join(
        df_encontrados.select(chaves_base).distinct(),
        on=chaves_base, how="left_anti"
    )

# COMMAND ----------

# ═══════════════════════════════════════════════════════════════════════════════
#  SEÇÃO 2 — Funções Silver (bronze → silver)
# ═══════════════════════════════════════════════════════════════════════════════

def save_table(df: DataFrame, table: str) -> None:
    """Grava um DataFrame como tabela Delta com overwrite."""
    (
        df.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(table)
    )
    print(f"✅ Gravado: {table} ({df.count()} registros)")


def null_to_empty(df: DataFrame, cols_list: list) -> DataFrame:
    """Substitui NULL por string vazia nas colunas informadas."""
    for c in cols_list:
        if c in df.columns:
            df = df.withColumn(c, F.coalesce(F.col(c).cast(StringType()), F.lit("")))
    return df


def add_id_hash(df: DataFrame) -> DataFrame:
    """Adiciona coluna id_hash (MD5) a partir de todas as colunas."""
    colunas_hash = [coalesce(col(c).cast(StringType()), lit("")) for c in df.columns]
    return df.withColumn("id_hash", md5(concat_ws("|", *colunas_hash)))


def schema_gp_bronze() -> StructType:
    """Retorna o schema da tabela Bronze do GP."""
    campos = [
        "CD_EMPRESA","DS_EMPRESA","CD_UNIDADE","DS_UNIDADE",
        "CD_LOCAL_FISICO","CD_ESTABELECIMENTO","DT_ADMISSAO","DT_DEMISSAO",
        "DS_SITUACAO","NM_NOME","CLASSIFICACAO_TIPO_DE_AFAST",
        "D_CLASSIFICACAO_TIPO_DE_AFAST","CLASSIFICACAO_REAF","D_CLASSIFICACAO_REAF",
        "STATUS","PERNR","ID_ATEST","BEGDA_ATEST","ENDDA_ATEST",
        "NDIAS_AFAST","D_SEXTO_DIA","DUR_AUSEN","STATUS_ESOC",
        "ENTREG_ATEST","DUPLIC_ATEST","CID1","CID2","NOME_EMIT",
        "NUM_OC","CRM","UF_OC","COD_ESOC","TP_ACID","HV_CONV",
        "CONV_BEN","DT_CONV","ORIG_RETIF","TP_PROCE","NUM_PROC_PREV",
        "ATEST_ANTE","DIAS_ANTE","MOT_ANTE","RESP_ANTE","REAFAST_MESMO_MOT",
        "ATEST_RELA","RESP_ANTE_TEXT","INFO_ADD","REC_ESOC","REC_ESOC_2",
        "OBS_ATEST","MODIF_USER","MODIF_DATE","REG_LOCL",
        "MODIF_USER_2","MODIF_DATE_2","MODIF_LOCL_2","PERNR_PERI",
        "ID_ATEST_REL","BEGDA_PREV","ENDDA_PREV","DUPLIC_GEST",
        "MOT_AFAST","DATE_INICAFAST","DT_PERI","RESULTADO","OBS_PER",
        "ENC_INSS","SIT_INSS","DT_REQ","NUM_REQ","NUM_BEN","TPBEN",
        "DT_INI_BENE","DIAS_BENE","BEN_CESS","INAPTO","DT_CESS_BEN",
        "DT_ALTA","CONC_API","DT_IN_API","DT_FIM_API","DT_REC",
        "NUM_REQREC","DT_LIM","DT_FIM_LIMBO","REAB_CERT","DT_REAB",
        "CAN_BEN","DT_CAN_BEN","DT_TRANS_NEXO","DT_CONV_BEN","TP_NEXO",
        "HV_CONT","DT_CONTEST_NEXO","NUM_OF_CONTEST","CONT_PRAZO",
        "STATUS_CONT","NEC_CONTEST","DT_NOT_JUR","OBS",
        "MODIF_USER_GEST","MODIF_DATE_GEST","REG_LOCL_GEST",
        "MODIF_USER_GEST_2","MODIF_DATE_GEST_2","MODIF_LOCL_GEST",
        "ID_HASH",
    ]
    return StructType([StructField(c, StringType(), True) for c in campos])


def format_cid_single(col_expr, default_empty="S/H"):
    """Formata CID: 3 chars mantém, 4 chars insere ponto, null→default."""
    c = F.trim(col_expr)
    return (
        F.when(c.isNull() | (c == "") | (c == "null"), F.lit(default_empty))
        .when(F.length(c) == 3, c)
        .when(F.length(c) == 4, F.concat(F.substring(c, 1, 3), F.lit("."), F.substring(c, 4, 1)))
        .otherwise(c)
    )


def clean_control_chars(df: DataFrame, cols_list: list) -> DataFrame:
    """Remove \\r, \\n, \\t e substitui | por /."""
    for c in cols_list:
        if c in df.columns:
            df = df.withColumn(c, F.regexp_replace(
                F.regexp_replace(F.regexp_replace(
                    F.regexp_replace(F.trim(F.col(c)), "\\r", ""), "\\n", ""),
                    "\\t", ""), "\\|", "/"))
    return df


def apply_defaults(df: DataFrame, defaults_map: dict) -> DataFrame:
    """Aplica valor padrão para colunas null/vazias."""
    for col_name, default_val in defaults_map.items():
        if col_name in df.columns:
            df = df.withColumn(col_name,
                F.when(F.trim(F.col(col_name)).isNull() | (F.trim(F.col(col_name)) == ""),
                       F.lit(default_val)).otherwise(F.col(col_name)))
    return df


def build_exclusion_filter(exclusions: list) -> F.Column:
    """Condição de exclusão a partir de tuplas (PERNR, BEGDA, ENDDA)."""
    cond = F.lit(False)
    for pernr, begda, endda in exclusions:
        cond = cond | ((F.col("PERNR") == pernr) & (F.col("_begda_norm") == begda) & (F.col("_endda_norm") == endda))
    return cond

# COMMAND ----------

# ═══════════════════════════════════════════════════════════════════════════════
#  SEÇÃO 3 — Funções genéricas de validação
# ═══════════════════════════════════════════════════════════════════════════════

def _is_filled(c):
    """Condição PySpark: coluna preenchida (não nula e não vazia)."""
    return F.col(c).isNotNull() & (F.trim(F.col(c)) != F.lit(""))

def _is_empty(c):
    """Condição PySpark: coluna vazia (nula ou string vazia)."""
    return F.col(c).isNull() | (F.trim(F.col(c)) == F.lit(""))

def to_date_ddmmyyyy(coluna):
    """Converte coluna string ddMMyyyy para date."""
    return F.to_date(F.col(coluna), "ddMMyyyy")


def validar_tamanho_formato(df: DataFrame, campos_tamanhos: dict,
                            template: str) -> None:
    """Regra 1.1 — Valida tamanho e formato de campos."""
    regex_data = r'^(?:0[1-9]|[12][0-9]|3[01])(?:0[1-9]|1[0-2])(?:19\d{2}|20\d{2})$'
    execucao = datetime.now().strftime("%Y%m%d%H%M")

    for campo, r in campos_tamanhos.items():
        if campo not in df.columns:
            continue
        tipo    = r.get("tipo", "fixo")
        tamanho = r.get("tamanho")
        formato = r.get("formato", "alfanumerico")
        excecao = r.get("excecao")

        base = _is_filled(campo)
        cond_tam = (F.length(F.col(campo)) != tamanho) if tipo == "fixo" else \
                   (F.length(F.col(campo)) > tamanho)  if tipo == "max"  else F.lit(False)

        fmt_map = {
            "alfanumerico":     r'^[A-Za-z0-9]+$',
            "numerico":         r'^[0-9]+$',
            "numerico_decimal": r'^[0-9]+([.,][0-9]+)?$',
            "numero_decimal":   r'^[0-9]+([.,][0-9]+)?$',
            "letra":            r'^[A-Za-zÀ-ÿ\s\W]+$',
            "letra_especial":   r'^[A-Za-zÀ-ÿ0-9\s\-\._]+$',
        }
        if formato in fmt_map:
            cond_fmt = ~F.col(campo).rlike(fmt_map[formato])
        elif formato == "data":
            cond_fmt = (~F.col(campo).rlike(r'^[0-9]{8}$')) | (~F.col(campo).rlike(regex_data))
            if excecao:
                cond_fmt = cond_fmt & (F.col(campo) != excecao)
        else:
            cond_fmt = F.lit(False)

        df_erro = df.filter(base & (cond_tam | cond_fmt))
        qtd = df_erro.count()
        if qtd > 0:
            print(f"  ❌ {campo}: {qtd} erros (tipo={tipo}, tam={tamanho}, fmt={formato})")
            caminho = salvar_arquivo(df_erro, f"regra1.1_{campo}", template, execucao)
            salvar_log(template, "regra1.1", log_erro, execucao, caminho)
        else:
            print(f"  ✅ {campo}: OK")


def validar_picklists(df: DataFrame, mapa_picklist: dict,
                      base_path: str, template: str) -> None:
    """Regra 1.2 — Valida campos contra picklists CSV."""
    execucao = datetime.now().strftime("%Y%m%d%H%M")
    for campo_df, info in mapa_picklist.items():
        if campo_df not in df.columns:
            continue
        try:
            pkl_df = ler_arquivo_csv(base_path + info["picklist"].strip(), ";", 1)
            valores = [row[info["campo"]] for row in pkl_df.select(info["campo"]).collect()]
        except Exception as e:
            print(f"  ⚠️  {campo_df}: erro ao ler picklist — {e}")
            continue
        df_erro = df.filter(_is_filled(campo_df) & ~F.col(campo_df).isin(valores))
        qtd = df_erro.count()
        if qtd > 0:
            print(f"  ❌ {campo_df}: {qtd} fora da picklist")
            caminho = salvar_arquivo(df_erro, f"regra1.2_{campo_df}", template, execucao)
            salvar_log(template, "regra1.2", log_erro, execucao, caminho)
        else:
            print(f"  ✅ {campo_df}: OK")


def valida_campos_devem_ser_vazios(df: DataFrame, campos: list) -> DataFrame:
    """Regra 1.3 — Retorna linhas onde algum campo que deveria ser vazio está preenchido."""
    cond = F.lit(False)
    for c in campos:
        if c in df.columns:
            cond = cond | _is_filled(c)
    return df.filter(cond)


def valida_dependentes_preenchidos(df: DataFrame, campo_gatilho: str,
                                   campos_dep: list) -> DataFrame:
    """Se campo_gatilho preenchido, todos campos_dep devem estar preenchidos."""
    df_f = df.filter(_is_filled(campo_gatilho))
    cond_erro = F.lit(False)
    for c in campos_dep:
        if c in df.columns:
            cond_erro = cond_erro | _is_empty(c)
    return df_f.filter(cond_erro)


def valida_data_operador(df: DataFrame, coluna_base: str,
                         colunas_comparacao: list,
                         condicao: str = "<") -> DataFrame:
    """Valida relação entre datas (ddMMyyyy) com operador. Retorna linhas em violação."""
    df2 = df.withColumn("_dt_base", to_date_ddmmyyyy(coluna_base))
    condicoes = []
    for cc in colunas_comparacao:
        df2 = df2.withColumn(f"_dt_{cc}", to_date_ddmmyyyy(cc))
        ops = {"<":">=", ">":"<=", "<=":">", ">=":"<", "==":"!=", "!=":"=="}
        inv = ops.get(condicao, ">=")
        expr_map = {
            ">=": F.col("_dt_base") >= F.col(f"_dt_{cc}"),
            "<=": F.col("_dt_base") <= F.col(f"_dt_{cc}"),
            ">":  F.col("_dt_base") > F.col(f"_dt_{cc}"),
            "<":  F.col("_dt_base") < F.col(f"_dt_{cc}"),
            "!=": F.col("_dt_base") != F.col(f"_dt_{cc}"),
            "==": F.col("_dt_base") == F.col(f"_dt_{cc}"),
        }
        condicoes.append(expr_map[inv])
    filtro = reduce(lambda a, b: a | b, condicoes)
    aux_cols = ["_dt_base"] + [f"_dt_{c}" for c in colunas_comparacao]
    return df2.filter(filtro).drop(*aux_cols)


def filtrar_erros_por_valor(df: DataFrame, colunas: List[str], valor) -> DataFrame:
    """Retorna linhas onde TODAS as colunas igualam o valor."""
    if not colunas:
        return df.limit(0)
    conds = [col(c) == lit(valor) for c in colunas]
    return df.filter(reduce(operator.and_, conds))

# COMMAND ----------

# ═══════════════════════════════════════════════════════════════════════════════
#  SEÇÃO 4 — Engine de execução de validações
# ═══════════════════════════════════════════════════════════════════════════════

def executar_validacoes(df: DataFrame, validacoes: list,
                        template: str) -> dict:
    """
    Motor principal de validação. Recebe o DF cacheado e a lista de regras.
    Cada regra: {numero, funcao, regra, nome_log}

    Otimizações:
      - df deve vir cacheado
      - usa .isEmpty() quando possível
      - salva erros apenas quando existem
    """
    execucao = datetime.now().strftime("%Y%m%d%H%M")
    resultados = {}

    for v in validacoes:
        numero = v["numero"]
        regra  = v["regra"]
        nome   = v["nome_log"]
        fn     = v["funcao"]

        print(f"🔗 Regra {numero} — {regra}")
        try:
            invalidos = fn(df) if callable(fn) else fn
        except Exception as e:
            print(f"  ⚠️  Erro na execução: {e}")
            resultados[numero] = -1
            continue

        if invalidos is None or invalidos.rdd.isEmpty():
            print(f"  ✅ Sem erros")
            resultados[numero] = 0
        else:
            qtd = invalidos.count()
            print(f"  ❌ {qtd} registros com erro")
            caminho = salvar_arquivo(invalidos, f"regra{numero}_{nome}", template, execucao)
            salvar_log(template, f"regra{numero}", log_erro, execucao, caminho)
            resultados[numero] = qtd

    total_erros = sum(v for v in resultados.values() if v > 0)
    total_ok    = sum(1 for v in resultados.values() if v == 0)
    print(f"\n{'='*60}")
    print(f"Resumo: {total_ok} regras OK | {len(resultados)-total_ok} com erro | {total_erros} registros inválidos")
    print(f"{'='*60}")
    return resultados

# COMMAND ----------

# ── print final ───────────────────────────────────────────────────────────────

print("utils.py carregado com sucesso.")
print("   Funções disponíveis:")
_funcs = [
    "save_table / null_to_empty / add_id_hash / schema_gp_bronze",
    "format_cid_single / clean_control_chars / apply_defaults / build_exclusion_filter",
    "ler_arquivo_csv / salvar_arquivo / salvar_log / validar_arquivo_csv",
    "comparar_chaves_varios / validar_tamanho_formato / validar_picklists",
    "valida_campos_devem_ser_vazios / valida_dependentes_preenchidos",
    "valida_data_operador / filtrar_erros_por_valor / executar_validacoes",
]
for f in _funcs:
    print(f"   · {f}")