# Databricks notebook source
# MAGIC %md
# MAGIC # Arquitetura padrão de tratamento de dados para SuccessFactors - Databricks
# MAGIC
# MAGIC > Este documento define o padrão arquitetural a ser seguido em todos os projetos de processamento de dados no Databricks.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## Índice
# MAGIC
# MAGIC 1. Visão Geral
# MAGIC 2. Estrutura de Pastas
# MAGIC 3. Camadas e Responsabilidades
# MAGIC 4. config.py — Configurações Centralizadas
# MAGIC 5. utils.py — Utilitários Reutilizáveis
# MAGIC 6. Notebooks Bronze — Ingestão
# MAGIC 7. Notebooks Silver — Transformação
# MAGIC 8. Consolidação Final
# MAGIC 9. Validation — Validação de Qualidade
# MAGIC 10. Dependências e Ordem de Execução no Job
# MAGIC 11. Convenções de Nomenclatura
# MAGIC 12. Checklist para Novos Projetos
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 1. Visão Geral
# MAGIC
# MAGIC A arquitetura é organizada em quatro responsabilidades fixas, separadas em pastas dedicadas:
# MAGIC
# MAGIC ```
# MAGIC config → utils → notebooks (bronze → silver) → validation
# MAGIC ```
# MAGIC
# MAGIC - **config** fornece todas as constantes do projeto.
# MAGIC - **utils** fornece todas as funções reutilizáveis, consumindo config via `%run`.
# MAGIC - **notebooks** executam as transformações, consumindo utils via `%run`.
# MAGIC - **validation** verifica a qualidade do output final de forma independente.
# MAGIC
# MAGIC Nenhuma constante de path, schema ou nome de tabela deve aparecer fora do `config.py`. Nenhuma função com mais de 5 linhas deve ser definida dentro de um notebook — ela pertence ao `utils.py`.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 2. Estrutura de Pastas
# MAGIC
# MAGIC ```
# MAGIC Nome do Projeto/
# MAGIC ├── config/
# MAGIC │   └── config.py
# MAGIC ├── utils/
# MAGIC │   └── utils.py
# MAGIC ├── notebooks/
# MAGIC │   ├── 01_<fonte_a>_bronze.py
# MAGIC │   ├── 02_<fonte_b>_bronze.py
# MAGIC │   ├── ...
# MAGIC │   ├── 0N_<transformacao>_silver.py
# MAGIC │   └── 0N_<consolidacao>_silver.py
# MAGIC └── validation/
# MAGIC     └── layout_validation.py
# MAGIC ```
# MAGIC
# MAGIC A pasta `notebooks/` agrupa todas as etapas de processamento em ordem numérica, da ingestão à entrega. Não há subpastas separando bronze e silver — a numeração e o sufixo no nome já comunicam a camada.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 3. Camadas e Responsabilidades
# MAGIC
# MAGIC | Camada | Onde fica | Responsabilidade | O que NÃO deve fazer |
# MAGIC |---|---|---|---|
# MAGIC | **Config** | `config/config.py` | Declarar constantes: paths, schemas, nomes de tabela, nomes de aba, listas de colunas finais | Conter lógica, imports ou transformações |
# MAGIC | **Utils** | `utils/utils.py` | Definir funções genéricas e reutilizáveis | Conter constantes de negócio ou lógica específica de uma fonte |
# MAGIC | **Bronze** | `notebooks/0N_*_bronze.py` | Ler o arquivo bruto e gravar na tabela Delta Bronze sem transformações | Aplicar regras de negócio ou renomear colunas além do necessário para ingestão |
# MAGIC | **Silver** | `notebooks/0N_*_silver.py` | Aplicar transformações, joins, deduplicação e gravar na tabela Delta Silver | Ler arquivos brutos diretamente — sempre partir da Bronze |
# MAGIC | **Validation** | `validation/layout_validation.py` | Comparar o output gerado com o arquivo de referência via hash-match | Gravar dados em tabelas ou alterar o estado do pipeline |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 4. `config.py` — Configurações Centralizadas
# MAGIC
# MAGIC ### O que sempre deve conter
# MAGIC
# MAGIC ```python
# MAGIC # Databricks notebook source
# MAGIC
# MAGIC # ── Paths de entrada ──────────────────────────────────────────────────────────
# MAGIC RAW_BASE         = "/Volumes/<catalog>/<schema_volume>/<volume>/raw_files"
# MAGIC FONTE_A_PATH     = f"{RAW_BASE}/arquivo_fonte_a.csv"
# MAGIC FONTE_B_PATH     = f"{RAW_BASE}/arquivo_fonte_b.xlsx"
# MAGIC
# MAGIC # ── Schemas Unity Catalog ─────────────────────────────────────────────────────
# MAGIC BRONZE_SCHEMA    = "<catalog>.bron_<projeto>"
# MAGIC SILVER_SCHEMA    = "<catalog>.silv_<projeto>"
# MAGIC
# MAGIC # ── Tabelas Bronze ────────────────────────────────────────────────────────────
# MAGIC BRONZE_FONTE_A   = f"{BRONZE_SCHEMA}.fonte_a_raw"
# MAGIC BRONZE_FONTE_B   = f"{BRONZE_SCHEMA}.fonte_b_raw"
# MAGIC
# MAGIC # ── Tabelas Silver ────────────────────────────────────────────────────────────
# MAGIC SILVER_RESULTADO = f"{SILVER_SCHEMA}.resultado_final"
# MAGIC
# MAGIC # ── Parâmetros de leitura ─────────────────────────────────────────────────────
# MAGIC FONTE_B_SHEET    = "Nome_Da_Aba"
# MAGIC
# MAGIC # ── Colunas finais do layout de entrega ───────────────────────────────────────
# MAGIC FINAL_COL_ORDER  = [
# MAGIC     "Coluna_A",
# MAGIC     "Coluna_B",
# MAGIC     ...
# MAGIC ]
# MAGIC
# MAGIC print("Configurações carregadas.")
# MAGIC ```
# MAGIC
# MAGIC ### Regras
# MAGIC
# MAGIC - Toda constante usada em mais de um notebook **obrigatoriamente** vai para o config.
# MAGIC - Paths de output (volumes de saída) também ficam no config.
# MAGIC - `FINAL_COL_ORDER` deve ser declarada no config sempre que a lista de colunas finais for compartilhada entre o notebook de consolidação e o de validação.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 5. `utils.py` — Utilitários Reutilizáveis
# MAGIC
# MAGIC ### Estrutura base
# MAGIC
# MAGIC ```python
# MAGIC # Databricks notebook source
# MAGIC %run "/Workspace/.../config/config"
# MAGIC
# MAGIC from pyspark.sql import DataFrame
# MAGIC from pyspark.sql import functions as F
# MAGIC import pandas as pd
# MAGIC import io
# MAGIC import openpyxl
# MAGIC
# MAGIC # Funções do projeto...
# MAGIC
# MAGIC print("Utilitários carregados.")
# MAGIC ```
# MAGIC
# MAGIC ### Funções padrão recomendadas
# MAGIC
# MAGIC Abaixo estão as funções que devem ser implementadas em todo projeto, adaptando parâmetros conforme necessário:
# MAGIC
# MAGIC | Função | Quando usar |
# MAGIC |---|---|
# MAGIC | `read_csv_semicolon(path)` | Toda vez que a fonte for um CSV com separador `;` |
# MAGIC | `read_excel(path, sheet_name, header_row)` | Toda vez que a fonte for um arquivo Excel/XLSM |
# MAGIC | `normalize_col(col_name, to_upper)` | Sempre que precisar padronizar nomes de colunas vindos de fontes externas |
# MAGIC | `rename_cols(df, to_upper)` | Aplicar `normalize_col` em todas as colunas de um DataFrame |
# MAGIC | `save_table(df, table)` | Toda gravação em tabela Delta — substitui o par `TRUNCATE + insertInto` |
# MAGIC | `prefix_df(df, prefix, join_col, join_alias)` | Antes de JOINs entre DataFrames com colunas de mesmo nome |
# MAGIC | `null_to_empty(df, cols)` | Antes de exportar o arquivo final, garantindo que não haja NULL nas colunas de entrega |
# MAGIC | `export_df_to_csv_excel(df, volume_path, file_base)` | Exportação do output final para o Volume |
# MAGIC
# MAGIC ### Exemplo de `save_table()`
# MAGIC
# MAGIC ```python
# MAGIC def save_table(df: DataFrame, table: str) -> None:
# MAGIC     """Trunca e reinsere um DataFrame como tabela Delta."""
# MAGIC     spark.sql(f"TRUNCATE TABLE {table}")
# MAGIC     df.write.insertInto(table)
# MAGIC     print(f"✅ Gravado: {table} ({df.count()} registros)")
# MAGIC ```
# MAGIC
# MAGIC > **Por que não usar `mode("overwrite")`?** O `overwrite` pode recriar a tabela e quebrar permissões, comentários e propriedades configuradas no Unity Catalog. O padrão `TRUNCATE + insertInto` preserva o schema registrado.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 6. Notebooks Bronze — Ingestão
# MAGIC
# MAGIC ### Responsabilidade
# MAGIC
# MAGIC Ler o arquivo bruto do Volume e gravar na tabela Delta Bronze **sem aplicar regras de negócio**. A única transformação permitida é a normalização dos nomes de colunas.
# MAGIC
# MAGIC ### Estrutura padrão
# MAGIC
# MAGIC ```python
# MAGIC # Databricks notebook source
# MAGIC %run ".../utils/utils"
# MAGIC
# MAGIC %pip install openpyxl
# MAGIC
# MAGIC # <NOME_FONTE> — Camada Bronze
# MAGIC
# MAGIC df_bronze = read_csv_semicolon(FONTE_A_PATH)   # ou read_excel(...)
# MAGIC df_bronze = rename_cols(df_bronze)
# MAGIC
# MAGIC print(f"Registros lidos: {df_bronze.count()}")
# MAGIC print(f"Colunas: {df_bronze.columns}")
# MAGIC display(df_bronze)
# MAGIC
# MAGIC save_table(df_bronze, BRONZE_FONTE_A)
# MAGIC ```
# MAGIC
# MAGIC ### Casos especiais
# MAGIC
# MAGIC **Fonte com header em linha diferente de 0 (ex: Excel com cabeçalho na linha 2):**
# MAGIC ```python
# MAGIC df_bronze = read_excel(FONTE_B_PATH, FONTE_B_SHEET, header_row=1)
# MAGIC ```
# MAGIC
# MAGIC **Fonte que depende de outra Bronze (ex: enriquecimento via DE-PARA):**
# MAGIC - Documentar a dependência no cabeçalho do notebook com um comentário explícito.
# MAGIC - Configurar a dependência no Databricks Job (não confiar apenas na numeração).
# MAGIC - Usar `F.broadcast()` na tabela pequena para otimizar o JOIN.
# MAGIC
# MAGIC ```python
# MAGIC # Depende de: 02_de_para_bronze (BRONZE_DE_PARA deve estar gravada antes)
# MAGIC df_de_para = spark.table(BRONZE_DE_PARA)
# MAGIC df = df.join(F.broadcast(df_de_para), on="chave", how="left")
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 7. Notebooks Silver — Transformação
# MAGIC
# MAGIC ### Responsabilidade
# MAGIC
# MAGIC Ler da camada Bronze, aplicar transformações de negócio e gravar na camada Silver. Nunca ler arquivos brutos diretamente.
# MAGIC
# MAGIC ### Tipos comuns de notebook Silver
# MAGIC
# MAGIC **Silver simples** — transformação de uma única fonte:
# MAGIC ```python
# MAGIC df = spark.table(BRONZE_FONTE_A)
# MAGIC
# MAGIC # transformações...
# MAGIC
# MAGIC save_table(df_silver, SILVER_RESULTADO)
# MAGIC ```
# MAGIC
# MAGIC **Silver de join** — consolida múltiplas fontes Bronze:
# MAGIC ```python
# MAGIC df_a = spark.table(BRONZE_FONTE_A)
# MAGIC df_b = spark.table(BRONZE_FONTE_B)
# MAGIC
# MAGIC df_b_j = prefix_df(df_b, "Prefixo_B", "chave_join", "_join_b")
# MAGIC
# MAGIC df_a.cache()
# MAGIC df_resultado = df_a.join(df_b_j, df_a["chave"] == df_b_j["_join_b"], "left").drop("_join_b")
# MAGIC df_a.unpersist()
# MAGIC
# MAGIC save_table(df_resultado, SILVER_RESULTADO)
# MAGIC ```
# MAGIC
# MAGIC **Silver de layout final** — prepara o DataFrame para entrega:
# MAGIC ```python
# MAGIC df = spark.table(SILVER_RESULTADO)
# MAGIC
# MAGIC # drop de colunas de diagnóstico
# MAGIC # renomeação para nomes de negócio
# MAGIC # reordenação por FINAL_COL_ORDER
# MAGIC # filtro final + deduplicação
# MAGIC df = null_to_empty(df, FINAL_COL_ORDER)
# MAGIC
# MAGIC save_table(df, SILVER_CONSOLIDADO)
# MAGIC export_df_to_csv_excel(df, OUTPUT_PATH, "Nome_Do_Template")
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 8. Consolidação Final
# MAGIC
# MAGIC Quando o projeto tiver múltiplas fontes Silver independentes que precisam ser unidas, o notebook de consolidação deve:
# MAGIC
# MAGIC 1. Carregar todas as tabelas Silver individuais.
# MAGIC 2. Fazer `unionByName()` garantindo que os schemas sejam compatíveis.
# MAGIC 3. Aplicar `dropDuplicates()` global.
# MAGIC 4. Validar duplicatas de chave primária antes de gravar.
# MAGIC 5. Gravar na tabela Silver consolidada.
# MAGIC 6. Exportar o arquivo final via `export_df_to_csv_excel()`.
# MAGIC
# MAGIC ```python
# MAGIC df_final = (
# MAGIC     df_fonte_a
# MAGIC     .unionByName(df_fonte_b)
# MAGIC     .unionByName(df_fonte_c)
# MAGIC     .filter(F.col("coluna_chave").isNotNull())
# MAGIC     .dropDuplicates()
# MAGIC     .orderBy("coluna_chave")
# MAGIC )
# MAGIC
# MAGIC # Verificação de IDs duplicados
# MAGIC duplicados = df_final.groupBy("ID_Externo").count().filter(F.col("count") > 1)
# MAGIC if duplicados.count() > 0:
# MAGIC     print(f"⚠️  {duplicados.count()} IDs duplicados detectados!")
# MAGIC else:
# MAGIC     print("✅ Nenhum ID duplicado — integridade OK.")
# MAGIC
# MAGIC save_table(df_final, SILVER_CONSOLIDADO)
# MAGIC ```
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 9. `validation` — Validação de Qualidade
# MAGIC
# MAGIC ### Objetivo
# MAGIC
# MAGIC Comparar o output gerado pelo pipeline com um arquivo de referência fornecido pelo cliente, usando hash-match row-by-row.
# MAGIC
# MAGIC ### Estrutura padrão
# MAGIC
# MAGIC ```python
# MAGIC # 1) Carrega o output gerado pelo pipeline
# MAGIC df_pipeline = spark.table(SILVER_CONSOLIDADO)
# MAGIC df_pipeline = null_to_empty(df_pipeline, FINAL_COL_ORDER)
# MAGIC
# MAGIC df_hash_pipeline = df_pipeline.withColumn(
# MAGIC     "hash_key",
# MAGIC     F.md5(F.concat_ws("||", *[
# MAGIC         F.coalesce(F.col(c).cast(StringType()), F.lit(""))
# MAGIC         for c in FINAL_COL_ORDER
# MAGIC     ]))
# MAGIC )
# MAGIC df_hash_pipeline.createOrReplaceTempView("df_pipeline")
# MAGIC
# MAGIC # 2) Carrega o arquivo de referência do cliente
# MAGIC df_ref = spark.read.format("csv").option("delimiter", ";").option("header", True).load(VALIDATION_PATH)
# MAGIC df_ref = null_to_empty(df_ref, FINAL_COL_ORDER)
# MAGIC
# MAGIC df_hash_ref = df_ref.withColumn(
# MAGIC     "hash_key",
# MAGIC     F.md5(F.concat_ws("||", *[
# MAGIC         F.coalesce(F.col(c), F.lit(""))
# MAGIC         for c in FINAL_COL_ORDER if c in df_ref.columns
# MAGIC     ]))
# MAGIC )
# MAGIC df_hash_ref.createOrReplaceTempView("df_ref")
# MAGIC
# MAGIC # 3) Comparação
# MAGIC result = spark.sql("""
# MAGIC     SELECT
# MAGIC         CASE WHEN r.hash_key IS NOT NULL THEN '✅ Match' ELSE '❌ Sem match' END AS status,
# MAGIC         p.*
# MAGIC     FROM df_pipeline p
# MAGIC     LEFT JOIN df_ref r ON p.hash_key = r.hash_key
# MAGIC """)
# MAGIC ```
# MAGIC
# MAGIC ### Gráfico de tempo de execução
# MAGIC
# MAGIC O notebook de validação também deve conter o bloco de integração com a API do Databricks Jobs para plotar o tempo de execução de cada notebook da última run, diferenciando notebooks paralelos dos sequenciais. Isso facilita a identificação de gargalos de performance ao longo do tempo.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 10. Dependências e Ordem de Execução no Job
# MAGIC
# MAGIC ### Princípio
# MAGIC
# MAGIC Notebooks Bronze de fontes independentes sempre devem ser configurados para execução **em paralelo** no Job. A dependência sequencial só deve existir quando há relação real de dados entre dois notebooks.
# MAGIC
# MAGIC ### Modelo de configuração
# MAGIC
# MAGIC ```
# MAGIC Momento 1 (paralelo)
# MAGIC     → 01_fonte_a_bronze
# MAGIC     → 02_fonte_b_bronze
# MAGIC     → 03_fonte_c_bronze
# MAGIC     → ...
# MAGIC
# MAGIC Momento 2 (notebooks com dependência de outro Bronze)
# MAGIC     → 0N_fonte_x_bronze   ← depende de 02_fonte_b_bronze
# MAGIC
# MAGIC Momento 3 (Silver de join — aguarda todos os Bronze)
# MAGIC     → 0N_<join>_silver
# MAGIC
# MAGIC Momento 4 (Silver de layout — aguarda o Silver de join)
# MAGIC     → 0N_<layout>_silver
# MAGIC
# MAGIC Momento 5 (opcional — validação)
# MAGIC     → validation/layout_validation
# MAGIC ```
# MAGIC
# MAGIC ### Regras
# MAGIC
# MAGIC - Nunca usar apenas a numeração para inferir paralelismo — configurar explicitamente as dependências no Job.
# MAGIC - Documentar no cabeçalho do notebook toda dependência não óbvia.
# MAGIC - Notebooks de validação nunca devem bloquear a entrega — podem ser configurados como tarefa opcional ou separada.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 11. Convenções de Nomenclatura
# MAGIC
# MAGIC ### Notebooks
# MAGIC
# MAGIC | Padrão | Exemplo | Significado |
# MAGIC |---|---|---|
# MAGIC | `0N_<fonte>_bronze.py` | `03_ghe_bronze.py` | Ingestão da fonte GHE na Bronze |
# MAGIC | `0N_<transformacao>_silver.py` | `07_formata_matriz_silver.py` | Transformação silver de join/formatação |
# MAGIC | `0N_<entrega>_silver.py` | `08_arquivo_layout_sap_silver.py` | Silver final de entrega |
# MAGIC
# MAGIC ### Tabelas Delta
# MAGIC
# MAGIC | Camada | Padrão | Exemplo |
# MAGIC |---|---|---|
# MAGIC | Bronze | `<catalog>.bron_<projeto>.<fonte>_raw` | `humanresources_insight.bron_pcehsmatriz.ghe_raw` |
# MAGIC | Silver | `<catalog>.silv_<projeto>.<nome_logico>` | `humanresources_insight.silv_pcehsmatriz.formata_matriz` |
# MAGIC
# MAGIC ### Variáveis no config
# MAGIC
# MAGIC | Tipo | Padrão | Exemplo |
# MAGIC |---|---|---|
# MAGIC | Path de entrada | `<FONTE>_INPUT_PATH` | `GHE_INPUT_PATH` |
# MAGIC | Tabela Bronze | `BRONZE_<FONTE>` | `BRONZE_GHE` |
# MAGIC | Tabela Silver | `SILVER_<NOME>` | `SILVER_CONSOLIDADO` |
# MAGIC | Aba de Excel | `<FONTE>_SHEET_NAME` | `GHE_SHEET_NAME` |
# MAGIC | Colunas finais | `FINAL_COL_ORDER` | `FINAL_COL_ORDER` |
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC ## 12. Checklist para Novos Projetos
# MAGIC
# MAGIC Use este checklist ao iniciar um novo projeto seguindo esta arquitetura.
# MAGIC
# MAGIC ### Setup inicial
# MAGIC
# MAGIC - [ ] Criar a estrutura de pastas: `config/`, `utils/`, `notebooks/`, `validation/`
# MAGIC - [ ] Criar `config.py` com todos os paths, schemas e nomes de tabela
# MAGIC - [ ] Criar `utils.py` com as funções padrão e o `%run` do config
# MAGIC - [ ] Criar as tabelas Delta no Unity Catalog (Bronze e Silver) com os schemas corretos
# MAGIC
# MAGIC ### Por fonte de dado
# MAGIC
# MAGIC - [ ] Criar notebook `0N_<fonte>_bronze.py`
# MAGIC - [ ] Verificar se há dependência com outra Bronze — se sim, documentar e configurar no Job
# MAGIC - [ ] Testar a ingestão com `display()` antes de gravar
# MAGIC - [ ] Confirmar contagem e schema após `save_table()`
# MAGIC
# MAGIC ### Transformações Silver
# MAGIC
# MAGIC - [ ] Partir sempre da tabela Bronze — nunca do arquivo bruto
# MAGIC - [ ] Usar `prefix_df()` antes de JOINs com colunas de mesmo nome
# MAGIC - [ ] Usar `cache()` / `unpersist()` em DataFrames reutilizados em múltiplos JOINs
# MAGIC - [ ] Validar duplicatas antes de gravar a Silver final
# MAGIC - [ ] Usar `null_to_empty()` antes de exportar
# MAGIC
# MAGIC ### Entrega e validação
# MAGIC
# MAGIC - [ ] Confirmar que `FINAL_COL_ORDER` está no config e é usada tanto pelo notebook de entrega quanto pelo de validação
# MAGIC - [ ] Testar `export_df_to_csv_excel()` no Volume de output
# MAGIC - [ ] Executar `validation/layout_validation.py` e confirmar 100% de match (ou investigar divergências)
# MAGIC
# MAGIC ### Job
# MAGIC
# MAGIC - [ ] Configurar paralelismo correto (fontes independentes em paralelo)
# MAGIC - [ ] Configurar dependências sequenciais onde há relação de dados
# MAGIC - [ ] Validar tempo total de execução pelo gráfico do notebook de validação
# MAGIC