# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EC - 49/utils/utils"

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window

# COMMAND ----------

# CARGA
df_strings = read_table(PS_STRINGS_TBL).alias("s")
df_region = read_table(PS_REG_REGION_TBL).alias("rr")
df_conv = read_table(PS_CONV_TBL).alias("v")
df_job = read_table(PS_JOB).alias("j")
df_pers_data = read_table(PS_PERS_DATA).alias("ef")
df_employment = read_table(PS_EMPLOYMENT).alias("e")
df_tmp_dat = read_table(PS_TMP_DAT2).alias("x")

# PREPARAÇÕES
date_ptp_value = get_date_ptp(df_strings.select(F.col("s.string_id"), F.col("s.string_text")))
df_ini_mov = get_ptp_ini_mov(df_strings.select(F.col("s.string_id"), F.col("s.string_text")))

df_region_filtered = F.broadcast(
    df_region.filter(F.col("rr.country").isin(PAISES_ASIA))
)

df_conv_asia = F.broadcast(
    df_conv
    .filter(F.col("v.v_convert_id") == "ABSENCE_ASIA")
    .withColumn("action_reason_key", F.substring(F.col("v.descr100"), 1, 11))
    .withColumn(
        "sex_indicator",
        F.when(F.substring(F.col("v.descr100"), 12, 1) == "|", F.lit(""))
         .otherwise(F.substring(F.col("v.descr100"), 12, 1))
    )
    .withColumn(
        "end_action_key",
        F.when(
            F.substring(F.col("v.descr100"), 12, 1) == "|",
            F.substring(F.col("v.descr100"), 17, 7)
        ).otherwise(F.substring(F.col("v.descr100"), 18, 7))
    )
)

df_pers_enriched = build_pers_enriched(
    df_pers_data.select(F.col("ef.emplid"), F.col("ef.effdt"), F.col("ef.sex"))
).alias("ef")

df_tmp_filtered = (
    df_tmp_dat
    .filter(F.col("x.processtype") == "GO_LIVE")
    .select(
        F.col("x.oprid").alias("user_id"),
        F.col("x.vp_emplid"),
        F.col("x.empl_rcd")
    )
    .alias("x")
)

# JOIN PRINCIPAL
df_job_filtered = df_job.filter(F.col("j.effdt") <= F.lit(date_ptp_value)).alias("j")

df_main = (
    df_job_filtered
    .join(df_region_filtered, F.col("j.reg_region") == F.col("rr.reg_region"), "inner")
    .join(
        df_tmp_filtered,
        (F.col("j.emplid") == F.col("x.vp_emplid")) &
        (F.col("j.empl_rcd") == F.col("x.empl_rcd")),
        "inner"
    )
    .join(df_pers_enriched, F.col("j.emplid") == F.col("ef.emplid"), "inner")
    .withColumn("action_key",
                F.concat(F.lit("INI|"), F.col("j.action"), F.lit("|"), F.col("j.action_reason")))
    .join(
        df_conv_asia,
        (F.col("action_key") == F.col("action_reason_key")) &
        ((F.col("sex_indicator") == "") | (F.col("sex_indicator") == F.col("sex_normalized"))),
        "inner"
    )
    .select(
        F.col("user_id"),
        F.col("v.v_char_to").alias("timeType_externalCode"),
        F.col("j.emplid").alias("emplid"),
        F.col("j.empl_rcd").alias("empl_rcd"),
        F.col("j.effdt").alias("effdt"),
        F.col("j.effseq").alias("effseq"),
        F.col("j.action").alias("action"),
        F.col("j.action_reason").alias("action_reason"),
        F.col("sex_normalized"),
        F.col("end_action_key")
    )
)

# MAIOR EFFDT/EFFSEQ POR EMPLID
df_main = df_main.withColumn(
    "effdt_seq_key",
    F.concat(F.date_format(F.col("effdt"), "yyyyMMdd"), F.lpad(F.col("effseq"), 4, "0"))
)

w_max = Window.partitionBy("emplid", "empl_rcd").orderBy(F.col("effdt_seq_key").desc())
df_main = (
    df_main
    .withColumn("max_effdt_seq", F.first(F.col("effdt_seq_key")).over(w_max))
    .filter(F.col("effdt_seq_key") == F.col("max_effdt_seq"))
)

# DATA DE FIM (PRÓXIMA ACTION)
df_conv_end = df_conv_asia.select(
    F.col("end_action_key"),
    F.col("sex_indicator").alias("sex_ind_end")
).alias("cv2")

df_job_next = df_job.select(
    F.col("j.emplid").alias("next_emplid"),
    F.col("j.empl_rcd").alias("next_empl_rcd"),
    F.col("j.effdt").alias("next_effdt"),
    F.col("j.effseq").alias("next_effseq"),
    F.col("j.action").alias("next_action"),
    F.col("j.action_reason").alias("next_action_reason"),
    F.concat(
        F.date_format(F.col("j.effdt"), "yyyyMMdd"),
        F.lpad(F.col("j.effseq"), 4, "0")
    ).alias("next_effdt_seq_key")
).alias("r")

df_with_next = (
    df_main
    .join(
        df_job_next,
        (F.col("emplid") == F.col("next_emplid")) &
        (F.col("empl_rcd") == F.col("next_empl_rcd")) &
        (F.col("next_effdt_seq_key") > F.col("effdt_seq_key")),
        "left"
    )
    .withColumn("next_action_key",
                F.concat(F.col("next_action"), F.lit("|"), F.col("next_action_reason")))
)

df_with_end_validated = df_with_next.join(
    df_conv_end,
    (F.col("next_action_key") == F.col("cv2.end_action_key")) &
    ((F.col("cv2.sex_ind_end") == "") | (F.col("cv2.sex_ind_end") == F.col("sex_normalized"))),
    "left"
)

w_min_end = Window.partitionBy("emplid", "empl_rcd", "effdt_seq_key").orderBy(F.col("next_effdt").asc())
df_with_end_date = (
    df_with_end_validated
    .withColumn("rn_end", F.row_number().over(w_min_end))
    .filter((F.col("rn_end") == 1) | F.col("next_effdt").isNull())
    .withColumn(
        "endDate_calc",
        F.when(
            F.col("next_effdt").isNotNull(),
            F.when(F.col("next_effdt") == F.col("effdt"),
                   F.date_add(F.col("next_effdt"), 1))
             .otherwise(F.col("next_effdt"))
        )
    )
)

# VERIFICAÇÃO: NÃO PODE HAVER ACTION POSTERIOR
df_job_after = (
    df_job
    .filter(F.col("j.effdt") <= F.lit(date_ptp_value))
    .select(
        F.col("j.emplid").alias("after_emplid"),
        F.col("j.empl_rcd").alias("after_empl_rcd"),
        F.col("j.action").alias("after_action"),
        F.col("j.action_reason").alias("after_action_reason"),
        F.concat(
            F.date_format(F.col("j.effdt"), "yyyyMMdd"),
            F.lpad(F.col("j.effseq"), 4, "0")
        ).alias("after_effdt_seq_key")
    )
    .alias("b")
)

df_conv_after = df_conv_asia.select(
    F.col("action_reason_key").alias("after_conv_key"),
    F.col("sex_indicator").alias("sex_ind_after")
).alias("cv3")

df_final_check = (
    df_with_end_date
    .join(
        df_job_after,
        (F.col("emplid") == F.col("after_emplid")) &
        (F.col("empl_rcd") == F.col("after_empl_rcd")) &
        (F.col("after_effdt_seq_key") > F.col("effdt_seq_key")) &
        (F.col("after_effdt_seq_key") <=
         F.concat(F.date_format(F.lit(date_ptp_value), "yyyyMMdd"), F.lit("9999"))),
        "left"
    )
    .withColumn("after_action_key",
                F.concat(F.lit("INI|"), F.col("after_action"), F.lit("|"), F.col("after_action_reason")))
    .join(
        df_conv_after,
        (F.col("after_action_key") == F.col("cv3.after_conv_key")) &
        ((F.col("cv3.sex_ind_after") == "") | (F.col("cv3.sex_ind_after") == F.col("sex_normalized"))),
        "left"
    )
    .filter(F.col("cv3.after_conv_key").isNull())
)

# SELEÇÃO FINAL
df_base = (
    df_final_check
    .select(
        F.col("user_id"),
        F.col("timeType_externalCode"),
        F.date_format(F.col("effdt"), "dd/MM/yyyy").alias("startDate"),
        F.coalesce(
            F.date_format(F.date_sub(F.col("endDate_calc"), 1), "dd/MM/yyyy"),
            F.lit("")
        ).alias("endDate"),
        F.col("emplid"),
        F.col("empl_rcd")
    )
    .distinct()
)

df_with_emp = df_base.join(
    df_employment.select(
        F.col("e.emplid").alias("e_emplid"),
        F.col("e.hire_dt"),
        F.col("e.rehire_dt")
    ),
    F.col("emplid") == F.col("e_emplid"),
    "inner"
)

df_filtered = (
    df_with_emp
    .crossJoin(df_ini_mov)
    .filter(
        (F.coalesce(F.to_date(F.col("endDate"), "dd/MM/yyyy"), F.col("ptp_ini_mov")) >= F.col("ptp_ini_mov")) &
        (F.coalesce(
            F.col("e.rehire_dt"),
            F.coalesce(F.col("e.hire_dt"), F.to_date(F.col("startDate"), "dd/MM/yyyy"))
        ) <= F.to_date(F.col("startDate"), "dd/MM/yyyy"))
    )
)

df_result = df_filtered.select(
    F.col("user_id"),
    F.col("timeType_externalCode"),
    F.col("startDate"),
    F.col("endDate"),
    F.lit("APPROVED").alias("approvalStatus"),
    F.lit("").alias("quantityInDays"),
    F.lit("").alias("quantityInHours"),
    F.lit("").alias("workflowRequestId"),
    F.lit("").alias("cancellationWorkflowRequestId"),
    F.coalesce(
        F.datediff(F.to_date(F.col("endDate"), "dd/MM/yyyy"),
                   F.to_date(F.col("startDate"), "dd/MM/yyyy")) + 1,
        F.lit(0)
    ).alias("fractionQuantity"),
    F.lit("TRUE").alias("editable"),
    F.lit("").alias("loaStartJobInfoId"),
    F.lit("").alias("loaEndJobInfoId"),
    F.coalesce(
        F.date_format(F.date_add(F.to_date(F.col("endDate"), "dd/MM/yyyy"), 1), "dd/MM/yyyy"),
        F.date_format(F.add_months(F.to_date(F.col("startDate"), "dd/MM/yyyy"), 24), "dd/MM/yyyy")
    ).alias("loaExpectedReturnDate"),
    F.coalesce(F.trim(F.col("endDate")), F.lit("")).alias("loaActualReturnDate"),
    F.lit("FALSE").alias("flexibleRequesting"),
    F.lit("").alias("deductionQuantity"),
    F.lit("").alias("startTime"),
    F.lit("").alias("endTime"),
    F.lit("FALSE").alias("undeterminedEndDate"),
    F.lit("").alias("recurrenceGroup"),
    F.lit("").alias("displayQuantity"),
    F.lit("").alias("physicalStartDate"),
    F.lit("").alias("physicalEndDate"),
    F.lit("").alias("externalCode")
)

df_typed  = apply_sf_types(df_result)
df_output = select_final_ec49(df_output)

print(df_output.count())
display(df_output)
# save_table(df_output, SILVER_EXTRATOR_ASIA)