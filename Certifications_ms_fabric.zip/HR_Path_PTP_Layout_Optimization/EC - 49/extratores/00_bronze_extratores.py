# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EC - 49/utils/utils"

# COMMAND ----------

# Arquivos de Controle
load_bronze(PS_STRINGS_TBL, BRONZE_STRINGS_TBL)
load_bronze(PS_REG_REGION_TBL, BRONZE_REG_REGION_TBL)
load_bronze(PS_CONV_TBL, BRONZE_CONV_TBL)

# Arquivos Principais
load_bronze(PS_JOB, BRONZE_JOB)
load_bronze(PS_PERS_DATA, BRONZE_PERS_DATA)
load_bronze(PS_EMPLOYMENT, BRONZE_EMPLOYMENT)
load_bronze(PS_TMP_DAT2, BRONZE_TMP_DAT2)

print("Carga Bronze Extratores EC-49 concluída.")