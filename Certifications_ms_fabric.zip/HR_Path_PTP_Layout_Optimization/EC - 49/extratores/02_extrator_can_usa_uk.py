# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EC - 49/utils/utils"

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window

# COMMAND ----------

# CARGA
df_strings = read_table(BRONZE_STRINGS_TBL).alias("s")
df_reg_region = read_table(BRONZE_REG_REGION_TBL).alias("rr")
df_conv_tbl = read_table(BRONZE_CONV_TBL).alias("v")
df_job = read_table(BRONZE_JOB).alias("j")
df_pers_data = read_table(BRONZE_PERS_DATA).alias("ef")
df_employment = read_table(BRONZE_EMPLOYMENT).alias("e")
df_tmp_dat2 = read_table(BRONZE_TMP_DAT2).alias("x")

# PREPARAÇÕES
date_ptp = get_date_ptp(df_strings.select(F.col("s.string_id"), F.col("s.string_text")))
ptp_ini_mov = get_ptp_ini_mov(df_strings.select(
    F.col("s.string_id"), F.col("s.string_text"))
).first()["ptp_ini_mov"]

# Tabela de conversão ABSENCE_CAN_USA_UK
df_conv_absence = (
    df_conv_tbl
    .filter(F.col("v_convert_id") == "ABSENCE_CAN_USA_UK")
    .cache()
)

df_conv_position = (
    df_conv_absence
    .filter(F.substring(F.col("descr100"), 1, 12) == "INI_POSITION")
    .withColumn("position_nbr",      F.substring(F.col("descr100"), 14, 8))
    .withColumn("end_action_reason", F.substring(F.col("descr100"), 27, 7))
)

df_conv_ini = (
    df_conv_absence
    .filter(F.substring(F.col("descr100"), 1, 4) == "INI|")
    .withColumn("action_reason_key", F.substring(F.col("descr100"), 5, 7))
    .withColumn("gender_flag",       F.substring(F.col("descr100"), 12, 1))
    .withColumn("end_action_offset",
                F.when(F.substring(F.col("descr100"), 12, 1) == "|", 17).otherwise(18))
    .withColumn("end_action_reason",
                F.expr("substring(descr100, end_action_offset, 7)"))
)

df_reg_region_filtered = F.broadcast(
    df_reg_region.filter(F.col("country").isin(PAISES_CAN_USA_UK))
)

df_tmp_dat2_filtered = df_tmp_dat2.filter(F.col("processtype") == "GO_LIVE")

df_job_prepared = (
    df_job
    .withColumn("job_key",
                F.concat(
                    F.lpad(F.date_format(F.col("effdt"), "yyyyMMdd"), 8, "0"),
                    F.lpad(F.col("effseq").cast("string"), 4, "0")
                ))
    .withColumn("action_reason_key",
                F.concat(F.col("action"), F.lit("|"), F.col("action_reason")))
    .filter(F.col("effdt") <= F.lit(date_ptp))
)

df_pers_with_rank = build_pers_enriched(
    df_pers_data.select(
        F.col("ef.emplid"), F.col("ef.effdt"), F.col("ef.sex")
    )
).withColumnRenamed("sex_normalized", "gender_decoded")

# UNION PARTE 1 — INI_POSITION
df_union1_base = (
    df_job_prepared
    .select(
        F.col("emplid").alias("j_emplid"),
        F.col("empl_rcd").alias("j_empl_rcd"),
        F.col("job_key").alias("j_job_key"),
        F.col("effdt").alias("j_effdt"),
        F.col("position_nbr").alias("j_position_nbr"),
        F.col("action_reason_key").alias("j_action_reason_key"),
        F.col("reg_region").alias("j_reg_region")
    )
    .join(df_conv_position.select(
        F.col("position_nbr").alias("v_position_nbr"),
        F.col("v_char_to").alias("v_char_to"),
        F.col("end_action_reason").alias("v_end_action_reason")
    ), F.col("j_position_nbr") == F.col("v_position_nbr"), "inner")
    .join(df_reg_region_filtered.select(
        F.col("reg_region").alias("rr_reg_region"),
        F.col("country").alias("rr_country")
    ), F.col("j_reg_region") == F.col("rr_reg_region"), "inner")
    .join(df_tmp_dat2_filtered.select(
        F.col("vp_emplid").alias("x_vp_emplid"),
        F.col("empl_rcd").alias("x_empl_rcd"),
        F.col("oprid").alias("x_oprid")
    ), (F.col("j_emplid") == F.col("x_vp_emplid")) & (F.col("j_empl_rcd") == F.col("x_empl_rcd")), "inner")
    .join(df_pers_with_rank.select(
        F.col("emplid").alias("ef_emplid"),
        F.col("gender_decoded").alias("ef_gender_decoded")
    ), F.col("j_emplid") == F.col("ef_emplid"), "inner")
)

# End dates UNION 1
df_job_for_end_1 = (
    df_job_prepared
    .select(
        F.col("emplid").alias("r_emplid"),
        F.col("empl_rcd").alias("r_empl_rcd"),
        F.col("job_key").alias("r_job_key"),
        F.col("effdt").alias("r_effdt"),
        F.col("effseq").alias("r_effseq"),
        F.col("action_reason_key").alias("r_action_reason_key")
    )
    .join(df_conv_position.select(
        F.col("end_action_reason").alias("v2_end_action_reason")
    ).distinct(), F.col("r_action_reason_key") == F.col("v2_end_action_reason"), "inner")
)

window_next_1 = Window.partitionBy("base_emplid", "base_empl_rcd", "base_job_key").orderBy("r_effdt", "r_effseq")

df_end_dates_1 = (
    df_union1_base
    .select(
        F.col("j_emplid").alias("base_emplid"),
        F.col("j_empl_rcd").alias("base_empl_rcd"),
        F.col("j_job_key").alias("base_job_key"),
        F.col("j_effdt").alias("base_effdt")
    ).distinct()
    .join(df_job_for_end_1,
          (F.col("base_emplid") == F.col("r_emplid")) &
          (F.col("base_empl_rcd") == F.col("r_empl_rcd")) &
          (F.col("r_job_key") > F.col("base_job_key")), "left")
    .withColumn("adjusted_effdt",
                F.when(F.col("r_effdt") == F.col("base_effdt"), F.date_add(F.col("r_effdt"), 1))
                 .otherwise(F.col("r_effdt")))
    .withColumn("rank", F.row_number().over(window_next_1))
    .filter(F.col("rank") == 1)
    .select(
        F.col("base_emplid"),
        F.col("base_job_key"),
        F.date_sub(F.col("adjusted_effdt"), 1).alias("end_date")
    )
)

# NOT EXISTS conditions UNION 1
df_ne1 = (
    df_job_prepared
    .select(F.col("emplid").alias("b1_emplid"), F.col("empl_rcd").alias("b1_empl_rcd"),
            F.col("job_key").alias("b1_job_key"), F.col("position_nbr").alias("b1_position_nbr"))
    .join(df_conv_position.select(F.col("position_nbr").alias("cv21_position_nbr")).distinct(),
          F.col("b1_position_nbr") == F.col("cv21_position_nbr"), "inner")
)
df_u1s1 = df_union1_base.join(df_ne1,
    (F.col("j_emplid") == F.col("b1_emplid")) & (F.col("j_empl_rcd") == F.col("b1_empl_rcd")) &
    (F.col("b1_job_key") > F.col("j_job_key")) & (F.col("b1_position_nbr") != F.col("j_position_nbr")),
    "left_anti")

df_ne2 = (
    df_job_prepared
    .select(F.col("emplid").alias("b2_emplid"), F.col("empl_rcd").alias("b2_empl_rcd"),
            F.col("job_key").alias("b2_job_key"), F.col("action_reason_key").alias("b2_action_reason_key"))
    .join(df_conv_ini.select(F.col("action_reason_key").alias("cv22_action_reason_key"),
                             F.col("gender_flag").alias("cv22_gender_flag")),
          F.col("b2_action_reason_key") == F.col("cv22_action_reason_key"), "inner")
    .join(df_pers_with_rank.select(F.col("emplid").alias("ef2_emplid"), F.col("gender_decoded").alias("ef2_gender")),
          F.col("b2_emplid") == F.col("ef2_emplid"), "inner")
    .filter(F.coalesce(F.when(F.col("cv22_gender_flag") == "|", F.lit("")), F.col("ef2_gender")) == F.col("ef2_gender"))
    .select("b2_emplid", "b2_empl_rcd", "b2_job_key")
)
df_u1s2 = df_u1s1.join(df_ne2,
    (F.col("j_emplid") == F.col("b2_emplid")) & (F.col("j_empl_rcd") == F.col("b2_empl_rcd")) &
    (F.col("b2_job_key") > F.col("j_job_key")), "left_anti")

df_ne3 = (
    df_job_prepared
    .select(F.col("emplid").alias("b3_emplid"), F.col("empl_rcd").alias("b3_empl_rcd"),
            F.col("job_key").alias("b3_job_key"), F.col("reg_region").alias("b3_reg_region"))
    .join(df_reg_region_filtered.select(F.col("reg_region").alias("rr3_reg_region")),
          F.col("b3_reg_region") == F.col("rr3_reg_region"), "inner")
    .select("b3_emplid", "b3_empl_rcd", "b3_job_key")
)
df_u1_final = df_u1s2.join(df_ne3,
    (F.col("j_emplid") == F.col("b3_emplid")) & (F.col("j_empl_rcd") == F.col("b3_empl_rcd")) &
    (F.col("b3_job_key") > F.col("j_job_key")), "left_anti")

df_union1 = (
    df_u1_final
    .join(df_end_dates_1,
          (F.col("j_emplid") == F.col("base_emplid")) & (F.col("j_job_key") == F.col("base_job_key")), "left")
    .select(
        F.col("j_emplid").alias("emplid"),
        F.col("x_oprid").alias("user_id"),
        F.col("v_char_to").alias("timeType_externalCode"),
        F.date_format(F.col("j_effdt"), "dd/MM/yyyy").alias("startDate"),
        F.coalesce(F.date_format(F.col("end_date"), "dd/MM/yyyy"), F.lit("")).alias("endDate")
    )
)

# UNION PARTE 2 — INI|action|action_reason
df_union2_base = (
    df_job_prepared
    .select(
        F.col("emplid").alias("j_emplid"), F.col("empl_rcd").alias("j_empl_rcd"),
        F.col("job_key").alias("j_job_key"), F.col("effdt").alias("j_effdt"),
        F.col("position_nbr").alias("j_position_nbr"),
        F.col("action_reason_key").alias("j_action_reason_key"),
        F.col("reg_region").alias("j_reg_region"),
        F.col("action").alias("j_action"), F.col("action_reason").alias("j_action_reason")
    )
    .join(df_conv_ini.select(
        F.col("action_reason_key").alias("v_action_reason_key"),
        F.col("v_char_to").alias("v_char_to"),
        F.col("gender_flag").alias("v_gender_flag"),
        F.col("end_action_reason").alias("v_end_action_reason")
    ), F.col("j_action_reason_key") == F.col("v_action_reason_key"), "inner")
    .join(df_reg_region_filtered.select(F.col("reg_region").alias("rr_reg_region")),
          F.col("j_reg_region") == F.col("rr_reg_region"), "inner")
    .join(df_tmp_dat2_filtered.select(
        F.col("vp_emplid").alias("x_vp_emplid"),
        F.col("empl_rcd").alias("x_empl_rcd"),
        F.col("oprid").alias("x_oprid")
    ), (F.col("j_emplid") == F.col("x_vp_emplid")) & (F.col("j_empl_rcd") == F.col("x_empl_rcd")), "inner")
    .join(df_pers_with_rank.select(
        F.col("emplid").alias("ef_emplid"), F.col("gender_decoded").alias("ef_gender_decoded")
    ),
    (F.col("j_emplid") == F.col("ef_emplid")) &
    (F.coalesce(F.when(F.col("v_gender_flag") == "|", F.lit("")), F.col("ef_gender_decoded")) == F.col("ef_gender_decoded")),
    "inner")
)

df_job_for_end_2 = (
    df_job_prepared
    .select(
        F.col("emplid").alias("r_emplid"), F.col("empl_rcd").alias("r_empl_rcd"),
        F.col("job_key").alias("r_job_key"), F.col("effdt").alias("r_effdt"),
        F.col("effseq").alias("r_effseq"), F.col("action_reason_key").alias("r_action_reason_key")
    )
    .join(df_conv_ini.select(
        F.col("end_action_reason").alias("v2_end_action_reason"),
        F.col("gender_flag").alias("v2_gender_flag")
    ), F.col("r_action_reason_key") == F.col("v2_end_action_reason"), "inner")
    .join(df_pers_with_rank.select(
        F.col("emplid").alias("ef2_emplid"), F.col("gender_decoded").alias("ef2_gender")
    ), F.col("r_emplid") == F.col("ef2_emplid"), "inner")
    .filter(F.coalesce(F.when(F.col("v2_gender_flag") == "|", F.lit("")), F.col("ef2_gender")) == F.col("ef2_gender"))
)

window_next_2 = Window.partitionBy("base_emplid", "base_empl_rcd", "base_job_key").orderBy("r_effdt", "r_effseq")

df_end_dates_2 = (
    df_union2_base
    .select(
        F.col("j_emplid").alias("base_emplid"), F.col("j_empl_rcd").alias("base_empl_rcd"),
        F.col("j_job_key").alias("base_job_key"), F.col("j_effdt").alias("base_effdt"),
        F.col("ef_gender_decoded").alias("base_gender")
    ).distinct()
    .join(df_job_for_end_2,
          (F.col("base_emplid") == F.col("r_emplid")) &
          (F.col("base_empl_rcd") == F.col("r_empl_rcd")) &
          (F.col("r_job_key") > F.col("base_job_key")), "left")
    .withColumn("adjusted_effdt",
                F.when(F.col("r_effdt") == F.col("base_effdt"), F.date_add(F.col("r_effdt"), 1))
                 .otherwise(F.col("r_effdt")))
    .withColumn("rank", F.row_number().over(window_next_2))
    .filter(F.col("rank") == 1)
    .select(F.col("base_emplid"), F.col("base_job_key"),
            F.date_sub(F.col("adjusted_effdt"), 1).alias("end_date"))
)

df_ne2_1 = (
    df_job_prepared
    .select(F.col("emplid").alias("b_emplid"), F.col("empl_rcd").alias("b_empl_rcd"),
            F.col("job_key").alias("b_job_key"), F.col("action_reason_key").alias("b_action_reason_key"))
    .join(df_conv_ini.select(F.col("action_reason_key").alias("cv2_action_reason_key"),
                             F.col("gender_flag").alias("cv2_gender_flag")),
          F.col("b_action_reason_key") == F.col("cv2_action_reason_key"), "inner")
    .join(df_pers_with_rank.select(F.col("emplid").alias("ef_cv2_emplid"),
                                   F.col("gender_decoded").alias("ef_cv2_gender")),
          F.col("b_emplid") == F.col("ef_cv2_emplid"), "inner")
    .filter(F.coalesce(F.when(F.col("cv2_gender_flag") == "|", F.lit("")), F.col("ef_cv2_gender")) == F.col("ef_cv2_gender"))
    .select("b_emplid", "b_empl_rcd", "b_job_key")
)

df_union2_filtered = df_union2_base.join(df_ne2_1,
    (F.col("j_emplid") == F.col("b_emplid")) & (F.col("j_empl_rcd") == F.col("b_empl_rcd")) &
    (F.col("b_job_key") > F.col("j_job_key")), "left_anti")

df_union2 = (
    df_union2_filtered
    .join(df_end_dates_2,
          (F.col("j_emplid") == F.col("base_emplid")) & (F.col("j_job_key") == F.col("base_job_key")), "left")
    .select(
        F.col("j_emplid").alias("emplid"),
        F.col("x_oprid").alias("user_id"),
        F.col("v_char_to").alias("timeType_externalCode"),
        F.date_format(F.col("j_effdt"), "dd/MM/yyyy").alias("startDate"),
        F.coalesce(F.date_format(F.col("end_date"), "dd/MM/yyyy"), F.lit("")).alias("endDate")
    )
)

# UNIÃO E CÁLCULOS FINAIS
df_combined = df_union1.union(df_union2)

df_final = (
    df_combined
    .join(df_employment.select(
        F.col("e.emplid").alias("e_emplid"),
        F.col("e.rehire_dt").alias("e_rehire_dt"),
        F.col("e.hire_dt").alias("e_hire_dt")
    ), F.col("emplid") == F.col("e_emplid"), "inner")
    .filter(
        F.coalesce(F.to_date(F.col("endDate"), "dd/MM/yyyy"), F.lit(ptp_ini_mov)) >= F.lit(ptp_ini_mov)
    )
    .filter(
        F.coalesce(
            F.col("e_rehire_dt"),
            F.coalesce(F.col("e_hire_dt"), F.to_date(F.col("startDate"), "dd/MM/yyyy"))
        ) <= F.to_date(F.col("startDate"), "dd/MM/yyyy")
    )
)

df_result = (
    df_final
    .withColumn("approvalStatus", F.lit("APPROVED"))
    .withColumn("quantityInDays", F.lit(""))
    .withColumn("quantityInHours", F.lit(""))
    .withColumn("workflowRequestId", F.lit(""))
    .withColumn("cancellationWorkflowRequestId", F.lit(""))
    .withColumn("fractionQuantity",
                F.coalesce(
                    F.datediff(F.to_date(F.col("endDate"), "dd/MM/yyyy"),
                               F.to_date(F.col("startDate"), "dd/MM/yyyy")) + 1,
                    F.lit(0)
                ))
    .withColumn("editable", F.lit("TRUE"))
    .withColumn("loaStartJobInfoId", F.lit(""))
    .withColumn("loaEndJobInfoId", F.lit(""))
    .withColumn("loaExpectedReturnDate",
                F.coalesce(
                    F.date_format(F.date_add(F.to_date(F.col("endDate"), "dd/MM/yyyy"), 1), "dd/MM/yyyy"),
                    F.date_format(F.add_months(F.to_date(F.col("startDate"), "dd/MM/yyyy"), 24), "dd/MM/yyyy")
                ))
    .withColumn("loaActualReturnDate",
                F.coalesce(
                    F.date_format(F.date_add(F.to_date(F.col("endDate"), "dd/MM/yyyy"), 1), "dd/MM/yyyy"),
                    F.lit("")
                ))
    .withColumn("flexibleRequesting", F.lit("FALSE"))
    .withColumn("deductionQuantity", F.lit(""))
    .withColumn("startTime", F.lit(""))
    .withColumn("endTime", F.lit(""))
    .withColumn("undeterminedEndDate", F.lit("FALSE"))
    .withColumn("recurrenceGroup", F.lit(""))
    .withColumn("displayQuantity", F.lit(""))
    .withColumn("physicalStartDate", F.lit(""))
    .withColumn("physicalEndDate", F.lit(""))
    .withColumn("externalCode", F.lit(""))
)

df_typed  = apply_sf_types(df_result)
df_output = add_hash_key(df_typed, [c for c in df_result.columns if c in df_typed.columns])
df_output = select_final_ec49(df_output)

display(df_output)
# save_table(df_output, SILVER_EXTRATOR_CAN_USA_UK)