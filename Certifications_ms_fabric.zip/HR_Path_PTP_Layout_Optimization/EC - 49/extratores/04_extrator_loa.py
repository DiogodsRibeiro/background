# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EC - 49/utils/utils"

# COMMAND ----------

from pyspark.sql import functions as F

# COMMAND ----------

# CARGA
df_tmp_dat2 = read_table(BRONZE_TMP_DAT2)
df_conv_tbl = read_table(BRONZE_CONV_TBL)

# DATASET DAT (BRA)
df_dat = build_dat_bra(df_tmp_dat2).cache()

# AFASTAMENTOS BRA — filtrado por CODIGOS_LOA
df_afastamentos = (
    build_afastamentos_bra(df_conv_tbl)
    .filter(F.col("cod_ausencia").isin(CODIGOS_LOA))
)

# JOIN E CÁLCULOS FINAIS
df_joined = (
    df_dat
    .join(df_afastamentos, df_dat["vp_emplid"] == df_afastamentos["ID"], "inner")
    .filter(F.col("dt_ini") >= F.col("dt_hire"))
)

df_result = df_joined.select(
    F.col("oprid").alias("user_id"),
    F.col("cod_ausencia").alias("timeType_externalCode"),
    F.date_format(F.col("dt_ini"), "dd/MM/yyyy").alias("startDate"),
    F.when(
        F.col("dt_fim_str") == "01/01/9999",
        F.date_format(F.add_months(F.col("dt_ini"), 324), "dd/MM/yyyy")
    ).otherwise(
        F.date_format(F.col("dt_fim"), "dd/MM/yyyy")
    ).alias("endDate"),
    F.lit("APPROVED").alias("approvalStatus"),
    F.lit("").alias("quantityInDays"),
    F.lit("").alias("quantityInHours"),
    F.lit("").alias("workflowRequestId"),
    F.lit("").alias("cancellationWorkflowRequestId"),
    F.when(F.col("dt_fim_str") == "01/01/9999", F.lit(0))
     .otherwise(F.col("days")).alias("fractionQuantity"),
    F.lit("TRUE").alias("editable"),
    F.lit("").alias("loaStartJobInfoId"),
    F.lit("").alias("loaEndJobInfoId"),
    # loaExpectedReturnDate: dt_fim + 1 dia (ou dt_ini + 324 meses + 1 dia se 9999)
    F.when(
        F.col("dt_fim_str") == "01/01/9999",
        F.date_format(F.add_months(F.col("dt_ini"), 324) + F.expr("INTERVAL 1 DAY"), "dd/MM/yyyy")
    ).otherwise(
        F.date_format(F.expr("dt_fim + INTERVAL 1 DAY"), "dd/MM/yyyy")
    ).alias("loaExpectedReturnDate"),
    # loaActualReturnDate: vazio se 9999 ou posterior a 31/05/2025
    F.when(
        F.col("dt_fim") == F.to_date(F.lit("01/01/9999"), "dd/MM/yyyy"),
        F.lit("")
    ).when(
        F.col("dt_fim") > F.to_date(F.lit("31/05/2025"), "dd/MM/yyyy"),
        F.lit("")
    ).otherwise(
        F.date_format(F.expr("dt_fim + INTERVAL 1 DAY"), "dd/MM/yyyy")
    ).alias("loaActualReturnDate"),
    F.lit("FALSE").alias("flexibleRequesting"),
    F.lit("").alias("deductionQuantity"),
    F.lit("").alias("startTime"),
    F.lit("").alias("endTime"),
    F.lit("FALSE").alias("undeterminedEndDate"),
    F.lit("").alias("recurrenceGroup"),
    F.lit("").alias("displayQuantity"),
    F.lit("").alias("physicalStartDate"),
    F.lit("").alias("physicalEndDate"),
    F.lit("").alias("externalCode")
)

df_typed  = apply_sf_types(df_result)
df_output = add_hash_key(df_typed, [c for c in df_result.columns])
df_output = select_final_ec49(df_output)

display(df_output)
# save_table(df_output, SILVER_EXTRATOR_LOA)