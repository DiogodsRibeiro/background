# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EC - 49/utils/utils"

# COMMAND ----------

from pyspark.sql import functions as F

# COMMAND ----------

# CARGA
df_tmp_dat2 = read_table(BRONZE_TMP_DAT2)
df_conv_tbl = read_table(BRONZE_CONV_TBL)

# DATASET DAT (BRA)
df_dat = build_dat_bra(df_tmp_dat2).cache()

# AFASTAMENTOS BRA — filtrado por código 0383
df_afastamentos = (
    build_afastamentos_bra(df_conv_tbl)
    .filter(F.col("cod_ausencia") == CODIGO_NAO_LOA_PRORROG)
)

# JOIN E CÁLCULOS FINAIS
df_joined = (
    df_dat
    .join(df_afastamentos, df_dat["vp_emplid"] == df_afastamentos["ID"], "inner")
    .filter(F.col("dt_ini") >= F.col("dt_hire"))
)

df_result = df_joined.select(
    F.col("oprid").alias("user_id"),
    F.col("cod_ausencia").alias("timeType_externalCode"),
    F.date_format(F.col("dt_ini"), "dd/MM/yyyy").alias("startDate"),
    F.date_format(F.col("dt_fim"), "dd/MM/yyyy").alias("endDate"),
    F.lit("APPROVED").alias("approvalStatus"),
    F.lit("").alias("quantityInDays"),
    F.lit("").alias("quantityInHours"),
    F.lit("").alias("workflowRequestId"),
    F.lit("").alias("cancellationWorkflowRequestId"),
    F.col("days").alias("fractionQuantity"),
    F.lit("TRUE").alias("editable"),
    F.lit("").alias("loaStartJobInfoId"),
    F.lit("").alias("loaEndJobInfoId"),
    F.lit("").alias("loaExpectedReturnDate"),
    F.lit("").alias("loaActualReturnDate"),
    F.lit("FALSE").alias("flexibleRequesting"),
    F.lit("").alias("deductionQuantity"),
    F.lit("").alias("startTime"),
    F.lit("").alias("endTime"),
    F.lit("FALSE").alias("undeterminedEndDate"),
    F.lit("").alias("recurrenceGroup"),
    F.lit("").alias("displayQuantity"),
    F.lit("").alias("physicalStartDate"),
    F.lit("").alias("physicalEndDate"),
    F.lit("").alias("externalCode")
)

df_typed  = apply_sf_types(df_result)
df_output = add_hash_key(df_typed, [c for c in df_result.columns])
df_output = select_final_ec49(df_output)

display(df_output)
# save_table(df_output, SILVER_EXTRATOR_NAO_LOA_PRORROG)