# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EC - 49/utils/utils"

# COMMAND ----------

import os
import requests
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.lines as mlines
from pyspark.sql import functions as F
from pyspark.sql.types import *

# COMMAND ----------

# CARREGAR TODOS OS EXTRATORES DAS TABELAS SILVER
df_extrator_asia = read_table(SILVER_EXTRATOR_ASIA)
df_extrator_can_usa_uk = read_table(SILVER_EXTRATOR_CAN_USA_UK)
df_extrator_ferias = read_table(SILVER_EXTRATOR_FERIAS)
df_extrator_loa = read_table(SILVER_EXTRATOR_LOA)
df_extrator_nao_loa = read_table(SILVER_EXTRATOR_NAO_LOA)
df_extrator_nao_loa_prorrog = read_table(SILVER_EXTRATOR_NAO_LOA_PRORROG)

df_extratores = (
    df_extrator_asia
    .unionAll(df_extrator_can_usa_uk)
    .unionAll(df_extrator_ferias)
    .unionAll(df_extrator_loa)
    .unionAll(df_extrator_nao_loa)
    .unionAll(df_extrator_nao_loa_prorrog)
)

print(f"Total de registros (extratores HR Path): {df_extratores.count():,}")
display(df_extratores)
# save_table(df_extratores, SILVER_CONSOLIDADO)