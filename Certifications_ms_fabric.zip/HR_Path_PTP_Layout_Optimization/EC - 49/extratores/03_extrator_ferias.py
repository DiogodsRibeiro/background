# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EC - 49/utils/utils"

# COMMAND ----------

from pyspark.sql import functions as F

# COMMAND ----------

# CARGA
df_dat2 = read_table(BRONZE_TMP_DAT2)
df_conv = read_table(BRONZE_CONV_TBL)

# TABELA DE CONVERSÃO FERIAS_FPW
df_f = (
    df_conv
    .filter(F.col("v_convert_id") == "FERIAS_FPW")
    .withColumn("descr_split",  F.split(F.col("descr100"), "\\|"))
    .withColumn("v_char_split", F.split(F.col("v_char_to"), "\\|"))
    .select(
        F.col("descr_split")[0].alias("id"),
        F.to_date(F.col("v_char_split")[1], "dd/MM/yyyy").alias("dt_inicio"),
        F.to_date(F.col("v_char_split")[2], "dd/MM/yyyy").alias("dt_fim"),
        F.col("v_char_split")[0].alias("timeType_externalCode")
    )
    .cache()
)

# DATASET DAT (BRA)
df_dat = build_dat_bra(df_dat2).cache()

# JOIN E RESULTADO
df_result = (
    df_dat
    .join(df_f, F.col("vp_emplid") == F.col("id"), "inner")
    .select(
        F.col("oprid").alias("user_id"),
        F.col("timeType_externalCode"),
        F.date_format(F.col("dt_inicio"), "dd/MM/yyyy").alias("startDate"),
        F.date_format(F.col("dt_fim"),    "dd/MM/yyyy").alias("endDate"),
        F.lit("APPROVED").alias("approvalStatus"),
        F.lit("").alias("quantityInDays"),
        F.lit("").alias("quantityInHours"),
        F.lit("").alias("workflowRequestId"),
        F.lit("").alias("cancellationWorkflowRequestId"),
        (F.datediff(F.col("dt_fim"), F.col("dt_inicio")) + 1).alias("fractionQuantity"),
        F.lit("TRUE").alias("editable"),
        F.lit("").alias("loaStartJobInfoId"),
        F.lit("").alias("loaEndJobInfoId"),
        F.lit("").alias("loaExpectedReturnDate"),
        F.lit("").alias("loaActualReturnDate"),
        F.lit("FALSE").alias("flexibleRequesting"),
        F.lit("").alias("deductionQuantity"),
        F.lit("").alias("startTime"),
        F.lit("").alias("endTime"),
        F.lit("FALSE").alias("undeterminedEndDate"),
        F.lit("").alias("recurrenceGroup"),
        F.lit("").alias("displayQuantity"),
        F.lit("").alias("physicalStartDate"),
        F.lit("").alias("physicalEndDate"),
        F.lit("").alias("externalCode")
    )
)

df_typed  = apply_sf_types(df_result)
df_output = add_hash_key(df_typed, [c for c in df_result.columns])
df_output = select_final_ec49(df_output)

display(df_output)
# save_table(df_output, SILVER_EXTRATOR_FERIAS)