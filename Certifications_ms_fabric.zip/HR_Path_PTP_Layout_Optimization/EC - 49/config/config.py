# Databricks notebook source
# Databricks notebook source
# Configurações Globais — EC-49 (Layout SAP SuccessFactors)

# Volume de entrada
RAW_BASE = "/Volumes/humanresources_insight/acqu_pcec49/acqu_pcec49/ec_49/raw_files/"

# Caminhos dos arquivos de entrada
PS_STRINGS_TBL = f"{RAW_BASE}/ps_strings_tbl.txt"
PS_REG_REGION_TBL = f"{RAW_BASE}/ps_reg_region_tbl.txt"
PS_CONV_TBL = f"{RAW_BASE}/ps_v_ptp_conv_tbl.txt"
PS_JOB = f"{RAW_BASE}/ps_job.txt"
PS_PERS_DATA = f"{RAW_BASE}/ps_pers_data_effdt.txt"
PS_EMPLOYMENT = f"{RAW_BASE}/ps_employment.txt"
PS_TMP_DAT2 = f"{RAW_BASE}/ps_v_ptp_tmp_dat2.txt"

# Schemas
BRONZE_SCHEMA = "humanresources_insight.bron_pcec49"
SILVER_SCHEMA = "humanresources_insight.silv_pcec49"

# Tabelas Bronze
BRONZE_STRINGS_TBL = f"{BRONZE_SCHEMA}.ps_strings_tbl"
BRONZE_REG_REGION_TBL = f"{BRONZE_SCHEMA}.ps_reg_region_tbl"
BRONZE_CONV_TBL = f"{BRONZE_SCHEMA}.ps_v_ptp_conv_tbl"
BRONZE_JOB = f"{BRONZE_SCHEMA}.ps_job"
BRONZE_PERS_DATA = f"{BRONZE_SCHEMA}.ps_pers_data_effdt"
BRONZE_EMPLOYMENT = f"{BRONZE_SCHEMA}.ps_employment"
BRONZE_TMP_DAT2 = f"{BRONZE_SCHEMA}.ps_v_ptp_tmp_dat2"

# Tabelas Silver — Extratores
SILVER_EXTRATOR_ASIA = f"{SILVER_SCHEMA}.extrator_asia"
SILVER_EXTRATOR_CAN_USA_UK = f"{SILVER_SCHEMA}.extrator_can_usa_uk"
SILVER_EXTRATOR_FERIAS = f"{SILVER_SCHEMA}.extrator_ferias"
SILVER_EXTRATOR_LOA = f"{SILVER_SCHEMA}.extrator_loa"
SILVER_EXTRATOR_NAO_LOA = f"{SILVER_SCHEMA}.extrator_nao_loa"
SILVER_EXTRATOR_NAO_LOA_PRORROG = f"{SILVER_SCHEMA}.extrator_nao_loa_prorrog"

# Tabela consolidada final
SILVER_CONSOLIDADO = f"{SILVER_SCHEMA}.ec_49_arquivo_layout_sap"

# Constantes de negócio
PAISES_ASIA = ['MYS', 'SGP', 'ARE', 'IND', 'IDN', 'OMN', 'AUS']
PAISES_CAN_USA_UK  = ['CAN', 'USA', 'GBR']

CODIGOS_LOA = [
    '0251', '0210', '0290', '0390', '0294', '0253', '0211', '0310', '0252',
    '0293', '0292', '0250', '9012', '9019', '9011', '9010', '9013', '0291', '0311'
]

CODIGOS_NAO_LOA = [
    '0380', '0201', '0255', '0300', '0320', '9015', '9003', '9007',
    '0340', '9005', '9008', '0256', '0297', '0200', '9021', '9006',
    '0371', '9009', '0386', '9004', '9002', '0385', '9016', '9017'
]

CODIGO_NAO_LOA_PRORROG = '0383'

EMPRESAS_VALIDAS = [1, 3, 4, 46, 64, 68, 90, 112, 360, 632, 646]

# Colunas finais padronizadas EC-49
EC49_FINAL_COLS = [
    "user_id", "timeType_externalCode", "startDate", "endDate",
    "approvalStatus", "quantityInDays", "quantityInHours",
    "workflowRequestId", "cancellationWorkflowRequestId",
    "fractionQuantity", "editable", "loaStartJobInfoId",
    "loaEndJobInfoId", "loaExpectedReturnDate", "loaActualReturnDate",
    "flexibleRequesting", "deductionQuantity", "startTime", "endTime",
    "undeterminedEndDate", "recurrenceGroup", "displayQuantity",
    "physicalStartDate", "physicalEndDate", "externalCode", "hash_key"
]

VALIDATION_PATH = "/Volumes/humanresources_insight/acqu_pcec49/acqu_pcec49/ec_49/validation_files/"

print("Configurações EC-49 carregadas.")