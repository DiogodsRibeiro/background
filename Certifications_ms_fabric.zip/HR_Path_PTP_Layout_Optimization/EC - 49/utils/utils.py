# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EC - 49/config/config"

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import (
    StringType, DecimalType, BooleanType, LongType
)
import io
import pandas as pd

# COMMAND ----------

def read_table(table: str) -> DataFrame:
    """Lê uma tabela Delta e retorna um DataFrame Spark."""
    return spark.table(table)

def load_bronze(path: str, table: str) -> None:
    df = (
        spark.read
        .option("header", "true")
        .option("delimiter", ";")
        .option("inferSchema", "false")
        .csv(path)
    )

    print(f"{path.split('/')[-1]} → {df.count()} registros | colunas: {df.columns}")

    (
        df.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(table)
    )
    print(f"✅ Gravado: {table} ({df.count()} registros)")

def read_txt(path: str, sep: str = ";") -> DataFrame:
    """Lê um arquivo TXT do Volume e retorna um DataFrame Spark."""
    df = spark.read.text(path)
    header = df.first()[0].split(sep)
    df = df.filter(F.col("value") != df.first()[0])
    df = df.select(F.split(F.col("value"), sep).alias("cols"))
    return df.select([F.col("cols")[i].alias(header[i]) for i in range(len(header))])

def save_table(df: DataFrame, table: str) -> None:
    """Grava um DataFrame como tabela Delta com overwrite."""
    (
        df.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(table)
    )
    print(f"Gravado: {table} ({df.count()} registros)")


def truncate_and_insert(df: DataFrame, table: str) -> None:
    """Trunca a tabela Delta e reinsere os dados."""
    spark.sql(f"DELETE FROM {table}")
    df.write.format("delta").mode("append").saveAsTable(table)
    print(f"Truncado e reinserido: {table} ({df.count()} registros)")


# PREPARAÇÕES DE DADOS COMUNS

def get_date_ptp(df_strings: DataFrame) -> object:
    """Extrai o valor de DATE_PTP como objeto date Python."""
    row = (
        df_strings
        .filter(F.col("string_id") == "DATE_PTP")
        .select(F.to_date(F.col("string_text"), "dd/MM/yyyy").alias("date_ptp"))
        .first()
    )
    return row["date_ptp"]


def get_ptp_ini_mov(df_strings: DataFrame) -> DataFrame:
    """Retorna DataFrame de uma linha com a data PTP_INI_MOV."""
    return (
        df_strings
        .filter(F.col("string_id") == "PTP_INI_MOV")
        .select(F.to_date(F.col("string_text"), "dd/MM/yyyy").alias("ptp_ini_mov"))
    )


def build_pers_enriched(df_pers_data: DataFrame) -> DataFrame:
    """
    Retorna o último registro de dados pessoais por emplid,
    com coluna 'sex_normalized' (F / M / X).
    """
    w = Window.partitionBy("emplid").orderBy(F.col("effdt").desc())
    return (
        df_pers_data
        .withColumn("rn", F.row_number().over(w))
        .filter(F.col("rn") == 1)
        .withColumn(
            "sex_normalized",
            F.when(F.trim(F.col("sex")) == "F", F.lit("F"))
             .when(F.trim(F.col("sex")) == "M", F.lit("M"))
             .otherwise(F.lit("X"))
        )
        .select("emplid", "effdt", "sex", "sex_normalized")
    )


def build_dat_bra(df_tmp_dat2: DataFrame) -> DataFrame:
    """
    Constrói o dataset DAT para extrações BRA:
    registros GO_LIVE ou CURRENT% ativos joined com HIRE para dt_hire.
    """
    df_hire = (
        df_tmp_dat2
        .filter(
            (F.col("processtype") == "HIRE") &
            (F.col("country") == "BRA")
        )
        .select(
            F.col("vp_emplid").alias("h_vp_emplid"),
            F.col("empl_rcd").alias("h_empl_rcd"),
            F.col("oprid").alias("h_oprid"),
            F.col("effdt").alias("dt_hire")
        )
    )

    df_active = (
        df_tmp_dat2
        .filter(
            (F.col("country") == "BRA") &
            (
                (F.col("processtype") == "GO_LIVE") |
                (
                    (F.col("hr_status") == "A") &
                    (F.col("rowname1").like("CURRENT%")) &
                    (~F.col("processtype").isin(
                        ["FORA_DO_ESCOPO", "HOST_HIRE", "HOST_HIST", "HOST_TER"]
                    ))
                )
            )
        )
        .select("vp_emplid", "empl_rcd", "emplid2", "oprid", "hr_status", "country")
    )

    return (
        df_active
        .join(
            df_hire,
            (df_active["vp_emplid"] == df_hire["h_vp_emplid"]) &
            (df_active["empl_rcd"]  == df_hire["h_empl_rcd"]) &
            (df_active["oprid"]     == df_hire["h_oprid"]),
            "inner"
        )
        .select(
            df_active["vp_emplid"], df_active["empl_rcd"],
            df_active["emplid2"],   df_active["oprid"],
            df_active["hr_status"], df_active["country"],
            df_hire["dt_hire"]
        )
        .distinct()
    )


def build_afastamentos_bra(df_conv_tbl: DataFrame) -> DataFrame:
    """
    Processa a tabela de conversão AFASTAMENTOS_BRA,
    extraindo campos via posição de pipes em v_char_to / descr100.
    """
    return (
        df_conv_tbl
        .filter(F.col("v_convert_id") == "AFASTAMENTOS_BRA")
        .withColumn("pos1", F.expr("instr(v_char_to, '|')"))
        .withColumn("cod_ausencia", F.expr("substring(v_char_to, 1, pos1 - 1)"))
        .withColumn("dt_ini_str",   F.trim(F.expr("substring(v_char_to, pos1 + 1, 10)")))
        .withColumn("pos2",         F.expr("instr(substring(v_char_to, pos1 + 1), '|') + pos1"))
        .withColumn("dt_fim_str",   F.trim(F.expr("substring(v_char_to, pos2 + 1, 10)")))
        .withColumn("ID",           F.expr("substring(descr100, 1, instr(descr100, '|') - 1)"))
        .withColumn("dt_ini",       F.to_date(F.col("dt_ini_str"), "dd/MM/yyyy"))
        .withColumn(
            "dt_fim",
            F.when(
                F.col("dt_fim_str") == "01/01/9999",
                F.add_months(F.col("dt_ini"), 324)
            ).otherwise(F.to_date(F.col("dt_fim_str"), "dd/MM/yyyy"))
        )
        .withColumn(
            "days",
            F.when(
                F.col("dt_fim_str") == "01/01/9999",
                F.datediff(F.add_months(F.col("dt_ini"), 324), F.add_months(F.col("dt_ini"), 72)) + 1
            ).otherwise(
                F.datediff(F.to_date(F.col("dt_fim_str"), "dd/MM/yyyy"), F.col("dt_ini")) + 1
            )
        )
        .select("ID", "cod_ausencia", "dt_ini", "dt_fim", "dt_fim_str", "days")
    )


# TIPAGEM E PADRONIZAÇÃO SAP SUCCESSFACTORS

def apply_sf_types(df: DataFrame) -> DataFrame:
    user_col = "user_id" if "user_id" in df.columns else "userid"
    return (
        df
        .withColumn(user_col, F.substring(F.col(user_col).cast(StringType()), 1, 40))
        .withColumn("timeType_externalCode", F.substring(F.col("timeType_externalCode").cast(StringType()), 1, 38))
        .withColumn("startDate",   F.col("startDate").cast(StringType()))
        .withColumn("endDate",     F.col("endDate").cast(StringType()))
        .withColumn("approvalStatus", F.substring(F.col("approvalStatus"), 1, 128))
        .withColumn("quantityInDays",
            F.when(F.col("quantityInDays") == "", F.lit(None))
             .otherwise(F.col("quantityInDays").cast(DecimalType(22, 2))))
        .withColumn("quantityInHours",
            F.when(F.col("quantityInHours") == "", F.lit(None))
             .otherwise(F.col("quantityInHours").cast(DecimalType(22, 2))))
        .withColumn("workflowRequestId",
            F.when(F.col("workflowRequestId") == "", F.lit(None))
             .otherwise(F.col("workflowRequestId").cast(LongType())))
        .withColumn("cancellationWorkflowRequestId",
            F.when(F.col("cancellationWorkflowRequestId") == "", F.lit(None))
             .otherwise(F.col("cancellationWorkflowRequestId").cast(LongType())))
        .withColumn("fractionQuantity", F.col("fractionQuantity").cast(DecimalType(22, 2)))
        .withColumn("editable",
            F.when(F.upper(F.col("editable")) == "TRUE",  F.lit(True))
             .when(F.upper(F.col("editable")) == "FALSE", F.lit(False))
             .otherwise(F.lit(None)).cast(BooleanType()))
        .withColumn("loaStartJobInfoId",
            F.when(F.col("loaStartJobInfoId") == "", F.lit(None))
             .otherwise(F.col("loaStartJobInfoId").cast(LongType())))
        .withColumn("loaEndJobInfoId",
            F.when(F.col("loaEndJobInfoId") == "", F.lit(None))
             .otherwise(F.col("loaEndJobInfoId").cast(LongType())))
        .withColumn("loaExpectedReturnDate", F.col("loaExpectedReturnDate").cast(StringType()))
        .withColumn("loaActualReturnDate",   F.col("loaActualReturnDate").cast(StringType()))
        .withColumn("flexibleRequesting",
            F.when(F.upper(F.col("flexibleRequesting")) == "TRUE",  F.lit(True))
             .when(F.upper(F.col("flexibleRequesting")) == "FALSE", F.lit(False))
             .otherwise(F.lit(None)).cast(BooleanType()))
        .withColumn("deductionQuantity",
            F.when(F.col("deductionQuantity") == "", F.lit(None))
             .otherwise(F.col("deductionQuantity").cast(DecimalType(22, 2))))
        .withColumn("startTime", F.substring(F.col("startTime"), 1, 21))
        .withColumn("endTime",   F.substring(F.col("endTime"), 1, 21))
        .withColumn("undeterminedEndDate",
            F.when(F.upper(F.col("undeterminedEndDate")) == "TRUE",  F.lit(True))
             .when(F.upper(F.col("undeterminedEndDate")) == "FALSE", F.lit(False))
             .otherwise(F.lit(None)).cast(BooleanType()))
        .withColumn("recurrenceGroup", F.substring(F.col("recurrenceGroup"), 1, 38))
        .withColumn("displayQuantity",
            F.when(F.col("displayQuantity") == "", F.lit(None))
             .otherwise(F.col("displayQuantity").cast(DecimalType(22, 2))))
        .withColumn("physicalStartDate",
            F.when(F.col("physicalStartDate") == "", F.lit(None))
             .otherwise(F.col("physicalStartDate").cast(DecimalType(22, 2))))
        .withColumn("physicalEndDate",
            F.when(F.col("physicalEndDate") == "", F.lit(None))
             .otherwise(F.col("physicalEndDate").cast(DecimalType(22, 2))))
        .withColumn("externalCode", F.substring(F.col("externalCode"), 1, 128))
    )


def add_hash_key(df: DataFrame, source_cols: list) -> DataFrame:
    """Adiciona coluna hash_key (MD5) baseada nas colunas source_cols."""
    return df.withColumn(
        "hash_key",
        F.md5(F.concat_ws("||", *[
            F.coalesce(F.col(c).cast(StringType()), F.lit(""))
            for c in source_cols
        ]))
    )


def select_final_ec49(df: DataFrame) -> DataFrame:
    """Renomeia userid → user_id, seleciona EC49_FINAL_COLS, distinct, ordena."""
    if "userid" in df.columns and "user_id" not in df.columns:
        df = df.withColumnRenamed("userid", "user_id")

    rename_map = {
        "timetype_externalcode": "timeType_externalCode",
        "startdate": "startDate", "enddate": "endDate",
        "approvalstatus": "approvalStatus",
        "quantityindays": "quantityInDays", "quantityinhours": "quantityInHours",
        "workflowrequestid": "workflowRequestId",
        "cancellationworkflowrequestid": "cancellationWorkflowRequestId",
        "fractionquantity": "fractionQuantity",
        "loastartjobinfoid": "loaStartJobInfoId", "loaendjobinfoid": "loaEndJobInfoId",
        "loaexpectedreturndate": "loaExpectedReturnDate",
        "loaactualreturndate": "loaActualReturnDate",
        "flexiblerequesting": "flexibleRequesting",
        "deductionquantity": "deductionQuantity",
        "starttime": "startTime", "endtime": "endTime",
        "undeterminedenddate": "undeterminedEndDate",
        "recurrencegroup": "recurrenceGroup", "displayquantity": "displayQuantity",
        "physicalstartdate": "physicalStartDate", "physicalenddate": "physicalEndDate",
        "externalcode": "externalCode",
    }
    for old, new in rename_map.items():
        if old in df.columns:
            df = df.withColumnRenamed(old, new)

    return (
        df.select(*EC49_FINAL_COLS).distinct()
        .orderBy(
            F.lpad(F.col("user_id"), 15, "0"),
            F.to_date(F.col("startDate"), "dd/MM/yyyy")
        )
    )


def export_df_to_csv_excel(df: DataFrame, volume_path: str, file_base: str) -> None:
    """Exporta um DataFrame para CSV e Excel em um volume."""
    base  = volume_path.rstrip("/")
    final_csv = f"{base}/{file_base}.csv"
    final_excel = f"{base}/{file_base}.xlsx"
    dbutils.fs.mkdirs(base)
    pdf = df.toPandas()
    with open(final_csv, "w", encoding="utf-8-sig") as f:
        pdf.to_csv(f, index=False)
    print(f"CSV exportado: {final_csv}")
    buf = io.BytesIO()
    pdf.to_excel(buf, index=False, engine="openpyxl")
    buf.seek(0)
    with open(final_excel, "wb") as f:
        f.write(buf.read())
    print(f"Excel exportado: {final_excel}")

print("Utilitários EC-49 carregados.")