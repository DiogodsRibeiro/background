# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EC - 49/utils/utils"
# MAGIC

# COMMAND ----------

import os
import requests
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.lines as mlines
from pyspark.sql import functions as F
from pyspark.sql.types import *

# COMMAND ----------

# CARREGAR TABELA CONSOLIDADA DE EXTRATORES
df_extratores = read_table(SILVER_CONSOLIDADO)

print(f"Total de registros (extratores HR Path): {df_extratores.count():,}")
df_extratores.createOrReplaceTempView("df_extratores")

# COMMAND ----------

# Output gerado pela VALE

# Caminho centralizado no config.py
validation_path = VALIDATION_PATH

all_files = [
    f.path for f in dbutils.fs.ls(validation_path)
    if f.path.endswith(".csv") and "update" not in f.path
]

df_output_final = (
    spark.read.csv(all_files, header=True, inferSchema=True, sep=",")
    .select(
        F.col("userid").cast(StringType()).alias("user_id"),
        F.col("`timeType.externalCode`").cast(StringType()).alias("timeType_externalCode"),
        F.col("startDate").cast(StringType()).alias("startDate"),
        F.col("endDate").cast(StringType()).alias("endDate"),
        F.col("approvalStatus").cast(StringType()).alias("approvalStatus"),
        F.col("quantityInDays").cast(DecimalType(22, 2)).alias("quantityInDays"),
        F.col("quantityInHours").cast(DecimalType(22, 2)).alias("quantityInHours"),
        F.col("workflowRequestId").cast(LongType()).alias("workflowRequestId"),
        F.col("cancellationWorkflowRequestId").cast(LongType()).alias("cancellationWorkflowRequestId"),
        F.col("fractionQuantity").cast(DecimalType(22, 2)).alias("fractionQuantity"),
        F.when(F.upper(F.trim(F.col("editable"))) == "TRUE",  True)
         .when(F.upper(F.trim(F.col("editable"))) == "FALSE", False)
         .otherwise(None).cast(BooleanType()).alias("editable"),
        F.col("loaStartJobInfoId").cast(LongType()).alias("loaStartJobInfoId"),
        F.col("loaEndJobInfoId").cast(LongType()).alias("loaEndJobInfoId"),
        F.col("loaExpectedReturnDate").cast(StringType()).alias("loaExpectedReturnDate"),
        F.col("loaActualReturnDate").cast(StringType()).alias("loaActualReturnDate"),
        F.when(F.upper(F.trim(F.col("flexibleRequesting"))) == "TRUE",  True)
         .when(F.upper(F.trim(F.col("flexibleRequesting"))) == "FALSE", False)
         .otherwise(None).cast(BooleanType()).alias("flexibleRequesting"),
        F.col("deductionQuantity").cast(DecimalType(22, 2)).alias("deductionQuantity"),
        F.col("startTime").cast(StringType()).alias("startTime"),
        F.col("endTime").cast(StringType()).alias("endTime"),
        F.when(F.upper(F.trim(F.col("undeterminedEndDate"))) == "TRUE",  True)
         .when(F.upper(F.trim(F.col("undeterminedEndDate"))) == "FALSE", False)
         .otherwise(None).cast(BooleanType()).alias("undeterminedEndDate"),
        F.col("`recurrenceGroup.externalCode`").cast(StringType()).alias("recurrenceGroup"),
        F.col("displayQuantity").cast(DecimalType(22, 2)).alias("displayQuantity"),
        F.col("physicalStartDate").cast(DecimalType(22, 2)).alias("physicalStartDate"),
        F.col("physicalEndDate").cast(DecimalType(22, 2)).alias("physicalEndDate"),
        F.col("externalCode").cast(StringType()).alias("externalCode")
    )
)

final_col_order = [c for c in EC49_FINAL_COLS if c != "hash_key"]

df_output_final = df_output_final.withColumn(
    "hash_key",
    F.md5(F.concat_ws("||", *[
        F.coalesce(F.col(c).cast(StringType()), F.lit(""))
        for c in final_col_order
    ]))
).withColumn(
    "file_name",
    F.regexp_extract(F.col("_metadata.file_path"), r"([^/]+\.csv)$", 1)
)

print(f"Total de registros (output VALE): {df_output_final.count():,}")
df_output_final.createOrReplaceTempView("df_output_final")

# Verificação de arquivos com problemas de formatação
offender_rows = spark.sql("""
    SELECT * FROM df_output_final
    WHERE user_id LIKE '%\"%\"%'
""")
offender_rows.createOrReplaceTempView("offender_rows")

offender_files = spark.sql("SELECT DISTINCT file_name FROM offender_rows")
offender_files_list = [row.file_name for row in offender_files.collect()]
print(f"Arquivos com problemas de formatação: {len(offender_files_list)}")
print(f"Lista: {offender_files_list}")
print(f"Total de registros com erro: {offender_rows.count():,}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Validações

# COMMAND ----------

# Match por hash_key
result_null  = spark.sql("""
    SELECT COUNT(*) AS count FROM (
        SELECT otp.* FROM df_output_final otp
        LEFT JOIN df_extratores ext ON otp.hash_key = ext.hash_key
        WHERE ext.hash_key IS NULL
    )
""")
result_match = spark.sql("""
    SELECT COUNT(*) AS count FROM (
        SELECT otp.* FROM df_output_final otp
        LEFT JOIN df_extratores ext ON otp.hash_key = ext.hash_key
        WHERE ext.hash_key IS NOT NULL
    )
""")

sem_match = result_null.toPandas()['count'].iloc[0]
com_match = result_match.toPandas()['count'].iloc[0]
total     = sem_match + com_match
pct_sem   = (sem_match / total) * 100
pct_com   = (com_match / total) * 100

categorias = ['Sem Match', 'Com Match']
valores    = [sem_match, com_match]
cores      = ['#e74c3c', '#2ecc71']

plt.figure(figsize=(10, 6))
barras = plt.bar(categorias, valores, color=cores, edgecolor='black', linewidth=1.2)
for barra, valor, pct in zip(barras, valores, [pct_sem, pct_com]):
    plt.text(barra.get_x() + barra.get_width() / 2., barra.get_height() / 2,
             f'{valor:,}\n({pct:.1f}%)',
             ha='center', va='center', fontsize=12, fontweight='bold', color='white')
plt.ylabel('Quantidade', fontsize=12)
plt.title('Análise de Matches — EC-49', fontsize=14, fontweight='bold')
plt.grid(axis='y', alpha=0.3, linestyle='--')
plt.tight_layout()
plt.show()

print(f"\n{'='*50}")
print(f"Total de registros : {total:,}")
print(f"Com Match          : {com_match:,} ({pct_com:.2f}%)")
print(f"Sem Match          : {sem_match:,} ({pct_sem:.2f}%)")
print(f"{'='*50}")

# COMMAND ----------

# DataViz — Match por Extrator
extratores_views = {
    "asia":            "df_extrator_asia",
    "can_usa_uk":      "df_extrator_can_usa_uk",
    "ferias":          "df_extrator_ferias",
    "loa":             "df_extrator_loa",
    "nao_loa":         "df_extrator_nao_loa",
    "nao_loa_prorrog": "df_extrator_nao_loa_prorrog",
}

for nome, df_var in [
    ("df_extrator_asia",            df_extrator_asia),
    ("df_extrator_can_usa_uk",      df_extrator_can_usa_uk),
    ("df_extrator_ferias",          df_extrator_ferias),
    ("df_extrator_loa",             df_extrator_loa),
    ("df_extrator_nao_loa",         df_extrator_nao_loa),
    ("df_extrator_nao_loa_prorrog", df_extrator_nao_loa_prorrog),
]:
    df_var.createOrReplaceTempView(nome)

resultados = []
print(f"{'='*80}")
print(f"{'Extrator':<40} {'Total':<10} {'Match':<10} {'Sem Match':<10} {'% Match':<10}")
print(f"{'='*80}")

for label, view in extratores_views.items():
    total_ext = spark.sql(f"SELECT COUNT(*) AS c FROM {view}").toPandas()['c'].iloc[0]
    com_m = spark.sql(f"""
        SELECT COUNT(*) AS c FROM (
            SELECT ext.* FROM {view} ext
            INNER JOIN df_output_final otp ON ext.hash_key = otp.hash_key
        )
    """).toPandas()['c'].iloc[0]
    sem_m = total_ext - com_m
    pct   = (com_m / total_ext * 100) if total_ext > 0 else 0
    resultados.append({'extrator': label, 'total': total_ext, 'com_match': com_m, 'sem_match': sem_m, 'pct_match': pct})
    print(f"{label:<40} {total_ext:<10} {com_m:<10} {sem_m:<10} {pct:<10.2f}%")

print(f"{'='*80}\n")

df_res = pd.DataFrame(resultados).sort_values('pct_match', ascending=False)

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))
x_pos = range(len(df_res))

ax1.barh(x_pos, df_res['com_match'], color='#2ecc71', label='Com Match')
ax1.barh(x_pos, df_res['sem_match'], left=df_res['com_match'], color='#e74c3c', label='Sem Match')
for i, (_, row) in enumerate(df_res.iterrows()):
    ax1.text(row['total'] / 2, i, f"{row['pct_match']:.1f}%",
             ha='center', va='center', fontsize=10, fontweight='bold', color='white')
ax1.set_yticks(x_pos); ax1.set_yticklabels(df_res['extrator'])
ax1.set_xlabel('Quantidade'); ax1.set_title('Match por Extrator (absoluto)', fontweight='bold')
ax1.legend(); ax1.grid(axis='x', alpha=0.3, linestyle='--')

cores_bar = ['#27ae60' if p >= 90 else '#f39c12' if p >= 70 else '#e74c3c' for p in df_res['pct_match']]
bars = ax2.barh(x_pos, df_res['pct_match'], color=cores_bar, edgecolor='black', linewidth=1.2)
for i, (bar, pct) in enumerate(zip(bars, df_res['pct_match'])):
    ax2.text(pct + 1, i, f"{pct:.1f}%", ha='left', va='center', fontsize=10, fontweight='bold')
ax2.set_yticks(x_pos); ax2.set_yticklabels(df_res['extrator'])
ax2.set_xlabel('% Match'); ax2.set_title('% de Match por Extrator', fontweight='bold')
ax2.set_xlim(0, 105); ax2.axvline(x=90, color='green', linestyle='--', alpha=0.5, label='Meta: 90%')
ax2.legend(); ax2.grid(axis='x', alpha=0.3, linestyle='--')

plt.tight_layout()
plt.show()

print("\n" + "=" * 80)
print("RESUMO GERAL:")
print("=" * 80)
print(f"Total de extratores           : {len(df_res)}")
print(f"Com 100% de match             : {len(df_res[df_res['pct_match'] == 100])}")
print(f"Com ≥90% de match             : {len(df_res[df_res['pct_match'] >= 90])}")
print(f"Com <90% de match             : {len(df_res[df_res['pct_match'] < 90])}")
print(f"Média de match                : {df_res['pct_match'].mean():.2f}%")
print(f"Melhor extrator               : {df_res.iloc[0]['extrator']} ({df_res.iloc[0]['pct_match']:.2f}%)")
print(f"Extrator c/ maior gap         : {df_res.iloc[-1]['extrator']} ({df_res.iloc[-1]['pct_match']:.2f}%)")
print("=" * 80)

# COMMAND ----------

# Tempo de execução do Job
DATABRICKS_INSTANCE = "https://adb-1155906991732329.9.azuredatabricks.net"
TOKEN  = dbutils.secrets.get(scope="ptp", key="databricks_token")
JOB_ID = xxxxxxx

headers = {"Authorization": f"Bearer {TOKEN}"}

runs_resp = requests.get(
    f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/list",
    headers=headers,
    params={"job_id": JOB_ID, "limit": 1, "active_only": False}
)
run_data   = runs_resp.json()
latest_run = run_data["runs"][0]
run_id     = latest_run["run_id"]

run_detail = requests.get(
    f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/get",
    headers=headers,
    params={"run_id": run_id}
).json()

tasks     = run_detail.get("tasks", [])
task_data = []
for t in tasks:
    name     = t.get("task_key", t.get("notebook_task", {}).get("notebook_path", ""))
    duration = (t["end_time"] - t["start_time"]) / 1000 if t.get("end_time") and t.get("start_time") else 0
    task_data.append({"notebook": name, "duration_sec": duration})

df_tasks = pd.DataFrame(task_data).sort_values("duration_sec", ascending=False)

parallel_1 = ["01_extrator_asia", "02_extrator_can_usa_uk", "03_extrator_ferias"]
parallel_2 = ["04_extrator_loa",  "05_extrator_nao_loa",   "06_extrator_nao_loa_prorrog"]

df_p1  = df_tasks[df_tasks["notebook"].isin(parallel_1)]
df_p2  = df_tasks[df_tasks["notebook"].isin(parallel_2)]
df_seq = df_tasks[~df_tasks["notebook"].isin(parallel_1 + parallel_2)]

total_sec = df_p1["duration_sec"].max() + df_p2["duration_sec"].max() + df_seq["duration_sec"].sum()
total_str = f"{int(total_sec // 60)}m {int(total_sec % 60)}s"

def get_color(nb):
    if nb in parallel_1: return "#FFD580"
    if nb in parallel_2: return "#E89DFA"
    return "skyblue"

colors = [get_color(nb) for nb in df_tasks["notebook"]]

plt.figure(figsize=(10, 6))
bars = plt.barh(df_tasks["notebook"], df_tasks["duration_sec"], color=colors)
for bar, dur in zip(bars, df_tasks["duration_sec"]):
    plt.text(bar.get_width() + 1, bar.get_y() + bar.get_height() / 2,
             f"{dur:.1f}s", va='center')
plt.axvline(total_sec, color="#FFD580", linestyle="--")
plt.legend(handles=[
    mpatches.Patch(color='#FFD580', label='Paralelo Momento 1'),
    mpatches.Patch(color='#E89DFA', label='Paralelo Momento 2'),
    mpatches.Patch(color='skyblue', label='Sequencial'),
    mlines.Line2D([], [], color='#FFD580', linestyle='--', label=f'Total: {total_str}')
], loc='lower right', borderpad=1.5, labelspacing=1.5, handletextpad=1.5, borderaxespad=7)
plt.xlabel("Duração (segundos)")
plt.title("Tempo de execução por notebook — EC-49")
plt.tight_layout()
plt.show()