# Prontuário Médico — ETL PySpark/Databricks

## Visão Geral

Pipeline de ETL que migra o processamento de dados do **Prontuário Médico** (SAP SuccessFactors) de Power Query/Excel para PySpark no Databricks, seguindo a arquitetura padrão Bronze → Silver.

## Estrutura do Projeto

```
Prontuario_Medico/
├── config/
│   └── config.ipynb          # Constantes: paths, schemas, tabelas, colunas
├── utils/
│   └── utils.ipynb           # Funções reutilizáveis (leitura, limpeza, export)
├── notebooks/
│   ├── 01_exame_clinico_bronze.ipynb
│   ├── 02_pcd_bronze.ipynb
│   ├── 03_exames_complementares_bronze.ipynb
│   ├── 04_cabecalho_exame_clinico_bronze.ipynb
│   ├── 05_cabecalho_exames_compl_bronze.ipynb
│   ├── 06_local_sso_de_para_bronze.ipynb
│   ├── 07_ec_local_fisico_bronze.ipynb
│   ├── 08_formata_exame_clinico_silver.ipynb
│   ├── 09_exame_clinico_nao_ec_silver.ipynb
│   ├── 10_formata_pcd_silver.ipynb
│   ├── 11_pcd_sem_decreto_silver.ipynb
│   ├── 12_formata_exames_complementares_silver.ipynb
│   └── 13_consolidacao_exportacao_silver.ipynb
└── validation/
    └── layout_validation.ipynb
```

## Fluxos de Dados

### Fluxo 1: Exame Clínico
```
Power Query original: Formata_Pront_Med_Exame_Clinico / Local SSO Não EC

01_exame_clinico_bronze ──┐
04_cabecalho_ec_bronze ───┤
06_local_sso_bronze ──────┼──→ 08_formata_exame_clinico_silver ──→ 13_consolidacao
07_ec_local_fisico_bronze ┤
                          └──→ 09_exame_clinico_nao_ec_silver (diagnóstico)
```

### Fluxo 2: PCD (Pessoa com Deficiência)
```
Power Query original: Formata_Prontuario_Medico_PCD / Sem_Decreto

02_pcd_bronze ────────────┐
07_ec_local_fisico_bronze ┼──→ 10_formata_pcd_silver ──────────→ 13_consolidacao
                          └──→ 11_pcd_sem_decreto_silver (diagnóstico)
```

### Fluxo 3: Exames Complementares
```
Power Query original: Formata Exames Complementares

03_exames_compl_bronze ───┐
05_cabecalho_compl_bronze ┼──→ 12_formata_exames_compl_silver ──→ 13_consolidacao
```

## Configuração do Job (Databricks Workflows)

```
Momento 1 (paralelo):
  → 01_exame_clinico_bronze
  → 02_pcd_bronze
  → 03_exames_complementares_bronze
  → 04_cabecalho_exame_clinico_bronze
  → 05_cabecalho_exames_compl_bronze
  → 06_local_sso_de_para_bronze
  → 07_ec_local_fisico_bronze

Momento 2 (aguarda todos os Bronze):
  → 08_formata_exame_clinico_silver
  → 09_exame_clinico_nao_ec_silver
  → 10_formata_pcd_silver
  → 11_pcd_sem_decreto_silver
  → 12_formata_exames_complementares_silver

Momento 3 (aguarda todos os Silver):
  → 13_consolidacao_exportacao_silver

Momento 4 (opcional):
  → validation/layout_validation
```

## Mapeamento Power Query → PySpark

| Query Power Query | Notebook PySpark | Camada |
|---|---|---|
| Folder.Files + Transform File (EC) | 01_exame_clinico_bronze | Bronze |
| DB_PCD (CSV) | 02_pcd_bronze | Bronze |
| Folder.Files + Transform File (Compl) | 03_exames_complementares_bronze | Bronze |
| Cabecalho_Prontuario_Medico_Exame_Clinico | 04_cabecalho_exame_clinico_bronze | Bronze |
| Cabecalho Exames Complementares | 05_cabecalho_exames_compl_bronze | Bronze |
| Local SSO_ DE X PARA | 06_local_sso_de_para_bronze | Bronze |
| EC (Local_Fisico_De_Para_Mock4) | 07_ec_local_fisico_bronze | Bronze |
| Formata_Pront_Med_Exame_Clinico | 08_formata_exame_clinico_silver | Silver |
| Local SSO Não EC | 09_exame_clinico_nao_ec_silver | Silver |
| Formata_Prontuario_Medico_PCD | 10_formata_pcd_silver | Silver |
| Sem_Decreto | 11_pcd_sem_decreto_silver | Silver |
| Formata Exames Complementares | 12_formata_exames_complementares_silver | Silver |
| (exportação manual) | 13_consolidacao_exportacao_silver | Silver |

## Pré-requisitos

1. Criar tabelas Delta no Unity Catalog (schemas `bron_prontuario_medico` e `silv_prontuario_medico`)
2. Fazer upload dos arquivos de entrada para os Volumes configurados no `config.py`
3. Instalar `openpyxl` nos clusters (ou usar `%pip install openpyxl`)
