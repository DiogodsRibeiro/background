# Databricks notebook source
'''
══════════════════════════════════════════════════════════════════════════════
08 — FORMATA PRONTUÁRIO MÉDICO EXAME CLÍNICO — Camada Silver
══════════════════════════════════════════════════════════════════════════════
Origem PQ: Formata_Pront_Med_Exame_Clinico
Lógica:
  1. Lê dados brutos do Exame Clínico (Bronze)
  2. Remove colunas administrativas (CD_EMPRESA, UNIDADE, etc.)
  3. Remove '/' das colunas de data (DATE_PERFORMED_3, DT_ASO_234)
  4. Extrai apenas dígitos do CRM (MED_CRM_CM_232 → MED_CRM_CM)
  5. Trata INAPTO_CM (valores 5 ou 6 → "0")
  6. Remove duplicatas
  7. Cross-join com cabeçalho (colunas do template SAP)
  8. JOIN com Local SSO DE x PARA → resolve novo código local
  9. JOIN com EC → filtra apenas locais válidos (EC encontrado)
 10. Ajustes finais de colunas (renomeia LOCL_OCUP, LOCL_SUPORTE)

Depende de: 01_exame_clinico_bronze, 04_cabecalho_exame_clinico_bronze,
            06_local_sso_de_para_bronze, 07_ec_local_fisico_bronze
Destino: SILVER_EXAME_CLINICO
══════════════════════════════════════════════════════════════════════════════
'''

# COMMAND ----------

# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Prontuário Médico/utils/utils"

# COMMAND ----------

# ── 1. Carregar fontes Bronze ─────────────────────────────────────────────────

df_exame = spark.table(BRONZE_EXAME_CLINICO)
df_cabecalho = spark.table(BRONZE_CABECALHO_EXAME_CLINICO)
df_local_sso = spark.table(BRONZE_LOCAL_SSO_DE_PARA)
df_ec = spark.table(BRONZE_EC_LOCAL_FISICO)
 
print(f"Exame Clínico: {df_exame.count()} registros")
print(f"Cabeçalho: {df_cabecalho.count()} registros")
print(f"Local SSO DE x PARA: {df_local_sso.count()} registros")
print(f"EC Local Físico: {df_ec.count()} registros")
print(f"\nColunas Bronze ({len(df_exame.columns)}): {df_exame.columns}")

# COMMAND ----------

# ── 2. Renomear colunas Oracle → layout SAP e remover administrativas ────────

df = df_exame

for old_name, new_name in ORACLE_TO_SAP_RENAME.items():
    if old_name in df.columns:
        df = df.withColumnRenamed(old_name, new_name)

DROP_COLS = [
    "EMPRESA", "DT_ADMISSAO", "DT_DEMISSAO", "DS_LOCAL_FISICO",
    "CONCLUSAO_FINAL",
    "CD_EMPRESA", "NM_NOME", "NU_DOCUMENTO", "DS_SITUACAO",
    "TIPO_EXAME", "XXXXXX", "Source.Name",
]
for col_name in DROP_COLS:
    if col_name in df.columns:
        df = df.drop(col_name)

print(f"Colunas após mapeamento ({len(df.columns)}): {df.columns}")

# COMMAND ----------

# ── 3. Remover '/' das colunas de data ────────────────────────────────────────

date_cols = [c for c in ["DATE_PERFORMED", "DT_ASO"] if c in df.columns]
df = remove_slashes(df, date_cols)

# COMMAND ----------

# ── 4. Tratar valores numéricos e CRM ─────────────────────────────────────

NUMERIC_FIX_COLS = ["APTO_LIB_CM", "INAPTO_CM", "TP_EXAME"]

for c in NUMERIC_FIX_COLS:
    if c in df.columns:
        df = df.withColumn(
            c,
            F.when(
                F.col(c).isNull() | (F.col(c) == ""),
                F.lit("")
            ).otherwise(
                F.regexp_replace(
                    F.col(c).cast("decimal(38,0)").cast("string"),
                    "^null$", "0"
                )
            )
        )

if "MED_CRM_CM_232" in df.columns:
    df = extract_digits(df, "MED_CRM_CM_232", "MED_CRM_CM")
    df = df.drop("MED_CRM_CM_232")

if "INAPTO_CM_236" in df.columns:
    df = df.withColumn(
        "INAPTO_CM",
        F.when(F.col("INAPTO_CM_236").isin("5", "6"), F.lit("0"))
         .otherwise(F.col("INAPTO_CM_236"))
    ).drop("INAPTO_CM_236")
elif "INAPTO_CM" in df.columns:
    df = df.withColumn(
        "INAPTO_CM",
        F.when(F.col("INAPTO_CM").isin("5", "6"), F.lit("0"))
         .otherwise(F.col("INAPTO_CM"))
    )

# COMMAND ----------

# ── 5. Remover duplicatas ─────────────────────────────────────────────────────
 
df = df.dropDuplicates()

# COMMAND ----------

# ── 6. Cross-join com cabeçalho (template SAP) ───────────────────────────────
# O cabeçalho tem 1 linha com Seq=1; cada registro recebe colunas do template.

# Dropar do cabeçalho colunas que já existem no df para evitar conflito
cols_in_df = set(df.columns)
df_cab = df_cabecalho

# Colunas do cabeçalho que podem conflitar com dados do Oracle
# (nomes pré-rename + nomes com espaço do Excel template)
conflict_cols = [
    "PERNR", "SRV_NUMBER", "DATE_PERFORMED", "PGROUP", "PNUMBER",
    "SRV_PROTTYPE", "MED_NAME_CM", "MED_CRM_CM", "UF_CM", "DT_ASO",
    "APTO_LIB_CM", "INAPTO_CM", "LOCL_OCUP",
    # Colunas com espaço que serão criadas/renomeadas depois
    "LOCL SUPORTE", "MED NAME CAA", "MED CRM CAA", "UF CAA",
    "PRE ENQ CAA", "CONCL",
]

for c in df_cab.columns:
    if c in cols_in_df or c in conflict_cols:
        if c != "Seq":
            df_cab = df_cab.drop(c)

df = cross_join_with_header(df, df_cab)

if "Seq" in df.columns:
    df = df.drop("Seq")

df = df.dropDuplicates()

# COMMAND ----------

# ── 7. JOIN com Local SSO DE x PARA ──────────────────────────────────────────

df_local_sso_join = df_local_sso.select(
    F.col("CD_UNIDADE(DE)").alias("_lsso_cd_de"),
    F.col("CD_LOCAL_FISICO").alias("_lsso_local_fisico"),
    F.col("CD_UNIDADE (PARA)").alias("_lsso_cd_para"),
)

df = df.join(
    df_local_sso_join,
    (df["LOCL_OCUP"] == df_local_sso_join["_lsso_cd_de"]) &
    (df["LOCAL_FISICO"] == df_local_sso_join["_lsso_local_fisico"]),
    "left"
)

df = df.withColumn(
    "CD_LOCAL_SSO_NEW",
    F.when(
        (F.col("_lsso_cd_para").isNull()) | (F.col("_lsso_cd_para") == ""),
        F.col("LOCL_OCUP")
    ).otherwise(F.col("_lsso_cd_para"))
)

df = df.drop("_lsso_cd_de", "_lsso_local_fisico", "_lsso_cd_para")

# COMMAND ----------

# ── 8. JOIN com EC para validar local SSO ───────────────────────────────────
# Chave: CD_LOCAL_SSO_NEW = "Local SSO SDWEB"
# FILTRO: Manter apenas registros COM match na EC
 
df_ec_join = df_ec.select(
    F.col("Local SSO SDWEB").alias("_ec_sdweb"),
    F.col("Local SSO (Código)").alias("_ec_codigo"),
)
 
df = df.join(
    F.broadcast(df_ec_join),
    df["CD_LOCAL_SSO_NEW"] == df_ec_join["_ec_sdweb"],
    "left"
)
 
df = df.filter(F.col("_ec_codigo").isNotNull())

# COMMAND ----------

# ── 9. Ajustes finais — popular apenas colunas com dados reais ─────────────

df = df.withColumn("LOCL_OCUP_FINAL", F.col("_ec_codigo"))
df = df.withColumn("LOCL_SUPORTE_FINAL", F.col("_ec_codigo"))

df = df.drop("LOCL_OCUP", "CD_LOCAL_SSO_NEW", "_ec_sdweb", "_ec_codigo", "LOCAL_FISICO")
df = df.withColumnRenamed("LOCL_OCUP_FINAL", "LOCL_OCUP")
df = df.withColumnRenamed("LOCL_SUPORTE_FINAL", "LOCL_SUPORTE_243")

df = df.dropDuplicates()

COLS_COM_DADOS = [
    "PERNR", "SRV_NUMBER", "DATE_PERFORMED", "PGROUP",
    "PNUMBER", "SRV_PROTTYPE",
    "TP_EXAME", "REF", "CODE", "DT_REAL", "RELAT_ANL", "ASSINATURA",
    "MED_NAME_CM", "MED_CRM_CM", "UF_CM", "DT_ASO",
    "APTO_LIB_CM", "INAPTO_CM",
    "LOCL_OCUP", "LOCL_SUPORTE_243",
]

for c in df.columns:
    if c not in COLS_COM_DADOS:
        df = df.withColumn(c, F.lit(""))

print(f"✅ Exame Clínico formatado: {df.count()} registros")

# COMMAND ----------

# ── 10. Montar DataFrame final com todas as colunas do layout ─────────────

for col in FINAL_COL_ORDER_EXAME_CLINICO:
    if col not in df.columns:
        df = df.withColumn(col, F.lit(""))

# Deixar as colunas especificadas vazias por padrão
cols_vazias = ["TP_EXAME", "CODE", "DT_REAL", "RELAT_ANL", "ASSINATURA", "LOCL_SUPORTE_243"]
for col in cols_vazias:
    if col in df.columns:
        df = df.withColumn(col, F.lit(""))

df_final = df.select(*FINAL_COL_ORDER_EXAME_CLINICO)
df_final = null_to_empty(df_final, FINAL_COL_ORDER_EXAME_CLINICO)

df_exame_clinico_count = df_final.count()  # guardar count antes do filtro
print(f"📊 Antes do filtro JobInfo: {df_exame_clinico_count} registros")
print(f'Número de colunas: {len(df_final.columns)}.')
# display(df_final)

# COMMAND ----------

# ── 11. Filtrar apenas funcionários ativos (EC_33 JobInfo) ────────────────────
# Faz inner join com a base de funcionários ativos para manter apenas
# registros de pessoas que existem no JobInfo Brasil.

# Ler Excel: header na linha 2 (0-indexed: header_row=1), ignorando a linha 1
pdf_jobinfo = pd.read_excel(EC_33_PATH, header=1, dtype=str)
pdf_jobinfo = pdf_jobinfo.fillna("")
df_jobinfo = spark.createDataFrame(pdf_jobinfo)

# Renomear para evitar ambiguidade no join
df_jobinfo_key = df_jobinfo.select(
    F.col("ID do usuário").alias("_jobinfo_pernr")
).dropDuplicates()

print(f"JobInfo: {df_jobinfo_key.count()} funcionários únicos")

# Inner join: manter apenas PERNR que existem no JobInfo
df_final = df_final.join(
    F.broadcast(df_jobinfo_key),
    df_final["PERNR"] == df_jobinfo_key["_jobinfo_pernr"],
    "inner"
).drop("_jobinfo_pernr")

print(f"✅ Após filtro JobInfo: {df_final.count()} registros (de {df_exame_clinico_count} originais)")
display(df_final)

# COMMAND ----------

save_table(df_final, SILVER_EXAME_CLINICO)