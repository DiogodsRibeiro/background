# Databricks notebook source
'''
══════════════════════════════════════════════════════════════════════════════
05 — CABEÇALHO EXAMES COMPLEMENTARES — Camada Bronze
══════════════════════════════════════════════════════════════════════════════
Fonte: Template Excel com cabeçalho/colunas do layout SAP
Destino: BRONZE_CABECALHO_EXAMES_COMPL
Dependências: Nenhuma
══════════════════════════════════════════════════════════════════════════════
'''

# COMMAND ----------

# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Prontuário Médico/utils/utils"
# MAGIC

# COMMAND ----------

df_bronze = read_excel(CABECALHO_EXAMES_COMPL_PATH, sheet_name=CABECALHO_EXAMES_SHEET_NAME)
df_bronze = rename_cols(df_bronze)

print(f"Registros lidos: {df_bronze.count()}")
print(f"Colunas ({len(df_bronze.columns)}): {df_bronze.columns}")
display(df_bronze)


# COMMAND ----------

save_table(df_bronze, BRONZE_CABECALHO_EXAMES_COMPL)
