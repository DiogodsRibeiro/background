# Databricks notebook source
'''
══════════════════════════════════════════════════════════════════════════════
07 — EC (LOCAL FÍSICO DE-PARA) — Camada Bronze
══════════════════════════════════════════════════════════════════════════════
Fonte: Excel com mapeamento EC (Estrutura Corporativa) de locais físicos
Destino: BRONZE_EC_LOCAL_FISICO
Dependências: Nenhuma
══════════════════════════════════════════════════════════════════════════════
'''

# COMMAND ----------

# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Prontuário Médico/utils/utils"
# MAGIC

# COMMAND ----------

df_bronze = read_excel(EC_LOCAL_FISICO_PATH, sheet_name=EC_SHEET_NAME)
df_bronze = rename_cols(df_bronze)

# Filtrar registros onde "Local SSO SDWEB" não seja nulo (mesma lógica do PQ)
df_bronze = df_bronze.filter(
    (F.col("Local SSO SDWEB").isNotNull()) & (F.col("Local SSO SDWEB") != "")
)

print(f"Registros lidos: {df_bronze.count()}")
print(f"Colunas ({len(df_bronze.columns)}): {df_bronze.columns}")
display(df_bronze)


# COMMAND ----------

save_table(df_bronze, BRONZE_EC_LOCAL_FISICO)
