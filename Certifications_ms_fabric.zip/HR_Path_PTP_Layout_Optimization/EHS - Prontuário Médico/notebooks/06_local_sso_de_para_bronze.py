# Databricks notebook source
'''
══════════════════════════════════════════════════════════════════════════════
06 — LOCAL SSO DE x PARA — Camada Bronze
══════════════════════════════════════════════════════════════════════════════
Fonte: Excel com mapeamento de locais SSO antigos para novos
Destino: BRONZE_LOCAL_SSO_DE_PARA
Dependências: Nenhuma
══════════════════════════════════════════════════════════════════════════════
'''

# COMMAND ----------

# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Prontuário Médico/utils/utils"
# MAGIC

# COMMAND ----------

df_bronze = read_excel(LOCAL_SSO_DE_PARA_PATH, sheet_name=LOCAL_SSO_SHEET_NAME)
df_bronze = rename_cols(df_bronze)

print(f"Registros lidos: {df_bronze.count()}")
print(f"Colunas ({len(df_bronze.columns)}): {df_bronze.columns}")
display(df_bronze)

# COMMAND ----------

save_table(df_bronze, BRONZE_LOCAL_SSO_DE_PARA)
