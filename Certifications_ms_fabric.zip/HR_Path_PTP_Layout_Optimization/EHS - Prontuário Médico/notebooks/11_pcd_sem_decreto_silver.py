# Databricks notebook source
'''
══════════════════════════════════════════════════════════════════════════════
11 — PCD SEM DECRETO — Camada Silver
══════════════════════════════════════════════════════════════════════════════
Origem PQ: Sem_Decreto
Lógica: Mesmo pipeline do PCD, porém ao final filtra apenas registros
         onde DECRETO1A = "" (vazio). Usado para diagnóstico/controle.

Depende de: 02_pcd_bronze, 07_ec_local_fisico_bronze
Destino: SILVER_PCD_SEM_DECRETO
══════════════════════════════════════════════════════════════════════════════
'''

# COMMAND ----------

# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Prontuário Médico/utils/utils"
# MAGIC

# COMMAND ----------

# ── 1. Carregar fontes Bronze ─────────────────────────────────────────────────

df_pcd = spark.table(BRONZE_PCD)
df_ec = spark.table(BRONZE_EC_LOCAL_FISICO)


# COMMAND ----------

# ── 2. NÃO filtrar por decreto aqui — o filtro será feito ao final ───────────

df = df_pcd

# Criar chave de ordenação e deduplicar
df = df.withColumn(
    "CHAVE_ORDENACAO",
    F.concat_ws("_",
        F.col("PERNR"),
        F.col("DATE_PERFORMED"),
        F.col("DT_REG"),
        F.col("DECRETO1A"),
        F.col("CID"),
    )
)

df = dedup_by_sort_key(df, key_col="CHAVE_ORDENACAO", sort_col="PERNR")
df = df.drop("CHAVE_ORDENACAO")


# COMMAND ----------

# ── 3. Limpeza e transformações (mesmas do notebook 10) ──────────────────────

df = clean_special_chars(df, PCD_TEXT_CLEANUP_COLS)
df = replace_pipe_with_slash(df, PCD_PIPE_REPLACE_COLS)
df = remove_punctuation(df, PCD_NUMOC_CLEANUP_COLS)
df = df.dropDuplicates()


# COMMAND ----------

# ── 4. JOIN com EC ────────────────────────────────────────────────────────────

df_ec_join = df_ec.select(
    F.col("Local SSO SDWEB").alias("_ec_sdweb"),
    F.col("Local SSO (Código)").alias("_ec_codigo"),
)

df = df.join(
    F.broadcast(df_ec_join),
    df["LOCL_OCUP"] == df_ec_join["_ec_sdweb"],
    "left"
)

df = df.dropDuplicates()
df = df.filter(F.col("_ec_codigo").isNotNull())

# Replicar código EC
df = (
    df.withColumn("LOCL_SUPORTE", F.col("_ec_codigo"))
      .withColumn("LOCL_OCUP_NEW", F.col("_ec_codigo"))
      .withColumn("LOCL_ATEND_NEW", F.col("_ec_codigo"))
)

df = (
    df.drop("LOCL_OCUP", "LOCL_ATEND", "_ec_sdweb", "_ec_codigo")
      .withColumnRenamed("LOCL_OCUP_NEW", "LOCL_OCUP")
      .withColumnRenamed("LOCL_ATEND_NEW", "LOCL_ATEND")
)


# COMMAND ----------

# ── 5. FILTRO FINAL: manter somente registros SEM decreto ────────────────────

df = df.filter(
    (F.col("DECRETO1A").isNull()) | (F.col("DECRETO1A") == "")
)


# COMMAND ----------

# ── 6. Selecionar e gravar ───────────────────────────────────────────────────

final_cols = [c for c in FINAL_COL_ORDER_PCD if c in df.columns]
df_final = df.select(*final_cols)
df_final = null_to_empty(df_final, final_cols)

print(f"✅ PCD sem decreto: {df_final.count()} registros")
display(df_final)


# COMMAND ----------

save_table(df_final, SILVER_PCD_SEM_DECRETO)
