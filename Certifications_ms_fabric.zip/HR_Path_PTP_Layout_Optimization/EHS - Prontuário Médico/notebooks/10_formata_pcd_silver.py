# Databricks notebook source
'''
══════════════════════════════════════════════════════════════════════════════
10 — FORMATA PRONTUÁRIO MÉDICO PCD — Camada Silver (v3)
══════════════════════════════════════════════════════════════════════════════
Origem PQ: Formata_Prontuario_Medico_PCD
Lógica:
  1. Filtra apenas registros COM decreto (DECRETO1A <> "")
  2. Fix colunas decimais do Oracle (DECRETO1A, TIPO)
  3. Cria chave de ordenação composta e dedup
  4. Limpa caracteres especiais e substitui '|' por '/'
  5. Remove pontuação de NUMOC_MED e MED_CRM_CAA
  6. Inner JOIN com EC 33 (JobInfo) por PERNR → traz "Local físico"
  7. JOIN com Árvore Localização: "Local físico" (EC33) == "Código" (Árvore)
     → obtém "Local SSO (Código)"
  8. Substitui LOCL_OCUP, LOCL_ATEND, LOCL_SUPORTE pelo valor obtido

Depende de: 02_pcd_bronze, EC_33, Arvore_Localizacao
Destino: SILVER_PCD
══════════════════════════════════════════════════════════════════════════════
'''

# COMMAND ----------

# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Prontuário Médico/utils/utils"
# MAGIC

# COMMAND ----------

df_pcd = spark.table(BRONZE_PCD)
print(f"PCD: {df_pcd.count()} registros")


# COMMAND ----------

df = df_pcd.filter(
    (F.col("DECRETO1A").isNotNull()) & (F.col("DECRETO1A") != "")
)
print(f"Registros com decreto: {df.count()}")


# COMMAND ----------

# ── Fix colunas decimais do Oracle ANTES da chave ────────────────────────
PCD_NUMERIC_FIX_COLS = ["DECRETO1A", "TIPO"]

for c in PCD_NUMERIC_FIX_COLS:
    if c in df.columns:
        df = df.withColumn(
            c,
            F.when(
                F.col(c).isNull() | (F.col(c) == ""),
                F.lit("")
            ).otherwise(
                F.regexp_replace(
                    F.col(c).cast("decimal(38,0)").cast("string"),
                    "^null$", ""
                )
            )
        )

print("Fix decimal aplicado em:", PCD_NUMERIC_FIX_COLS)


# COMMAND ----------

df = df.withColumn(
    "CHAVE_ORDENACAO",
    F.concat_ws("_",
        F.col("PERNR"),
        F.col("DATE_PERFORMED"),
        F.col("DT_REG"),
        F.col("DECRETO1A"),
        F.col("CID"),
    )
)

df = dedup_by_sort_key(df, key_col="CHAVE_ORDENACAO", sort_col="PERNR")
df = df.drop("CHAVE_ORDENACAO")


# COMMAND ----------

df = clean_special_chars(df, PCD_TEXT_CLEANUP_COLS)


# COMMAND ----------

df = replace_pipe_with_slash(df, PCD_PIPE_REPLACE_COLS)


# COMMAND ----------

df = df.dropDuplicates()


# COMMAND ----------

df = remove_punctuation(df, PCD_NUMOC_CLEANUP_COLS)


# COMMAND ----------

final_cols = [c for c in FINAL_COL_ORDER_PCD if c in df.columns]
df_final = df.select(*final_cols)
df_final = null_to_empty(df_final, final_cols)

df_final_count = df_final.count()
print(f"PCD formatado: {df_final_count} registros")
print(f"Número de colunas: {len(df_final.columns)}.")


# COMMAND ----------

# ══════════════════════════════════════════════════════════════════════════════
# DE/PARA: EC 33 (JobInfo) → Árvore Localização → Local SSO (Código)
# ══════════════════════════════════════════════════════════════════════════════

# ── 1. Carregar EC 33 (JobInfo Brasil) ────────────────────────────────────────
pdf_jobinfo = pd.read_excel(EC_33_PATH, header=1, dtype=str)
pdf_jobinfo = pdf_jobinfo.fillna("")
df_jobinfo = spark.createDataFrame(pdf_jobinfo)

# Selecionar colunas necessárias: PERNR + Local físico
df_jobinfo_key = df_jobinfo.select(
    F.trim(F.col("ID do usuário")).alias("_jobinfo_pernr"),
    F.trim(F.col("Local físico")).alias("_local_fisico"),
).dropDuplicates(["_jobinfo_pernr"])

print(f"EC 33 JobInfo: {df_jobinfo_key.count()} funcionários únicos")

# ── 2. Carregar Árvore Localização ────────────────────────────────────────────
# Se precisar especificar aba, ajuste o sheet_name abaixo
pdf_arvore = pd.read_excel(ARVORE_LOC_PATH, dtype=str)
pdf_arvore = pdf_arvore.fillna("")
df_arvore = spark.createDataFrame(pdf_arvore)

df_arvore_key = df_arvore.select(
    F.trim(F.col("Código")).alias("_arvore_codigo"),
    F.trim(F.col("Local SSO (Código)")).alias("_arvore_local_sso"),
).filter(
    (F.col("_arvore_local_sso").isNotNull()) & (F.col("_arvore_local_sso") != "")
).dropDuplicates(["_arvore_codigo"])

print(f"Árvore Localização: {df_arvore_key.count()} registros com Local SSO")

# ── 3. Inner JOIN PCD → EC 33 (filtra funcionários ativos + traz Local físico)
df_final = df_final.join(
    F.broadcast(df_jobinfo_key),
    df_final["PERNR"] == df_jobinfo_key["_jobinfo_pernr"],
    "inner"
)
print(f"Após inner join EC 33: {df_final.count()} registros")

# ── 4. Left JOIN EC 33.Local físico → Árvore Localização.Código ──────────────
df_final = df_final.join(
    F.broadcast(df_arvore_key),
    F.col("_local_fisico") == F.col("_arvore_codigo"),
    "left"
)

# Diagnóstico
com_sso = df_final.filter(F.col("_arvore_local_sso").isNotNull()).count()
sem_sso = df_final.filter(F.col("_arvore_local_sso").isNull()).count()
print(f"Com Local SSO (Código):  {com_sso}")
print(f"Sem Local SSO (Código):  {sem_sso}")

if sem_sso > 0:
    print("\nExemplos de Local físico sem match na Árvore (primeiros 10):")
    df_final.filter(F.col("_arvore_local_sso").isNull()).select(
        "PERNR", "_local_fisico"
    ).distinct().show(10, truncate=False)


# COMMAND ----------

# ── 5. Substituir colunas de local pelo Local SSO (Código) da Árvore ─────
df_final = (
    df_final
    .withColumn("LOCL_SUPORTE",
        F.when(F.col("_arvore_local_sso").isNotNull(), F.col("_arvore_local_sso"))
         .otherwise(F.col("LOCL_SUPORTE"))
    )
    .withColumn("LOCL_OCUP",
        F.when(F.col("_arvore_local_sso").isNotNull(), F.col("_arvore_local_sso"))
         .otherwise(F.col("LOCL_OCUP"))
    )
    .withColumn("LOCL_ATEND",
        F.when(F.col("_arvore_local_sso").isNotNull(), F.col("_arvore_local_sso"))
         .otherwise(F.col("LOCL_ATEND"))
    )
)

# Limpar colunas auxiliares
df_final = df_final.drop("_jobinfo_pernr", "_local_fisico", "_arvore_codigo", "_arvore_local_sso")

print(f"✅ Colunas LOCL_SUPORTE, LOCL_OCUP, LOCL_ATEND atualizadas")
print(f"Total final: {df_final.count()} registros")


# COMMAND ----------

# Garantir ordem final das colunas
final_cols = [c for c in FINAL_COL_ORDER_PCD if c in df_final.columns]
df_final = df_final.select(*final_cols)

print(f"Colunas finais: {len(df_final.columns)}")


# COMMAND ----------

save_table(df_final, SILVER_PCD)


# COMMAND ----------

# ── Verificação ──────────────────────────────────────────────────────────
df = spark.read.table(SILVER_PCD)
print(f"Total na silver: {df.count()} registros")
print(f"PERNR 331371: {df.filter(F.col('PERNR') == '331371').count()} registros")
display(df.filter(F.col('PERNR') == '331371').select(
    'PERNR', 'LOCL_OCUP', 'LOCL_ATEND', 'LOCL_SUPORTE'
))
