# Databricks notebook source
'''
══════════════════════════════════════════════════════════════════════════════
09 — LOCAL SSO NÃO EC (EXAME CLÍNICO) — Camada Silver
══════════════════════════════════════════════════════════════════════════════
Origem PQ: "Local SSO Não EC"
Lógica: Mesmo pipeline do Exame Clínico, porém filtra registros cujo
         local SSO NÃO foi encontrado na tabela EC (EC.Local SSO Código = null).
         Útil para diagnóstico de locais não mapeados.

Depende de: 01_exame_clinico_bronze, 04_cabecalho_exame_clinico_bronze,
            06_local_sso_de_para_bronze, 07_ec_local_fisico_bronze
Destino: SILVER_EXAME_CLINICO_NAO_EC
══════════════════════════════════════════════════════════════════════════════
'''

# COMMAND ----------

# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Prontuário Médico/utils/utils"
# MAGIC

# COMMAND ----------

# ── 1. Carregar fontes Bronze ─────────────────────────────────────────────────
 
df_exame = spark.table(BRONZE_EXAME_CLINICO)
df_cabecalho = spark.table(BRONZE_CABECALHO_EXAME_CLINICO)
df_local_sso = spark.table(BRONZE_LOCAL_SSO_DE_PARA)
df_ec = spark.table(BRONZE_EC_LOCAL_FISICO)

# COMMAND ----------

# ── 2. Renomear colunas Oracle → layout SAP e remover administrativas ────────
 
df = df_exame
 
for old_name, new_name in ORACLE_TO_SAP_RENAME.items():
    if old_name in df.columns:
        df = df.withColumnRenamed(old_name, new_name)
 
DROP_COLS = [
    "EMPRESA", "DT_ADMISSAO", "DT_DEMISSAO", "DS_LOCAL_FISICO",
    "CONCLUSAO_FINAL",
    "CD_EMPRESA", "NM_NOME", "NU_DOCUMENTO", "DS_SITUACAO",
    "TIPO_EXAME", "XXXXXX", "Source.Name",
]
for col_name in DROP_COLS:
    if col_name in df.columns:
        df = df.drop(col_name)

# COMMAND ----------

# ── 3. Remover '/' das datas ─────────────────────────────────────────────────
 
date_cols = [c for c in ["DATE_PERFORMED_3", "DT_ASO_234"] if c in df.columns]
df = remove_slashes(df, date_cols)

# COMMAND ----------

# ── 4. Tratar CRM e INAPTO ───────────────────────────────────────────────────
 
if "MED_CRM_CM_232" in df.columns:
    df = extract_digits(df, "MED_CRM_CM_232", "MED_CRM_CM")
    df = df.drop("MED_CRM_CM_232")
 
if "INAPTO_CM_236" in df.columns:
    df = df.withColumn(
        "INAPTO_CM",
        F.when(F.col("INAPTO_CM_236").isin("5", "6"), F.lit("0"))
         .otherwise(F.col("INAPTO_CM_236"))
    ).drop("INAPTO_CM_236")
elif "INAPTO_CM" in df.columns:
    df = df.withColumn(
        "INAPTO_CM",
        F.when(F.col("INAPTO_CM").isin("5", "6"), F.lit("0"))
         .otherwise(F.col("INAPTO_CM"))
    )
 
df = df.dropDuplicates()

# COMMAND ----------

# ── 5. Cross-join com cabeçalho ──────────────────────────────────────────────
 
cols_in_df = set(df.columns)
df_cab = df_cabecalho
 
conflict_cols = [
    "PERNR", "SRV_NUMBER", "DATE_PERFORMED", "PGROUP", "PNUMBER",
    "SRV_PROTTYPE", "MED_NAME_CM", "MED_CRM_CM", "UF_CM", "DT_ASO",
    "APTO_LIB_CM", "INAPTO_CM", "LOCL_OCUP",
]
for c in df_cab.columns:
    if c in cols_in_df or c in conflict_cols:
        if c != "Seq":
            df_cab = df_cab.drop(c)
 
df = cross_join_with_header(df, df_cab)
 
if "Seq" in df.columns:
    df = df.drop("Seq")
 
df = df.dropDuplicates()

# COMMAND ----------

# ── 6. JOIN com Local SSO DE x PARA ──────────────────────────────────────────
 
df_local_sso_join = df_local_sso.select(
    F.col("CD_UNIDADE(DE)").alias("_lsso_cd_de"),
    F.col("CD_LOCAL_FISICO").alias("_lsso_local_fisico"),
    F.col("CD_UNIDADE (PARA)").alias("_lsso_cd_para"),
)
 
df = df.join(
    df_local_sso_join,
    (df["LOCL_OCUP_237"] == df_local_sso_join["_lsso_cd_de"]) &
    (df["LOCAL_FISICO"] == df_local_sso_join["_lsso_local_fisico"]),
    "left"
)
 
df = df.withColumn(
    "CD_LOCAL_SSO_NEW",
    F.when(
        (F.col("_lsso_cd_para").isNull()) | (F.col("_lsso_cd_para") == ""),
        F.col("LOCL_OCUP_237")
    ).otherwise(F.col("_lsso_cd_para"))
)
 
df = df.drop("_lsso_cd_de", "_lsso_local_fisico", "_lsso_cd_para")

# COMMAND ----------

# ── 7. JOIN com EC — FILTRO INVERTIDO (NÃO encontrado) ───────────────────────
 
df_ec_join = df_ec.select(
    F.col("Local SSO SDWEB").alias("_ec_sdweb"),
    F.col("Local SSO (Código)").alias("_ec_codigo"),
)
 
df = df.join(
    F.broadcast(df_ec_join),
    df["CD_LOCAL_SSO_NEW"] == df_ec_join["_ec_sdweb"],
    "left"
)
 
# FILTRO INVERTIDO: manter somente registros SEM match na EC
df = df.filter(F.col("_ec_codigo").isNull())

# COMMAND ----------

# ── 8. Ajustes finais ────────────────────────────────────────────────────────
 
df = df.drop("CD_LOCAL_SSO_NEW", "_ec_sdweb", "_ec_codigo", "LOCAL_FISICO")
df = df.dropDuplicates()
 
print(f"⚠️  Locais SSO não encontrados na EC: {df.count()} registros")
display(df)

# COMMAND ----------

save_table(df, SILVER_EXAME_CLINICO_NAO_EC)
