# Databricks notebook source
'''
══════════════════════════════════════════════════════════════════════════════
04 — CABEÇALHO PRONTUÁRIO MÉDICO EXAME CLÍNICO — Camada Bronze
══════════════════════════════════════════════════════════════════════════════
Fonte: Template Excel com cabeçalho/colunas do layout SAP
Destino: BRONZE_CABECALHO_EXAME_CLINICO
Dependências: Nenhuma
══════════════════════════════════════════════════════════════════════════════
'''

# COMMAND ----------

# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Prontuário Médico/utils/utils"
# MAGIC

# COMMAND ----------

df_bronze = read_excel(CABECALHO_EXAME_CLINICO_PATH, sheet_name=CABECALHO_EC_SHEET_NAME)
df_bronze = rename_cols(df_bronze)

print(f"Registros lidos: {df_bronze.count()}")
print(f"Colunas ({len(df_bronze.columns)}): {df_bronze.columns}")
display(df_bronze)


# COMMAND ----------

save_table(df_bronze, BRONZE_CABECALHO_EXAME_CLINICO)
