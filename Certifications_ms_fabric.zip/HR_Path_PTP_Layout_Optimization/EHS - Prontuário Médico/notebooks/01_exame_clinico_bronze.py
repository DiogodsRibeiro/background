# Databricks notebook source
'''
══════════════════════════════════════════════════════════════════════════════
01 — EXAME CLÍNICO — Camada Bronze
══════════════════════════════════════════════════════════════════════════════
Fonte: Pasta com arquivos Excel (Exportar Planilha) do prontuário médico
Destino: BRONZE_EXAME_CLINICO
Dependências: Nenhuma
══════════════════════════════════════════════════════════════════════════════
'''

# COMMAND ----------

# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Prontuário Médico/utils/utils"
# MAGIC

# COMMAND ----------

query = f"""
(
WITH tab AS (
SELECT EMPRESA,
       UNIDADE,
       cd_local_fisico,
       ds_local_fisico,
       To_Char(DT_ADMISSAO, 'dd/mm/yyyy')    AS DT_ADMISSAO,
       To_Char(DT_DEMISSAO, 'dd/mm/yyyy')    AS DT_DEMISSAO,
       PERNR,
       '' as SRV_NUMBER,
       To_Char(DATE_PERFORMED, 'dd/mm/yyyy') AS DATE_PERFORMED,
       '021' AS PGROUP,
       P_NUMBER,
       SRV_PROTTYPE,
       MED_NAME_CM,
       MED_CRM_CM,
       UF_CM,
       To_Char(Nvl(DT_ASO, DT_ASO_MAX), 'dd/mm/yyyy') AS DT_ASO ,
       APTO_LIB_CM,
       INAPTO_CM,
       UNIDADE as LOCL_OCUP_237
FROM (SELECT e.cd_empresa empresa,
            u.cd_unidade unidade,
            local_fisico.cl000000000000abcd000200000000 cd_local_fisico,
            local_fisico.cl000000000000abcd000300000000 ds_local_fisico,
            v.nu_matricula as PERNR,
            teo.CL000000000000ABCD001100000000 as DATE_PERFORMED,
            dt_admissao,
            dt_demissao,
            CASE teo.CLF4EC17B3314746E2A709B12CEAED
               WHEN 'a2f01a82-d0fa-40f1-b5a6-150cfe5bd2fd' THEN '048' -- Periodico
               WHEN '83dc1c33-3542-43f2-8d59-8db298d55b7c' THEN '044' -- Admissional
               WHEN 'a6d6cd3f-721e-412a-a841-9211ddd98e17' THEN '049' -- Retorno ao Trabalho
               WHEN '57bd74c7-e337-4627-9c89-e7dea7c024ba' THEN '045' -- Demissional
               WHEN '436d43e9-1a0e-4438-84b5-54ba02ee8cbb' THEN '046' -- Especial
               WHEN '850803d1-1f58-49a6-bed4-27245957319f' THEN '046' -- Especial
               WHEN 'ee92ca56-2956-4e88-9030-213873fb3657' THEN '047' -- Mudanca de Funcao
            END AS P_NUMBER,
            CASE teo.CLF4EC17B3314746E2A709B12CEAED
               WHEN '83dc1c33-3542-43f2-8d59-8db298d55b7c' THEN '228' -- Admissional
               WHEN '57bd74c7-e337-4627-9c89-e7dea7c024ba' THEN '231' -- Demissional
               WHEN '850803d1-1f58-49a6-bed4-27245957319f' THEN '235' -- Especial
               WHEN '436d43e9-1a0e-4438-84b5-54ba02ee8cbb' THEN '235' -- Especial
               WHEN 'ee92ca56-2956-4e88-9030-213873fb3657' THEN '237' -- Mudanca de Funcao
               WHEN 'a2f01a82-d0fa-40f1-b5a6-150cfe5bd2fd' THEN '240' -- Periodico
               WHEN 'a6d6cd3f-721e-412a-a841-9211ddd98e17' THEN '246' -- Retorno ao Trabalho
            END AS SRV_PROTTYPE,
            CASE teo.CLF4EC17B3314746E2A709B12CEAED
               WHEN '83dc1c33-3542-43f2-8d59-8db298d55b7c' THEN 1
               WHEN '57bd74c7-e337-4627-9c89-e7dea7c024ba' THEN 3
               WHEN '850803d1-1f58-49a6-bed4-27245957319f' THEN 6
               WHEN '436d43e9-1a0e-4438-84b5-54ba02ee8cbb' THEN 6
               WHEN 'ee92ca56-2956-4e88-9030-213873fb3657' THEN 5
               WHEN 'a2f01a82-d0fa-40f1-b5a6-150cfe5bd2fd' THEN 2
               WHEN 'a6d6cd3f-721e-412a-a841-9211ddd98e17' THEN 4
            END AS TP_EXAME,
            eco.CL000000000000ABCD001100000000 DT_REAL,
            {ORACLE_SCHEMA}.FC_VALOR_TAB_TR('TB802A2B0A33CC4082984AF5A74_TR', 'CL000000000000ABCD000200000000', eco.CL802A2B0A33CC4082984AF5A74AB5) AS RELAT_ANL,
            prof.CL58284C47272B4729ABF5215F368D MED_NAME_CM,
            regexp_replace(prof.CLD71E82DA3FE94E6993408F732A72,'[^0-9]','') MED_CRM_CM,
            CASE {ORACLE_SCHEMA}.FC_VALOR_TAB_TR('TBB432B979EEBE4ECA8A629623E_TR', 'CL000000000000ABCD000200000000', prof.CLB432B979EEBE4ECA8A629623EBB7)
               WHEN 'AC' THEN '01'
               WHEN 'AL' THEN '02'
               WHEN 'AP' THEN '03'
               WHEN 'AM' THEN '04'
               WHEN 'BA' THEN '05'
               WHEN 'CE' THEN '06'
               WHEN 'DF' THEN '07'
               WHEN 'ES' THEN '08'
               WHEN 'GO' THEN '09'
               WHEN 'MA' THEN '10'
               WHEN 'MT' THEN '11'
               WHEN 'MS' THEN '12'
               WHEN 'MG' THEN '13'
               WHEN 'PA' THEN '14'
               WHEN 'PB' THEN '15'
               WHEN 'PR' THEN '16'
               WHEN 'PE' THEN '17'
               WHEN 'PI' THEN '18'
               WHEN 'RJ' THEN '19'
               WHEN 'RN' THEN '20'
               WHEN 'RS' THEN '21'
               WHEN 'RO' THEN '22'
               WHEN 'RR' THEN '23'
               WHEN 'SC' THEN '24'
               WHEN 'SP' THEN '25'
               WHEN 'SE' THEN '26'
               WHEN 'TO' THEN '27'
            ELSE ''
            END AS uf_cm,
            eco.CL000000000000ABCD001200000000 dt_aso,
            (SELECT LISTAGG(TR.CL000000000000ABCD000200000000, ',')
                    WITHIN GROUP (ORDER BY TR.CL000000000000ABCD000200000000)
             FROM {ORACLE_SCHEMA}.TB0485ABA11B0246CE940D89D48_MV MV,
                   {ORACLE_SCHEMA}.TBAFCAC66BC6DA4E8DB23A45DD4_TR TR
             WHERE MV.ID_REGISTRO = ECO.CL000000000000ABCD000000000000
                AND MV.CL000000000000ABCD001300000000 = TR.CL000000000000ABCD000000000000
                AND TR.ID_IDIOMA_VERSAO = '00000000-0000-0000-0000-000000000000') CONCLUSAO_FINAL,
            CASE {ORACLE_SCHEMA}.FC_VALOR_TAB_TR('TBAFCAC66BC6DA4E8DB23A45DD4_TR', 'CL000000000000ABCD000200000000', mv.CL000000000000ABCD001300000000)
               WHEN 'C.01A' THEN 1
               WHEN 'D.01A' THEN 2
               WHEN 'E.01A' THEN 3
            ELSE 0
            END APTO_LIB_CM,
            CASE {ORACLE_SCHEMA}.FC_VALOR_TAB_TR('TBAFCAC66BC6DA4E8DB23A45DD4_TR', 'CL000000000000ABCD000200000000', mv.CL000000000000ABCD001300000000)
               WHEN 'C.01B' THEN 1
               WHEN 'D.01B' THEN 2
               WHEN 'E.01B' THEN 3
            ELSE 0
            END INAPTO_CM,
            (SELECT Max(eco1.CL000000000000ABCD001200000000)
            FROM {ORACLE_SCHEMA}.TB0485ABA11B0246CE940D89D48F03 eco1,
                  {ORACLE_SCHEMA}.TBD4F8369149424FFB82ED155DF4ED teo1
            WHERE teo1.CL000000000000ABCD001000000000 = v.id_vinculo
               AND teo1.cl000000000000abcd001100000000 <= teo.cl000000000000abcd001100000000
               AND eco1.CL000000000000ABCD001000000000 = teo1.CL000000000000ABCD000000000000) dt_aso_max
      FROM {ORACLE_SCHEMA}.vw_ish_vinculo v,
           {ORACLE_SCHEMA}.vw_ish_empresa e,
           {ORACLE_SCHEMA}.vw_ish_unidade u,
           {ORACLE_SCHEMA}.TBD4F8369149424FFB82ED155DF4ED teo,
           {ORACLE_SCHEMA}.TB0485ABA11B0246CE940D89D48F03 eco,
           {ORACLE_SCHEMA}.TBE63597B2CC4F45AFA0EB8871ABA6 prof,
           {ORACLE_SCHEMA}.TBF4EC17B3314746E2A709B12CE_tr te_tr,
           (SELECT *
            FROM {ORACLE_SCHEMA}.TB0485ABA11B0246CE940D89D48_MV
            WHERE CL000000000000ABCD001300000000 IS NOT NULL) mv,
            {ORACLE_SCHEMA}.TBFF2D8A76B59546C89939908C7239 local_fisico
      WHERE  teo.CL000000000000ABCD001000000000   = v.id_vinculo
         AND v.id_empresa                         = e.id_empresa
         AND v.id_unidade                         = u.id_unidade
         AND v.id_local_fisico                    = local_fisico.CL000000000000ABCD000000000000 (+)
         AND te_tr.CL000000000000ABCD000000000000 = teo.CLF4EC17B3314746E2A709B12CEAED
         AND te_tr.id_idioma_versao               = '00000000-0000-0000-0000-000000000000'
         AND eco.CL000000000000ABCD001000000000   = teo.CL000000000000ABCD000000000000
         AND eco.CLE71A57D3889D4C778D70781BAF07   = prof.CL000000000000ABCD000000000000
         AND eco.CL000000000000ABCD000000000000   = mv.id_registro (+)
         AND e.cd_empresa in ('00001', '00004', '00046', '00064', '00068', '00112', '00284', '00360', '00632','00646')
         AND eco.CL000000000000ABCD001200000000 >= To_Date('01/10/2021', 'dd/mm/yyyy')
         AND v.NU_MATRICULA NOT LIKE '%APAGAR%' AND v.NU_MATRICULA NOT LIKE '%-%' AND v.NU_MATRICULA NOT LIKE '%CONV%' AND Length(v.NU_MATRICULA) < 11
         AND ((v.dt_admissao <= To_Date('23/03/2026', 'dd/mm/yyyy') AND v.dt_demissao IS NULL) OR v.dt_demissao >= To_Date('01/10/2021', 'dd/mm/yyyy')))
WHERE Nvl(DT_ASO, DT_ASO_MAX) >= To_Date('01/10/2021', 'dd/mm/yyyy')
  AND Nvl(DT_ASO, DT_ASO_MAX) <= To_Date('23/03/2026', 'dd/mm/yyyy'))
SELECT * FROM TAB t
WHERE DATE_PERFORMED = (SELECT MAX(DATE_PERFORMED) FROM TAB WHERE PERNR = T.PERNR AND SRV_PROTTYPE = T.SRV_PROTTYPE)
) Q
"""

df = (
    spark.read.format("jdbc")
    .option("url",      ORACLE_JDBC_URL)
    .option("dbtable",  query)
    .option("user",     ORACLE_USER)
    .option("password", ORACLE_PASSWORD)
    .option("driver",   ORACLE_DRIVER)
    .load()
)

df_bronze = rename_cols(df)

print(f"Registros lidos: {df_bronze.count()}")
print(f"Colunas ({len(df_bronze.columns)}): {df_bronze.columns}")
display(df_bronze)

# COMMAND ----------

save_table(df_bronze, BRONZE_EXAME_CLINICO)