# Databricks notebook source
'''
══════════════════════════════════════════════════════════════════════════════
12 — FORMATA EXAMES COMPLEMENTARES — Camada Silver
══════════════════════════════════════════════════════════════════════════════
Origem PQ: "Formata Exames Complementares"
Lógica:
  1. Lê Exames Complementares (Bronze)
  2. Split de P_NUMBER, SRV_PROTTYPE e COD_EXAME pelo espaço (1ª parte numérica)
  3. Seleciona apenas as colunas necessárias
  4. Cross-join com cabeçalho (template SAP — colunas expandidas)
  5. Reordena colunas no layout final
  6. Adiciona prefixo "0" em P_NUMBER
  7. Remove '/' de DATA_PERFORMAD e DATE_RESULT
  8. Deduplicação final

Depende de: 03_exames_complementares_bronze, 05_cabecalho_exames_compl_bronze
Destino: SILVER_EXAMES_COMPLEMENTARES
══════════════════════════════════════════════════════════════════════════════
'''

# COMMAND ----------

# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Prontuário Médico/utils/utils"
# MAGIC

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.types import StringType, IntegerType

# COMMAND ----------

df_bronze = spark.table(BRONZE_EXAMES_COMPLEMENTARES)
print(f"Bronze — colunas: {len(df_bronze.columns)}")
print(f"Bronze — colunas: {df_bronze.columns}")
print(f"total de registros Bronze: {spark.read.table(BRONZE_EXAMES_COMPLEMENTARES).count()} ")

# COMMAND ----------

# Cabeçalho SAP (Excel do Volume) — extrai a lista de 420 colunas na ordem correta
df_cabecalho = read_excel(CABECALHO_EXAMES_COMPL_PATH, CABECALHO_EXAMES_SHEET_NAME)
SAP_COLUMNS = [c for c in df_cabecalho.columns if c != "Seq"]

# Renames para alinhar com o layout final (PQ faz isso no split/reorder)
RENAME_MAP = {
    "P_NUMBER":      "PNUMBER",
    "DATA_PERFORMAD": "DATE_PERFORMED",
    "DATE_COLETA_1":  "DATE_COLETA2",
}
for old, new in RENAME_MAP.items():
    SAP_COLUMNS = [new if c == old else c for c in SAP_COLUMNS]

print(f"Cabeçalho SAP — colunas: {len(SAP_COLUMNS)}")

# COMMAND ----------

df = df_bronze.filter(
    ~F.col("PERNR").rlike("[A-Za-z]")
)

df = df.dropDuplicates()

# COMMAND ----------

df = (
    df
    .withColumn("P_NUMBER",     F.split(F.col("P_NUMBER"),     " ").getItem(0).cast(IntegerType()))
    .withColumn("SRV_PROTTYPE", F.split(F.col("SRV_PROTTYPE"), " ").getItem(0).cast(IntegerType()))
    .withColumn("COD_EXAME",    F.split(F.col("COD_EXAME"),    " ").getItem(0).cast(IntegerType()))
)


# COMMAND ----------

COLUNAS_BASE = [
    "PGROUP",
    "P_NUMBER",
    "SRV_PROTTYPE",
    "PERNR",
    "COD_EXAME",
    "DATE_RESULT",
    "RES_REF_LAB",
    "RELAT_ANL",
    "DATA_PERFORMAD",
]

# COMMAND ----------

df = df.select(*COLUNAS_BASE)


# COMMAND ----------

RENAME_MAP = {
    "P_NUMBER":       "PNUMBER",
    "DATA_PERFORMAD": "DATE_PERFORMED",
}

# Aplicar renames
for old_name, new_name in RENAME_MAP.items():
    df = df.withColumnRenamed(old_name, new_name)

# Colunas base já no DataFrame (com nomes Silver)
colunas_existentes = set(df.columns)

# Adicionar todas as colunas faltantes como null (string)
for col_name in SAP_COLUMNS:
    if col_name not in colunas_existentes:
        df = df.withColumn(col_name, F.lit(None).cast(StringType()))

# COMMAND ----------

# ══════════════════════════════════════════════════════════════════════════════
# 6. Reordenar conforme layout SAP (FINAL_COL_ORDER_EXAMES_COMPL)
# ══════════════════════════════════════════════════════════════════════════════

df = df.select(*SAP_COLUMNS)

print(f"Silver — colunas: {len(df.columns)}")

# COMMAND ----------

# 7. Formatações
#    a) PNUMBER: prefixo "0" → ex: 44 → "044", 228 → "0228"
#       Power Query: "0" & Text.From(_, "pt-BR")
#    b) DATE_PERFORMED: data → string ddMMyyyy (sem separador)
#       Power Query: converte para texto, depois remove "/"
#    c) DATE_RESULT: mesmo tratamento que DATE_PERFORMED
# ══════════════════════════════════════════════════════════════════════════════

df = (
    df
    # a) Prefixo "0" no PNUMBER
    .withColumn("PNUMBER",
        F.concat(F.lit("0"), F.col("PNUMBER").cast(StringType()))
    )

    # b) DATE_PERFORMED → ddMMyyyy
    .withColumn("DATE_PERFORMED",
        F.date_format(F.col("DATE_PERFORMED").cast("date"), "ddMMyyyy")
    )

    # c) DATE_RESULT → ddMMyyyy
    .withColumn("DATE_RESULT",
        F.date_format(F.col("DATE_RESULT").cast("date"), "ddMMyyyy")
    )
    # d) Garantir que TODAS as colunas sejam string
    .select([F.col(c).cast(StringType()).alias(c) for c in SAP_COLUMNS])
)

# COMMAND ----------

df_silver = df.dropDuplicates()

df_final = df_silver

df_final_count = df_final.count()

print(f"PCD formatado: {df_final_count} registros")

print(f"Antes do filtro JobInfo: {df_final_count} registros")
print(f'Número de colunas: {len(df_final.columns)}.')

# COMMAND ----------

# ── 11. Filtrar apenas funcionários ativos (EC_33 JobInfo) ────────────────────
# Faz inner join com a base de funcionários ativos para manter apenas
# registros de pessoas que existem no JobInfo Brasil.

# Ler Excel: header na linha 2 (0-indexed: header_row=1), ignorando a linha 1
pdf_jobinfo = pd.read_excel(EC_33_PATH, header=1, dtype=str)
pdf_jobinfo = pdf_jobinfo.fillna("")
df_jobinfo = spark.createDataFrame(pdf_jobinfo)

# Renomear para evitar ambiguidade no join
df_jobinfo_key = df_jobinfo.select(
    F.col("ID do usuário").alias("_jobinfo_pernr")
).dropDuplicates()

print(f"JobInfo: {df_jobinfo_key.count()} funcionários únicos")

# Inner join: manter apenas PERNR que existem no JobInfo
df_final = df_final.join(
    F.broadcast(df_jobinfo_key),
    df_final["PERNR"] == df_jobinfo_key["_jobinfo_pernr"],
    "inner"
).drop("_jobinfo_pernr")

print(f"✅ Após filtro JobInfo: {df_final.count()} registros (de {df_final_count} originais)")

# COMMAND ----------

save_table(df_final, SILVER_EXAMES_COMPLEMENTARES)
print(f'Tabela gravada: {SILVER_EXAMES_COMPLEMENTARES}')