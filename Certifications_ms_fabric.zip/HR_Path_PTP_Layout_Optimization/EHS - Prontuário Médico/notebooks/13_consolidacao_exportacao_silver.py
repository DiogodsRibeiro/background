# Databricks notebook source
'''
══════════════════════════════════════════════════════════════════════════════
13 — CONSOLIDAÇÃO FINAL E EXPORTAÇÃO — Camada Silver
══════════════════════════════════════════════════════════════════════════════
Responsabilidade:
  Consolida os resultados dos três fluxos (Exame Clínico, PCD, Exames
  Complementares) e exporta os arquivos finais para o Volume de saída.

  Cada fluxo gera seu próprio arquivo de layout SAP — eles NÃO são
  unidos por unionByName (schemas distintos).

Depende de: 08_formata_exame_clinico_silver,
            10_formata_pcd_silver,
            12_formata_exames_complementares_silver
══════════════════════════════════════════════════════════════════════════════
'''

# COMMAND ----------

# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Prontuário Médico/utils/utils"
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### Formata Exame Clínico - Exportação XLSX - Com duas abas

# COMMAND ----------

# ══════════════════════════════════════════════════════════════════════════════
# EXAME CLÍNICO — Exportação
# ══════════════════════════════════════════════════════════════════════════════
 
df_exame_clinico = spark.table(SILVER_EXAME_CLINICO)

# Contagem ANTES do filtro: matrículas distintas na bronze (com decreto)
df_bronze_exames_clinicos = spark.table(BRONZE_EXAME_CLINICO)
matriculas_antes = df_bronze_exames_clinicos.select("PERNR").distinct().count()

# Contagem DEPOIS do filtro: matrículas distintas na silver (já filtrada pelo JobInfo)
matriculas_depois = df_exame_clinico.select("PERNR").distinct().count()

print(f"📊 Matrículas antes do filtro: {matriculas_antes}")
print(f"📊 Matrículas depois do filtro: {matriculas_depois}")
print(f"📊 Total Formata Exames Clínicos: {df_exame_clinico.count()} registros")
 
export_df_to_excel_with_counts(
    df_exame_clinico,
    OUTPUT_BASE,
    "Formata_Pront_Med_Exame_Clinico",
    counts={
        "Matriculas antes do filtro": matriculas_antes,
        "Matriculas depois do filtro": matriculas_depois,
    },
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Formata Exame Clínico - Layout SAP - Exportação CSV

# COMMAND ----------

# ══════════════════════════════════════════════════════════════════════════════
# EXAME CLÍNICO — Exportação CSV para SAP SuccessFactors
# ══════════════════════════════════════════════════════════════════════════════
# Layout: Layout_Prontuário_Médico_V10a (243 colunas)
# Formato: CSV, delimitador vírgula, UTF-8, valores entre aspas duplas
# Datas: formato DDMMAAAA (sem separadores)

df_exame_clinico = spark.table(SILVER_EXAME_CLINICO)

# ── Mapeamento: coluna interna (com sufixo dedup) → nome original do layout ──
# O layout SAP usa nomes duplicados; o Spark usa sufixos para desambiguar.
# A ordem aqui define a ordem das colunas no CSV final.
LAYOUT_MAP = [
    # (nome_interno,              nome_csv,             is_date)
    ("PERNR",                     "PERNR",              False),
    ("SRV_NUMBER",                "SRV_NUMBER",         False),
    ("DATE_PERFORMED",            "DATE_PERFORMED",     True),
    ("PGROUP",                    "PGROUP",             False),
    ("PNUMBER",                   "PNUMBER",            False),
    ("SRV_PROTTYPE",              "SRV_PROTTYPE",       False),
    ("REF",                       "REF",                False),
    ("TP_EXAME",                  "TP_EXAME",           False),
    ("CODE",                      "CODE",               False),
    ("TEST_VALUE",                "TEST_VALUE",         False),
    ("TEST_LUNIT",                "TEST_LUNIT",         False),
    ("TEST_RESULTT",              "TEST_RESULTT",       False),
    ("DT_REAL",                   "DT_REAL",            True),
    ("RESULTADO",                 "RESULTADO",          False),
    ("RELAT_ANL",                 "RELAT_ANL",          False),
    ("ASSINATURA",                "ASSINATURA",         False),
    ("AVALRAC",                   "AVALRAC",            False),
    # RAC1 block
    ("RAC1",                      "RAC1",               False),
    ("DT_AVAL_RAC",               "DT_AVAL_RAC",        True),
    ("SITUACAO",                  "SITUACAO",           False),
    ("CONTRAINDICACAO",           "CONTRAINDICACAO",    False),
    ("REAVALIACAO_RAC",           "REAVALIACAO_RAC",    False),
    ("TEMPO_REAVALIACAO",         "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM",                  "DATA_FIM",           True),
    ("ULT_AVALIACAO",             "ULT_AVALIACAO",      True),
    # RAC2 block
    ("RAC2",                      "RAC2",               False),
    ("DT_AVAL_RAC_1",             "DT_AVAL_RAC",        True),
    ("SITUACAO_1",                "SITUACAO",           False),
    ("CONTRAINDICACAO_1",         "CONTRAINDICACAO",    False),
    ("REAVALIACAO_RAC_1",         "REAVALIACAO_RAC",    False),
    ("TEMPO_REAVALIACAO_1",       "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_1",                "DATA_FIM",           True),
    ("ULT_AVALIACAO_1",           "ULT_AVALIACAO",      True),
    # RAC3 block
    ("RAC3",                      "RAC3",               False),
    ("DT_AVAL_RAC_2",             "DT_AVAL_RAC",        True),
    ("SITUACAO_2",                "SITUACAO",           False),
    ("CONTRAINDICACAO_2",         "CONTRAINDICACAO",    False),
    ("REAVALIACAO_RAC_2",         "REAVALIACAO_RAC",    False),
    ("TEMPO_REAVALIACAO_2",       "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_2",                "DATA_FIM",           True),
    ("ULT_AVALIACAO_2",           "ULT_AVALIACAO",      True),
    # RAC5 block
    ("RAC5",                      "RAC5",               False),
    ("DT_AVAL_RAC_3",             "DT_AVAL_RAC",        True),
    ("SITUACAO_3",                "SITUACAO",           False),
    ("CONTRAINDICACAO_3",         "CONTRAINDICACAO",    False),
    ("REAVALIACAO_RAC_3",         "REAVALIACAO_RAC",    False),
    ("TEMPO_REAVALIACAO_3",       "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_3",                "DATA_FIM",           True),
    ("ULT_AVALIACAO_3",           "ULT_AVALIACAO",      True),
    # RAC6 block
    ("RAC6",                      "RAC6",               False),
    ("DT_AVAL_RAC_4",             "DT_AVAL_RAC",        True),
    ("SITUACAO_4",                "SITUACAO",           False),
    ("CONTRAINDICACAO_4",         "CONTRAINDICACAO",    False),
    ("REAVALIACAO_RAC_4",         "REAVALIACAO_RAC",    False),
    ("TEMPO_REAVALIACAO_4",       "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_4",                "DATA_FIM",           True),
    ("ULT_AVALIACAO_4",           "ULT_AVALIACAO",      True),
    # RAC10 block
    ("RAC10",                     "RAC10",              False),
    ("DT_AVAL_RAC_5",             "DT_AVAL_RAC",        True),
    ("SITUACAO_5",                "SITUACAO",           False),
    ("CONTRAINDICACAO_5",         "CONTRAINDICACAO",    False),
    ("REAVALIACAO_RAC_5",         "REAVALIACAO_RAC",    False),
    ("TEMPO_REAVALIACAO_5",       "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_5",                "DATA_FIM",           True),
    ("ULT_AVALIACAO_5",           "ULT_AVALIACAO",      True),
    # RAC11 block
    ("RAC11",                     "RAC11",              False),
    ("DT_AVAL_RAC_6",             "DT_AVAL_RAC",        True),
    ("SITUACAO_6",                "SITUACAO",           False),
    ("CONTRAINDICACAO_6",         "CONTRAINDICACAO",    False),
    ("REAVALIACAO_RAC_6",         "REAVALIACAO_RAC",    False),
    ("TEMPO_REAVALIACAO_6",       "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_6",                "DATA_FIM",           True),
    ("ULT_AVALIACAO_6",           "ULT_AVALIACAO",      True),
    # RESTATIV + ATIVID_RESTRICAO blocks (1-13, sem número, 14-18)
    ("RESTATIV",                  "RESTATIV",           False),
    # Block 1
    ("ATIVID_RESTRICAO1",         "ATIVID_RESTRICAO1",  False),
    ("SITUACAO_7",                "SITUACAO",           False),
    ("DT_AVAL_MEDICA",            "DT_AVAL_MEDICA",     True),
    ("REAVALIACAO_MED",           "REAVALIACAO_MED",    False),
    ("TEMPO_REAVALIACAO_7",       "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_7",                "DATA_FIM",           True),
    ("ULT_AVALIACAO_7",           "ULT_AVALIACAO",      True),
    # Block 2
    ("ATIVID_RESTRICAO2",         "ATIVID_RESTRICAO2",  False),
    ("SITUACAO_8",                "SITUACAO",           False),
    ("DT_AVAL_MEDICA_1",          "DT_AVAL_MEDICA",     True),
    ("REAVALIACAO_MED_1",         "REAVALIACAO_MED",    False),
    ("TEMPO_REAVALIACAO_8",       "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_8",                "DATA_FIM",           True),
    ("ULT_AVALIACAO_8",           "ULT_AVALIACAO",      True),
    # Block 3
    ("ATIVID_RESTRICAO3",         "ATIVID_RESTRICAO3",  False),
    ("SITUACAO_9",                "SITUACAO",           False),
    ("DT_AVAL_MEDICA_2",          "DT_AVAL_MEDICA",     True),
    ("REAVALIACAO_MED_2",         "REAVALIACAO_MED",    False),
    ("TEMPO_REAVALIACAO_9",       "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_9",                "DATA_FIM",           True),
    ("ULT_AVALIACAO_9",           "ULT_AVALIACAO",      True),
    # Block 4
    ("ATIVID_RESTRICAO4",         "ATIVID_RESTRICAO4",  False),
    ("SITUACAO_10",               "SITUACAO",           False),
    ("DT_AVAL_MEDICA_3",          "DT_AVAL_MEDICA",     True),
    ("REAVALIACAO_MED_3",         "REAVALIACAO_MED",    False),
    ("TEMPO_REAVALIACAO_10",      "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_10",               "DATA_FIM",           True),
    ("ULT_AVALIACAO_10",          "ULT_AVALIACAO",      True),
    # Block 5
    ("ATIVID_RESTRICAO5",         "ATIVID_RESTRICAO5",  False),
    ("SITUACAO_11",               "SITUACAO",           False),
    ("DT_AVAL_MEDICA_4",          "DT_AVAL_MEDICA",     True),
    ("REAVALIACAO_MED_4",         "REAVALIACAO_MED",    False),
    ("TEMPO_REAVALIACAO_11",      "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_11",               "DATA_FIM",           True),
    ("ULT_AVALIACAO_11",          "ULT_AVALIACAO",      True),
    # Block 6
    ("ATIVID_RESTRICAO6",         "ATIVID_RESTRICAO6",  False),
    ("SITUACAO_12",               "SITUACAO",           False),
    ("DT_AVAL_MEDICA_5",          "DT_AVAL_MEDICA",     True),
    ("REAVALIACAO_MED_5",         "REAVALIACAO_MED",    False),
    ("TEMPO_REAVALIACAO_12",      "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_12",               "DATA_FIM",           True),
    ("ULT_AVALIACAO_12",          "ULT_AVALIACAO",      True),
    # Block 7
    ("ATIVID_RESTRICAO7",         "ATIVID_RESTRICAO7",  False),
    ("SITUACAO_13",               "SITUACAO",           False),
    ("DT_AVAL_MEDICA_6",          "DT_AVAL_MEDICA",     True),
    ("REAVALIACAO_MED_6",         "REAVALIACAO_MED",    False),
    ("TEMPO_REAVALIACAO_13",      "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_13",               "DATA_FIM",           True),
    ("ULT_AVALIACAO_13",          "ULT_AVALIACAO",      True),
    # Block 8
    ("ATIVID_RESTRICAO8",         "ATIVID_RESTRICAO8",  False),
    ("SITUACAO_14",               "SITUACAO",           False),
    ("DT_AVAL_MEDICA_7",          "DT_AVAL_MEDICA",     True),
    ("REAVALIACAO_MED_7",         "REAVALIACAO_MED",    False),
    ("TEMPO_REAVALIACAO_14",      "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_14",               "DATA_FIM",           True),
    ("ULT_AVALIACAO_14",          "ULT_AVALIACAO",      True),
    # Block 9
    ("ATIVID_RESTRICAO9",         "ATIVID_RESTRICAO9",  False),
    ("SITUACAO_15",               "SITUACAO",           False),
    ("DT_AVAL_MEDICA_8",          "DT_AVAL_MEDICA",     True),
    ("REAVALIACAO_MED_8",         "REAVALIACAO_MED",    False),
    ("TEMPO_REAVALIACAO_15",      "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_15",               "DATA_FIM",           True),
    ("ULT_AVALIACAO_15",          "ULT_AVALIACAO",      True),
    # Block 10
    ("ATIVID_RESTRICAO10",        "ATIVID_RESTRICAO10", False),
    ("SITUACAO_16",               "SITUACAO",           False),
    ("DT_AVAL_MEDICA_9",          "DT_AVAL_MEDICA",     True),
    ("REAVALIACAO_MED_9",         "REAVALIACAO_MED",    False),
    ("TEMPO_REAVALIACAO_16",      "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_16",               "DATA_FIM",           True),
    ("ULT_AVALIACAO_16",          "ULT_AVALIACAO",      True),
    # Block 11
    ("ATIVID_RESTRICAO11",        "ATIVID_RESTRICAO11", False),
    ("SITUACAO_17",               "SITUACAO",           False),
    ("DT_AVAL_MEDICA_10",         "DT_AVAL_MEDICA",     True),
    ("REAVALIACAO_MED_10",        "REAVALIACAO_MED",    False),
    ("TEMPO_REAVALIACAO_17",      "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_17",               "DATA_FIM",           True),
    ("ULT_AVALIACAO_17",          "ULT_AVALIACAO",      True),
    # Block 12
    ("ATIVID_RESTRICAO12",        "ATIVID_RESTRICAO12", False),
    ("SITUACAO_18",               "SITUACAO",           False),
    ("DT_AVAL_MEDICA_11",         "DT_AVAL_MEDICA",     True),
    ("REAVALIACAO_MED_11",        "REAVALIACAO_MED",    False),
    ("TEMPO_REAVALIACAO_18",      "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_18",               "DATA_FIM",           True),
    ("ULT_AVALIACAO_18",          "ULT_AVALIACAO",      True),
    # Block 13
    ("ATIVID_RESTRICAO13",        "ATIVID_RESTRICAO13", False),
    ("SITUACAO_19",               "SITUACAO",           False),
    ("DT_AVAL_MEDICA_12",         "DT_AVAL_MEDICA",     True),
    ("REAVALIACAO_MED_12",        "REAVALIACAO_MED",    False),
    ("TEMPO_REAVALIACAO_19",      "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_19",               "DATA_FIM",           True),
    ("ULT_AVALIACAO_19",          "ULT_AVALIACAO",      True),
    # Block sem número
    ("ATIVID_RESTRICAO",          "ATIVID_RESTRICAO",   False),
    ("SITUACAO_20",               "SITUACAO",           False),
    ("DT_AVAL_MEDICA_13",         "DT_AVAL_MEDICA",     True),
    ("REAVALIACAO_MED_13",        "REAVALIACAO_MED",    False),
    ("TEMPO_REAVALIACAO_20",      "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_20",               "DATA_FIM",           True),
    ("ULT_AVALIACAO_20",          "ULT_AVALIACAO",      True),
    # Block 14
    ("ATIVID_RESTRICAO14",        "ATIVID_RESTRICAO14", False),
    ("SITUACAO_21",               "SITUACAO",           False),
    ("DT_AVAL_MEDICA_14",         "DT_AVAL_MEDICA",     True),
    ("REAVALIACAO_MED_14",        "REAVALIACAO_MED",    False),
    ("TEMPO_REAVALIACAO_21",      "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_21",               "DATA_FIM",           True),
    ("ULT_AVALIACAO_21",          "ULT_AVALIACAO",      True),
    # Block 15
    ("ATIVID_RESTRICAO15",        "ATIVID_RESTRICAO15", False),
    ("SITUACAO_22",               "SITUACAO",           False),
    ("DT_AVAL_MEDICA_15",         "DT_AVAL_MEDICA",     True),
    ("REAVALIACAO_MED_15",        "REAVALIACAO_MED",    False),
    ("TEMPO_REAVALIACAO_22",      "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_22",               "DATA_FIM",           True),
    ("ULT_AVALIACAO_22",          "ULT_AVALIACAO",      True),
    # Block 16
    ("ATIVID_RESTRICAO16",        "ATIVID_RESTRICAO16", False),
    ("SITUACAO_23",               "SITUACAO",           False),
    ("DT_AVAL_MEDICA_16",         "DT_AVAL_MEDICA",     True),
    ("REAVALIACAO_MED_16",        "REAVALIACAO_MED",    False),
    ("TEMPO_REAVALIACAO_23",      "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_23",               "DATA_FIM",           True),
    ("ULT_AVALIACAO_23",          "ULT_AVALIACAO",      True),
    # Block 17
    ("ATIVID_RESTRICAO17",        "ATIVID_RESTRICAO17", False),
    ("SITUACAO_24",               "SITUACAO",           False),
    ("DT_AVAL_MEDICA_17",         "DT_AVAL_MEDICA",     True),
    ("REAVALIACAO_MED_17",        "REAVALIACAO_MED",    False),
    ("TEMPO_REAVALIACAO_24",      "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_24",               "DATA_FIM",           True),
    ("ULT_AVALIACAO_24",          "ULT_AVALIACAO",      True),
    # Block 18 + OUTROS
    ("ATIVID_RESTRICAO18",        "ATIVID_RESTRICAO18", False),
    ("OUTROS",                    "OUTROS",             False),
    ("SITUACAO_25",               "SITUACAO",           False),
    ("DT_AVAL_MEDICA_18",         "DT_AVAL_MEDICA",     True),
    ("REAVALIACAO_MED_18",        "REAVALIACAO_MED",    False),
    ("TEMPO_REAVALIACAO_25",      "TEMPO_REAVALIACAO",  False),
    ("DATA_FIM_25",               "DATA_FIM",           True),
    ("ULT_AVALIACAO_25",          "ULT_AVALIACAO",      True),
    # Laudo PCD
    ("READAPTACAO",               "READAPTACAO",        False),
    ("DT_REG",                    "DT_REG",             True),
    ("DECRETO",                   "DECRETO",            False),
    ("TIPO",                      "TIPO",               False),
    ("CAUSA",                     "CAUSA",              False),
    ("CLASS",                     "CLASS",              False),
    ("TP_DEF",                    "TP_DEF",             False),
    ("DESC_ALT",                  "DESC_ALT",           False),
    ("JUST_ALT",                  "JUST_ALT",           False),
    ("CID",                       "CID",                False),
    ("LIM_CORP",                  "LIM_CORP",           False),
    ("DESC_LIM",                  "DESC_LIM",           False),
    ("DT_CARAC",                  "DT_CARAC",           True),
    ("OBS",                       "OBS",                False),   # <-- NOVO
    ("NOME_MED",                  "NOME_MED",           False),
    ("OC_MED",                    "OC_MED",             False),
    ("NUMOC_MED",                 "NUMOC_MED",          False),
    ("ESTADO",                    "ESTADO",             False),
    ("LOCL_ATEND",                "LOCL_ATEND",         False),
    ("DT_DESCARAC",               "DT_DESCARAC",        True),
    ("DT_CESS",                   "DT_CESS",            True),
    ("MOT_DESCARAC",              "MOT_DESCARAC",       False),
    # Conclusão atendimento ocupacional
    ("MED_NAME_CM",               "MED_NAME_CM",        False),
    ("MED_CRM_CM",                "MED_CRM_CM",         False),
    ("UF_CM",                     "UF_CM",              False),
    ("DT_ASO",                    "DT_ASO",             True),
    ("APTO_LIB_CM",               "APTO_LIB_CM",        False),
    ("INAPTO_CM",                 "INAPTO_CM",          False),
    ("LOCL_OCUP",                 "LOCL_OCUP",          False),   # <-- renomeado de LOCL_OCUP_237
    # Conclusão atendimento suporte ocupacional  <-- bloco inteiro NOVO
    ("MED_NAME_CAA",              "MED NAME CAA",       False),
    ("MED_CRM_CAA",               "MED CRM CAA",        False),
    ("UF_CAA",                    "UF CAA",             False),
    ("CONCL",                     "CONCL",              False),
    ("PRE_ENQ_CAA",               "PRE ENQ CAA",        False),
    ("LOCL_SUPORTE",              "LOCL SUPORTE",       False),
]

assert len(LAYOUT_MAP) == 243, f"LAYOUT_MAP tem {len(LAYOUT_MAP)} colunas, esperava 243"

# ── Selecionar colunas internas na ordem do layout ────────────────────────────
internal_cols = [m[0] for m in LAYOUT_MAP]

# Garantir que todas as colunas existem (criar vazias se necessário)
for col_name in internal_cols:
    if col_name not in df_exame_clinico.columns:
        df_exame_clinico = df_exame_clinico.withColumn(col_name, F.lit(""))

df_csv = df_exame_clinico.select(*internal_cols)
df_csv = null_to_empty(df_csv, internal_cols)

# ── Formatar datas: dd/mm/yyyy ou ddmmyyyy → DDMMAAAA (8 dígitos, sem /) ──────
date_cols = [m[0] for m in LAYOUT_MAP if m[2]]
for c in date_cols:
    df_csv = df_csv.withColumn(c, F.regexp_replace(F.col(c), "[/\\-]", ""))

print(f"📊 Exame Clínico para CSV SAP: {df_csv.count()} registros, {len(df_csv.columns)} colunas")

# ── Exportar CSV com header duplicado, vírgula, aspas duplas ──────────────────
import os, shutil, csv

csv_header = [m[1] for m in LAYOUT_MAP]  # nomes originais (com duplicatas)

tmp_csv  = f"/tmp/Arquivo_layout_SAP_Exame_Clinico.csv"
final_csv = f"{OUTPUT_BASE}/Arquivo_layout_SAP_Exame_Clinico.csv"

with open(tmp_csv, "w", encoding="utf-8", newline="") as f:
    writer = csv.writer(f, delimiter=",", quoting=csv.QUOTE_ALL)
    writer.writerow(csv_header)

    count = 0
    for row in df_csv.toLocalIterator():
        writer.writerow([str(row[c]) if row[c] is not None else "" for c in internal_cols])
        count += 1
        if count % 10_000 == 0:
            print(f"  ... {count} linhas")

shutil.copy2(tmp_csv, final_csv)
os.remove(tmp_csv)

print(f"✅ CSV SAP exportado: {final_csv} ({count} linhas, 243 colunas)")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Exames Complementares - Exportação XLSX - Com duas abas

# COMMAND ----------

df_formata_exames_complementares = spark.table(SILVER_EXAMES_COMPLEMENTARES)

# Contagem ANTES do filtro: matrículas distintas na bronze (com decreto)
df_bronze_exames_complementares = spark.table(BRONZE_EXAMES_COMPLEMENTARES)
matriculas_antes = df_bronze_exames_complementares.select("PERNR").distinct().count()

# Contagem DEPOIS do filtro: matrículas distintas na silver (já filtrada pelo JobInfo)
matriculas_depois = df_formata_exames_complementares.select("PERNR").distinct().count()

print(f"📊 Matrículas antes do filtro: {matriculas_antes}")
print(f"📊 Matrículas depois do filtro: {matriculas_depois}")
print(f"📊 Total Formata Exames Complementares: {df_formata_exames_complementares.count()} registros")

export_df_to_excel_with_counts(
    df_formata_exames_complementares,
    OUTPUT_BASE,
    "Formata_Exames_Compl",
    counts={
        "Matriculas antes do filtro": matriculas_antes,
        "Matriculas depois do filtro": matriculas_depois,
    },
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Formata PCD - Exportação XLSX - Com três abas

# COMMAND ----------

df_formata_pcd = spark.table(SILVER_PCD)
df_bronze_pcd = spark.table(BRONZE_PCD)

# Contagens
matriculas_antes = df_bronze_pcd.select("PERNR").distinct().count()
matriculas_depois = df_formata_pcd.select("PERNR").distinct().count()

# ── Descartados: bronze com decreto que não encontrou no DE/PARA ──
df_ec = read_excel(EC_LOCAL_FISICO_PATH, sheet_name=EC_SHEET_NAME)
df_ec_sdweb = (
    df_ec.filter((F.col("Local SSO SDWEB").isNotNull()) & (F.col("Local SSO SDWEB") != ""))
         .select(F.col("Local SSO SDWEB").alias("_ec_sdweb"))
         .dropDuplicates()
)

df_descartados_ec = (
    df_bronze_pcd
    .filter((F.col("DECRETO1A").isNotNull()) & (F.col("DECRETO1A") != ""))
    .join(df_ec_sdweb, df_bronze_pcd["LOCL_OCUP"] == df_ec_sdweb["_ec_sdweb"], "left")
    .filter(F.col("_ec_sdweb").isNull())
    .select(
        F.col("PERNR").alias("Matricula"),
        F.col("LOCL_OCUP").alias("LOCL_OCUP não encontrado no DE/PARA"),
    )
    .dropDuplicates()
)

print(f"📊 Matrículas antes do filtro: {matriculas_antes}")
print(f"📊 Matrículas depois do filtro: {matriculas_depois}")
print(f"⚠️  Descartados no DE/PARA: {df_descartados_ec.count()}")
print(f"📊 Total Formata PCD: {df_formata_pcd.count()} registros")

export_df_to_excel_with_counts(
    df_formata_pcd,
    OUTPUT_BASE,
    "Formata_Prontuario_Medico_PCD",
    counts={
        "Matriculas antes do filtro": matriculas_antes,
        "Matriculas depois do filtro": matriculas_depois,
    },
    df_descartados=df_descartados_ec,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Formata PCD - Layout SAP - Exportação CSV

# COMMAND ----------

df_pcd_csv = spark.table(SILVER_PCD)

# A ordem aqui define a ordem das colunas no CSV final.
LAYOUT_MAP_PCD = [
    # (nome_interno,              nome_csv,             is_date)
    ("PERNR",                         "PERNR",                 False),
    ("SRV_NUMBER",                    "SRV_NUMBER",            False),
    ("DATE_PERFORMED",                "DATE_PERFORMED",        True),
    ("PGROUP",                        "PGROUP",                False),
    ("PNUMBER",                       "PNUMBER",               False),
    ("SRV_PROTTYPE",                  "SRV_PROTTYPE",          False),
    ("REF",                           "REF",                   False),
    ("TP_EXAME",                      "TP_EXAME",              False),
    ("CODE",                          "CODE",                  False),
    ("TEST_VALUE",                    "TEST_VALUE",            False),
    ("TEST_LUNIT",                    "TEST_LUNIT",            False),
    ("TEST_RESULTT",                  "TEST_RESULTT",          False),
    ("DT_REAL",                       "DT_REAL",               True),
    ("RESULTADO",                     "RESULTADO",             False),
    ("RELAT_ANL",                     "RELAT_ANL",             False),
    ("ASSINATURA",                    "ASSINATURA",            False),
    ("AVALRAC",                       "AVALRAC",               False),
    # RAC1 block
    ("RAC1",                          "RAC1",                  False),
    ("DT_AVAL_RAC1",                  "DT_AVAL_RAC",           True),
    ("SITUACAO1",                     "SITUACAO",              False),
    ("CONTRAINDICACAO1",              "CONTRAINDICACAO",       False),
    ("REAVALIACAO_RAC1",              "REAVALIACAO_RAC",       False),
    ("TEMPO_REAVALIACAO1",            "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM1",                     "DATA_FIM",              True),
    ("ULT_AVALIACAO1",                "ULT_AVALIACAO",         True),
    # RAC2 block
    ("RAC2",                          "RAC2",                  False),
    ("DT_AVAL_RAC2",                  "DT_AVAL_RAC",           True),
    ("SITUACAO2",                     "SITUACAO",              False),
    ("CONTRAINDICACAO2",              "CONTRAINDICACAO",       False),
    ("REAVALIACAO_RAC2",              "REAVALIACAO_RAC",       False),
    ("TEMPO_REAVALIACAO2",            "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM2",                     "DATA_FIM",              True),
    ("ULT_AVALIACAO2",                "ULT_AVALIACAO",         True),
    # RAC3 block
    ("RAC3",                          "RAC3",                  False),
    ("DT_AVAL_RAC3",                  "DT_AVAL_RAC",           True),
    ("SITUACAO3",                     "SITUACAO",              False),
    ("CONTRAINDICACAO3",              "CONTRAINDICACAO",       False),
    ("REAVALIACAO_RAC3",              "REAVALIACAO_RAC",       False),
    ("TEMPO_REAVALIACAO3",            "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM3",                     "DATA_FIM",              True),
    ("ULT_AVALIACAO3",                "ULT_AVALIACAO",         True),
    # RAC5 block
    ("RAC5",                          "RAC5",                  False),
    ("DT_AVAL_RAC5",                  "DT_AVAL_RAC",           True),
    ("SITUACAO5",                     "SITUACAO",              False),
    ("CONTRAINDICACAO5",              "CONTRAINDICACAO",       False),
    ("REAVALIACAO_RAC5",              "REAVALIACAO_RAC",       False),
    ("TEMPO_REAVALIACAO5",            "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM5",                     "DATA_FIM",              True),
    ("ULT_AVALIACAO5",                "ULT_AVALIACAO",         True),
    # RAC6 block
    ("RAC6",                          "RAC6",                  False),
    ("DT_AVAL_RAC6",                  "DT_AVAL_RAC",           True),
    ("SITUACAO6",                     "SITUACAO",              False),
    ("CONTRAINDICACAO6",              "CONTRAINDICACAO",       False),
    ("REAVALIACAO_RAC6",              "REAVALIACAO_RAC",       False),
    ("TEMPO_REAVALIACAO6",            "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM6",                     "DATA_FIM",              True),
    ("ULT_AVALIACAO6",                "ULT_AVALIACAO",         True),
    # RAC10 block
    ("RAC10",                         "RAC10",                 False),
    ("DT_AVAL_RAC10",                 "DT_AVAL_RAC",           True),
    ("SITUACAO10",                    "SITUACAO",              False),
    ("CONTRAINDICACAO10",             "CONTRAINDICACAO",       False),
    ("REAVALIACAO_RAC10",             "REAVALIACAO_RAC",       False),
    ("TEMPO_REAVALIACAO10",           "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM10",                    "DATA_FIM",              True),
    ("ULT_AVALIACAO10",               "ULT_AVALIACAO",         True),
    # RAC11 block
    ("RAC11",                         "RAC11",                 False),
    ("DT_AVAL_RAC11",                 "DT_AVAL_RAC",           True),
    ("SITUACAO11",                    "SITUACAO",              False),
    ("CONTRAINDICACAO11",             "CONTRAINDICACAO",       False),
    ("REAVALIACAO_RAC11",             "REAVALIACAO_RAC",       False),
    ("TEMPO_REAVALIACAO11",           "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM11",                    "DATA_FIM",              True),
    ("ULT_AVALIACAO11",               "ULT_AVALIACAO",         True),
    # RESTATIV + ATIVID_RESTRICAO blocks (1-13, sem número, 14-18)
    ("RESTATIV",                      "RESTATIV",              False),
    # Block 1
    ("ATIVID_RESTRICAO1",             "ATIVID_RESTRICAO1",     False),
    ("SITUACAO_1",                    "SITUACAO",              False),
    ("DT_AVAL_MEDICA_1",              "DT_AVAL_MEDICA",        True),
    ("REAVALIACAO_MED_1",             "REAVALIACAO_MED",       False),
    ("TEMPO_REAVALIACAO_1",           "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM_1",                    "DATA_FIM",              True),
    ("ULT_AVALIACAO_1",               "ULT_AVALIACAO",         True),
    # Block 2
    ("ATIVID_RESTRICAO2",             "ATIVID_RESTRICAO2",     False),
    ("SITUACAO_2",                    "SITUACAO",              False),
    ("DT_AVAL_MEDICA_2",              "DT_AVAL_MEDICA",        True),
    ("REAVALIACAO_MED_2",             "REAVALIACAO_MED",       False),
    ("TEMPO_REAVALIACAO_2",           "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM_2",                    "DATA_FIM",              True),
    ("ULT_AVALIACAO_2",               "ULT_AVALIACAO",         True),
    # Block 3
    ("ATIVID_RESTRICAO3",             "ATIVID_RESTRICAO3",     False),
    ("SITUACAO_3",                    "SITUACAO",              False),
    ("DT_AVAL_MEDICA_3",              "DT_AVAL_MEDICA",        True),
    ("REAVALIACAO_MED_3",             "REAVALIACAO_MED",       False),
    ("TEMPO_REAVALIACAO_3",           "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM_3",                    "DATA_FIM",              True),
    ("ULT_AVALIACAO_3",               "ULT_AVALIACAO",         True),
    # Block 4
    ("ATIVID_RESTRICAO4",             "ATIVID_RESTRICAO4",     False),
    ("SITUACAO_4",                    "SITUACAO",              False),
    ("DT_AVAL_MEDICA_4",              "DT_AVAL_MEDICA",        True),
    ("REAVALIACAO_MED_4",             "REAVALIACAO_MED",       False),
    ("TEMPO_REAVALIACAO_4",           "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM_4",                    "DATA_FIM",              True),
    ("ULT_AVALIACAO_4",               "ULT_AVALIACAO",         True),
    # Block 5
    ("ATIVID_RESTRICAO5",             "ATIVID_RESTRICAO5",     False),
    ("SITUACAO_5",                    "SITUACAO",              False),
    ("DT_AVAL_MEDICA_5",              "DT_AVAL_MEDICA",        True),
    ("REAVALIACAO_MED_5",             "REAVALIACAO_MED",       False),
    ("TEMPO_REAVALIACAO_5",           "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM_5",                    "DATA_FIM",              True),
    ("ULT_AVALIACAO_5",               "ULT_AVALIACAO",         True),
    # Block 6
    ("ATIVID_RESTRICAO6",             "ATIVID_RESTRICAO6",     False),
    ("SITUACAO_6",                    "SITUACAO",              False),
    ("DT_AVAL_MEDICA_6",              "DT_AVAL_MEDICA",        True),
    ("REAVALIACAO_MED_6",             "REAVALIACAO_MED",       False),
    ("TEMPO_REAVALIACAO_6",           "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM_6",                    "DATA_FIM",              True),
    ("ULT_AVALIACAO_6",               "ULT_AVALIACAO",         True),
    # Block 7
    ("ATIVID_RESTRICAO7",             "ATIVID_RESTRICAO7",     False),
    ("SITUACAO_7",                    "SITUACAO",              False),
    ("DT_AVAL_MEDICA_7",              "DT_AVAL_MEDICA",        True),
    ("REAVALIACAO_MED_7",             "REAVALIACAO_MED",       False),
    ("TEMPO_REAVALIACAO_7",           "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM_7",                    "DATA_FIM",              True),
    ("ULT_AVALIACAO_7",               "ULT_AVALIACAO",         True),
    # Block 8
    ("ATIVID_RESTRICAO8",             "ATIVID_RESTRICAO8",     False),
    ("SITUACAO_8",                    "SITUACAO",              False),
    ("DT_AVAL_MEDICA_8",              "DT_AVAL_MEDICA",        True),
    ("REAVALIACAO_MED_8",             "REAVALIACAO_MED",       False),
    ("TEMPO_REAVALIACAO_8",           "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM_8",                    "DATA_FIM",              True),
    ("ULT_AVALIACAO",                 "ULT_AVALIACAO",         True),
    # Block 9
    ("ATIVID_RESTRICAO9",             "ATIVID_RESTRICAO9",     False),
    ("SITUACAO_9",                    "SITUACAO",              False),
    ("DT_AVAL_MEDICA_9",              "DT_AVAL_MEDICA",        True),
    ("REAVALIACAO_MED_9",             "REAVALIACAO_MED",       False),
    ("TEMPO_REAVALIACAO_9",           "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM_9",                    "DATA_FIM",              True),
    ("ULT_AVALIACAO_9",               "ULT_AVALIACAO",         True),
    # Block 10
    ("ATIVID_RESTRICAO10",            "ATIVID_RESTRICAO10",    False),
    ("SITUACAO_10",                   "SITUACAO",              False),
    ("DT_AVAL_MEDICA_10",             "DT_AVAL_MEDICA",        True),
    ("REAVALIACAO_MED_10",            "REAVALIACAO_MED",       False),
    ("TEMPO_REAVALIACAO_10",          "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM_10",                   "DATA_FIM",              True),
    ("ULT_AVALIACAO_10",              "ULT_AVALIACAO",         True),
    # Block 11
    ("ATIVID_RESTRICAO11",            "ATIVID_RESTRICAO11",    False),
    ("SITUACAO_11",                   "SITUACAO",              False),
    ("DT_AVAL_MEDICA_11",             "DT_AVAL_MEDICA",        True),
    ("REAVALIACAO_MED_11",            "REAVALIACAO_MED",       False),
    ("TEMPO_REAVALIACAO_11",          "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM_11",                   "DATA_FIM",              True),
    ("ULT_AVALIACAO_11",              "ULT_AVALIACAO",         True),
    # Block 12
    ("ATIVID_RESTRICAO12",            "ATIVID_RESTRICAO12",    False),
    ("SITUACAO_12",                   "SITUACAO",              False),
    ("DT_AVAL_MEDICA_12",             "DT_AVAL_MEDICA",        True),
    ("REAVALIACAO_MED_12",            "REAVALIACAO_MED",       False),
    ("TEMPO_REAVALIACAO_12",          "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM_12",                   "DATA_FIM",              True),
    ("ULT_AVALIACAO_12",              "ULT_AVALIACAO",         True),
    # Block 13
    ("ATIVID_RESTRICAO13",            "ATIVID_RESTRICAO13",    False),
    ("SITUACAO_13",                   "SITUACAO",              False),
    ("DT_AVAL_MEDICA_13",             "DT_AVAL_MEDICA",        True),
    ("REAVALIACAO_MED_13",            "REAVALIACAO_MED",       False),
    ("TEMPO_REAVALIACAO_13",          "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM_13",                   "DATA_FIM",              True),
    ("ULT_AVALIACAO_13",              "ULT_AVALIACAO",         True),
    # Block sem número (ATIVID_RESTRICAO0 interno → ATIVID_RESTRICAO no CSV)
    ("ATIVID_RESTRICAO0",             "ATIVID_RESTRICAO",      False),
    ("SITUACAO0",                     "SITUACAO",              False),
    ("DT_AVAL_MEDICA0",               "DT_AVAL_MEDICA",        True),
    ("REAVALIACAO_MED0",              "REAVALIACAO_MED",       False),
    ("TEMPO_REAVALIACAO0",            "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM0",                     "DATA_FIM",              True),
    ("ULT_AVALIACAO0",                "ULT_AVALIACAO",         True),
    # Block 14
    ("ATIVID_RESTRICAO14",            "ATIVID_RESTRICAO14",    False),
    ("SITUACAO_14",                   "SITUACAO",              False),
    ("DT_AVAL_MEDICA_14",             "DT_AVAL_MEDICA",        True),
    ("REAVALIACAO_MED_14",            "REAVALIACAO_MED",       False),
    ("TEMPO_REAVALIACAO_14",          "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM_14",                   "DATA_FIM",              True),
    ("ULT_AVALIACAO_14",              "ULT_AVALIACAO",         True),
    # Block 15
    ("ATIVID_RESTRICAO15",            "ATIVID_RESTRICAO15",    False),
    ("SITUACAO_15",                   "SITUACAO",              False),
    ("DT_AVAL_MEDICA_15",             "DT_AVAL_MEDICA",        True),
    ("REAVALIACAO_MED_15",            "REAVALIACAO_MED",       False),
    ("TEMPO_REAVALIACAO_15",          "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM_15",                   "DATA_FIM",              True),
    ("ULT_AVALIACAO_15",              "ULT_AVALIACAO",         True),
    # Block 16
    ("ATIVID_RESTRICAO16",            "ATIVID_RESTRICAO16",    False),
    ("SITUACAO_16",                   "SITUACAO",              False),
    ("DT_AVAL_MEDICA_16",             "DT_AVAL_MEDICA",        True),
    ("REAVALIACAO_MED_16",            "REAVALIACAO_MED",       False),
    ("TEMPO_REAVALIACAO_16",          "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM_16",                   "DATA_FIM",              True),
    ("ULT_AVALIACAO_16",              "ULT_AVALIACAO",         True),
    # Block 17
    ("ATIVID_RESTRICAO17",            "ATIVID_RESTRICAO17",    False),
    ("SITUACAO_17",                   "SITUACAO",              False),
    ("DT_AVAL_MEDICA_17",             "DT_AVAL_MEDICA",        True),
    ("REAVALIACAO_MED_17",            "REAVALIACAO_MED",       False),
    ("TEMPO_REAVALIACAO_17",          "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM_17",                   "DATA_FIM",              True),
    ("ULT_AVALIACAO_17",              "ULT_AVALIACAO",         True),
    # Block 18 + OUTROS
    ("ATIVID_RESTRICAO18",            "ATIVID_RESTRICAO18",    False),
    ("OUTROS",                        "OUTROS",                False),
    ("SITUACAO_18",                   "SITUACAO",              False),
    ("DT_AVAL_MEDICA_18",             "DT_AVAL_MEDICA",        True),
    ("REAVALIACAO_MED_18",            "REAVALIACAO_MED",       False),
    ("TEMPO_REAVALIACAO_18",          "TEMPO_REAVALIACAO",     False),
    ("DATA_FIM_18",                   "DATA_FIM",              True),
    ("ULT_AVALIACAO_18",              "ULT_AVALIACAO",         True),
    # Laudo PCD (DECRETO1A interno → DECRETO no CSV)
    ("READAPTACAO",                   "READAPTACAO",           False),
    ("DT_REG",                        "DT_REG",                True),
    ("DECRETO1A",                     "DECRETO",               False),
    ("TIPO",                          "TIPO",                  False),
    ("CAUSA",                         "CAUSA",                 False),
    ("CLASS",                         "CLASS",                 False),
    ("TP_DEF",                        "TP_DEF",                False),
    ("DESC_ALT",                      "DESC_ALT",              False),
    ("JUST_ALT",                      "JUST_ALT",              False),
    ("CID",                           "CID",                   False),
    ("LIM_CORP",                      "LIM_CORP",              False),
    ("DESC_LIM",                      "DESC_LIM",              False),
    ("DT_CARAC",                      "DT_CARAC",              True),
    # OBS não faz parte do layout CSV (coluna interna extra)
    ("NOME_MED",                      "NOME_MED",              False),
    ("OC_MED",                        "OC_MED",                False),
    ("NUMOC_MED",                     "NUMOC_MED",             False),
    ("ESTADO",                        "ESTADO",                False),
    ("LOCL_ATEND",                    "LOCL_ATEND",            False),
    ("DT_DESCARAC",                   "DT_DESCARAC",           True),
    ("DT_CESS",                       "DT_CESS",               True),
    ("MOT_DESCARAC",                  "MOT_DESCARAC",          False),
    # Conclusão
    ("MED_NAME_CM",                   "MED_NAME_CM",           False),
    ("MED_CRM_CM",                    "MED_CRM_CM",            False),
    ("UF_CM",                         "UF_CM",                 False),
    ("DT_ASO",                        "DT_ASO",                True),
    ("APTO_LIB_CM",                   "APTO_LIB_CM",           False),
    ("INAPTO_CM",                     "INAPTO_CM",             False),
]

assert len(LAYOUT_MAP_PCD) == 235, f"LAYOUT_MAP_PCD tem {len(LAYOUT_MAP_PCD)} colunas, esperava 235"

# ── Selecionar colunas internas na ordem do layout
internal_cols = [m[0] for m in LAYOUT_MAP_PCD]

# Garantir que todas as colunas existem (criar vazias se necessário)
for col_name in internal_cols:
    if col_name not in df_pcd_csv.columns:
        df_pcd_csv = df_pcd_csv.withColumn(col_name, F.lit(""))

df_csv = df_pcd_csv.select(*internal_cols)
df_csv = null_to_empty(df_csv, internal_cols)

# ── Formatar datas: dd/mm/yyyy ou ddmmyyyy → DDMMAAAA (8 dígitos, sem /) ──────
date_cols = [m[0] for m in LAYOUT_MAP_PCD if m[2]]
for c in date_cols:
    df_csv = df_csv.withColumn(c, F.regexp_replace(F.col(c), "[/\\-]", ""))

print(f"📊 PCD para CSV SAP: {df_csv.count()} registros, {len(df_csv.columns)} colunas")

# ── Exportar CSV com header duplicado, vírgula, aspas duplas
import os, shutil, csv

csv_header = [m[1] for m in LAYOUT_MAP_PCD]  # nomes originais (com duplicatas)

tmp_csv = f"/tmp/Formata_Prontuario_Medico_PCD_SAP.csv"
final_csv = f"{OUTPUT_BASE}/Formata_Prontuario_Medico_PCD_SAP.csv"

with open(tmp_csv, "w", encoding="utf-8", newline="") as f:
    writer = csv.writer(f, delimiter=",", quoting=csv.QUOTE_ALL)
    writer.writerow(csv_header)
    
    count = 0
    for row in df_csv.toLocalIterator():
        writer.writerow([str(row[c]) if row[c] is not None else "" for c in internal_cols])
        count += 1
        if count % 10_000 == 0:
            print(f"  ... {count} linhas")

shutil.copy2(tmp_csv, final_csv)
os.remove(tmp_csv)

print(f"✅ CSV SAP exportado: {final_csv} ({count} linhas, 235 colunas)")

# COMMAND ----------

# ══════════════════════════════════════════════════════════════════════════════
# RESUMO GERAL
# ══════════════════════════════════════════════════════════════════════════════

print("=" * 60)
print("RESUMO DA EXPORTAÇÃO")
print("=" * 60)
print(f"  Exame Clínico:          {df_exame_clinico.count():>8} registros")
print(f"  PCD (com decreto):      {df_pcd.count():>8} registros")
print(f"  PCD (sem decreto):      {df_pcd_sem_decreto.count():>8} registros")
print(f"  Exames Complementares:  {df_exames_compl.count():>8} registros")
print("=" * 60)
print(f"  📁 Arquivos exportados para: {OUTPUT_BASE}")
