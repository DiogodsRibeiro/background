# Databricks notebook source
'''
03 — EXAMES COMPLEMENTARES — Camada Bronze
══════════════════════════════════════════════════════════════════════════════
Fonte  : Oracle SDweb — Views VW_EXP_* por grupo de exame
Destino: BRONZE_EXAMES_COMPLEMENTARES
           (humanresources_insight.bron_prontuario_medico.exames_complementares_raw)
 
Por que existem 8 scripts SQL?
-----------------------------------------------------------------------
Cada script corresponde a um GRUPO de exames complementares cadastrado
no sistema de saúde ocupacional (SDweb/Oracle). Dentro de cada grupo
existem múltiplas views (VW_EXP_*), uma por código de exame, que são
unidas via UNION ALL num único resultado.
 
Grupo                  | Script de origem             | Nº de exames
-----------------------|------------------------------|-------------
Audiometria            | Audiometria_Union             |  2
Avaliação Especial     | Aval_Esp_Union                |  6  (+ ECA0010 em separado)
Avaliação Esp ECA0010  | Aval_Esp_ECA0010              |  1  (lógica diferente)
Bioquímicos            | Bioquimicos_Union             | 59
Coprologia             | Coprologia_Union              |  4
Exames Diversos        | Exames_Div_Union              |  1
Hematologia            | Hematologia_Union             | 13
Provas Funcionais      | Provas_Funcionais_Union       | 10
-----------------------------------------------------------------------
Total: 96 exames/views
 
Todos os grupos compartilham:
  - O mesmo padrão de colunas de saída (PGROUP, P_NUMBER, SRV_PROTTYPE,
    PERNR, COD_EXAME, DATE_RESULT, RES_REF_LAB, RELAT_ANL, MES_REF,
    COD_EXAME_II, TIPO_EXAME_II, DATA_PERFORMAD)
  - Os mesmos filtros de período (01/10/2021 → data de corte)
  - A mesma lista de empresas e de matrículas excluídas
  - A mesma lógica de deduplicação: mantém apenas o registro mais
    recente por (PERNR, COD_EXAME_II, TIPO_EXAME_II)
 
Por isso faz sentido ler cada grupo via JDBC, empilhá-los com
unionByName e gravar uma única tabela Bronze.
══════════════════════════════════════════════════════════════════════════════
'''

# COMMAND ----------

# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Prontuário Médico/utils/utils"
# MAGIC

# COMMAND ----------

import time

# COMMAND ----------

BIOQUIMICOS_VIEWS = [
    ('1 "EBA0064"',    'EBA0064', 'EBA0064'),
    ('4 "EHA0038"',    'EHA0038', 'EHA0038'),
    ('6 "EBA0023"',    'EBA0023', 'EBA0023'),
    ('7 "EBA0046"',    'EBA0046', 'EBA0046'),
    ('8 "EBA0050"',    'EBA0050', 'EBA0050'),
    ('9 "EBA0050"',    'EBA0050', 'EBA0050'),
    ('10 "EBA0050"',   'EBA0050', 'EBA0050'),
    ('11 "EBA0059"',   'EBA0059', 'EBA0059'),
    ('12 "EBA0053"',   'EBA0053', 'EBA0053'),
    ('13 "EBA0028"',   'EBA0028', 'EBA0028'),
    ('14 "EBA0090"',   'EBA0090', 'EBA0090'),
    ('15 "EBA0093"',   'EBA0093', 'EBA0093'),
    ('16 "EBA0062"',   'EBA0062', 'EBA0062'),
    ('19 "EBA0006"',   'EBA0006', 'EBA0006'),
    ('20 "EBA0044"',   'EBA0044', 'EBA0044'),
    ('21 "EBA0022"',   'EBA0022', 'EBA0022'),
    ('22 "EBA0042"',   'EBA0042', 'EBA0042'),
    ('22 "EBA0031"',   'EBA0031', 'EBA0031'),
    ('23 "EBA0081"',   'EBA0081', 'EBA0081'),
    ('26 "EBA0040"',   'EBA0040', 'EBA0040'),
    ('27 "EBA0041"',   'EBA0041', 'EBA0041'),
    ('28 "EBA0038"',   'EBA0038', 'EBA0038'),
    ('30 "EBA0012"',   'EBA0012', 'EBA0012'),
    ('31 "EBA0058"',   'EBA0058', 'EBA0058'),
    ('32 "EBA0019"',   'EBA0019', 'EBA0019'),
    ('33 "EBA0078"',   'EBA0078', 'EBA0078'),
    ('34 "EBA0036"',   'EBA0036', 'EBA0036'),
    ('36 "EBA0076"',   'EBA0076', 'EBA0076'),
    ('37 "EBA0048"',   'EBA0048', 'EBA0048'),
    ('38 "EBA0010"',   'EBA0010', 'EBA0010'),
    ('39 "EBA0056"',   'EBA0056', 'EBA0056'),
    ('41 "EBA0084"',   'EBA0084', 'EBA0084'),
    ('43 "EBA0085"',   'EBA0085', 'EBA0085'),
    ('44 "EBA0082"',   'EBA0082', 'EBA0082'),
    ('45 "EBA0052"',   'EBA0052', 'EBA0052'),
    ('46 "EBA0066"',   'EBA0066', 'EBA0066'),
    ('47 "EBA0068"',   'EBA0068', 'EBA0068'),
    ('48 "EBA0072"',   'EBA0072', 'EBA0072'),
    ('49 "EBA0074"',   'EBA0074', 'EBA0074'),
    ('50 "EBA0032"',   'EBA0032', 'EBA0032'),
    ('50 "EBA0087"',   'EBA0087', 'EBA0087'),
    ('51 "EBA0034"',   'EBA0034', 'EBA0034'),
    ('51 "EBA0087"',   'EBA0087', 'EBA0087'),
    ('52 "EBA0088"',   'EBA0088', 'EBA0088'),
    ('53 "EBA0070"',   'EBA0070', 'EBA0070'),
    ('54 "EBA0021"',   'EBA0021', 'EBA0021'),
    ('55 "EBA0086"',   'EBA0086', 'EBA0086'),
    ('56 "EBA0026"',   'EBA0026', 'EBA0026'),
    ('57 "EBA0027"',   'EBA0027', 'EBA0027'),
    ('58 "EBA0015"',   'EBA0015', 'EBA0015'),
    ('59 "EBA0014"',   'EBA0014', 'EBA0014'),
    ('60 "EBA0024"',   'EBA0024', 'EBA0024'),
    ('25 "EHA0015"',   'EHA0015', 'EHA0015'),
    ('42 "EHA0050"',   'EHA0050', 'EHA0050'),
    ('689 "EBA0018"',  'EBA0018', 'EBA0018'),
    ('423 "EBA0004"',  'EBA0004', 'EBA0004'),
    ('424 "EBA0005"',  'EBA0005', 'EBA0005'),
    ('426 "EBA0003"',  'EBA0003', 'EBA0003'),
    ('689 "EBA0017"',  'EBA0017', 'EBA0017'),
    ('1222 "EBA0008"', 'EBA0008', 'EBA0008'),
    ('1442 "EBA0013"', 'EBA0013', 'EBA0013'),
    ('1493 "EBA0094"', 'EBA0094', 'EBA0094'),
]

# COMMAND ----------

def _fmt(s):
    if s < 60:   return f"{s:.1f}s"
    if s < 3600: return f"{int(s//60)}min {s%60:.1f}s"
    return f"{int(s//3600)}h {int((s%3600)//60)}min {s%60:.0f}s"

def read_oracle_query(sql: str, nome: str = '', num_partitions: int = 4) -> DataFrame:
    t1 = time.time()

    # 1) COUNT — conexão rápida só para saber o total
    count_query = f"(SELECT COUNT(*) AS CNT FROM ({sql}) Q) Q2"
    total = int(
        spark.read.format("jdbc")
        .option("url",      ORACLE_JDBC_URL)
        .option("driver",   ORACLE_DRIVER)
        .option("user",     ORACLE_USER)
        .option("password", ORACLE_PASSWORD)
        .option("dbtable",  count_query)
        .option("queryTimeout",  "3600")
        .option("socketTimeout", "3600")
        .load()
        .collect()[0]["CNT"]
    )

    if total == 0:
        print(f"  ⏭ {nome} — vazio")
        return None

    # 2) Leitura particionada via ROWNUM — igual ao Valano
    query_rn = f"(SELECT CAST(ROWNUM AS INTEGER) AS RN, T.* FROM ({sql}) T) Q"

    df = (
        spark.read.format("jdbc")
        .option("url",             ORACLE_JDBC_URL)
        .option("driver",          ORACLE_DRIVER)
        .option("user",            ORACLE_USER)
        .option("password",        ORACLE_PASSWORD)
        .option("dbtable",         query_rn)
        .option("partitionColumn", "RN")
        .option("lowerBound",      "1")
        .option("upperBound",      str(total))
        .option("numPartitions",   str(num_partitions))
        .option("fetchsize",       "10000")
        .option("queryTimeout",    "3600")
        .option("socketTimeout",   "3600")
        .load()
        .drop("RN")
    )

    print(f"  ✅ {nome} — {total:,} registros | {_fmt(time.time()-t1)}")
    return df

# COMMAND ----------

SQL_AUDIOMETRIA = f"""
WITH TAB AS (SELECT * FROM (SELECT * FROM (
SELECT
CD_EMPRESA,
CD_UNIDADE,
 '021' AS PGROUP,
CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
"NU_MATRICULA" as PERNR,
'1435 "EPA0010"' as COD_EXAME,
"Data" as DATE_RESULT,

CASE
  WHEN "Conclusao_OD" IS NULL AND "Conclusao_OE" IS NULL AND "Conclusao_Bilateral" IS NULL THEN NULL
  WHEN "Conclusao_OD" = 'NORMAL' AND "Conclusao_OE" = 'NORMAL' AND "Conclusao_Bilateral" = 'NORMAL' THEN '1'
  WHEN (
    (CASE WHEN "Conclusao_OD" = 'NORMAL' THEN 1 ELSE 0 END +
     CASE WHEN "Conclusao_OE" = 'NORMAL' THEN 1 ELSE 0 END +
     CASE WHEN "Conclusao_Bilateral" = 'NORMAL' THEN 1 ELSE 0 END) >= 1
    AND
    (CASE WHEN "Conclusao_OD" IS NULL THEN 1 ELSE 0 END +
     CASE WHEN "Conclusao_OE" IS NULL THEN 1 ELSE 0 END +
     CASE WHEN "Conclusao_Bilateral" IS NULL THEN 1 ELSE 0 END) = (3 -
     (CASE WHEN "Conclusao_OD" = 'NORMAL' THEN 1 ELSE 0 END +
      CASE WHEN "Conclusao_OE" = 'NORMAL' THEN 1 ELSE 0 END +
      CASE WHEN "Conclusao_Bilateral" = 'NORMAL' THEN 1 ELSE 0 END))
  ) THEN NULL
  WHEN (
    (CASE WHEN "Conclusao_OD" IS NOT NULL AND "Conclusao_OD" <> 'NORMAL' THEN 1 ELSE 0 END +
     CASE WHEN "Conclusao_OE" IS NOT NULL AND "Conclusao_OE" <> 'NORMAL' THEN 1 ELSE 0 END +
     CASE WHEN "Conclusao_Bilateral" IS NOT NULL AND "Conclusao_Bilateral" <> 'NORMAL' THEN 1 ELSE 0 END) >= 1
    AND
    (CASE WHEN "Conclusao_OD" IS NULL THEN 1 ELSE 0 END +
     CASE WHEN "Conclusao_OE" IS NULL THEN 1 ELSE 0 END +
     CASE WHEN "Conclusao_Bilateral" IS NULL THEN 1 ELSE 0 END) = (3 -
     (CASE WHEN "Conclusao_OD" IS NOT NULL AND "Conclusao_OD" <> 'NORMAL' THEN 1 ELSE 0 END +
      CASE WHEN "Conclusao_OE" IS NOT NULL AND "Conclusao_OE" <> 'NORMAL' THEN 1 ELSE 0 END +
      CASE WHEN "Conclusao_Bilateral" IS NOT NULL AND "Conclusao_Bilateral" <> 'NORMAL' THEN 1 ELSE 0 END))
  ) THEN '2'
  ELSE '2'
END AS RES_REF_LAB,

"Relatorio_Anual" as RELAT_ANL,
mes_ref as MES_REF,
 'EPA0010' as COD_EXAME_II,
"TIPO_EXAME" as TIPO_EXAME_II,
"DT_ASO" as DATA_PERFORMAD,
"Conclusao_OD",
"Conclusao_OE",
"Conclusao_Bilateral"
FROM {ORACLE_SCHEMA}.VW_EXP_EPA0010

UNION ALL

SELECT
CD_EMPRESA,
CD_UNIDADE,
 '021' AS PGROUP,
CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
"NU_MATRICULA" as PERNR,
 '1435 "EPA0009"' as COD_EXAME,
"Data" as DATE_RESULT,

CASE
  WHEN "Conclusao_OD" IS NULL AND "Conclusao_OE" IS NULL AND "Conclusao_Bilateral" IS NULL THEN NULL
  WHEN "Conclusao_OD" = 'NORMAL' AND "Conclusao_OE" = 'NORMAL' AND "Conclusao_Bilateral" = 'NORMAL' THEN '1'
  WHEN (
    (CASE WHEN "Conclusao_OD" = 'NORMAL' THEN 1 ELSE 0 END +
     CASE WHEN "Conclusao_OE" = 'NORMAL' THEN 1 ELSE 0 END +
     CASE WHEN "Conclusao_Bilateral" = 'NORMAL' THEN 1 ELSE 0 END) >= 1
    AND
    (CASE WHEN "Conclusao_OD" IS NULL THEN 1 ELSE 0 END +
     CASE WHEN "Conclusao_OE" IS NULL THEN 1 ELSE 0 END +
     CASE WHEN "Conclusao_Bilateral" IS NULL THEN 1 ELSE 0 END) = (3 -
     (CASE WHEN "Conclusao_OD" = 'NORMAL' THEN 1 ELSE 0 END +
      CASE WHEN "Conclusao_OE" = 'NORMAL' THEN 1 ELSE 0 END +
      CASE WHEN "Conclusao_Bilateral" = 'NORMAL' THEN 1 ELSE 0 END))
  ) THEN NULL
  WHEN (
    (CASE WHEN "Conclusao_OD" IS NOT NULL AND "Conclusao_OD" <> 'NORMAL' THEN 1 ELSE 0 END +
     CASE WHEN "Conclusao_OE" IS NOT NULL AND "Conclusao_OE" <> 'NORMAL' THEN 1 ELSE 0 END +
     CASE WHEN "Conclusao_Bilateral" IS NOT NULL AND "Conclusao_Bilateral" <> 'NORMAL' THEN 1 ELSE 0 END) >= 1
    AND
    (CASE WHEN "Conclusao_OD" IS NULL THEN 1 ELSE 0 END +
     CASE WHEN "Conclusao_OE" IS NULL THEN 1 ELSE 0 END +
     CASE WHEN "Conclusao_Bilateral" IS NULL THEN 1 ELSE 0 END) = (3 -
     (CASE WHEN "Conclusao_OD" IS NOT NULL AND "Conclusao_OD" <> 'NORMAL' THEN 1 ELSE 0 END +
      CASE WHEN "Conclusao_OE" IS NOT NULL AND "Conclusao_OE" <> 'NORMAL' THEN 1 ELSE 0 END +
      CASE WHEN "Conclusao_Bilateral" IS NOT NULL AND "Conclusao_Bilateral" <> 'NORMAL' THEN 1 ELSE 0 END))
  ) THEN '2'
  ELSE '2'
END AS RES_REF_LAB,

"Relatorio_Anual" as RELAT_ANL,
mes_ref as MES_REF,
 'EPA0009' as COD_EXAME_II,
"TIPO_EXAME" as TIPO_EXAME_II,
"DT_ASO" as DATA_PERFORMAD,
"Conclusao_OD",
"Conclusao_OE",
"Conclusao_Bilateral"
FROM {ORACLE_SCHEMA}.VW_EXP_EPA0009
)
WHERE DATA_PERFORMAD >= to_date('01/10/2021','dd/MM/yyyy')
  AND DATA_PERFORMAD < to_date('23/03/2026','dd/MM/yyyy')
  AND CD_EMPRESA IN ('00001', '00004', '00046', '00064', '00068', '00112', '00284', '00360', '00632','00646')
  AND PERNR NOT IN ('81055446', '81052313', '81051932', '81052318', '81047976', '81047974', '81055848', '81055911', '81055919', '81047936', '81020731', '81048496', '81048494', '81052371', '81052628', '81055929', '81055931', '81056217', '81056220', '81056222', '81056232', '81048547', '81048720', '81056298', '81049183', '81056586', '81049213', '81051807', '81049154', '81049193', '81049336', '81049118', '81049131', '81049132', '81049133', '81049134', '81049137', '81049142', '81049158', '81049165', '81049181', '81049280', '81049318', '81049358', '81049380', '81049449', '81049290', '81049089', '81049090', '81049194', '81049082', '81049094', '81049117', '81049195', '81049203', '81049211', '81049281', '81049316', '81049441', '81049455', '81048840', '81048913', '81049289', '81048727', '81048750', '81048756', '81048757', '81048763', '81048776', '81048780', '81048781', '81048782', '81048783', '81048784', '81048785', '81048787', '81048810', '81048818', '81048820', '81048822', '81048836', '81048847', '81048852', '81048861', '81048877', '81048885', '81048888', '81048909', '81048924', '81048926', '81048930', '81048931', '81048980', '81048984', '81048988', '81048991', '81049005', '81049012', '81049022', '81049023', '81049033', '81049034', '81049060', '81049065', '81049304', '81049308', '81049309', '81049320', '81049325', '81049338', '81049344', '81049347', '81049348', '81049370', '81049371', '81049392', '81049393', '81049394', '81049404', '81049453', '81049454', '81049456', '81049457', '81049460', '81049468', '81049469', '81048736', '81048833', '81048834', '81048842', '81048845', '81048846', '81048857', '81048878', '81048891', '81048893', '81048895', '81048896', '81048918', '81048920', '81048933', '81048934', '81048944', '81048948', '81048963', '81048971', '81048981', '81049021', '81049038', '81049161', '81049317', '81049329', '81049331', '81049385', '81049388', '81049437', '81049108', '81048359', '81040759', '81049006', '81049028', '81049032', '81049129', '81049174', '81049244', '81049333', '81049378', '81049382', '81049365', '81049466', '81048839', '81048728', '81048731', '81048755', '81048766', '81048767', '81048773', '81048816', '81048821', '81048830', '81048843', '81048870', '81048887', '81048911', '81048912', '81048915', '81048925', '81048929', '81048970', '81049002', '81049024', '81049037', '81049136', '81049138', '81049201', '81049210', '81049216', '81049219', '81049231', '81049277', '81049297', '81049299', '81049300', '81049335', '81049350', '81049359', '81049361', '81049377', '81049379', '81049439', '81049452', '81049040', '81048838', '81056340', '81056355', '81056360', '81056361', '81056365', '81056370', '81056372', '81056376', '81056377', '81056387', '81056390', '81056399', '81056308', '81056342', '81056352', '81056353', '81056354', '81056357', '81056358', '81056359', '81056362', '81056363', '81056364', '81056369', '81056371', '81056373', '81056374', '81056375', '81056378', '81056379', '81056380', '81056381', '81056382', '81056383', '81056384', '81056388', '81056389', '81056401', '81056402', '81056403', '81056404', '81056405', '81056406', '81056408', '81056420', '81056595', '81049096', '81049230', '81049396', '81052674', '81052696', '81052753', '81052824', '81052834', '81052874', '81052880', '81052910', '81052806', '81052833', '81052854', '81052861', '81052899', '81048788', '81048792', '81048819', '81048886', '81048954', '81048972', '81049050', '81049063', '81049069', '81049311', '81049447', '81048805', '81048808', '81048813', '81048814', '81048862', '81048946', '81048957', '81048959', '81048960', '81049000', '81049020', '81049120', '81049122', '81049145', '81049148', '81049177', '81049180', '81049182', '81049204', '81049206', '81049222', '81049225', '81049227', '81049240', '81049249', '81049250', '81049251', '81049252', '81049254', '81049257', '81049310', '81049312', '81049313', '81049321', '81049322', '81049324', '81049334', '81049341', '81049342', '81049354', '81049364', '81049372', '81049381', '81049398', '81049434', '81049440', '81049443', '81048807', '81048998', '81049031', '81049127', '81049179', '81049261', '81049360', '81049363', '81056341', '81056391', '81056392', '81056393', '81056397', '81056398', '81056409', '81056593', '81056599', '81056602', '81052204', '81050190', '81050191', '81050201', '81050043', '81050128', '81056385', '421545', '163147', '262923', '287474', '402248', '456343', '510123', '608554', '919845', '920850', '655902', '971077')
  AND EXISTS (SELECT 1 FROM {ORACLE_SCHEMA}.vw_ish_vinculo
              WHERE nu_matricula = PERNR
                AND ((dt_admissao < to_date('23/03/2026','dd/MM/yyyy') AND dt_demissao IS NULL)
                     OR dt_demissao >= to_date('01/06/2021','dd/MM/yyyy')))))
SELECT * FROM TAB t
WHERE data_performad = (SELECT Max(data_performad) FROM tab
                        WHERE pernr = t.pernr
                          AND cod_exame_ii = t.cod_exame_ii
                          AND tipo_exame_ii = t.tipo_exame_ii)
"""

# COMMAND ----------

SQL_ECA0010 = f"""
WITH TAB AS (SELECT * FROM (
SELECT
CD_EMPRESA,
CD_UNIDADE,
 '021' AS PGROUP,
CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
"NU_MATRICULA" as PERNR,
 '295 "ECA0010"' as COD_EXAME,
"DT_ASO" AS DATE_RESULT,
'' as RES_REF_LAB,
"Conclusao_NR7" as RELAT_ANL,
mes_ref as MES_REF,
 'ECA0010' as COD_EXAME_II,
"TIPO_EXAME" as TIPO_EXAME_II,
"DT_ASO" as DATA_PERFORMAD,
"DT_ASO"
FROM {ORACLE_SCHEMA}.VW_EXP_ECA0010
)
WHERE DATA_PERFORMAD >= to_date('01/10/2021','dd/MM/yyyy')
  AND DATA_PERFORMAD < to_date('23/03/2026','dd/MM/yyyy')
  AND CD_EMPRESA IN ('00001', '00004', '00046', '00064', '00068', '00112', '00284', '00360', '00632','00646')
  AND PERNR NOT IN ('81055446', '81052313', '81051932', '81052318', '81047976', '81047974', '81055848', '81055911', '81055919', '81047936', '81020731', '81048496', '81048494', '81052371', '81052628', '81055929', '81055931', '81056217', '81056220', '81056222', '81056232', '81048547', '81048720', '81056298', '81049183', '81056586', '81049213', '81051807', '81049154', '81049193', '81049336', '81049118', '81049131', '81049132', '81049133', '81049134', '81049137', '81049142', '81049158', '81049165', '81049181', '81049280', '81049318', '81049358', '81049380', '81049449', '81049290', '81049089', '81049090', '81049194', '81049082', '81049094', '81049117', '81049195', '81049203', '81049211', '81049281', '81049316', '81049441', '81049455', '81048840', '81048913', '81049289', '81048727', '81048750', '81048756', '81048757', '81048763', '81048776', '81048780', '81048781', '81048782', '81048783', '81048784', '81048785', '81048787', '81048810', '81048818', '81048820', '81048822', '81048836', '81048847', '81048852', '81048861', '81048877', '81048885', '81048888', '81048909', '81048924', '81048926', '81048930', '81048931', '81048980', '81048984', '81048988', '81048991', '81049005', '81049012', '81049022', '81049023', '81049033', '81049034', '81049060', '81049065', '81049304', '81049308', '81049309', '81049320', '81049325', '81049338', '81049344', '81049347', '81049348', '81049370', '81049371', '81049392', '81049393', '81049394', '81049404', '81049453', '81049454', '81049456', '81049457', '81049460', '81049468', '81049469', '81048736', '81048833', '81048834', '81048842', '81048845', '81048846', '81048857', '81048878', '81048891', '81048893', '81048895', '81048896', '81048918', '81048920', '81048933', '81048934', '81048944', '81048948', '81048963', '81048971', '81048981', '81049021', '81049038', '81049161', '81049317', '81049329', '81049331', '81049385', '81049388', '81049437', '81049108', '81048359', '81040759', '81049006', '81049028', '81049032', '81049129', '81049174', '81049244', '81049333', '81049378', '81049382', '81049365', '81049466', '81048839', '81048728', '81048731', '81048755', '81048766', '81048767', '81048773', '81048816', '81048821', '81048830', '81048843', '81048870', '81048887', '81048911', '81048912', '81048915', '81048925', '81048929', '81048970', '81049002', '81049024', '81049037', '81049136', '81049138', '81049201', '81049210', '81049216', '81049219', '81049231', '81049277', '81049297', '81049299', '81049300', '81049335', '81049350', '81049359', '81049361', '81049377', '81049379', '81049439', '81049452', '81049040', '81048838', '81056340', '81056355', '81056360', '81056361', '81056365', '81056370', '81056372', '81056376', '81056377', '81056387', '81056390', '81056399', '81056308', '81056342', '81056352', '81056353', '81056354', '81056357', '81056358', '81056359', '81056362', '81056363', '81056364', '81056369', '81056371', '81056373', '81056374', '81056375', '81056378', '81056379', '81056380', '81056381', '81056382', '81056383', '81056384', '81056388', '81056389', '81056401', '81056402', '81056403', '81056404', '81056405', '81056406', '81056408', '81056420', '81056595', '81049096', '81049230', '81049396', '81052674', '81052696', '81052753', '81052824', '81052834', '81052874', '81052880', '81052910', '81052806', '81052833', '81052854', '81052861', '81052899', '81048788', '81048792', '81048819', '81048886', '81048954', '81048972', '81049050', '81049063', '81049069', '81049311', '81049447', '81048805', '81048808', '81048813', '81048814', '81048862', '81048946', '81048957', '81048959', '81048960', '81049000', '81049020', '81049120', '81049122', '81049145', '81049148', '81049177', '81049180', '81049182', '81049204', '81049206', '81049222', '81049225', '81049227', '81049240', '81049249', '81049250', '81049251', '81049252', '81049254', '81049257', '81049310', '81049312', '81049313', '81049321', '81049322', '81049324', '81049334', '81049341', '81049342', '81049354', '81049364', '81049372', '81049381', '81049398', '81049434', '81049440', '81049443', '81048807', '81048998', '81049031', '81049127', '81049179', '81049261', '81049360', '81049363', '81056341', '81056391', '81056392', '81056393', '81056397', '81056398', '81056409', '81056593', '81056599', '81056602', '81052204', '81050190', '81050191', '81050201', '81050043', '81050128', '81056385', '421545', '163147', '262923', '287474', '402248', '456343', '510123', '608554', '919845', '920850', '655902', '971077')
  AND EXISTS (SELECT 1 FROM {ORACLE_SCHEMA}.vw_ish_vinculo
              WHERE nu_matricula = PERNR
                AND ((dt_admissao <= to_date('23/03/2026','dd/MM/yyyy') AND dt_demissao IS NULL)
                     OR dt_demissao >= to_date('01/06/2021','dd/MM/yyyy'))))
SELECT * FROM TAB t
WHERE data_performad = (SELECT Max(data_performad) FROM tab
                        WHERE pernr = t.pernr
                          AND cod_exame_ii = t.cod_exame_ii
                          AND tipo_exame_ii = t.tipo_exame_ii)
"""

# COMMAND ----------

SQL_AVAL_ESP = f"""
WITH TAB AS (SELECT * FROM (
SELECT
CD_EMPRESA,
CD_UNIDADE,
 '021' AS PGROUP,
CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
"NU_MATRICULA" as PERNR,
 '1513 "EEA0030"' as COD_EXAME,
"Data" as DATE_RESULT,
CASE "Normalidade" WHEN 'D' THEN '1'  WHEN 'F' THEN '2' END as RES_REF_LAB,
"Relatorio_Anual" as RELAT_ANL,
mes_ref as MES_REF,
 'EEA0030' as COD_EXAME_II,
"TIPO_EXAME" as TIPO_EXAME_II,
"DT_ASO" as DATA_PERFORMAD,
"DT_ASO"
FROM {ORACLE_SCHEMA}.VW_EXP_EEA0030

union all

SELECT
CD_EMPRESA,
CD_UNIDADE,
 '021' AS PGROUP,
CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
"NU_MATRICULA" as PERNR,
 '1516 "EDA0082"' as COD_EXAME,
"Data" as DATE_RESULT,
CASE "Normalidade" WHEN 'D' THEN '1'  WHEN 'F' THEN '2' END as RES_REF_LAB,
"Relatorio_Anual" as RELAT_ANL,
mes_ref as MES_REF,
 'EDA0082' as COD_EXAME_II,
"TIPO_EXAME" as TIPO_EXAME_II,
"DT_ASO" as DATA_PERFORMAD,
"DT_ASO"
FROM {ORACLE_SCHEMA}.VW_EXP_EDA0082

union all

SELECT
CD_EMPRESA,
CD_UNIDADE,
 '021' AS PGROUP,
CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
"NU_MATRICULA" as PERNR,
 '1516 "EEA0051"' as COD_EXAME,
"Data" as DATE_RESULT,
CASE "Normalidade" WHEN 'D' THEN '1'  WHEN 'F' THEN '2' END as RES_REF_LAB,
"Relatorio_Anual" as RELAT_ANL,
mes_ref as MES_REF,
 'EEA0051' as COD_EXAME_II,
"TIPO_EXAME" as TIPO_EXAME_II,
"DT_ASO" as DATA_PERFORMAD,
"DT_ASO"
FROM {ORACLE_SCHEMA}.VW_EXP_EEA0051

union all

SELECT
CD_EMPRESA,
CD_UNIDADE,
 '021' AS PGROUP,
CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
"NU_MATRICULA" as PERNR,
 '1515 "EDA0081"' as COD_EXAME,
"Data" as DATE_RESULT,
CASE "Normalidade" WHEN 'D' THEN '1'  WHEN 'F' THEN '2' END as RES_REF_LAB,
"Relatorio_Anual" as RELAT_ANL,
mes_ref as MES_REF,
 'EDA0081' as COD_EXAME_II,
"TIPO_EXAME" as TIPO_EXAME_II,
"DT_ASO" as DATA_PERFORMAD,
"DT_ASO"
FROM {ORACLE_SCHEMA}.VW_EXP_EDA0081

union all

SELECT
CD_EMPRESA,
CD_UNIDADE,
 '021' AS PGROUP,
CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
"NU_MATRICULA" as PERNR,
 '1515 "EEA0018"' as COD_EXAME,
"Data" as DATE_RESULT,
CASE "Normalidade" WHEN 'D' THEN '1'  WHEN 'F' THEN '2' END as RES_REF_LAB,
"Relatorio_Anual" as RELAT_ANL,
mes_ref as MES_REF,
 'EEA0018' as COD_EXAME_II,
"TIPO_EXAME" as TIPO_EXAME_II,
"DT_ASO" as DATA_PERFORMAD,
"DT_ASO"
FROM {ORACLE_SCHEMA}.VW_EXP_EEA0018_01

union all

SELECT
CD_EMPRESA,
CD_UNIDADE,
 '021' AS PGROUP,
CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
"NU_MATRICULA" as PERNR,
 '1515 "EEA0018"' as COD_EXAME,
"Data" as DATE_RESULT,
CASE "Normalidade" WHEN 'D' THEN '1'  WHEN 'F' THEN '2' END as RES_REF_LAB,
"Relatorio_Anual" as RELAT_ANL,
mes_ref as MES_REF,
 'EEA0018' as COD_EXAME_II,
"TIPO_EXAME" as TIPO_EXAME_II,
"DT_ASO" as DATA_PERFORMAD,
"DT_ASO"
FROM {ORACLE_SCHEMA}.VW_EXP_EEA0018_02)
WHERE DATA_PERFORMAD >= to_date('01/10/2021','dd/MM/yyyy')
  AND DATA_PERFORMAD < to_date('23/03/2026','dd/MM/yyyy')
  AND CD_EMPRESA IN ('00001', '00004', '00046', '00064', '00068', '00112', '00284', '00360', '00632','00646')
  AND PERNR NOT IN ('81055446', '81052313', '81051932', '81052318', '81047976', '81047974', '81055848', '81055911', '81055919', '81047936', '81020731', '81048496', '81048494', '81052371', '81052628', '81055929', '81055931', '81056217', '81056220', '81056222', '81056232', '81048547', '81048720', '81056298', '81049183', '81056586', '81049213', '81051807', '81049154', '81049193', '81049336', '81049118', '81049131', '81049132', '81049133', '81049134', '81049137', '81049142', '81049158', '81049165', '81049181', '81049280', '81049318', '81049358', '81049380', '81049449', '81049290', '81049089', '81049090', '81049194', '81049082', '81049094', '81049117', '81049195', '81049203', '81049211', '81049281', '81049316', '81049441', '81049455', '81048840', '81048913', '81049289', '81048727', '81048750', '81048756', '81048757', '81048763', '81048776', '81048780', '81048781', '81048782', '81048783', '81048784', '81048785', '81048787', '81048810', '81048818', '81048820', '81048822', '81048836', '81048847', '81048852', '81048861', '81048877', '81048885', '81048888', '81048909', '81048924', '81048926', '81048930', '81048931', '81048980', '81048984', '81048988', '81048991', '81049005', '81049012', '81049022', '81049023', '81049033', '81049034', '81049060', '81049065', '81049304', '81049308', '81049309', '81049320', '81049325', '81049338', '81049344', '81049347', '81049348', '81049370', '81049371', '81049392', '81049393', '81049394', '81049404', '81049453', '81049454', '81049456', '81049457', '81049460', '81049468', '81049469', '81048736', '81048833', '81048834', '81048842', '81048845', '81048846', '81048857', '81048878', '81048891', '81048893', '81048895', '81048896', '81048918', '81048920', '81048933', '81048934', '81048944', '81048948', '81048963', '81048971', '81048981', '81049021', '81049038', '81049161', '81049317', '81049329', '81049331', '81049385', '81049388', '81049437', '81049108', '81048359', '81040759', '81049006', '81049028', '81049032', '81049129', '81049174', '81049244', '81049333', '81049378', '81049382', '81049365', '81049466', '81048839', '81048728', '81048731', '81048755', '81048766', '81048767', '81048773', '81048816', '81048821', '81048830', '81048843', '81048870', '81048887', '81048911', '81048912', '81048915', '81048925', '81048929', '81048970', '81049002', '81049024', '81049037', '81049136', '81049138', '81049201', '81049210', '81049216', '81049219', '81049231', '81049277', '81049297', '81049299', '81049300', '81049335', '81049350', '81049359', '81049361', '81049377', '81049379', '81049439', '81049452', '81049040', '81048838', '81056340', '81056355', '81056360', '81056361', '81056365', '81056370', '81056372', '81056376', '81056377', '81056387', '81056390', '81056399', '81056308', '81056342', '81056352', '81056353', '81056354', '81056357', '81056358', '81056359', '81056362', '81056363', '81056364', '81056369', '81056371', '81056373', '81056374', '81056375', '81056378', '81056379', '81056380', '81056381', '81056382', '81056383', '81056384', '81056388', '81056389', '81056401', '81056402', '81056403', '81056404', '81056405', '81056406', '81056408', '81056420', '81056595', '81049096', '81049230', '81049396', '81052674', '81052696', '81052753', '81052824', '81052834', '81052874', '81052880', '81052910', '81052806', '81052833', '81052854', '81052861', '81052899', '81048788', '81048792', '81048819', '81048886', '81048954', '81048972', '81049050', '81049063', '81049069', '81049311', '81049447', '81048805', '81048808', '81048813', '81048814', '81048862', '81048946', '81048957', '81048959', '81048960', '81049000', '81049020', '81049120', '81049122', '81049145', '81049148', '81049177', '81049180', '81049182', '81049204', '81049206', '81049222', '81049225', '81049227', '81049240', '81049249', '81049250', '81049251', '81049252', '81049254', '81049257', '81049310', '81049312', '81049313', '81049321', '81049322', '81049324', '81049334', '81049341', '81049342', '81049354', '81049364', '81049372', '81049381', '81049398', '81049434', '81049440', '81049443', '81048807', '81048998', '81049031', '81049127', '81049179', '81049261', '81049360', '81049363', '81056341', '81056391', '81056392', '81056393', '81056397', '81056398', '81056409', '81056593', '81056599', '81056602', '81052204', '81050190', '81050191', '81050201', '81050043', '81050128', '81056385', '421545', '163147', '262923', '287474', '402248', '456343', '510123', '608554', '919845', '920850', '655902', '971077')
  AND EXISTS (SELECT 1 FROM {ORACLE_SCHEMA}.vw_ish_vinculo
              WHERE nu_matricula = PERNR
                AND ((dt_admissao < to_date('23/03/2026','dd/MM/yyyy') AND dt_demissao IS NULL)
                     OR dt_demissao >= to_date('01/06/2021','dd/MM/yyyy'))))
SELECT * FROM TAB t
WHERE data_performad = (SELECT Max(data_performad) FROM tab
                        WHERE pernr = t.pernr
                          AND cod_exame_ii = t.cod_exame_ii
                          AND tipo_exame_ii = t.tipo_exame_ii)
"""

# COMMAND ----------

# SQL_BIOQUIMICOS = f"""
# WITH TAB AS (SELECT   * FROM (
#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '1 "EBA0064"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0064' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0064

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '4 "EHA0038"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EHA0038' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EHA0038

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '6 "EBA0023"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0023' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0023

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '7 "EBA0046"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0046' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0046

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '8 "EBA0050"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0050' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0050

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '9 "EBA0050"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0050' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0050

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '10 "EBA0050"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0050' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0050

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '11 "EBA0059"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0059' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0059

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '12 "EBA0053"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0053' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0053

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '13 "EBA0028"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0028' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0028

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '14 "EBA0090"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0090' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0090

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '15 "EBA0093"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0093' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0093

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '16 "EBA0062"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0062' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0062

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '19 "EBA0006"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0006' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0006

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '20 "EBA0044"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0044' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0044

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '21 "EBA0022"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0022' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0022

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '22 "EBA0042"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0042' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0042

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '22 "EBA0031"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0031' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0031

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '23 "EBA0081"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0081' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0081

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '26 "EBA0040"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0040' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0040

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '27 "EBA0041"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0041' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0041

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '28 "EBA0038"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0038' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0038

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '30 "EBA0012"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0012' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0012

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '31 "EBA0058"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0058' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0058

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '32 "EBA0019"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0019' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0019

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '33 "EBA0078"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0078' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0078

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '34 "EBA0036"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0036' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0036

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '36 "EBA0076"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0076' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0076

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '37 "EBA0048"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0048' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0048

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '38 "EBA0010"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0010' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0010

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '39 "EBA0056"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0056' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0056

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '41 "EBA0084"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0084' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0084

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '43 "EBA0085"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0085' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0085

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '44 "EBA0082"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0082' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0082

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '45 "EBA0052"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0052' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0052

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '46 "EBA0066"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0066' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0066

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '47 "EBA0068"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0068' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0068

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '48 "EBA0072"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0072' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0072

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '49 "EBA0074"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0074' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0074

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '50 "EBA0032"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0032' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0032

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '50 "EBA0087"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0087' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0087

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '51 "EBA0034"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0034' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0034

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '51 "EBA0087"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0087' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0087

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '52 "EBA0088"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0088' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0088

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '53 "EBA0070"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0070' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0070

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '54 "EBA0021"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0021' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0021

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '55 "EBA0086"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0086' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0086

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '56 "EBA0026"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0026' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0026

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '57 "EBA0027"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0027' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0027

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '58 "EBA0015"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0015' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0015

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '59 "EBA0014"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0014' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0014

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '60 "EBA0024"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0024' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0024

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '25 "EHA0015"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EHA0015' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EHA0015

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '42 "EHA0050"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EHA0050' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EHA0050

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '689 "EBA0018"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0018' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0018

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '423 "EBA0004"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0004' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0004

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '424 "EBA0005"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0005' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0005

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '426 "EBA0003"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0003' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0003

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '689 "EBA0017"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0017' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0017

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '1222 "EBA0008"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0008' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0008

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '1442 "EBA0013"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0013' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0013

#     UNION ALL

#     SELECT
#         CD_EMPRESA,
#         CD_UNIDADE,
#         '021' AS PGROUP,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '044 "ADM"'
#             WHEN 'Demissional' THEN '045 "DEM"'
#             WHEN 'Especial' THEN '046 "ES"'
#             WHEN 'Supletiva' THEN '046 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '047 "MF"'
#             WHEN 'Periódico' THEN '048 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
#         END AS P_NUMBER,
#         CASE TIPO_EXAME
#             WHEN 'Admissional' THEN '228 "ADM"'
#             WHEN 'Demissional' THEN '231 "DEM"'
#             WHEN 'Especial' THEN '235 "ES"'
#             WHEN 'Supletiva' THEN '235 "SUP"'
#             WHEN 'Mudança de Funçao' THEN '237 "MF"'
#             WHEN 'Periódico' THEN '240 "PER"'
#             WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
#         END AS SRV_PROTTYPE,
#         "NU_MATRICULA" as PERNR,
#         '1493 "EBA0094"' as COD_EXAME,
#         "Data" as DATE_RESULT,
#         CASE "Normalidade"
#             WHEN 'D' THEN '1'
#             WHEN 'F' THEN '2'
#         END as RES_REF_LAB,
#         "Relatorio_Anual" as RELAT_ANL,
#         mes_ref as MES_REF,
#         'EBA0094' as COD_EXAME_II,
#         "TIPO_EXAME" as TIPO_EXAME_II,
#     "DT_ASO" as DATA_PERFORMAD
# FROM {ORACLE_SCHEMA}.VW_EXP_EBA0094

# )
# WHERE DATA_PERFORMAD >= to_date('01/10/2021','dd/MM/yyyy')
#   AND DATA_PERFORMAD < to_date('23/03/2026','dd/MM/yyyy')
#  and CD_EMPRESA in ('00001', '00004', '00046', '00064', '00068', '00112', '00284', '00360', '00632','00646')
#   AND PERNR NOT IN ('81055446', '81052313', '81051932', '81052318', '81047976', '81047974', '81055848', '81055911', '81055919', '81047936', '81020731', '81048496', '81048494', '81052371', '81052628', '81055929', '81055931', '81056217', '81056220', '81056222', '81056232', '81048547', '81048720', '81056298', '81049183', '81056586', '81049213', '81051807', '81049154', '81049193', '81049336', '81049118', '81049131', '81049132', '81049133', '81049134', '81049137', '81049142', '81049158', '81049165', '81049181', '81049280', '81049318', '81049358', '81049380', '81049449', '81049290', '81049089', '81049090', '81049194', '81049082', '81049094', '81049117', '81049195', '81049203', '81049211', '81049281', '81049316', '81049441', '81049455', '81048840', '81048913', '81049289', '81048727', '81048750', '81048756', '81048757', '81048763', '81048776', '81048780', '81048781', '81048782', '81048783', '81048784', '81048785', '81048787', '81048810', '81048818', '81048820', '81048822', '81048836', '81048847', '81048852', '81048861', '81048877', '81048885', '81048888', '81048909', '81048924', '81048926', '81048930', '81048931', '81048980', '81048984', '81048988', '81048991', '81049005', '81049012', '81049022', '81049023', '81049033', '81049034', '81049060', '81049065', '81049304', '81049308', '81049309', '81049320', '81049325', '81049338', '81049344', '81049347', '81049348', '81049370', '81049371', '81049392', '81049393', '81049394', '81049404', '81049453', '81049454', '81049456', '81049457', '81049460', '81049468', '81049469', '81048736', '81048833', '81048834', '81048842', '81048845', '81048846', '81048857', '81048878', '81048891', '81048893', '81048895', '81048896', '81048918', '81048920', '81048933', '81048934', '81048944', '81048948', '81048963', '81048971', '81048981', '81049021', '81049038', '81049161', '81049317', '81049329', '81049331', '81049385', '81049388', '81049437', '81049108', '81048359', '81040759', '81049006', '81049028', '81049032', '81049129', '81049174', '81049244', '81049333', '81049378', '81049382', '81049365', '81049466', '81048839', '81048728', '81048731', '81048755', '81048766', '81048767', '81048773', '81048816', '81048821', '81048830', '81048843', '81048870', '81048887', '81048911', '81048912', '81048915', '81048925', '81048929', '81048970', '81049002', '81049024', '81049037', '81049136', '81049138', '81049201', '81049210', '81049216', '81049219', '81049231', '81049277', '81049297', '81049299', '81049300', '81049335', '81049350', '81049359', '81049361', '81049377', '81049379', '81049439', '81049452', '81049040', '81048838', '81056340', '81056355', '81056360', '81056361', '81056365', '81056370', '81056372', '81056376', '81056377', '81056387', '81056390', '81056399', '81056308', '81056342', '81056352', '81056353', '81056354', '81056357', '81056358', '81056359', '81056362', '81056363', '81056364', '81056369', '81056371', '81056373', '81056374', '81056375', '81056378', '81056379', '81056380', '81056381', '81056382', '81056383', '81056384', '81056388', '81056389', '81056401', '81056402', '81056403', '81056404', '81056405', '81056406', '81056408', '81056420', '81056595', '81049096', '81049230', '81049396', '81052674', '81052696', '81052753', '81052824', '81052834', '81052874', '81052880', '81052910', '81052806', '81052833', '81052854', '81052861', '81052899', '81048788', '81048792', '81048819', '81048886', '81048954', '81048972', '81049050', '81049063', '81049069', '81049311', '81049447', '81048805', '81048808', '81048813', '81048814', '81048862', '81048946', '81048957', '81048959', '81048960', '81049000', '81049020', '81049120', '81049122', '81049145', '81049148', '81049177', '81049180', '81049182', '81049204', '81049206', '81049222', '81049225', '81049227', '81049240', '81049249', '81049250', '81049251', '81049252', '81049254', '81049257', '81049310', '81049312', '81049313', '81049321', '81049322', '81049324', '81049334', '81049341', '81049342', '81049354', '81049364', '81049372', '81049381', '81049398', '81049434', '81049440', '81049443', '81048807', '81048998', '81049031', '81049127', '81049179', '81049261', '81049360', '81049363', '81056341', '81056391', '81056392', '81056393', '81056397', '81056398', '81056409', '81056593', '81056599', '81056602', '81052204', '81050190', '81050191', '81050201', '81050043', '81050128', '81056385', '421545', '163147', '262923', '287474', '402248', '456343', '510123', '608554', '919845', '920850', '655902', '971077')
#   AND EXISTS (SELECT 1 FROM {ORACLE_SCHEMA}.vw_ish_vinculo
#               WHERE nu_matricula = PERNR
#                 AND ((dt_admissao < to_date('23/03/2026','dd/MM/yyyy') AND dt_demissao IS NULL)
#                      OR dt_demissao >= to_date('01/06/2021','dd/MM/yyyy'))))
# SELECT * FROM TAB t
# WHERE data_performad = (SELECT Max(data_performad) FROM tab
#                         WHERE pernr = t.pernr
#                           AND cod_exame_ii = t.cod_exame_ii
#                           AND tipo_exame_ii = t.tipo_exame_ii)
# """

# COMMAND ----------

SQL_COPROLOGIA = f"""
WITH TAB AS (SELECT * FROM (
SELECT
    CD_EMPRESA,
    CD_UNIDADE,
    '021' AS PGROUP,
    CASE TIPO_EXAME
        WHEN 'Admissional' THEN '044 "ADM"'
        WHEN 'Demissional' THEN '045 "DEM"'
        WHEN 'Especial' THEN '046 "ES"'
        WHEN 'Supletiva' THEN '046 "SUP"'
        WHEN 'Mudança de Funçao' THEN '047 "MF"'
        WHEN 'Periódico' THEN '048 "PER"'
        WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
    END AS P_NUMBER,
    CASE TIPO_EXAME
        WHEN 'Admissional' THEN '228 "ADM"'
        WHEN 'Demissional' THEN '231 "DEM"'
        WHEN 'Especial' THEN '235 "ES"'
        WHEN 'Supletiva' THEN '235 "SUP"'
        WHEN 'Mudança de Funçao' THEN '237 "MF"'
        WHEN 'Periódico' THEN '240 "PER"'
        WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
    END AS SRV_PROTTYPE,
    "NU_MATRICULA" as PERNR,
    '61 "EFA0020"' as COD_EXAME,
    "Data" as DATE_RESULT,
    CASE "Normalidade"
        WHEN 'D' THEN '1'
        WHEN 'F' THEN '2'
    END as RES_REF_LAB,
    "Relatorio_Anual"  as RELAT_ANL,
    mes_ref as MES_REF,
    'EFA0020' as COD_EXAME_II,
    "TIPO_EXAME" as TIPO_EXAME_II,
"DT_ASO" as DATA_PERFORMAD
FROM {ORACLE_SCHEMA}.VW_EXP_EFA0020

UNION ALL

SELECT
    CD_EMPRESA,
    CD_UNIDADE,
    '021' AS PGROUP,
    CASE TIPO_EXAME
        WHEN 'Admissional' THEN '044 "ADM"'
        WHEN 'Demissional' THEN '045 "DEM"'
        WHEN 'Especial' THEN '046 "ES"'
        WHEN 'Supletiva' THEN '046 "SUP"'
        WHEN 'Mudança de Funçao' THEN '047 "MF"'
        WHEN 'Periódico' THEN '048 "PER"'
        WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
    END AS P_NUMBER,
    CASE TIPO_EXAME
        WHEN 'Admissional' THEN '228 "ADM"'
        WHEN 'Demissional' THEN '231 "DEM"'
        WHEN 'Especial' THEN '235 "ES"'
        WHEN 'Supletiva' THEN '235 "SUP"'
        WHEN 'Mudança de Funçao' THEN '237 "MF"'
        WHEN 'Periódico' THEN '240 "PER"'
        WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
    END AS SRV_PROTTYPE,
    "NU_MATRICULA" as PERNR,
    '62 "EFA0040"' as COD_EXAME,
    "Data" as DATE_RESULT,
    CASE "Normalidade"
        WHEN 'D' THEN '1'
        WHEN 'F' THEN '2'
    END as RES_REF_LAB,
    "Relatorio_Anual" as RELAT_ANL,
    mes_ref as MES_REF,
    'EFA0040' as COD_EXAME_II,
    "TIPO_EXAME" as TIPO_EXAME_II,
"DT_ASO" as DATA_PERFORMAD
FROM {ORACLE_SCHEMA}.VW_EXP_EFA0040

UNION ALL

SELECT
    CD_EMPRESA,
    CD_UNIDADE,
    '021' AS PGROUP,
    CASE TIPO_EXAME
        WHEN 'Admissional' THEN '044 "ADM"'
        WHEN 'Demissional' THEN '045 "DEM"'
        WHEN 'Especial' THEN '046 "ES"'
        WHEN 'Supletiva' THEN '046 "SUP"'
        WHEN 'Mudança de Funçao' THEN '047 "MF"'
        WHEN 'Periódico' THEN '048 "PER"'
        WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
    END AS P_NUMBER,
    CASE TIPO_EXAME
        WHEN 'Admissional' THEN '228 "ADM"'
        WHEN 'Demissional' THEN '231 "DEM"'
        WHEN 'Especial' THEN '235 "ES"'
        WHEN 'Supletiva' THEN '235 "SUP"'
        WHEN 'Mudança de Funçao' THEN '237 "MF"'
        WHEN 'Periódico' THEN '240 "PER"'
        WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
    END AS SRV_PROTTYPE,
    "NU_MATRICULA" as PERNR,
    '63 "EFA0030"' as COD_EXAME,
    "Data" as DATE_RESULT,
    CASE "Normalidade"
        WHEN 'D' THEN '1'
        WHEN 'F' THEN '2'
    END as RES_REF_LAB,
    "Relatorio_Anual" as RELAT_ANL,
    mes_ref as MES_REF,
    'EFA0030' as COD_EXAME_II,
    "TIPO_EXAME" as TIPO_EXAME_II,
"DT_ASO" as DATA_PERFORMAD
FROM {ORACLE_SCHEMA}.VW_EXP_EFA0030

UNION ALL

SELECT
    CD_EMPRESA,
    CD_UNIDADE,
    '021' AS PGROUP,
    CASE TIPO_EXAME
        WHEN 'Admissional' THEN '044 "ADM"'
        WHEN 'Demissional' THEN '045 "DEM"'
        WHEN 'Especial' THEN '046 "ES"'
        WHEN 'Supletiva' THEN '046 "SUP"'
        WHEN 'Mudança de Funçao' THEN '047 "MF"'
        WHEN 'Periódico' THEN '048 "PER"'
        WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
    END AS P_NUMBER,
    CASE TIPO_EXAME
        WHEN 'Admissional' THEN '228 "ADM"'
        WHEN 'Demissional' THEN '231 "DEM"'
        WHEN 'Especial' THEN '235 "ES"'
        WHEN 'Supletiva' THEN '235 "SUP"'
        WHEN 'Mudança de Funçao' THEN '237 "MF"'
        WHEN 'Periódico' THEN '240 "PER"'
        WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
    END AS SRV_PROTTYPE,
    "NU_MATRICULA" as PERNR,
    '64 "EFA0010"' as COD_EXAME,
    "Data" as DATE_RESULT,
    CASE "Normalidade"
        WHEN 'D' THEN '1'
        WHEN 'F' THEN '2'
    END as RES_REF_LAB,
    "Relatorio_Anual" as RELAT_ANL,
    mes_ref as MES_REF,
    'EFA0010' as COD_EXAME_II,
    "TIPO_EXAME" as TIPO_EXAME_II,
"DT_ASO" as DATA_PERFORMAD
FROM {ORACLE_SCHEMA}.VW_EXP_EFA0010)
WHERE DATA_PERFORMAD >= to_date('01/10/2021','dd/MM/yyyy')
  AND DATA_PERFORMAD < to_date('23/03/2026','dd/MM/yyyy')
  AND CD_EMPRESA IN ('00001', '00004', '00046', '00064', '00068', '00112', '00284', '00360', '00632','00646')
  AND PERNR NOT IN ('81055446', '81052313', '81051932', '81052318', '81047976', '81047974', '81055848', '81055911', '81055919', '81047936', '81020731', '81048496', '81048494', '81052371', '81052628', '81055929', '81055931', '81056217', '81056220', '81056222', '81056232', '81048547', '81048720', '81056298', '81049183', '81056586', '81049213', '81051807', '81049154', '81049193', '81049336', '81049118', '81049131', '81049132', '81049133', '81049134', '81049137', '81049142', '81049158', '81049165', '81049181', '81049280', '81049318', '81049358', '81049380', '81049449', '81049290', '81049089', '81049090', '81049194', '81049082', '81049094', '81049117', '81049195', '81049203', '81049211', '81049281', '81049316', '81049441', '81049455', '81048840', '81048913', '81049289', '81048727', '81048750', '81048756', '81048757', '81048763', '81048776', '81048780', '81048781', '81048782', '81048783', '81048784', '81048785', '81048787', '81048810', '81048818', '81048820', '81048822', '81048836', '81048847', '81048852', '81048861', '81048877', '81048885', '81048888', '81048909', '81048924', '81048926', '81048930', '81048931', '81048980', '81048984', '81048988', '81048991', '81049005', '81049012', '81049022', '81049023', '81049033', '81049034', '81049060', '81049065', '81049304', '81049308', '81049309', '81049320', '81049325', '81049338', '81049344', '81049347', '81049348', '81049370', '81049371', '81049392', '81049393', '81049394', '81049404', '81049453', '81049454', '81049456', '81049457', '81049460', '81049468', '81049469', '81048736', '81048833', '81048834', '81048842', '81048845', '81048846', '81048857', '81048878', '81048891', '81048893', '81048895', '81048896', '81048918', '81048920', '81048933', '81048934', '81048944', '81048948', '81048963', '81048971', '81048981', '81049021', '81049038', '81049161', '81049317', '81049329', '81049331', '81049385', '81049388', '81049437', '81049108', '81048359', '81040759', '81049006', '81049028', '81049032', '81049129', '81049174', '81049244', '81049333', '81049378', '81049382', '81049365', '81049466', '81048839', '81048728', '81048731', '81048755', '81048766', '81048767', '81048773', '81048816', '81048821', '81048830', '81048843', '81048870', '81048887', '81048911', '81048912', '81048915', '81048925', '81048929', '81048970', '81049002', '81049024', '81049037', '81049136', '81049138', '81049201', '81049210', '81049216', '81049219', '81049231', '81049277', '81049297', '81049299', '81049300', '81049335', '81049350', '81049359', '81049361', '81049377', '81049379', '81049439', '81049452', '81049040', '81048838', '81056340', '81056355', '81056360', '81056361', '81056365', '81056370', '81056372', '81056376', '81056377', '81056387', '81056390', '81056399', '81056308', '81056342', '81056352', '81056353', '81056354', '81056357', '81056358', '81056359', '81056362', '81056363', '81056364', '81056369', '81056371', '81056373', '81056374', '81056375', '81056378', '81056379', '81056380', '81056381', '81056382', '81056383', '81056384', '81056388', '81056389', '81056401', '81056402', '81056403', '81056404', '81056405', '81056406', '81056408', '81056420', '81056595', '81049096', '81049230', '81049396', '81052674', '81052696', '81052753', '81052824', '81052834', '81052874', '81052880', '81052910', '81052806', '81052833', '81052854', '81052861', '81052899', '81048788', '81048792', '81048819', '81048886', '81048954', '81048972', '81049050', '81049063', '81049069', '81049311', '81049447', '81048805', '81048808', '81048813', '81048814', '81048862', '81048946', '81048957', '81048959', '81048960', '81049000', '81049020', '81049120', '81049122', '81049145', '81049148', '81049177', '81049180', '81049182', '81049204', '81049206', '81049222', '81049225', '81049227', '81049240', '81049249', '81049250', '81049251', '81049252', '81049254', '81049257', '81049310', '81049312', '81049313', '81049321', '81049322', '81049324', '81049334', '81049341', '81049342', '81049354', '81049364', '81049372', '81049381', '81049398', '81049434', '81049440', '81049443', '81048807', '81048998', '81049031', '81049127', '81049179', '81049261', '81049360', '81049363', '81056341', '81056391', '81056392', '81056393', '81056397', '81056398', '81056409', '81056593', '81056599', '81056602', '81052204', '81050190', '81050191', '81050201', '81050043', '81050128', '81056385', '421545', '163147', '262923', '287474', '402248', '456343', '510123', '608554', '919845', '920850', '655902', '971077')
  AND EXISTS (SELECT 1 FROM {ORACLE_SCHEMA}.vw_ish_vinculo
              WHERE nu_matricula = PERNR
                AND ((dt_admissao < to_date('23/03/2026','dd/MM/yyyy') AND dt_demissao IS NULL)
                     OR dt_demissao >= to_date('01/06/2021','dd/MM/yyyy'))))
SELECT * FROM TAB t
WHERE data_performad = (SELECT Max(data_performad) FROM tab
                        WHERE pernr = t.pernr
                          AND cod_exame_ii = t.cod_exame_ii
                          AND tipo_exame_ii = t.tipo_exame_ii)
"""

# COMMAND ----------

SQL_EXAMES_DIV = f"""
WITH TAB AS (SELECT * FROM (
SELECT
    CD_EMPRESA,
    CD_UNIDADE,
    '021' AS PGROUP,
    CASE TIPO_EXAME
        WHEN 'Admissional' THEN '044 "ADM"'
        WHEN 'Demissional' THEN '045 "DEM"'
        WHEN 'Especial' THEN '046 "ES"'
        WHEN 'Supletiva' THEN '046 "SUP"'
        WHEN 'Mudança de Funçao' THEN '047 "MF"'
        WHEN 'Periódico' THEN '048 "PER"'
        WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
    END AS P_NUMBER,
    CASE TIPO_EXAME
        WHEN 'Admissional' THEN '228 "ADM"'
        WHEN 'Demissional' THEN '231 "DEM"'
        WHEN 'Especial' THEN '235 "ES"'
        WHEN 'Supletiva' THEN '235 "SUP"'
        WHEN 'Mudança de Funçao' THEN '237 "MF"'
        WHEN 'Periódico' THEN '240 "PER"'
        WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
    END AS SRV_PROTTYPE,
    "NU_MATRICULA" as PERNR,
    '65 "EDA0026"' as COD_EXAME,
    "Data" as DATE_RESULT,
    CASE "Normalidade"
        WHEN 'D' THEN '1'
        WHEN 'F' THEN '2'
    END as RES_REF_LAB,
    "Relatorio_Anual" as RELAT_ANL,
    mes_ref as MES_REF,
    'EDA0026' as COD_EXAME_II,
    "TIPO_EXAME" as tipo_exame_ii,
     "DT_ASO" as DATA_PERFORMAD
FROM {ORACLE_SCHEMA}.VW_EXP_EDA0026)
WHERE DATA_PERFORMAD >= to_date('01/10/2021','dd/MM/yyyy')
  AND DATA_PERFORMAD < to_date('23/03/2026','dd/MM/yyyy')
  AND CD_EMPRESA IN ('00001', '00004', '00046', '00064', '00068', '00112', '00284', '00360', '00632','00646')
  AND PERNR NOT IN ('81055446', '81052313', '81051932', '81052318', '81047976', '81047974', '81055848', '81055911', '81055919', '81047936', '81020731', '81048496', '81048494', '81052371', '81052628', '81055929', '81055931', '81056217', '81056220', '81056222', '81056232', '81048547', '81048720', '81056298', '81049183', '81056586', '81049213', '81051807', '81049154', '81049193', '81049336', '81049118', '81049131', '81049132', '81049133', '81049134', '81049137', '81049142', '81049158', '81049165', '81049181', '81049280', '81049318', '81049358', '81049380', '81049449', '81049290', '81049089', '81049090', '81049194', '81049082', '81049094', '81049117', '81049195', '81049203', '81049211', '81049281', '81049316', '81049441', '81049455', '81048840', '81048913', '81049289', '81048727', '81048750', '81048756', '81048757', '81048763', '81048776', '81048780', '81048781', '81048782', '81048783', '81048784', '81048785', '81048787', '81048810', '81048818', '81048820', '81048822', '81048836', '81048847', '81048852', '81048861', '81048877', '81048885', '81048888', '81048909', '81048924', '81048926', '81048930', '81048931', '81048980', '81048984', '81048988', '81048991', '81049005', '81049012', '81049022', '81049023', '81049033', '81049034', '81049060', '81049065', '81049304', '81049308', '81049309', '81049320', '81049325', '81049338', '81049344', '81049347', '81049348', '81049370', '81049371', '81049392', '81049393', '81049394', '81049404', '81049453', '81049454', '81049456', '81049457', '81049460', '81049468', '81049469', '81048736', '81048833', '81048834', '81048842', '81048845', '81048846', '81048857', '81048878', '81048891', '81048893', '81048895', '81048896', '81048918', '81048920', '81048933', '81048934', '81048944', '81048948', '81048963', '81048971', '81048981', '81049021', '81049038', '81049161', '81049317', '81049329', '81049331', '81049385', '81049388', '81049437', '81049108', '81048359', '81040759', '81049006', '81049028', '81049032', '81049129', '81049174', '81049244', '81049333', '81049378', '81049382', '81049365', '81049466', '81048839', '81048728', '81048731', '81048755', '81048766', '81048767', '81048773', '81048816', '81048821', '81048830', '81048843', '81048870', '81048887', '81048911', '81048912', '81048915', '81048925', '81048929', '81048970', '81049002', '81049024', '81049037', '81049136', '81049138', '81049201', '81049210', '81049216', '81049219', '81049231', '81049277', '81049297', '81049299', '81049300', '81049335', '81049350', '81049359', '81049361', '81049377', '81049379', '81049439', '81049452', '81049040', '81048838', '81056340', '81056355', '81056360', '81056361', '81056365', '81056370', '81056372', '81056376', '81056377', '81056387', '81056390', '81056399', '81056308', '81056342', '81056352', '81056353', '81056354', '81056357', '81056358', '81056359', '81056362', '81056363', '81056364', '81056369', '81056371', '81056373', '81056374', '81056375', '81056378', '81056379', '81056380', '81056381', '81056382', '81056383', '81056384', '81056388', '81056389', '81056401', '81056402', '81056403', '81056404', '81056405', '81056406', '81056408', '81056420', '81056595', '81049096', '81049230', '81049396', '81052674', '81052696', '81052753', '81052824', '81052834', '81052874', '81052880', '81052910', '81052806', '81052833', '81052854', '81052861', '81052899', '81048788', '81048792', '81048819', '81048886', '81048954', '81048972', '81049050', '81049063', '81049069', '81049311', '81049447', '81048805', '81048808', '81048813', '81048814', '81048862', '81048946', '81048957', '81048959', '81048960', '81049000', '81049020', '81049120', '81049122', '81049145', '81049148', '81049177', '81049180', '81049182', '81049204', '81049206', '81049222', '81049225', '81049227', '81049240', '81049249', '81049250', '81049251', '81049252', '81049254', '81049257', '81049310', '81049312', '81049313', '81049321', '81049322', '81049324', '81049334', '81049341', '81049342', '81049354', '81049364', '81049372', '81049381', '81049398', '81049434', '81049440', '81049443', '81048807', '81048998', '81049031', '81049127', '81049179', '81049261', '81049360', '81049363', '81056341', '81056391', '81056392', '81056393', '81056397', '81056398', '81056409', '81056593', '81056599', '81056602', '81052204', '81050190', '81050191', '81050201', '81050043', '81050128', '81056385', '421545', '163147', '262923', '287474', '402248', '456343', '510123', '608554', '919845', '920850', '655902', '971077')
  AND EXISTS (SELECT 1 FROM {ORACLE_SCHEMA}.vw_ish_vinculo
              WHERE nu_matricula = PERNR
                AND ((dt_admissao < to_date('23/03/2026','dd/MM/yyyy') AND dt_demissao IS NULL)
                     OR dt_demissao >= to_date('01/06/2021','dd/MM/yyyy'))))
SELECT * FROM TAB t
WHERE data_performad = (SELECT Max(data_performad) FROM tab
                        WHERE pernr = t.pernr
                          AND cod_exame_ii = t.cod_exame_ii
                          AND tipo_exame_ii = t.tipo_exame_ii)
"""

# COMMAND ----------

SQL_HEMATOLOGIA = f"""
WITH TAB AS (SELECT * FROM (
    SELECT
        CD_EMPRESA,
        CD_UNIDADE,
        '021' AS PGROUP,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '044 "ADM"'
            WHEN 'Demissional' THEN '045 "DEM"'
            WHEN 'Especial' THEN '046 "ES"'
            WHEN 'Supletiva' THEN '046 "SUP"'
            WHEN 'Mudança de Funçao' THEN '047 "MF"'
            WHEN 'Periódico' THEN '048 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
        END AS P_NUMBER,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '228 "ADM"'
            WHEN 'Demissional' THEN '231 "DEM"'
            WHEN 'Especial' THEN '235 "ES"'
            WHEN 'Supletiva' THEN '235 "SUP"'
            WHEN 'Mudança de Funçao' THEN '237 "MF"'
            WHEN 'Periódico' THEN '240 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
        END AS SRV_PROTTYPE,
        "NU_MATRICULA" as PERNR,
        '66 "EHA0031"' as COD_EXAME,
        "Data" as DATE_RESULT,
        CASE "Normalidade"
            WHEN 'D' THEN '1'
            WHEN 'F' THEN '2'
        END as RES_REF_LAB,
        "Relatorio_Anual" as RELAT_ANL,
        mes_ref as MES_REF,
        'EHA0031' as COD_EXAME_II,
        "TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
    FROM {ORACLE_SCHEMA}.VW_EXP_EHA0031

    UNION ALL

    SELECT
        CD_EMPRESA,
        CD_UNIDADE,
        '021' AS PGROUP,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '044 "ADM"'
            WHEN 'Demissional' THEN '045 "DEM"'
            WHEN 'Especial' THEN '046 "ES"'
            WHEN 'Supletiva' THEN '046 "SUP"'
            WHEN 'Mudança de Funçao' THEN '047 "MF"'
            WHEN 'Periódico' THEN '048 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
        END AS P_NUMBER,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '228 "ADM"'
            WHEN 'Demissional' THEN '231 "DEM"'
            WHEN 'Especial' THEN '235 "ES"'
            WHEN 'Supletiva' THEN '235 "SUP"'
            WHEN 'Mudança de Funçao' THEN '237 "MF"'
            WHEN 'Periódico' THEN '240 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
        END AS SRV_PROTTYPE,
        "NU_MATRICULA" as PERNR,
        '67 "EHA0029"' as COD_EXAME,
        "Data" as DATE_RESULT,
        CASE "Normalidade"
            WHEN 'D' THEN '1'
            WHEN 'F' THEN '2'
        END as RES_REF_LAB,
        "Relatorio_Anual" as RELAT_ANL,
        mes_ref as MES_REF,
        'EHA0029' as COD_EXAME_II,
        "TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
    FROM {ORACLE_SCHEMA}.VW_EXP_EHA0029

    UNION ALL

    SELECT
        CD_EMPRESA,
        CD_UNIDADE,
        '021' AS PGROUP,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '044 "ADM"'
            WHEN 'Demissional' THEN '045 "DEM"'
            WHEN 'Especial' THEN '046 "ES"'
            WHEN 'Supletiva' THEN '046 "SUP"'
            WHEN 'Mudança de Funçao' THEN '047 "MF"'
            WHEN 'Periódico' THEN '048 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
        END AS P_NUMBER,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '228 "ADM"'
            WHEN 'Demissional' THEN '231 "DEM"'
            WHEN 'Especial' THEN '235 "ES"'
            WHEN 'Supletiva' THEN '235 "SUP"'
            WHEN 'Mudança de Funçao' THEN '237 "MF"'
            WHEN 'Periódico' THEN '240 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
        END AS SRV_PROTTYPE,
        "NU_MATRICULA" as PERNR,
        '68 "EHA0018"' as COD_EXAME,
        "Data" as DATE_RESULT,
        CASE "Normalidade"
            WHEN 'D' THEN '1'
            WHEN 'F' THEN '2'
        END as RES_REF_LAB,
        "Relatorio_Anual" as RELAT_ANL,
        mes_ref as MES_REF,
        'EHA0018' as COD_EXAME_II,
        "TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
    FROM {ORACLE_SCHEMA}.VW_EXP_EHA0018

    UNION ALL

    SELECT
        CD_EMPRESA,
        CD_UNIDADE,
        '021' AS PGROUP,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '044 "ADM"'
            WHEN 'Demissional' THEN '045 "DEM"'
            WHEN 'Especial' THEN '046 "ES"'
            WHEN 'Supletiva' THEN '046 "SUP"'
            WHEN 'Mudança de Funçao' THEN '047 "MF"'
            WHEN 'Periódico' THEN '048 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
        END AS P_NUMBER,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '228 "ADM"'
            WHEN 'Demissional' THEN '231 "DEM"'
            WHEN 'Especial' THEN '235 "ES"'
            WHEN 'Supletiva' THEN '235 "SUP"'
            WHEN 'Mudança de Funçao' THEN '237 "MF"'
            WHEN 'Periódico' THEN '240 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
        END AS SRV_PROTTYPE,
        "NU_MATRICULA" as PERNR,
        '69 "EHA0033"' as COD_EXAME,
        "Data" as DATE_RESULT,
        CASE "Normalidade"
            WHEN 'D' THEN '1'
            WHEN 'F' THEN '2'
        END as RES_REF_LAB,
        "Relatorio_Anual" as RELAT_ANL,
        mes_ref as MES_REF,
        'EHA0033' as COD_EXAME_II,
        "TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
    FROM {ORACLE_SCHEMA}.VW_EXP_EHA0033

    UNION ALL

    SELECT
        CD_EMPRESA,
        CD_UNIDADE,
        '021' AS PGROUP,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '044 "ADM"'
            WHEN 'Demissional' THEN '045 "DEM"'
            WHEN 'Especial' THEN '046 "ES"'
            WHEN 'Supletiva' THEN '046 "SUP"'
            WHEN 'Mudança de Funçao' THEN '047 "MF"'
            WHEN 'Periódico' THEN '048 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
        END AS P_NUMBER,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '228 "ADM"'
            WHEN 'Demissional' THEN '231 "DEM"'
            WHEN 'Especial' THEN '235 "ES"'
            WHEN 'Supletiva' THEN '235 "SUP"'
            WHEN 'Mudança de Funçao' THEN '237 "MF"'
            WHEN 'Periódico' THEN '240 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
        END AS SRV_PROTTYPE,
        "NU_MATRICULA" as PERNR,
        '70 "EHA0026"' as COD_EXAME,
        "Data" as DATE_RESULT,
        CASE "Normalidade"
            WHEN 'D' THEN '1'
            WHEN 'F' THEN '2'
        END as RES_REF_LAB,
        "Relatorio_Anual" as RELAT_ANL,
        mes_ref as MES_REF,
        'EHA0026' as COD_EXAME_II,
        "TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
    FROM {ORACLE_SCHEMA}.VW_EXP_EHA0026

    UNION ALL

    SELECT
        CD_EMPRESA,
        CD_UNIDADE,
        '021' AS PGROUP,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '044 "ADM"'
            WHEN 'Demissional' THEN '045 "DEM"'
            WHEN 'Especial' THEN '046 "ES"'
            WHEN 'Supletiva' THEN '046 "SUP"'
            WHEN 'Mudança de Funçao' THEN '047 "MF"'
            WHEN 'Periódico' THEN '048 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
        END AS P_NUMBER,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '228 "ADM"'
            WHEN 'Demissional' THEN '231 "DEM"'
            WHEN 'Especial' THEN '235 "ES"'
            WHEN 'Supletiva' THEN '235 "SUP"'
            WHEN 'Mudança de Funçao' THEN '237 "MF"'
            WHEN 'Periódico' THEN '240 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
        END AS SRV_PROTTYPE,
        "NU_MATRICULA" as PERNR,
        '72 "EHA0007"' as COD_EXAME,
        "Data" as DATE_RESULT,
        CASE "Normalidade"
            WHEN 'D' THEN '1'
            WHEN 'F' THEN '2'
        END as RES_REF_LAB,
        "Relatorio_Anual" as RELAT_ANL,
        mes_ref as MES_REF,
        'EHA0007' as COD_EXAME_II,
        "TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
    FROM {ORACLE_SCHEMA}.VW_EXP_EHA0007

    UNION ALL

    SELECT
        CD_EMPRESA,
        CD_UNIDADE,
        '021' AS PGROUP,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '044 "ADM"'
            WHEN 'Demissional' THEN '045 "DEM"'
            WHEN 'Especial' THEN '046 "ES"'
            WHEN 'Supletiva' THEN '046 "SUP"'
            WHEN 'Mudança de Funçao' THEN '047 "MF"'
            WHEN 'Periódico' THEN '048 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
        END AS P_NUMBER,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '228 "ADM"'
            WHEN 'Demissional' THEN '231 "DEM"'
            WHEN 'Especial' THEN '235 "ES"'
            WHEN 'Supletiva' THEN '235 "SUP"'
            WHEN 'Mudança de Funçao' THEN '237 "MF"'
            WHEN 'Periódico' THEN '240 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
        END AS SRV_PROTTYPE,
        "NU_MATRICULA" as PERNR,
        '673 "EHA0030"' as COD_EXAME,
        "Data" as DATE_RESULT,
        CASE "Normalidade"
            WHEN 'D' THEN '1'
            WHEN 'F' THEN '2'
        END as RES_REF_LAB,
        "Relatorio_Anual" as RELAT_ANL,
        mes_ref as MES_REF,
        'EHA0030' as COD_EXAME_II,
        "TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
    FROM {ORACLE_SCHEMA}.VW_EXP_EHA0030

    UNION ALL

    SELECT
        CD_EMPRESA,
        CD_UNIDADE,
        '021' AS PGROUP,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '044 "ADM"'
            WHEN 'Demissional' THEN '045 "DEM"'
            WHEN 'Especial' THEN '046 "ES"'
            WHEN 'Supletiva' THEN '046 "SUP"'
            WHEN 'Mudança de Funçao' THEN '047 "MF"'
            WHEN 'Periódico' THEN '048 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
        END AS P_NUMBER,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '228 "ADM"'
            WHEN 'Demissional' THEN '231 "DEM"'
            WHEN 'Especial' THEN '235 "ES"'
            WHEN 'Supletiva' THEN '235 "SUP"'
            WHEN 'Mudança de Funçao' THEN '237 "MF"'
            WHEN 'Periódico' THEN '240 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
        END AS SRV_PROTTYPE,
        "NU_MATRICULA" as PERNR,
        '1438 "EHA0006"' as COD_EXAME,
        "Data" as DATE_RESULT,
        CASE "Normalidade"
            WHEN 'D' THEN '1'
            WHEN 'F' THEN '2'
        END as RES_REF_LAB,
        "Relatorio_Anual" as RELAT_ANL,
        mes_ref as MES_REF,
        'EHA0006' as COD_EXAME_II,
        "TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
    FROM {ORACLE_SCHEMA}.VW_EXP_EHA0006

    UNION ALL

    SELECT
        CD_EMPRESA,
        CD_UNIDADE,
        '021' AS PGROUP,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '044 "ADM"'
            WHEN 'Demissional' THEN '045 "DEM"'
            WHEN 'Especial' THEN '046 "ES"'
            WHEN 'Supletiva' THEN '046 "SUP"'
            WHEN 'Mudança de Funçao' THEN '047 "MF"'
            WHEN 'Periódico' THEN '048 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
        END AS P_NUMBER,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '228 "ADM"'
            WHEN 'Demissional' THEN '231 "DEM"'
            WHEN 'Especial' THEN '235 "ES"'
            WHEN 'Supletiva' THEN '235 "SUP"'
            WHEN 'Mudança de Funçao' THEN '237 "MF"'
            WHEN 'Periódico' THEN '240 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
        END AS SRV_PROTTYPE,
        "NU_MATRICULA" as PERNR,
        '1438 "EHA0010"' as COD_EXAME,
        "Data" as DATE_RESULT,
        CASE "Normalidade"
            WHEN 'D' THEN '1'
            WHEN 'F' THEN '2'
        END as RES_REF_LAB,
        "Relatorio_Anual" as RELAT_ANL,
        mes_ref as MES_REF,
        'EHA0010' as COD_EXAME_II,
        "TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
    FROM {ORACLE_SCHEMA}.VW_EXP_EHA0010

    UNION ALL

    SELECT
        CD_EMPRESA,
        CD_UNIDADE,
        '021' AS PGROUP,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '044 "ADM"'
            WHEN 'Demissional' THEN '045 "DEM"'
            WHEN 'Especial' THEN '046 "ES"'
            WHEN 'Supletiva' THEN '046 "SUP"'
            WHEN 'Mudança de Funçao' THEN '047 "MF"'
            WHEN 'Periódico' THEN '048 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
        END AS P_NUMBER,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '228 "ADM"'
            WHEN 'Demissional' THEN '231 "DEM"'
            WHEN 'Especial' THEN '235 "ES"'
            WHEN 'Supletiva' THEN '235 "SUP"'
            WHEN 'Mudança de Funçao' THEN '237 "MF"'
            WHEN 'Periódico' THEN '240 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
        END AS SRV_PROTTYPE,
        "NU_MATRICULA" as PERNR,
        '1438 "EHA0011"' as COD_EXAME,
        "Data" as DATE_RESULT,
        CASE "Normalidade"
            WHEN 'D' THEN '1'
            WHEN 'F' THEN '2'
        END as RES_REF_LAB,
        "Relatorio_Anual" as RELAT_ANL,
        mes_ref as MES_REF,
        'EHA0011' as COD_EXAME_II,
        "TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
    FROM {ORACLE_SCHEMA}.VW_EXP_EHA0011

    UNION ALL

    SELECT
        CD_EMPRESA,
        CD_UNIDADE,
        '021' AS PGROUP,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '044 "ADM"'
            WHEN 'Demissional' THEN '045 "DEM"'
            WHEN 'Especial' THEN '046 "ES"'
            WHEN 'Supletiva' THEN '046 "SUP"'
            WHEN 'Mudança de Funçao' THEN '047 "MF"'
            WHEN 'Periódico' THEN '048 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
        END AS P_NUMBER,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '228 "ADM"'
            WHEN 'Demissional' THEN '231 "DEM"'
            WHEN 'Especial' THEN '235 "ES"'
            WHEN 'Supletiva' THEN '235 "SUP"'
            WHEN 'Mudança de Funçao' THEN '237 "MF"'
            WHEN 'Periódico' THEN '240 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
        END AS SRV_PROTTYPE,
        "NU_MATRICULA" as PERNR,
        '1438 "EHA0009"' as COD_EXAME,
        "Data" as DATE_RESULT,
        CASE "Normalidade"
            WHEN 'D' THEN '1'
            WHEN 'F' THEN '2'
        END as RES_REF_LAB,
        "Relatorio_Anual" as RELAT_ANL,
        mes_ref as MES_REF,
        'EHA0009' as COD_EXAME_II,
        "TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
    FROM {ORACLE_SCHEMA}.VW_EXP_EHA0009

    UNION ALL

    SELECT
        CD_EMPRESA,
        CD_UNIDADE,
        '021' AS PGROUP,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '044 "ADM"'
            WHEN 'Demissional' THEN '045 "DEM"'
            WHEN 'Especial' THEN '046 "ES"'
            WHEN 'Supletiva' THEN '046 "SUP"'
            WHEN 'Mudança de Funçao' THEN '047 "MF"'
            WHEN 'Periódico' THEN '048 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
        END AS P_NUMBER,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '228 "ADM"'
            WHEN 'Demissional' THEN '231 "DEM"'
            WHEN 'Especial' THEN '235 "ES"'
            WHEN 'Supletiva' THEN '235 "SUP"'
            WHEN 'Mudança de Funçao' THEN '237 "MF"'
            WHEN 'Periódico' THEN '240 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
        END AS SRV_PROTTYPE,
        "NU_MATRICULA" as PERNR,
        '1438 "EHA0008"' as COD_EXAME,
        "Data" as DATE_RESULT,
        CASE "Normalidade"
            WHEN 'D' THEN '1'
            WHEN 'F' THEN '2'
        END as RES_REF_LAB,
        "Relatorio_Anual" as RELAT_ANL,
        mes_ref as MES_REF,
        'EHA0008' as COD_EXAME_II,
        "TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
    FROM {ORACLE_SCHEMA}.VW_EXP_EHA0008

    UNION ALL

    SELECT
        CD_EMPRESA,
        CD_UNIDADE,
        '021' AS PGROUP,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '044 "ADM"'
            WHEN 'Demissional' THEN '045 "DEM"'
            WHEN 'Especial' THEN '046 "ES"'
            WHEN 'Supletiva' THEN '046 "SUP"'
            WHEN 'Mudança de Funçao' THEN '047 "MF"'
            WHEN 'Periódico' THEN '048 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '049 "RT"'
        END AS P_NUMBER,
        CASE TIPO_EXAME
            WHEN 'Admissional' THEN '228 "ADM"'
            WHEN 'Demissional' THEN '231 "DEM"'
            WHEN 'Especial' THEN '235 "ES"'
            WHEN 'Supletiva' THEN '235 "SUP"'
            WHEN 'Mudança de Funçao' THEN '237 "MF"'
            WHEN 'Periódico' THEN '240 "PER"'
            WHEN 'Retorno ao Trabalho' THEN '246 "RT"'
        END AS SRV_PROTTYPE,
        "NU_MATRICULA" as PERNR,
        '1522 "EHA0012"' as COD_EXAME,
        "Data" as DATE_RESULT,
        CASE "Normalidade"
            WHEN 'D' THEN '1'
            WHEN 'F' THEN '2'
        END as RES_REF_LAB,
        "Relatorio_Anual" as RELAT_ANL,
        mes_ref as MES_REF,
        'EHA0012' as COD_EXAME_II,
        "TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
    FROM {ORACLE_SCHEMA}.VW_EXP_EHA0012
)
WHERE DATA_PERFORMAD >= to_date('01/10/2021','dd/MM/yyyy')
  AND DATA_PERFORMAD < to_date('23/03/2026','dd/MM/yyyy')
  AND CD_EMPRESA IN ('00001', '00004', '00046', '00064', '00068', '00112', '00284', '00360', '00632','00646')
  AND PERNR NOT IN ('81055446', '81052313', '81051932', '81052318', '81047976', '81047974', '81055848', '81055911', '81055919', '81047936', '81020731', '81048496', '81048494', '81052371', '81052628', '81055929', '81055931', '81056217', '81056220', '81056222', '81056232', '81048547', '81048720', '81056298', '81049183', '81056586', '81049213', '81051807', '81049154', '81049193', '81049336', '81049118', '81049131', '81049132', '81049133', '81049134', '81049137', '81049142', '81049158', '81049165', '81049181', '81049280', '81049318', '81049358', '81049380', '81049449', '81049290', '81049089', '81049090', '81049194', '81049082', '81049094', '81049117', '81049195', '81049203', '81049211', '81049281', '81049316', '81049441', '81049455', '81048840', '81048913', '81049289', '81048727', '81048750', '81048756', '81048757', '81048763', '81048776', '81048780', '81048781', '81048782', '81048783', '81048784', '81048785', '81048787', '81048810', '81048818', '81048820', '81048822', '81048836', '81048847', '81048852', '81048861', '81048877', '81048885', '81048888', '81048909', '81048924', '81048926', '81048930', '81048931', '81048980', '81048984', '81048988', '81048991', '81049005', '81049012', '81049022', '81049023', '81049033', '81049034', '81049060', '81049065', '81049304', '81049308', '81049309', '81049320', '81049325', '81049338', '81049344', '81049347', '81049348', '81049370', '81049371', '81049392', '81049393', '81049394', '81049404', '81049453', '81049454', '81049456', '81049457', '81049460', '81049468', '81049469', '81048736', '81048833', '81048834', '81048842', '81048845', '81048846', '81048857', '81048878', '81048891', '81048893', '81048895', '81048896', '81048918', '81048920', '81048933', '81048934', '81048944', '81048948', '81048963', '81048971', '81048981', '81049021', '81049038', '81049161', '81049317', '81049329', '81049331', '81049385', '81049388', '81049437', '81049108', '81048359', '81040759', '81049006', '81049028', '81049032', '81049129', '81049174', '81049244', '81049333', '81049378', '81049382', '81049365', '81049466', '81048839', '81048728', '81048731', '81048755', '81048766', '81048767', '81048773', '81048816', '81048821', '81048830', '81048843', '81048870', '81048887', '81048911', '81048912', '81048915', '81048925', '81048929', '81048970', '81049002', '81049024', '81049037', '81049136', '81049138', '81049201', '81049210', '81049216', '81049219', '81049231', '81049277', '81049297', '81049299', '81049300', '81049335', '81049350', '81049359', '81049361', '81049377', '81049379', '81049439', '81049452', '81049040', '81048838', '81056340', '81056355', '81056360', '81056361', '81056365', '81056370', '81056372', '81056376', '81056377', '81056387', '81056390', '81056399', '81056308', '81056342', '81056352', '81056353', '81056354', '81056357', '81056358', '81056359', '81056362', '81056363', '81056364', '81056369', '81056371', '81056373', '81056374', '81056375', '81056378', '81056379', '81056380', '81056381', '81056382', '81056383', '81056384', '81056388', '81056389', '81056401', '81056402', '81056403', '81056404', '81056405', '81056406', '81056408', '81056420', '81056595', '81049096', '81049230', '81049396', '81052674', '81052696', '81052753', '81052824', '81052834', '81052874', '81052880', '81052910', '81052806', '81052833', '81052854', '81052861', '81052899', '81048788', '81048792', '81048819', '81048886', '81048954', '81048972', '81049050', '81049063', '81049069', '81049311', '81049447', '81048805', '81048808', '81048813', '81048814', '81048862', '81048946', '81048957', '81048959', '81048960', '81049000', '81049020', '81049120', '81049122', '81049145', '81049148', '81049177', '81049180', '81049182', '81049204', '81049206', '81049222', '81049225', '81049227', '81049240', '81049249', '81049250', '81049251', '81049252', '81049254', '81049257', '81049310', '81049312', '81049313', '81049321', '81049322', '81049324', '81049334', '81049341', '81049342', '81049354', '81049364', '81049372', '81049381', '81049398', '81049434', '81049440', '81049443', '81048807', '81048998', '81049031', '81049127', '81049179', '81049261', '81049360', '81049363', '81056341', '81056391', '81056392', '81056393', '81056397', '81056398', '81056409', '81056593', '81056599', '81056602', '81052204', '81050190', '81050191', '81050201', '81050043', '81050128', '81056385', '421545', '163147', '262923', '287474', '402248', '456343', '510123', '608554', '919845', '920850', '655902', '971077')
  AND EXISTS (SELECT 1 FROM {ORACLE_SCHEMA}.vw_ish_vinculo
              WHERE nu_matricula = PERNR
                AND ((dt_admissao < to_date('23/03/2026','dd/MM/yyyy') AND dt_demissao IS NULL)
                     OR dt_demissao >= to_date('01/06/2021','dd/MM/yyyy'))))
SELECT * FROM TAB t
WHERE data_performad = (SELECT Max(data_performad) FROM tab
                        WHERE pernr = t.pernr
                          AND cod_exame_ii = t.cod_exame_ii
                          AND tipo_exame_ii = t.tipo_exame_ii)
"""

# COMMAND ----------

SQL_PROVAS_FUNC = f"""
WITH TAB AS (SELECT * FROM (
SELECT
CD_EMPRESA,
CD_UNIDADE,
 '021' AS PGROUP,
CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
"NU_MATRICULA" as PERNR,
 '1437 "ERA0004"' as COD_EXAME,
"Data" as DATE_RESULT,
CASE "Normalidade" WHEN 'D' THEN '1'  WHEN 'F' THEN '2' END as RES_REF_LAB,
"Relatorio_Anual" as RELAT_ANL,
mes_ref as MES_REF,
 'ERA0004' as COD_EXAME_II,
"TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
FROM {ORACLE_SCHEMA}.VW_EXP_ERA0004

union all

SELECT
CD_EMPRESA,
CD_UNIDADE,
 '021' AS PGROUP,
CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
"NU_MATRICULA" as PERNR,
 '530 "EPA0040"' as COD_EXAME,
"Data" as DATE_RESULT,
CASE "Normalidade" WHEN 'D' THEN '1'  WHEN 'F' THEN '2' END as RES_REF_LAB,
"Relatorio_Anual" as RELAT_ANL,
mes_ref as MES_REF,
 'EPA0040' as COD_EXAME_II,
"TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
FROM {ORACLE_SCHEMA}.VW_EXP_EPA0040

UNION ALL

SELECT
CD_EMPRESA,
CD_UNIDADE,
 '021' AS PGROUP,
CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
"NU_MATRICULA" as PERNR,
 '1436 "EPA0030"' as COD_EXAME,
"Data" as DATE_RESULT,
CASE "Normalidade" WHEN 'D' THEN '1'  WHEN 'F' THEN '2' END as RES_REF_LAB,
"Relatorio_Anual" as RELAT_ANL,
mes_ref as MES_REF,
 'EPA0030' as COD_EXAME_II,
"TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
FROM {ORACLE_SCHEMA}.VW_EXP_EPA0030

UNION ALL

SELECT
CD_EMPRESA,
CD_UNIDADE,
 '021' AS PGROUP,
CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
"NU_MATRICULA" as PERNR,
 '1446 "EPA0070"' as COD_EXAME,
"Data" as DATE_RESULT,
CASE "Normalidade" WHEN 'D' THEN '1'  WHEN 'F' THEN '2' END as RES_REF_LAB,
"Relatorio_Anual" as RELAT_ANL,
mes_ref as MES_REF,
 'EPA0070' as COD_EXAME_II,
"TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
FROM {ORACLE_SCHEMA}.VW_EXP_EPA0070

UNION ALL

SELECT
CD_EMPRESA,
CD_UNIDADE,
 '021' AS PGROUP,
CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
"NU_MATRICULA" as PERNR,
 '1166 "EPA0020"' as COD_EXAME,
"Data" as DATE_RESULT,
'' as RES_REF_LAB,
"Relatorio_Anual" as RELAT_ANL,
mes_ref as MES_REF,
 'EPA0020' as COD_EXAME_II,
"TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
FROM {ORACLE_SCHEMA}.VW_EXP_EPA0020

UNION ALL

SELECT
CD_EMPRESA,
CD_UNIDADE,
 '021' AS PGROUP,
CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
"NU_MATRICULA" as PERNR,
 '256 "EPA0050"' as COD_EXAME,
"Data" as DATE_RESULT,
CASE "Normalidade" WHEN 'D' THEN '1'  WHEN 'F' THEN '2' END as RES_REF_LAB,
"Relatorio_Anual" as RELAT_ANL,
mes_ref as MES_REF,
 'EPA0050' as COD_EXAME_II,
"TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
FROM {ORACLE_SCHEMA}.VW_EXP_EPA0050

UNION ALL

SELECT
CD_EMPRESA,
CD_UNIDADE,
 '021' AS PGROUP,
CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
"NU_MATRICULA" as PERNR,
 '257 "EPA0080"' as COD_EXAME,
"Data" as DATE_RESULT,
CASE "Normalidade" WHEN 'D' THEN '1'  WHEN 'F' THEN '2' END as RES_REF_LAB,
"Relatorio_Anual" as RELAT_ANL,
mes_ref as MES_REF,
 'EPA0080' as COD_EXAME_II,
"TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
FROM {ORACLE_SCHEMA}.VW_EXP_EPA0080

UNION ALL

SELECT
CD_EMPRESA,
CD_UNIDADE,
 '021' AS PGROUP,
CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
"NU_MATRICULA" as PERNR,
 '258 "EPA0014"' as COD_EXAME,
"Data" as DATE_RESULT,
'' as RES_REF_LAB,
"Relatorio_Anual" as RELAT_ANL,
mes_ref as MES_REF,
 'EPA0014' as COD_EXAME_II,
"TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
FROM {ORACLE_SCHEMA}.VW_EXP_EPA0014

UNION ALL

SELECT
CD_EMPRESA,
CD_UNIDADE,
 '021' AS PGROUP,
CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
"NU_MATRICULA" as PERNR,
 '256 "EPA0060"' as COD_EXAME,
"Data" as DATE_RESULT,
'' as RES_REF_LAB,
"Relatorio_Anual" as RELAT_ANL,
mes_ref as MES_REF,
 'EPA0060' as COD_EXAME_II,
"TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
FROM {ORACLE_SCHEMA}.VW_EXP_EPA0060

union all

SELECT
CD_EMPRESA,
CD_UNIDADE,
 '021' AS PGROUP,
CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
"NU_MATRICULA" as PERNR,
 '1521 "EPA0095"' as COD_EXAME,
"Data" as DATE_RESULT,
'' as RES_REF_LAB,
"Relatorio_Anual" as RELAT_ANL,
mes_ref as MES_REF,
 'EPA0095' as COD_EXAME_II,
"TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
FROM {ORACLE_SCHEMA}.VW_EXP_EPA0095
)
WHERE DATA_PERFORMAD >= to_date('01/10/2021','dd/MM/yyyy')
  AND DATA_PERFORMAD < to_date('23/03/2026','dd/MM/yyyy')
  AND CD_EMPRESA IN ('00001', '00004', '00046', '00064', '00068', '00112', '00284', '00360', '00632','00646')
  AND PERNR NOT IN ('81055446', '81052313', '81051932', '81052318', '81047976', '81047974', '81055848', '81055911', '81055919', '81047936', '81020731', '81048496', '81048494', '81052371', '81052628', '81055929', '81055931', '81056217', '81056220', '81056222', '81056232', '81048547', '81048720', '81056298', '81049183', '81056586', '81049213', '81051807', '81049154', '81049193', '81049336', '81049118', '81049131', '81049132', '81049133', '81049134', '81049137', '81049142', '81049158', '81049165', '81049181', '81049280', '81049318', '81049358', '81049380', '81049449', '81049290', '81049089', '81049090', '81049194', '81049082', '81049094', '81049117', '81049195', '81049203', '81049211', '81049281', '81049316', '81049441', '81049455', '81048840', '81048913', '81049289', '81048727', '81048750', '81048756', '81048757', '81048763', '81048776', '81048780', '81048781', '81048782', '81048783', '81048784', '81048785', '81048787', '81048810', '81048818', '81048820', '81048822', '81048836', '81048847', '81048852', '81048861', '81048877', '81048885', '81048888', '81048909', '81048924', '81048926', '81048930', '81048931', '81048980', '81048984', '81048988', '81048991', '81049005', '81049012', '81049022', '81049023', '81049033', '81049034', '81049060', '81049065', '81049304', '81049308', '81049309', '81049320', '81049325', '81049338', '81049344', '81049347', '81049348', '81049370', '81049371', '81049392', '81049393', '81049394', '81049404', '81049453', '81049454', '81049456', '81049457', '81049460', '81049468', '81049469', '81048736', '81048833', '81048834', '81048842', '81048845', '81048846', '81048857', '81048878', '81048891', '81048893', '81048895', '81048896', '81048918', '81048920', '81048933', '81048934', '81048944', '81048948', '81048963', '81048971', '81048981', '81049021', '81049038', '81049161', '81049317', '81049329', '81049331', '81049385', '81049388', '81049437', '81049108', '81048359', '81040759', '81049006', '81049028', '81049032', '81049129', '81049174', '81049244', '81049333', '81049378', '81049382', '81049365', '81049466', '81048839', '81048728', '81048731', '81048755', '81048766', '81048767', '81048773', '81048816', '81048821', '81048830', '81048843', '81048870', '81048887', '81048911', '81048912', '81048915', '81048925', '81048929', '81048970', '81049002', '81049024', '81049037', '81049136', '81049138', '81049201', '81049210', '81049216', '81049219', '81049231', '81049277', '81049297', '81049299', '81049300', '81049335', '81049350', '81049359', '81049361', '81049377', '81049379', '81049439', '81049452', '81049040', '81048838', '81056340', '81056355', '81056360', '81056361', '81056365', '81056370', '81056372', '81056376', '81056377', '81056387', '81056390', '81056399', '81056308', '81056342', '81056352', '81056353', '81056354', '81056357', '81056358', '81056359', '81056362', '81056363', '81056364', '81056369', '81056371', '81056373', '81056374', '81056375', '81056378', '81056379', '81056380', '81056381', '81056382', '81056383', '81056384', '81056388', '81056389', '81056401', '81056402', '81056403', '81056404', '81056405', '81056406', '81056408', '81056420', '81056595', '81049096', '81049230', '81049396', '81052674', '81052696', '81052753', '81052824', '81052834', '81052874', '81052880', '81052910', '81052806', '81052833', '81052854', '81052861', '81052899', '81048788', '81048792', '81048819', '81048886', '81048954', '81048972', '81049050', '81049063', '81049069', '81049311', '81049447', '81048805', '81048808', '81048813', '81048814', '81048862', '81048946', '81048957', '81048959', '81048960', '81049000', '81049020', '81049120', '81049122', '81049145', '81049148', '81049177', '81049180', '81049182', '81049204', '81049206', '81049222', '81049225', '81049227', '81049240', '81049249', '81049250', '81049251', '81049252', '81049254', '81049257', '81049310', '81049312', '81049313', '81049321', '81049322', '81049324', '81049334', '81049341', '81049342', '81049354', '81049364', '81049372', '81049381', '81049398', '81049434', '81049440', '81049443', '81048807', '81048998', '81049031', '81049127', '81049179', '81049261', '81049360', '81049363', '81056341', '81056391', '81056392', '81056393', '81056397', '81056398', '81056409', '81056593', '81056599', '81056602', '81052204', '81050190', '81050191', '81050201', '81050043', '81050128', '81056385', '421545', '163147', '262923', '287474', '402248', '456343', '510123', '608554', '919845', '920850', '655902', '971077')
  AND EXISTS (SELECT 1 FROM {ORACLE_SCHEMA}.vw_ish_vinculo
              WHERE nu_matricula = PERNR
                AND ((dt_admissao < to_date('23/03/2026','dd/MM/yyyy') AND dt_demissao IS NULL)
                     OR dt_demissao >= to_date('01/06/2021','dd/MM/yyyy'))))
SELECT * FROM TAB t
WHERE data_performad = (SELECT Max(data_performad) FROM tab
                        WHERE pernr = t.pernr
                          AND cod_exame_ii = t.cod_exame_ii
                          AND tipo_exame_ii = t.tipo_exame_ii)
"""

# COMMAND ----------

SQL_ORTHORATER = f"""
WITH TAB AS (
SELECT *
FROM (
      SELECT EMP.CD_EMPRESA CD_EMPRESA,
            UNI.CD_UNIDADE,
            '021' AS PGROUP,
            CASE {ORACLE_SCHEMA}.FC_VALOR_TAB_TR('TBF4EC17B3314746E2A709B12CE_TR', 'CL000000000000ABCD000300000000', te.CLF4EC17B3314746E2A709B12CEAED)
                WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"'
                WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"'
                WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
            CASE {ORACLE_SCHEMA}.FC_VALOR_TAB_TR('TBF4EC17B3314746E2A709B12CE_TR', 'CL000000000000ABCD000300000000', te.CLF4EC17B3314746E2A709B12CEAED)
                WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"'
                WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"'
                WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
            V.CLA95D0DD6FEFB4A63A7CC460CF494 PERNR,
            '1521 "EPA0090"' as COD_EXAME,
            T.CL000000000000ABCD001100000000 AS DATE_RESULT,
            CASE {ORACLE_SCHEMA}.FC_VALOR_TAB_TR('TB7E6A8738086542FAB42E8411D_TR', 'CL000000000000ABCD000200000000', T.CL8F7A4680DE224C43A948896FD6F1)
                WHEN 'D' THEN '1' WHEN 'F' THEN '2' END as RES_REF_LAB,
            {ORACLE_SCHEMA}.FC_VALOR_TAB_TR('TB802A2B0A33CC4082984AF5A74_TR', 'CL000000000000ABCD000200000000', T.CL802A2B0A33CC4082984AF5A74AB5) AS RELAT_ANL,
            TE.CL000000000000ABCD001100000000 MES_REF,
            'EPA0090' as COD_EXAME_II,
            {ORACLE_SCHEMA}.FC_VALOR_TAB_TR('TBF4EC17B3314746E2A709B12CE_TR', 'CL000000000000ABCD000300000000', te.CLF4EC17B3314746E2A709B12CEAED) as TIPO_EXAME_II,
            (SELECT Max(CL000000000000ABCD001200000000)
             FROM {ORACLE_SCHEMA}.TB0485ABA11B0246CE940D89D48F03
             WHERE CL000000000000ABCD001000000000 = te.CL000000000000ABCD000000000000) as DATA_PERFORMAD
      FROM {ORACLE_SCHEMA}.TB442348AD84C543298F8DD2A6AA5A T,
           {ORACLE_SCHEMA}.TBD4F8369149424FFB82ED155DF4ED TE,
           {ORACLE_SCHEMA}.TB831F15D403654FCE84691FE856D2 V,
           {ORACLE_SCHEMA}.VW_ISH_EMPRESA EMP,
           {ORACLE_SCHEMA}.VW_ISH_UNIDADE UNI
      WHERE T.CL000000000000ABCD001000000000 = TE.CL000000000000ABCD000000000000
        AND V.CL000000000000ABCD000000000000 = TE.CL000000000000ABCD001000000000
        AND EMP.ID_EMPRESA = V.CL000000000000ABCD003400000000
        AND UNI.ID_UNIDADE = V.CL000000000000ABCD003500000000
        AND ((v.CL000000000000ABCD004200000000 < to_date('23/03/2026','dd/MM/yyyy') AND v.CL000000000000ABCD004000000000 IS NULL)
             OR v.CL000000000000ABCD004000000000 >= to_date('01/06/2021','dd/MM/yyyy'))
        AND CD_EMPRESA IN ('00001', '00004', '00046', '00064', '00068', '00112', '00284', '00360', '00632','00646')
) T
WHERE LENGTH(PERNR) < 10
  AND DATA_PERFORMAD >= to_date('01/10/2021','dd/MM/yyyy')
  AND DATA_PERFORMAD < to_date('23/03/2026','dd/MM/yyyy'))
SELECT * FROM TAB T
WHERE DATA_PERFORMAD = (SELECT MAX(DATA_PERFORMAD) FROM TAB
                        WHERE PERNR = T.PERNR
                          AND COD_EXAME_II = T.COD_EXAME_II
                          AND TIPO_EXAME_II = T.TIPO_EXAME_II)
"""

# COMMAND ----------

print('Lendo grupos do Oracle e gravando incremental...')

first_write = True
total_geral = 0

def gravar_bronze(df, nome):
    """Grava um DataFrame na Bronze (overwrite no primeiro, append nos demais)."""
    global first_write, total_geral
    if df is None:
        return
    df = df.dropDuplicates()

    df = df.select([F.col(c).cast(StringType()).alias(c) for c in df.columns])

    count = df.count()
    total_geral += count
    mode = "overwrite" if first_write else "append"
    (
        df.write.format("delta")
        .mode(mode)
        .option("overwriteSchema", "true" if first_write else "false")
        .option("mergeSchema", "true")
        .saveAsTable(BRONZE_EXAMES_COMPLEMENTARES)
    )
    print(f'    💾 {nome} gravado ({mode}) — {count:,} registros')
    df.unpersist()
    first_write = False


# ── 1) Bioquímicos — view a view (59 views) ──────────────────────
print('  Lendo Bioquimicos (view a view)...')
for cod_exame, cod_exame_ii, view_suffix in BIOQUIMICOS_VIEWS:
    sql = f"""
WITH TAB AS (SELECT * FROM (
SELECT
    CD_EMPRESA, CD_UNIDADE, '021' AS PGROUP,
    CASE TIPO_EXAME WHEN 'Admissional' THEN '044 "ADM"' WHEN 'Demissional' THEN '045 "DEM"' WHEN 'Especial' THEN '046 "ES"' WHEN 'Supletiva' THEN '046 "SUP"' WHEN 'Mudança de Funçao' THEN '047 "MF"' WHEN 'Periódico' THEN '048 "PER"' WHEN 'Retorno ao Trabalho' THEN '049 "RT"' END AS P_NUMBER,
    CASE TIPO_EXAME WHEN 'Admissional' THEN '228 "ADM"' WHEN 'Demissional' THEN '231 "DEM"' WHEN 'Especial' THEN '235 "ES"' WHEN 'Supletiva' THEN '235 "SUP"' WHEN 'Mudança de Funçao' THEN '237 "MF"' WHEN 'Periódico' THEN '240 "PER"' WHEN 'Retorno ao Trabalho' THEN '246 "RT"' END AS SRV_PROTTYPE,
    "NU_MATRICULA" as PERNR,
    '{cod_exame}' as COD_EXAME,
    "Data" as DATE_RESULT,
    CASE "Normalidade" WHEN 'D' THEN '1' WHEN 'F' THEN '2' END as RES_REF_LAB,
    "Relatorio_Anual" as RELAT_ANL,
    mes_ref as MES_REF,
    '{cod_exame_ii}' as COD_EXAME_II,
    "TIPO_EXAME" as TIPO_EXAME_II,
    "DT_ASO" as DATA_PERFORMAD
FROM {ORACLE_SCHEMA}.VW_EXP_{view_suffix})
WHERE DATA_PERFORMAD >= to_date('01/10/2021','dd/MM/yyyy')
  AND DATA_PERFORMAD < to_date('23/03/2026','dd/MM/yyyy')
  AND CD_EMPRESA IN ('00001', '00004', '00046', '00064', '00068', '00112', '00284', '00360', '00632','00646')
  AND PERNR NOT IN ('81055446', '81052313', '81051932', '81052318', '81047976', '81047974', '81055848', '81055911', '81055919', '81047936', '81020731', '81048496', '81048494', '81052371', '81052628', '81055929', '81055931', '81056217', '81056220', '81056222', '81056232', '81048547', '81048720', '81056298', '81049183', '81056586', '81049213', '81051807', '81049154', '81049193', '81049336', '81049118', '81049131', '81049132', '81049133', '81049134', '81049137', '81049142', '81049158', '81049165', '81049181', '81049280', '81049318', '81049358', '81049380', '81049449', '81049290', '81049089', '81049090', '81049194', '81049082', '81049094', '81049117', '81049195', '81049203', '81049211', '81049281', '81049316', '81049441', '81049455', '81048840', '81048913', '81049289', '81048727', '81048750', '81048756', '81048757', '81048763', '81048776', '81048780', '81048781', '81048782', '81048783', '81048784', '81048785', '81048787', '81048810', '81048818', '81048820', '81048822', '81048836', '81048847', '81048852', '81048861', '81048877', '81048885', '81048888', '81048909', '81048924', '81048926', '81048930', '81048931', '81048980', '81048984', '81048988', '81048991', '81049005', '81049012', '81049022', '81049023', '81049033', '81049034', '81049060', '81049065', '81049304', '81049308', '81049309', '81049320', '81049325', '81049338', '81049344', '81049347', '81049348', '81049370', '81049371', '81049392', '81049393', '81049394', '81049404', '81049453', '81049454', '81049456', '81049457', '81049460', '81049468', '81049469', '81048736', '81048833', '81048834', '81048842', '81048845', '81048846', '81048857', '81048878', '81048891', '81048893', '81048895', '81048896', '81048918', '81048920', '81048933', '81048934', '81048944', '81048948', '81048963', '81048971', '81048981', '81049021', '81049038', '81049161', '81049317', '81049329', '81049331', '81049385', '81049388', '81049437', '81049108', '81048359', '81040759', '81049006', '81049028', '81049032', '81049129', '81049174', '81049244', '81049333', '81049378', '81049382', '81049365', '81049466', '81048839', '81048728', '81048731', '81048755', '81048766', '81048767', '81048773', '81048816', '81048821', '81048830', '81048843', '81048870', '81048887', '81048911', '81048912', '81048915', '81048925', '81048929', '81048970', '81049002', '81049024', '81049037', '81049136', '81049138', '81049201', '81049210', '81049216', '81049219', '81049231', '81049277', '81049297', '81049299', '81049300', '81049335', '81049350', '81049359', '81049361', '81049377', '81049379', '81049439', '81049452', '81049040', '81048838', '81056340', '81056355', '81056360', '81056361', '81056365', '81056370', '81056372', '81056376', '81056377', '81056387', '81056390', '81056399', '81056308', '81056342', '81056352', '81056353', '81056354', '81056357', '81056358', '81056359', '81056362', '81056363', '81056364', '81056369', '81056371', '81056373', '81056374', '81056375', '81056378', '81056379', '81056380', '81056381', '81056382', '81056383', '81056384', '81056388', '81056389', '81056401', '81056402', '81056403', '81056404', '81056405', '81056406', '81056408', '81056420', '81056595', '81049096', '81049230', '81049396', '81052674', '81052696', '81052753', '81052824', '81052834', '81052874', '81052880', '81052910', '81052806', '81052833', '81052854', '81052861', '81052899', '81048788', '81048792', '81048819', '81048886', '81048954', '81048972', '81049050', '81049063', '81049069', '81049311', '81049447', '81048805', '81048808', '81048813', '81048814', '81048862', '81048946', '81048957', '81048959', '81048960', '81049000', '81049020', '81049120', '81049122', '81049145', '81049148', '81049177', '81049180', '81049182', '81049204', '81049206', '81049222', '81049225', '81049227', '81049240', '81049249', '81049250', '81049251', '81049252', '81049254', '81049257', '81049310', '81049312', '81049313', '81049321', '81049322', '81049324', '81049334', '81049341', '81049342', '81049354', '81049364', '81049372', '81049381', '81049398', '81049434', '81049440', '81049443', '81048807', '81048998', '81049031', '81049127', '81049179', '81049261', '81049360', '81049363', '81056341', '81056391', '81056392', '81056393', '81056397', '81056398', '81056409', '81056593', '81056599', '81056602', '81052204', '81050190', '81050191', '81050201', '81050043', '81050128', '81056385', '421545', '163147', '262923', '287474', '402248', '456343', '510123', '608554', '919845', '920850', '655902', '971077')
  AND EXISTS (SELECT 1 FROM {ORACLE_SCHEMA}.vw_ish_vinculo
              WHERE nu_matricula = PERNR
                AND ((dt_admissao < to_date('23/03/2026','dd/MM/yyyy') AND dt_demissao IS NULL)
                     OR dt_demissao >= to_date('01/06/2021','dd/MM/yyyy'))))
SELECT * FROM TAB t
WHERE data_performad = (SELECT Max(data_performad) FROM tab
                        WHERE pernr = t.pernr
                          AND cod_exame_ii = t.cod_exame_ii
                          AND tipo_exame_ii = t.tipo_exame_ii)
"""
    df = read_oracle_query(sql, f'Bioq_{view_suffix}', num_partitions=2)
    gravar_bronze(df, f'Bioq_{view_suffix}')


# ── 2) Demais grupos — SQL completo (como antes) ─────────────────
outros_grupos = [
    ('Audiometria',       SQL_AUDIOMETRIA,    4),
    ('Aval Esp ECA0010',  SQL_ECA0010,        4),
    ('Aval Esp Union',    SQL_AVAL_ESP,       4),
    ('Coprologia',        SQL_COPROLOGIA,     4),
    ('Exames Diversos',   SQL_EXAMES_DIV,     4),
    ('Hematologia',       SQL_HEMATOLOGIA,    4),
    ('Provas Funcionais', SQL_PROVAS_FUNC,    4),
    ('Ortho Rater',       SQL_ORTHORATER,     4),
]

for nome, sql, n_part in outros_grupos:
    print(f'  Lendo {nome}...')
    df = read_oracle_query(sql, nome, num_partitions=n_part)
    gravar_bronze(df, nome)


print(f'\nTotal bronze: {total_geral:,} registros')
print(f'Tabela gravada: {BRONZE_EXAMES_COMPLEMENTARES}')

# COMMAND ----------

# df_bronze = spark.table(BRONZE_EXAMES_COMPLEMENTARES).dropDuplicates()
# save_table(df_bronze, BRONZE_EXAMES_COMPLEMENTARES)
# print(f'Dedup final — {df_bronze.count():,} registros')

# COMMAND ----------

# # Descomentar quando quiser salvar na Bronze
# save_table(df_bronze, BRONZE_EXAMES_COMPLEMENTARES)
# print(f'Tabela gravada: {BRONZE_EXAMES_COMPLEMENTARES}')
