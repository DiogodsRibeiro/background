# Databricks notebook source
'''
══════════════════════════════════════════════════════════════════════════════
VALIDATION — Prontuário Médico
══════════════════════════════════════════════════════════════════════════════
Compara o output gerado pelo pipeline com arquivos de referência via hash-match.
Executa validação independente para cada fluxo:
  - Exame Clínico
  - PCD
  - Exames Complementares

Depende de: 13_consolidacao_exportacao_silver (todos os Silver devem estar prontos)
══════════════════════════════════════════════════════════════════════════════
'''

# COMMAND ----------

# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Prontuário Médico/utils/utils"
# MAGIC

# COMMAND ----------

from pyspark.sql.types import StringType

def validate_against_reference(
    table_name: str,
    ref_path: str,
    col_order: list,
    label: str,
) -> None:
    """Compara output do pipeline com arquivo de referência via hash-match."""

    print(f"\n{'='*60}")
    print(f"VALIDAÇÃO: {label}")
    print(f"{'='*60}")

    # 1) Carrega output do pipeline
    df_pipeline = spark.table(table_name)
    df_pipeline = null_to_empty(df_pipeline, col_order)

    available_cols = [c for c in col_order if c in df_pipeline.columns]

    df_hash_pipeline = df_pipeline.withColumn(
        "hash_key",
        F.md5(F.concat_ws("||", *[
            F.coalesce(F.col(c).cast(StringType()), F.lit(""))
            for c in available_cols
        ]))
    )
    df_hash_pipeline.createOrReplaceTempView("df_pipeline")

    # 2) Carrega arquivo de referência
    try:
        df_ref = (
            spark.read
            .option("delimiter", ";")
            .option("header", True)
            .csv(ref_path)
        )
    except Exception as e:
        print(f"⚠️  Arquivo de referência não encontrado: {ref_path}")
        print(f"    Erro: {e}")
        print(f"    Pulando validação de {label}.")
        return

    df_ref = null_to_empty(df_ref, col_order)

    ref_cols = [c for c in col_order if c in df_ref.columns]

    df_hash_ref = df_ref.withColumn(
        "hash_key",
        F.md5(F.concat_ws("||", *[
            F.coalesce(F.col(c).cast(StringType()), F.lit(""))
            for c in ref_cols
        ]))
    )
    df_hash_ref.createOrReplaceTempView("df_ref")

    # 3) Comparação
    result = spark.sql("""
        SELECT
            CASE
                WHEN r.hash_key IS NOT NULL THEN '✅ Match'
                ELSE '❌ Sem match'
            END AS status,
            p.*
        FROM df_pipeline p
        LEFT JOIN df_ref r ON p.hash_key = r.hash_key
    """)

    total = result.count()
    matched = result.filter(F.col("status") == "✅ Match").count()
    unmatched = total - matched
    pct = (matched / total * 100) if total > 0 else 0

    print(f"  Total pipeline:    {total}")
    print(f"  Total referência:  {df_ref.count()}")
    print(f"  ✅ Match:          {matched} ({pct:.1f}%)")
    print(f"  ❌ Sem match:      {unmatched}")

    if unmatched > 0:
        print(f"\n  Amostra de registros sem match:")
        display(result.filter(F.col("status") == "❌ Sem match").limit(10))
    else:
        print(f"\n  🎉 100% de match — Validação OK!")


# COMMAND ----------

# ══════════════════════════════════════════════════════════════════════════════
# VALIDAÇÃO: Exame Clínico
# ══════════════════════════════════════════════════════════════════════════════

validate_against_reference(
    table_name=SILVER_EXAME_CLINICO,
    ref_path=VALIDATION_EXAME_CLINICO_PATH,
    col_order=FINAL_COL_ORDER_EXAME_CLINICO,
    label="Exame Clínico",
)


# COMMAND ----------

# ══════════════════════════════════════════════════════════════════════════════
# VALIDAÇÃO: PCD
# ══════════════════════════════════════════════════════════════════════════════

validate_against_reference(
    table_name=SILVER_PCD,
    ref_path=VALIDATION_PCD_PATH,
    col_order=FINAL_COL_ORDER_PCD,
    label="PCD",
)


# COMMAND ----------

# ══════════════════════════════════════════════════════════════════════════════
# VALIDAÇÃO: Exames Complementares
# ══════════════════════════════════════════════════════════════════════════════

validate_against_reference(
    table_name=SILVER_EXAMES_COMPLEMENTARES,
    ref_path=VALIDATION_EXAMES_COMPL_PATH,
    col_order=FINAL_COL_ORDER_EXAMES_COMPL,
    label="Exames Complementares",
)


# COMMAND ----------

# ══════════════════════════════════════════════════════════════════════════════
# GRÁFICO DE TEMPO DE EXECUÇÃO (integração com Databricks Jobs API)
# ══════════════════════════════════════════════════════════════════════════════

import requests
import json

try:
    # Obter contexto do job atual
    context = json.loads(
        dbutils.notebook.entry_point.getDbutils()
        .notebook().getContext().toJson()
    )

    host = context.get("tags", {}).get("browserHostName", "")
    token = context.get("extraContext", {}).get("api_token", "")
    job_id = context.get("tags", {}).get("jobId", "")
    run_id = context.get("tags", {}).get("multitaskParentRunId", "")

    if host and token and run_id:
        headers = {"Authorization": f"Bearer {token}"}
        url = f"https://{host}/api/2.1/jobs/runs/get?run_id={run_id}"
        resp = requests.get(url, headers=headers)

        if resp.status_code == 200:
            run_data = resp.json()
            tasks = run_data.get("tasks", [])

            task_names = []
            durations = []

            for t in tasks:
                name = t.get("task_key", "?")
                start = t.get("start_time", 0)
                end = t.get("end_time", 0)
                dur_min = (end - start) / 60000.0 if end > start else 0
                task_names.append(name)
                durations.append(round(dur_min, 2))

            # Plot com matplotlib
            import matplotlib.pyplot as plt

            fig, ax = plt.subplots(figsize=(12, max(4, len(task_names) * 0.5)))
            bars = ax.barh(task_names, durations, color="#4CAF50")
            ax.set_xlabel("Duração (minutos)")
            ax.set_title(f"Tempo de execução — Job Run {run_id}")
            ax.bar_label(bars, fmt="%.1f min", padding=3)
            plt.tight_layout()
            display(fig)
        else:
            print(f"⚠️  Não foi possível obter dados do run: {resp.status_code}")
    else:
        print("ℹ️  Contexto de Job não disponível — gráfico de execução não gerado.")

except Exception as e:
    print(f"ℹ️  Gráfico de execução não disponível: {e}")
