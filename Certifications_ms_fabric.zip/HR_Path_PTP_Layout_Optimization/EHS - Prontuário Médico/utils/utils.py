# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Prontuário Médico/config/config"
# MAGIC

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import Window
from pyspark.sql.types import StringType
import pandas as pd
import io

# ── Leitura de fontes ─────────────────────────────────────────────────────────

def read_csv_semicolon(path: str, encoding: str = "UTF-8") -> DataFrame:
    """Lê CSV com delimitador ';' e header na primeira linha."""
    return (
        spark.read
        .option("delimiter", ";")
        .option("header", True)
        .option("encoding", encoding)
        .option("inferSchema", False)
        .csv(path)
    )


def read_excel(path: str, sheet_name: str, header_row: int = 0) -> DataFrame:
    """Lê um arquivo Excel (.xlsx) usando pandas e converte para Spark DataFrame.
    
    Args:
        path: Caminho do arquivo no Volume.
        sheet_name: Nome da aba a ser lida.
        header_row: Linha do cabeçalho (0-indexed).
    """
    pdf = pd.read_excel(path, sheet_name=sheet_name, header=header_row, dtype=str)
    pdf = pdf.fillna("")
    return spark.createDataFrame(pdf)


def read_excel_folder(folder_path: str, sheet_name: str = "Exportar Planilha") -> DataFrame:
    """Lê todos os arquivos .xlsx de uma pasta e os empilha (union).
    
    Equivale ao Folder.Files() + Transform File do Power Query.
    Cada arquivo é lido da aba indicada, com header promovido.
    """
    import os
    
    files = [f for f in os.listdir(folder_path) if f.endswith((".xlsx", ".xls")) and not f.startswith("~")]
    
    if not files:
        raise FileNotFoundError(f"Nenhum arquivo Excel encontrado em: {folder_path}")
    
    dfs = []
    for file_name in files:
        file_path = os.path.join(folder_path, file_name)
        try:
            pdf = pd.read_excel(file_path, sheet_name=sheet_name, dtype=str)
            pdf = pdf.fillna("")
            df = spark.createDataFrame(pdf)
            dfs.append(df)
        except Exception as e:
            print(f"⚠️  Erro ao ler {file_name}: {e}")
    
    if not dfs:
        raise ValueError(f"Nenhum arquivo pôde ser lido de: {folder_path}")
    
    result = dfs[0]
    for df in dfs[1:]:
        result = result.unionByName(df, allowMissingColumns=True)
    
    print(f"✅ {len(dfs)} arquivo(s) lido(s) de {folder_path}")
    return result


# ── Normalização de colunas ───────────────────────────────────────────────────

def normalize_col(col_name: str, to_upper: bool = False) -> str:
    """Normaliza nome de coluna: remove espaços extras, trim."""
    col_name = col_name.strip()
    if to_upper:
        col_name = col_name.upper()
    return col_name


def rename_cols(df: DataFrame, to_upper: bool = False) -> DataFrame:
    """Aplica normalize_col em todas as colunas do DataFrame."""
    for old_name in df.columns:
        new_name = normalize_col(old_name, to_upper)
        if old_name != new_name:
            df = df.withColumnRenamed(old_name, new_name)
    return df


# ── Gravação em tabelas Delta ─────────────────────────────────────────────────

def save_table(df: DataFrame, table: str) -> None:
    """Grava um DataFrame como tabela Delta com overwrite."""
    (
        df.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(table)
    )
    print(f"✅ Gravado: {table} ({df.count()} registros)")


# ── Preparação para JOINs ────────────────────────────────────────────────────

def prefix_df(df: DataFrame, prefix: str, join_col: str, join_alias: str) -> DataFrame:
    """Prefixa todas as colunas (exceto a de join) para evitar ambiguidade."""
    cols_to_rename = [c for c in df.columns if c != join_col]
    for c in cols_to_rename:
        df = df.withColumnRenamed(c, f"{prefix}_{c}")
    df = df.withColumnRenamed(join_col, join_alias)
    return df


# ── Limpeza de dados ─────────────────────────────────────────────────────────

def null_to_empty(df: DataFrame, cols: list = None) -> DataFrame:
    """Substitui NULL por string vazia nas colunas indicadas (ou todas se None)."""
    target_cols = cols if cols else df.columns
    for c in target_cols:
        if c in df.columns:
            df = df.withColumn(c, F.coalesce(F.col(c).cast(StringType()), F.lit("")))
    return df


def remove_slashes(df: DataFrame, cols: list) -> DataFrame:
    """Remove barras '/' de colunas de data (equivale ao ReplaceValue '/' -> '')."""
    for c in cols:
        if c in df.columns:
            df = df.withColumn(c, F.regexp_replace(F.col(c), "/", ""))
    return df


def extract_digits(df: DataFrame, col_name: str, new_col_name: str) -> DataFrame:
    """Extrai apenas dígitos de uma coluna (equivale ao Text.Select com '0'..'9')."""
    df = df.withColumn(new_col_name, F.regexp_replace(F.col(col_name), "[^0-9]", ""))
    return df


def clean_special_chars(df: DataFrame, cols: list) -> DataFrame:
    """Remove caracteres especiais (@#$, CR, LF, TAB, NULL char) de colunas de texto.
    
    Equivale à cadeia de Text.Replace do Power Query:
    - @#$ -> ""
    - Chr(13) -> " "
    - Chr(10) -> " "
    - Chr(9) -> " "
    - Chr(0) -> " "
    """
    for c in cols:
        if c in df.columns:
            df = (
                df.withColumn(c, F.regexp_replace(F.col(c), "@#\\$", ""))
                  .withColumn(c, F.regexp_replace(F.col(c), "[\\r\\n\\t\\x00]", " "))
            )
    return df


def replace_pipe_with_slash(df: DataFrame, cols: list) -> DataFrame:
    """Substitui '|' por '/' em colunas de texto."""
    for c in cols:
        if c in df.columns:
            df = df.withColumn(c, F.regexp_replace(F.col(c), "\\|", "/"))
    return df


def remove_punctuation(df: DataFrame, cols: list) -> DataFrame:
    """Remove '.', '-', '/' de colunas (usado em CRM, NUMOC, etc.)."""
    for c in cols:
        if c in df.columns:
            df = df.withColumn(c, F.regexp_replace(F.col(c), "[.\\-/]", ""))
    return df


def split_column_by_space(df: DataFrame, col_name: str, new_col1: str, new_col2: str) -> DataFrame:
    """Divide uma coluna pelo primeiro espaço (equivale ao Split Column by Delimiter)."""
    df = (
        df.withColumn(new_col1, F.split(F.col(col_name), " ").getItem(0))
          .withColumn(new_col2, F.split(F.col(col_name), " ").getItem(1))
          .drop(col_name)
    )
    return df


def add_leading_zero(df: DataFrame, col_name: str) -> DataFrame:
    """Adiciona '0' como prefixo a uma coluna (equivale ao Added Prefix '0' &)."""
    df = df.withColumn(col_name, F.concat(F.lit("0"), F.col(col_name)))
    return df


# ── Deduplicação com agrupamento (PCD) ───────────────────────────────────────

def dedup_by_sort_key(df: DataFrame, key_col: str, sort_col: str) -> DataFrame:
    """Agrupa por chave, ordena, e mantém apenas o primeiro registro por grupo.
    
    Equivale ao padrão PQ: Group + AddIndex + Filter(IndexA=0).
    """
    w = Window.partitionBy(key_col).orderBy(sort_col)
    df = df.withColumn("_row_num", F.row_number().over(w))
    df = df.filter(F.col("_row_num") == 1).drop("_row_num")
    return df


# ── Cross join com cabeçalho (via coluna Seq) ────────────────────────────────

def cross_join_with_header(df: DataFrame, df_header: DataFrame) -> DataFrame:
    """Faz cross join entre dados e cabeçalho usando coluna 'Seq' = 1.
    
    Equivale ao Merged Queries com Seq=1 no Power Query.
    O header deve ter exatamente 1 linha com Seq=1.
    """
    df = df.withColumn("_seq", F.lit("1"))
    df_header = df_header.withColumn("_seq", F.lit("1"))
    
    result = df.join(F.broadcast(df_header), on="_seq", how="left").drop("_seq")
    return result


# ── Exportação ────────────────────────────────────────────────────────────────
 

def export_df_to_excel(df: DataFrame, volume_path: str, file_base: str) -> None:
    """Exporta DataFrame para Excel (.xlsx) via streaming.
 
    Volumes do Databricks não suportam seek(), então:
      1. Grava o .xlsx em /tmp local (suporta seek)
      2. Copia para o Volume com shutil.copy2
    """
    import os, shutil
    from openpyxl import Workbook
 
    base = volume_path.rstrip("/")
    tmp_xlsx = f"/tmp/{file_base}.xlsx"
    final_xlsx = f"{base}/{file_base}.xlsx"
 
    cols = df.columns
 
    wb = Workbook(write_only=True)
    ws = wb.create_sheet("Dados")
    ws.append(cols)
 
    count = 0
    for row in df.toLocalIterator():
        ws.append([str(row[c]) if row[c] is not None else "" for c in cols])
        count += 1
        if count % 10_000 == 0:
            print(f"  ... {count} linhas escritas")
 
    wb.save(tmp_xlsx)
    wb.close()
 
    # Copiar do /tmp local para o Volume
    shutil.copy2(tmp_xlsx, final_xlsx)
    os.remove(tmp_xlsx)
 
    print(f"✅ Excel exportado: {final_xlsx} ({count} linhas)")
 
 
def export_df_to_csv(df: DataFrame, volume_path: str, file_base: str,
                     delimiter: str = "|") -> None:
    """Exporta DataFrame para CSV via streaming direto no Volume."""
    import os, shutil
 
    base = volume_path.rstrip("/")
    tmp_csv = f"/tmp/{file_base}.csv"
    final_csv = f"{base}/{file_base}.csv"
 
    cols = df.columns
 
    with open(tmp_csv, "w", encoding="utf-8") as f:
        f.write(delimiter.join(cols) + "\n")
        count = 0
        for row in df.toLocalIterator():
            vals = [str(row[c]) if row[c] is not None else "" for c in cols]
            f.write(delimiter.join(vals) + "\n")
            count += 1
 
    shutil.copy2(tmp_csv, final_csv)
    os.remove(tmp_csv)
 
    print(f"✅ CSV exportado: {final_csv} ({count} linhas)")


def export_df_to_excel_with_counts(
    df: DataFrame,
    volume_path: str,
    file_base: str,
    counts: dict,
    sheet_name: str = None,
    df_descartados: DataFrame = None,
) -> None:
    """Exporta DataFrame para Excel com aba de contagem e aba opcional de descartados."""
    import os, shutil
    from openpyxl import Workbook

    base = volume_path.rstrip("/")
    tmp_xlsx = f"/tmp/{file_base}.xlsx"
    final_xlsx = f"{base}/{file_base}.xlsx"
    ws_name = sheet_name or file_base

    cols = df.columns

    wb = Workbook(write_only=True)

    # ── Aba 1: dados ──
    ws_dados = wb.create_sheet(ws_name)
    ws_dados.append(cols)

    count = 0
    for row in df.toLocalIterator():
        ws_dados.append([str(row[c]) if row[c] is not None else "" for c in cols])
        count += 1
        if count % 10_000 == 0:
            print(f"  ... {count} linhas escritas")

    # ── Aba 2: Contagem ──
    ws_contagem = wb.create_sheet("Contagem")
    ws_contagem.append(list(counts.keys()))
    ws_contagem.append([str(v) for v in counts.values()])

    # ── Aba 3: Descartados no DE/PARA (opcional) ──
    if df_descartados is not None:
        ws_desc = wb.create_sheet("Nao_Encontrado_No_DE_PARA")
        desc_cols = df_descartados.columns
        ws_desc.append(desc_cols)
        for row in df_descartados.toLocalIterator():
            ws_desc.append([str(row[c]) if row[c] is not None else "" for c in desc_cols])

    wb.save(tmp_xlsx)
    wb.close()

    shutil.copy2(tmp_xlsx, final_xlsx)
    os.remove(tmp_xlsx)

    print(f"✅ Excel exportado: {final_xlsx} ({count} linhas, aba Contagem incluída)")
 
# Compatibilidade
def export_df_to_csv_excel(df: DataFrame, volume_path: str, file_base: str) -> None:
    """Exporta DataFrame para CSV (|) e Excel."""
    export_df_to_csv(df, volume_path, file_base, delimiter="|")
    export_df_to_excel(df, volume_path, file_base)


print("Utilitários carregados.")
