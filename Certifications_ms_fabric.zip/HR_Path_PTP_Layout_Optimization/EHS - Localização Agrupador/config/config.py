# Databricks notebook source
RAW_BASE = "/Volumes/humanresources_insight/acqu_pcehslocalagrupador/acqu_pcehslocalagrupador/localizacao_agrupador/raw_files"

# Arquivos principais
GERE_INPUT_PATH  = f"{RAW_BASE}/RelatorioGERE_Indicador_17032026.csv" # tem e já está no volume — lido como CSV com ";"
GHRM_INPUT_PATH  = f"{RAW_BASE}/Classificacao_dos_GHRMs_20260319.xlsx"                    # tem e já está no volume
GHP_INPUT_PATH   = f"{RAW_BASE}/GHP_20260313.xlsm"                                        # tem e já está no volume
AGRUPADOR_GHE_CODIFICADO_PATH = f"{RAW_BASE}/Agrupador_GHE_Codificado_20260324_01.xlsx"  # ← novo

GHE_INPUT_FOLDER = f"{RAW_BASE}/ghe_csv"

# Arquivos DE-PARA
GHE_CODIFICADO_PATH       = f"{RAW_BASE}/Agrupador_GHE_Codificado_20260319.xlsx"          # tem e já está no volume
AGRUPADOR_GHRM_CODIFICADO_PATH = f"{RAW_BASE}/Agrupador_GHRM_Codificado_20260324_01.xlsx" # tem e já está no volume
GHP_CODIFICADO_PATH       = f"{RAW_BASE}/Agrupador_GHP_Codificado_20260324.xlsx"          # tem e já está no volume
LOCAL_T_NAO_T_PATH        = f"{RAW_BASE}/LOCAL_T_NAO_T_MOCK4.xlsx"                        # tem e já está no volume
LOCAL_FISICO_DE_PARA_PATH = f"{RAW_BASE}/Local_Fisico_De_Para_Mock4.xlsx"                 # tem e já está no volume — ainda usado por GHE/GHP/GHRM

DE_PARA_LOCAL_FISICO_T_PATH  = f"{RAW_BASE}/LOCAL_T_NAO_T_20260310.XLSX"

# Arquivos DE-PARA — GERE (novos)
ARVORE_EC_PATH            = f"{RAW_BASE}/Arvore_Localizacao_EC_20260324.xlsx"             # tem e já está no volume
LOCAL_SSO_DE_PARA_PATH    = f"{RAW_BASE}/Local SSO_ DE X PARA_20260316.xlsx"              # tem e já está no volume

BRONZE_SCHEMA = "humanresources_insight.bron_pcehslocalagrupador"
SILVER_SCHEMA = "humanresources_insight.silv_pcehslocalagrupador"

BRONZE_GERE              = f"{BRONZE_SCHEMA}.gere_raw"
BRONZE_GHE               = f"{BRONZE_SCHEMA}.ghe_raw"
BRONZE_GHRM              = f"{BRONZE_SCHEMA}.ghrm_raw"
BRONZE_GHP               = f"{BRONZE_SCHEMA}.ghp_raw"
BRONZE_GHE_CODIFICADO    = f"{BRONZE_SCHEMA}.ghe_codificado_raw"
BRONZE_GHRM_CODIFICADO   = f"{BRONZE_SCHEMA}.ghrm_codificado_raw"
BRONZE_GHP_CODIFICADO    = f"{BRONZE_SCHEMA}.ghp_codificado_raw"
BRONZE_LOCAL_T_NAO_T     = f"{BRONZE_SCHEMA}.local_t_nao_t_raw"
BRONZE_LOCAL_FISICO_EC   = f"{BRONZE_SCHEMA}.local_fisico_ec_raw"                         # ainda usado por GHE/GHP/GHRM

# Bronzes novos — GERE
BRONZE_ARVORE_EC          = f"{BRONZE_SCHEMA}.arvore_localizacao_ec_raw"
BRONZE_LOCAL_SSO_DE_PARA  = f"{BRONZE_SCHEMA}.local_sso_de_para_raw"

SILVER_GERE        = f"{SILVER_SCHEMA}.arquivo_layout_sap_gere"
SILVER_GHE         = f"{SILVER_SCHEMA}.arquivo_layout_sap_ghe"
SILVER_GHRM        = f"{SILVER_SCHEMA}.arquivo_layout_sap_ghrm"
SILVER_GHP         = f"{SILVER_SCHEMA}.arquivo_layout_sap_ghp"
SILVER_CONSOLIDADO = f"{SILVER_SCHEMA}.agrup_loca_arquivo_layout"

AGRUPADOR_GHRM_CODIFICADO_SHEET = "Agrupador_GHRM_Codificado"
GERE_SHEET_NAME         = "In"
GHE_SHEET_NAME          = "Export Worksheet"
GHRM_SHEET_NAME         = "Agrupador_Cadastro"
GHP_SHEET_NAME          = "Agrupador_Cadastro"
GHE_CODIFICADO_SHEET    = "Sheet1"
GHRM_CODIFICADO_SHEET   = "Sheet1"
GHP_CODIFICADO_SHEET    = "Agrupador_GHP_Codificado"
LOCAL_T_SHEET           = "DE_PARA_Local_Fisico_T"
LOCAL_FISICO_EC_SHEET   = "EC"
AGRUPADOR_GHE_COD_SHEET     = "Agrupador_GHE_Codificado"  # ← novo
DE_PARA_LOCAL_T_SHEET = "DE_PARA_Local_Fisico_T"

# Sheets novos — GERE
ARVORE_EC_SHEET         = "LOCATION"
LOCAL_SSO_DE_PARA_SHEET = "Local SSO_ DE X PARA"

COL_ID_LOC_FISICO    = "ID_Localizacao_Tipo_Fisico"
COL_ID_ATIVIDADE     = "ID_Atividade_Agrupador"
COL_ID_EXTERNO_LOC   = "ID_Externo_Localizacao_VALE"
COL_ID_EXTERNO_AGRUP = "ID_Externo_Agrupador_VALE"
COL_TIPO_FONTE       = "Tipo_Fonte"
COL_DESCRICAO  = "Descricao_Atividade_Agrupador"
COL_TIPO       = "Tipo_Atividade_Agrupador"

#  Empresas filtradas no GHE
GHE_EMPRESAS_FILTRO = ["00001", "00064", "00068", "00112", "00284", "00360", "00632", "00646"]

# GHRM — Colunas finais
FINAL_COL_ORDER_GHRM = [
    "ID Localização do Tipo Físico",
    "ID da Atividade (Agrupador)",
    "ID Externo Localização VALE",
    "ID Externo Agrupador VALE",
]

print("Configurações carregadas.")