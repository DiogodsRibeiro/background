# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Localização Agrupador/utils/utils"
# MAGIC

# COMMAND ----------

df_full = spark.table(BRONZE_GHE)
df_full.cache()
print(f"BRONZE_GHE — Registros (3 arquivos): {df_full.count()}")

# COMMAND ----------

# =============================================================================
# 1) Dados_GHE
#    Remove colunas de diagnóstico e faz o distinct global que une os 3 arquivos.
#    Source.Name, id_matriz, status, DESC_STATUS_MATRIZ são descartados —
#    o distinct sobre as colunas restantes é o que colapsa Matriz+QUALI+QUANT
#    em 34120 registros únicos.
# =============================================================================
 
COLS_DROP_DADOS = ["Source.Name", "id_matriz", "status", "DESC_STATUS_MATRIZ"]
 
df_dados = df_full.drop(*[c for c in COLS_DROP_DADOS if c in df_full.columns])
 
for c in df_dados.columns:
    df_dados = df_dados.withColumn(c, F.trim(F.col(f"`{c}`")))
 
df_dados = df_dados.dropDuplicates()
df_dados.cache()
 
print(f"Dados_GHE — Registros após distinct global: {df_dados.count()}")

# COMMAND ----------

# =============================================================================
# 2) Agrupador_GHE_Codificado — leitura do Excel externo
#    Colunas usadas no join:
#      - ID Externo (Agrupador) VALE Primario  → chave de join
#      - DESC GHE                              → chave de join
#      - Agrupador 60 Caracteres               → nome/descrição do agrupador
#      - ID Externo (Agrupador) VALE.1         → ID Externo (Agrupador) VALE
# =============================================================================

def normalize_key(col_expr):
    """Remove apenas tabs e faz trim — preserva espaços internos legítimos"""
    return F.trim(F.regexp_replace(col_expr, r"\t", ""))
 
df_agrup_cod_raw = read_excel(AGRUPADOR_GHE_CODIFICADO_PATH, AGRUPADOR_GHE_COD_SHEET)

df_agrup_cod = (
    df_agrup_cod_raw
    .select(
        normalize_key(F.col("`ID Externo (Agrupador) VALE Primario`")).alias("_agc_id_ext_prim"),
        normalize_key(F.col("`DESC GHE`")).alias("_agc_desc_ghe"),
        F.trim(F.col("`Agrupador 60 Caracteres`")).alias("_agc_agrupador_60"),
        F.trim(F.col("`ID Externo (Agrupador) VALE.1`")).alias("_agc_id_ext_vale_1"),
    )
    .dropDuplicates()
)
 
print(f"Agrupador_GHE_Codificado — Registros: {df_agrup_cod.count()}")

# COMMAND ----------

# =============================================================================
# 3) Formata_Localizacao_Agrupador
#    - Filtra COD_LOCAL_FISICO_EC preenchido
#    - Join com Agrupador_GHE_Codificado por {ID_EXT_AGRUP_VALE_PRIMARIO, DESC_GHE}
#    - Renomeia snake_case → nomes originais do PQ
#    - Adiciona colunas de layout (vazias) e reordena
# =============================================================================

df_formata = df_dados.filter(
    F.col("COD_LOCAL_FISICO_EC").isNotNull() &
    (F.col("COD_LOCAL_FISICO_EC") != "")
)

# --- Join principal: duas chaves (ID_PRIMARIO + DESC_GHE) ---
df_join_duplo = df_formata.join(
    F.broadcast(df_agrup_cod),
    (normalize_key(df_formata["ID_EXT_AGRUP_VALE_PRIMARIO"]) == normalize_key(F.col("_agc_id_ext_prim"))) &
    (normalize_key(df_formata["DESC_GHE"])                   == normalize_key(F.col("_agc_desc_ghe"))),
    "left"
).drop("_agc_id_ext_prim", "_agc_desc_ghe")

# --- Fallback: só ID_PRIMARIO para os que ficaram sem match ---
df_sem_match = df_join_duplo.filter(
    F.col("_agc_id_ext_vale_1").isNull() | (F.col("_agc_id_ext_vale_1") == "")
).drop("_agc_id_ext_vale_1", "_agc_agrupador_60")

# Para o fallback, pega só a primeira ocorrência por ID_PRIMARIO no codificado
# (mesmo comportamento do NestedJoin do PQ)
from pyspark.sql.window import Window
df_agrup_cod_dedup = (
    df_agrup_cod
    .withColumn(
        "_rn",
        F.row_number().over(Window.partitionBy("_agc_id_ext_prim").orderBy("_agc_id_ext_prim"))
    )
    .filter(F.col("_rn") == 1)
    .drop("_rn", "_agc_desc_ghe")
)

df_fallback = df_sem_match.join(
    F.broadcast(df_agrup_cod_dedup),
    normalize_key(df_sem_match["ID_EXT_AGRUP_VALE_PRIMARIO"]) == normalize_key(df_agrup_cod_dedup["_agc_id_ext_prim"]),
    "left"
).drop("_agc_id_ext_prim")

# --- Une os dois resultados ---
df_formata = df_join_duplo.filter(
    F.col("_agc_id_ext_vale_1").isNotNull() & (F.col("_agc_id_ext_vale_1") != "")
).union(df_fallback)

df_formata = (
    df_formata
    .withColumn("ID Localização do Tipo Físico", F.lit(""))
    .withColumn("ID da Atividade (Agrupador)",   F.lit(""))
    .withColumn("DELIMITADOR COLUNA",             F.lit(""))
    .withColumnRenamed("LOCAL_NAO_T",          "DE_PARA_Local_Fisico_T.LOCAL NÃO-T")
    .withColumnRenamed("DESCR_1",              "DE_PARA_Local_Fisico_T.DESCR_1")
    .withColumnRenamed("SSO_CD_UNIDADE_PARA",  "Local SSO_ DE X PARA.CD_UNIDADE (PARA)")
    .withColumnRenamed("SSO_DS_UNIDADE_NEW",   "Local SSO_ DE X PARA.DS_UNIDADE_NEW")
    .withColumnRenamed("COD_LOCAL_SSO",        "COD LOCAL SSO")
    .withColumnRenamed("DESC_LOCAL_SSO",       "DESC LOCAL SSO")
    .withColumnRenamed("COD_LOCAL_FISICO",     "COD LOCAL FISICO")
    .withColumnRenamed("DESC_LOCAL_FISICO",    "DESC LOCAL FISICO")
    .withColumnRenamed("COD_GHE",              "COD GHE")
    .withColumnRenamed("DESC_GHE",             "DESC GHE")
    .withColumnRenamed("_agc_id_ext_vale_1",   "ID Externo (Agrupador) VALE")
    .withColumnRenamed("_agc_agrupador_60",    "Agrupador 60 Caracteres")
    .select(
        F.col("ID Localização do Tipo Físico"),
        F.col("ID da Atividade (Agrupador)"),
        F.col("COD_LOCAL_FISICO_EC").alias("ID Externo Localização VALE"),
        F.col("ID Externo (Agrupador) VALE"),
        F.col("DELIMITADOR COLUNA"),
        F.col("cod_empresa"),
        F.col("ds_empresa"),
        F.col("cd_estabelecimento"),
        F.col("ds_estabelecimento"),
        F.col("COD_LOCAL_SSO_ORIG").alias("cod_local_sso"),
        F.col("ds_local_sso"),
        F.col("`Local SSO_ DE X PARA.CD_UNIDADE (PARA)`"),
        F.col("`Local SSO_ DE X PARA.DS_UNIDADE_NEW`"),
        F.col("`COD LOCAL SSO`"),
        F.col("`DESC LOCAL SSO`"),
        F.col("COD_LOCAL_FISICO_ORIG").alias("cod_local_fisico"),
        F.col("ds_local_fisico"),
        F.col("`DE_PARA_Local_Fisico_T.LOCAL NÃO-T`"),
        F.col("`DE_PARA_Local_Fisico_T.DESCR_1`"),
        F.col("`COD LOCAL FISICO`"),
        F.col("`DESC LOCAL FISICO`"),
        F.col("cd_ghe"),
        F.col("ds_ghe"),
        F.col("`COD GHE`"),
        F.col("`DESC GHE`"),
    )
    .dropDuplicates()
)

print(f"Formata_Localizacao_Agrupador — Registros: {df_formata.count()}")

# COMMAND ----------

# =============================================================================
# 4) Arquivo_Layout_SAP (GHE) — 4 colunas de entrega
#
#   ID Localização do Tipo Físico → vazio
#   ID da Atividade (Agrupador)   → vazio
#   ID Externo Localização VALE   → COD_LOCAL_FISICO_EC
#   ID Externo (Agrupador) VALE   → ID Externo (Agrupador) VALE.1 (do Excel codificado)
# =============================================================================
 
df_silver = (
    df_formata
    .select(
        F.col("ID Localização do Tipo Físico"),
        F.col("ID da Atividade (Agrupador)"),
        F.col("ID Externo Localização VALE"),
        F.col("`ID Externo (Agrupador) VALE`"),
    )
    .filter(
        F.col("`ID Externo (Agrupador) VALE`").isNotNull() &
        (F.col("`ID Externo (Agrupador) VALE`") != "")
    )
    .orderBy("`ID Externo (Agrupador) VALE`")
)
 
print(f"Arquivo_Layout_SAP GHE — Registros: {df_silver.count()}")
# display(df_silver)

# COMMAND ----------

# save_table(df_silver, SILVER_GHE)

# COMMAND ----------

export_df_to_csv_excel(
    df_formata,
    "/Volumes/humanresources_insight/acqu_pcehslocalagrupador/acqu_pcehslocalagrupador/localizacao_agrupador/output/",
    "Formata_Localizacao_Agrupador_GHE"
)

# COMMAND ----------

# =============================================================================
# 5) LSSO_ou_LFisico_Nao_EC — registros de Dados_GHE sem match na Arvore EC
# =============================================================================
 
df_nao_ec = df_dados.filter(
    F.col("COD_LOCAL_FISICO_EC").isNull() |
    (F.col("COD_LOCAL_FISICO_EC") == "")
)
 
print(f"LSSO_ou_LFisico_Nao_EC — Registros: {df_nao_ec.count()}")

# COMMAND ----------

export_df_to_csv_excel(
    df_nao_ec,
    "/Volumes/humanresources_insight/acqu_pcehslocalagrupador/acqu_pcehslocalagrupador/localizacao_agrupador/output/",
    "LSSO_ou_LFisico_Nao_EC_GHE"
)

# COMMAND ----------


df_full.unpersist()
df_dados.unpersist()