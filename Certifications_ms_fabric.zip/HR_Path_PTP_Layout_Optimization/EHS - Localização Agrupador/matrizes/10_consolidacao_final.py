# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Localização Agrupador/utils/utils"

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

from pyspark.sql.functions import md5, concat_ws, col, coalesce, lit
from pyspark.sql.types import StringType
import pandas as pd
from pyspark.sql import functions as F


# COMMAND ----------

cols = ["id_localizacao_tipo_fisico", "id_atividade_agrupador", "id_externo_localizacao_vale", "id_externo_agrupador_vale"]

df_consolidado = (
    spark.table(SILVER_GERE).select(cols)
    .unionByName(spark.table(SILVER_GHE).select(cols))
    .unionByName(spark.table(SILVER_GHRM).select(cols))
    .unionByName(spark.table(SILVER_GHP).select(cols))
    .dropDuplicates(cols)
)

print(f"Total consolidado: {df_consolidado.count():,}")

# Salvar
spark.sql(f"TRUNCATE TABLE {SILVER_CONSOLIDADO}")
df_consolidado.write.insertInto(SILVER_CONSOLIDADO)
print("Silver consolidado finalizado.")

# COMMAND ----------

df_consolidado = (
    spark.table(SILVER_CONSOLIDADO)
    .withColumnsRenamed({
        "id_localizacao_tipo_fisico": "ID Localização do Tipo Físico",
        "id_atividade_agrupador": "ID da Atividade (Agrupador)",
        "id_externo_localizacao_vale": "ID Externo Localização VALE",
        "id_externo_agrupador_vale": "ID Externo Agrupador VALE"
    })
)

export_df_to_csv_excel(df_consolidado, '/Volumes/humanresources_insight/acqu_pcehslocalagrupador/acqu_pcehslocalagrupador/localizacao_agrupador/output/', 'Template_Localizacao_Agrupadores')