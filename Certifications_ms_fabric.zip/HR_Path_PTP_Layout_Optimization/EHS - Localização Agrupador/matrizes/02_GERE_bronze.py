# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Localização Agrupador/utils/utils"
# MAGIC

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

df_gere = spark.read.option("delimiter", ";").option("header", "true").option("encoding", "UTF-8").csv(GERE_INPUT_PATH)
spark.sql(f"""TRUNCATE TABLE {BRONZE_GERE}""")
df_gere_normalized = normalize_column_names(df_gere)
(
    df_gere_normalized.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(BRONZE_GERE)
)

# COMMAND ----------

# # # GERE (arquivo principal)
# df_gere = read_excel(GERE_INPUT_PATH, GERE_SHEET_NAME)
# spark.sql(f"""TRUNCATE TABLE {BRONZE_GERE}""")
# df_gere_normalized = normalize_column_names(df_gere)
# df_gere_normalized.write.insertInto(BRONZE_GERE)
# print("Bronze GERE finalizado.")