# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Localização Agrupador/utils/utils"
# MAGIC

# COMMAND ----------

# --- Leitura de TODOS os CSVs da pasta (Matriz + QUALI + QUANT) ---
df_raw = read_csv_folder(GHE_INPUT_FOLDER, delimiter=";", encoding="utf-8")
print(f"Registros brutos lidos (3 arquivos): {df_raw.count()}")
print(f"Colunas: {df_raw.columns}")

# --- Filtrar por empresas ---
df = df_raw.filter(F.col("cod_empresa").isin(GHE_EMPRESAS_FILTRO))

# --- Replace '""' → '' em id_matriz e cd_ghe ---
df = df.withColumn("id_matriz", F.regexp_replace(F.col("id_matriz"), '""', ""))
df = df.withColumn("cd_ghe",    F.regexp_replace(F.col("cd_ghe"),    '""', ""))

# --- Trim em todas as colunas ---
for c in df.columns:
    df = df.withColumn(c, F.trim(F.col(f"`{c}`")))

# --- Sort e filtro de cd_ghe ---
df = (
    df
    .orderBy("cd_ghe", "cod_local_sso")
    .filter(F.col("cd_ghe").isNotNull() & (F.col("cd_ghe") != ""))
)

# --- Preserva originais antes dos joins sobrescreverem ---
df = df.withColumn("COD_LOCAL_SSO_ORIG",    F.col("cod_local_sso"))
df = df.withColumn("COD_LOCAL_FISICO_ORIG", F.col("cod_local_fisico"))

# --- DESC_STATUS_MATRIZ ---
df = df.withColumn(
    "DESC_STATUS_MATRIZ",
    F.when(F.col("status") == "A", "APROVADA")
    .when(F.col("status") == "E", "EXCLUIDA")
    .when(F.col("status") == "I", "APROVADA")
    .when(F.col("status") == "P", "PENDENTE")
    .when(F.col("status") == "R", "REPROVADA")
    .otherwise("")
)

print(f"Registros após filtros iniciais: {df.count()}")

# =============================================================================
# Carrega tabelas DE_PARA
# =============================================================================

df_local_t  = read_excel(DE_PARA_LOCAL_FISICO_T_PATH, DE_PARA_LOCAL_T_SHEET)
df_local_sso = read_excel(LOCAL_SSO_DE_PARA_PATH, LOCAL_SSO_DE_PARA_SHEET)
df_arvore_ec = read_excel(ARVORE_EC_PATH, ARVORE_EC_SHEET)

# Garante coluna DESCR_1 (última coluna pode ter nome variável)
last_col = df_local_t.columns[-1]
if last_col != "DESCR_1":
    df_local_t = df_local_t.withColumnRenamed(last_col, "DESCR_1")

# =============================================================================
# Join 1: DE_PARA_Local_Fisico_T
# Chave  : cod_local_fisico = LOCAL-T
# Gera   : COD_LOCAL_FISICO, DESC_LOCAL_FISICO
# Preserva (rastreabilidade): LOCAL_NAO_T, DESCR_1
# =============================================================================

df = df.join(
    F.broadcast(
        df_local_t.select(
            F.col("`LOCAL-T`").alias("_jlft_local_t"),
            F.col("`LOCAL NÃO-T`").alias("_jlft_local_nao_t"),
            F.col("DESCR_1").alias("_jlft_descr_1"),
        )
    ),
    df["cod_local_fisico"] == F.col("_jlft_local_t"),
    "left"
).drop("_jlft_local_t")

df = (
    df
    .withColumn("LOCAL_NAO_T", F.col("_jlft_local_nao_t"))
    .withColumn("DESCR_1",     F.col("_jlft_descr_1"))
    .drop("_jlft_local_nao_t", "_jlft_descr_1")
    .withColumn(
        "COD_LOCAL_FISICO",
        F.when(
            F.col("LOCAL_NAO_T").isNull() | (F.col("LOCAL_NAO_T") == ""),
            F.col("cod_local_fisico")
        ).otherwise(F.col("LOCAL_NAO_T"))
    )
    .withColumn(
        "DESC_LOCAL_FISICO",
        F.when(
            F.col("DESCR_1").isNull() | (F.col("DESCR_1") == ""),
            F.col("ds_local_fisico")
        ).otherwise(F.col("DESCR_1"))
    )
)

# =============================================================================
# Join 2: Local SSO_ DE X PARA
# Chave  : cod_empresa + cd_estabelecimento + cod_local_sso + COD_LOCAL_FISICO
# Gera   : COD_LOCAL_SSO, DESC_LOCAL_SSO
# Preserva (rastreabilidade): SSO_CD_UNIDADE_PARA, SSO_DS_UNIDADE_NEW
# =============================================================================

df = df.join(
    F.broadcast(
        df_local_sso.select(
            F.col("CD_EMPRESA").alias("_jlss_empresa"),
            F.col("CD_ESTABELECIMENTO").alias("_jlss_estab"),
            F.col("`CD_UNIDADE(DE)`").alias("_jlss_unidade_de"),
            F.col("CD_LOCAL_FISICO").alias("_jlss_local_fisico"),
            F.col("`CD_UNIDADE (PARA)`").alias("SSO_CD_UNIDADE_PARA"),
            F.col("DS_UNIDADE_NEW").alias("SSO_DS_UNIDADE_NEW"),
        )
    ),
    (df["cod_empresa"]        == F.col("_jlss_empresa"))      &
    (df["cd_estabelecimento"] == F.col("_jlss_estab"))        &
    (df["cod_local_sso"]      == F.col("_jlss_unidade_de"))   &
    (df["COD_LOCAL_FISICO"]   == F.col("_jlss_local_fisico")),
    "left"
).drop("_jlss_empresa", "_jlss_estab", "_jlss_unidade_de", "_jlss_local_fisico")

df = (
    df
    .withColumn(
        "COD_LOCAL_SSO",
        F.when(
            F.col("SSO_CD_UNIDADE_PARA").isNull() | (F.col("SSO_CD_UNIDADE_PARA") == ""),
            F.col("cod_local_sso")
        ).otherwise(F.col("SSO_CD_UNIDADE_PARA"))
    )
    .withColumn(
        "DESC_LOCAL_SSO",
        F.when(
            F.col("SSO_DS_UNIDADE_NEW").isNull() | (F.col("SSO_DS_UNIDADE_NEW") == ""),
            F.col("ds_local_sso")
        ).otherwise(F.col("SSO_DS_UNIDADE_NEW"))
    )
)

# =============================================================================
# Gerar COD_GHE e DESC_GHE
# =============================================================================

# Remove aspas duplas de id_matriz e cd_ghe
df = df.withColumn("id_matriz", F.regexp_replace(F.col("id_matriz"), '"', ""))
df = df.withColumn("cd_ghe", F.regexp_replace(F.col("cd_ghe"), '"', ""))

df = df.withColumn(
    "COD_GHE",
    F.when(
        F.col("cd_ghe") == "A000000",
        F.concat(F.col("COD_LOCAL_FISICO"), F.lit("_"), F.col("DESC_STATUS_MATRIZ"))
    ).otherwise(F.col("cd_ghe"))
).withColumn("COD_GHE", F.regexp_replace(F.col("COD_GHE"), '"', ""))

df = df.withColumn(
    "DESC_GHE",
    F.when(
        F.col("cd_ghe") == "A000000",
        F.concat(F.col("COD_LOCAL_FISICO"), F.lit("_DUMMY_"), F.col("DESC_STATUS_MATRIZ"))
    ).when(
        (F.col("cd_ghe") != "A000000") & (F.col("ds_ghe") == "."),
        F.concat(F.col("cd_ghe"), F.lit(" - ."))
    ).otherwise(F.col("ds_ghe"))
)

df = df.dropDuplicates()

# ID_EXT_AGRUP_VALE_PRIMARIO = COD_GHE & "_" & COD_LOCAL_SSO
def normalize_key(col_expr):
    return F.trim(F.regexp_replace(col_expr, r"[\t ]+", " "))

df = df.withColumn(
    "ID_EXT_AGRUP_VALE_PRIMARIO",
    F.concat(
        F.trim(F.regexp_replace(F.col("COD_GHE"),      r"\t", "")),
        F.lit("_"),
        F.trim(F.regexp_replace(F.col("COD_LOCAL_SSO"), r"\t", ""))
    )
)

# =============================================================================
# Join 3: Arvore_Localizacao_EC
# Chave  : cd_estabelecimento + COD_LOCAL_SSO + COD_LOCAL_FISICO
#          = Estabelecimento Peoplesoft + Local SSO SDWEB + LOCAL PEOPLESOFT
# Gera   : COD_LOCAL_FISICO_EC, COD_LOCAL_SSO_EC
# =============================================================================

df = df.join(
    F.broadcast(
        df_arvore_ec.select(
            F.col("`Estabelecimento Peoplesoft`").alias("_jec_estab"),
            F.col("`Local SSO SDWEB`").alias("_jec_sso_sdweb"),
            F.col("`LOCAL PEOPLESOFT`").alias("_jec_local_ps"),
            F.col("`Código`").alias("COD_LOCAL_FISICO_EC"),
            F.col("`Local SSO (Código)`").alias("COD_LOCAL_SSO_EC"),
        )
    ),
    (df["cd_estabelecimento"] == F.col("_jec_estab"))     &
    (df["COD_LOCAL_SSO"]      == F.col("_jec_sso_sdweb")) &
    (df["COD_LOCAL_FISICO"]   == F.col("_jec_local_ps")),
    "left"
).drop("_jec_estab", "_jec_sso_sdweb", "_jec_local_ps")

df = df.dropDuplicates()

# Replace '|' → '/' em DESC_GHE
df = df.withColumn("DESC_GHE", F.regexp_replace(F.col("DESC_GHE"), r"\|", "/"))

# Trim final em todas as colunas
for c in df.columns:
    df = df.withColumn(c, F.trim(F.col(f"`{c}`")))

print(f"DATA BASE GHE FULL — Registros finais: {df.count()}")
print(f"Colunas: {df.columns}")

display(df)

# COMMAND ----------

save_table(df, BRONZE_GHE)