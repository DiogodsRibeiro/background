# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Localização Agrupador/utils/utils"
# MAGIC

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

# GHP (arquivo principal)
df_ghp = read_excel(GHP_INPUT_PATH, GHP_SHEET_NAME)
spark.sql(f"""TRUNCATE TABLE {BRONZE_GHP}""")
df_ghp_normalized = normalize_column_names(df_ghp)
df_ghp_normalized.write.insertInto(BRONZE_GHP)
print("Bronze GHP finalizado.")