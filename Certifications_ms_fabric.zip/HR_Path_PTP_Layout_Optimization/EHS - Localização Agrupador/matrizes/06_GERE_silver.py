# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Localização Agrupador/utils/utils"

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

df_gere_raw = spark.table(BRONZE_GERE)
df_local_t = spark.table(BRONZE_LOCAL_T_NAO_T)

# Arvore_Localizacao_EC — lido direto do Volume
df_arvore_ec = read_excel(ARVORE_EC_PATH, ARVORE_EC_SHEET)
df_arvore_ec = normalize_column_names(df_arvore_ec)
df_arvore_ec = trim_all_columns(df_arvore_ec)
# Remover aspas simples que o Excel injeta nos valores
for c in df_arvore_ec.columns:
    df_arvore_ec = df_arvore_ec.withColumn(c, F.regexp_replace(F.col(c), "^'|'$", ""))

# Local SSO_ DE X PARA — lido direto do Volume
df_local_sso_depara = read_excel(LOCAL_SSO_DE_PARA_PATH, LOCAL_SSO_DE_PARA_SHEET)
df_local_sso_depara = normalize_column_names(df_local_sso_depara)
df_local_sso_depara = trim_all_columns(df_local_sso_depara)

# COMMAND ----------

# ── 2. Preparar GERE base ────────────────────────────────────────────────────

df = trim_all_columns(df_gere_raw)

df = df.withColumn("cod__empresa", F.lpad(F.trim(F.col("cod__empresa")), 5, "0"))

df = df.dropDuplicates()

print(f"GERE base (dedup): {df.count():,}")

print(f"GERE base (dedup): {df.count():,}")

# ── 3. Join com DE_PARA_Local_Fisico_T ────────────────────────────────────────

df_local_t_prep = df_local_t.select(
    F.col("local_t").alias("lt_local_t"),
    F.col("local_nao_t").alias("lt_local_nao_t"),
    F.col("unnamed_3").alias("lt_desc_local_nao_t")
).dropDuplicates(["lt_local_t"])

df = df.join(df_local_t_prep, df["cod__local_de_trabalho"] == F.col("lt_local_t"), how="left").drop("lt_local_t")

df = df.withColumn(
    "cd_local_fisico_nao_t",
    F.when(F.col("lt_local_nao_t").isNotNull() & (F.trim(F.col("lt_local_nao_t")) != ""), F.col("lt_local_nao_t"))
    .otherwise(F.col("cod__local_de_trabalho"))
).withColumn(
    "ds_local_fisico_nao_t",
    F.when(F.col("lt_desc_local_nao_t").isNotNull() & (F.trim(F.col("lt_desc_local_nao_t")) != ""), F.col("lt_desc_local_nao_t"))
    .otherwise(F.col("local_de_trabalho"))
)

# ── 4. Join com Local SSO_ DE X PARA ─────────────────────────────────────────

df_local_sso_prep = df_local_sso_depara.select(
    F.col("cd_empresa").alias("sso_cd_empresa"),
    F.col("cd_unidadede").alias("sso_cd_unidade_de"),
    F.col("cd_local_fisico").alias("sso_cd_local_fisico"),
    F.col("cd_unidade_para").alias("sso_cd_unidade_para"),
    F.col("ds_unidade_new").alias("sso_ds_unidade_new")
).dropDuplicates(["sso_cd_empresa", "sso_cd_unidade_de", "sso_cd_local_fisico"])

df = df.join(
    df_local_sso_prep,
    (df["cod__empresa"] == F.col("sso_cd_empresa")) &
    (df["cod__local_sso"] == F.col("sso_cd_unidade_de")) &
    (df["cd_local_fisico_nao_t"] == F.col("sso_cd_local_fisico")),
    how="left"
).drop("sso_cd_empresa", "sso_cd_unidade_de", "sso_cd_local_fisico")

df = df.withColumn(
    "cd_local_sso_final",
    F.when(F.col("sso_cd_unidade_para").isNotNull() & (F.trim(F.col("sso_cd_unidade_para")) != ""), F.col("sso_cd_unidade_para"))
    .otherwise(F.col("cod__local_sso"))
).withColumn(
    "ds_local_sso_final",
    F.when(F.col("sso_ds_unidade_new").isNotNull() & (F.trim(F.col("sso_ds_unidade_new")) != ""), F.col("sso_ds_unidade_new"))
    .otherwise(F.col("local_sso"))
)

# ── 5. Join com Arvore_Localizacao_EC ─────────────────────────────────────────

df_arvore_prep = df_arvore_ec.select(
    F.col("empresa_peoplesoft").alias("arv_empresa_ps"),
    F.col("local_sso_sdweb").alias("arv_local_sso_sdweb"),
    F.col("local_peoplesoft").alias("arv_local_ps"),
    F.col("codigo").alias("local_fisico_ec"),
    F.col("local_sso_codigo").alias("local_sso_ec")
).dropDuplicates(["arv_empresa_ps", "arv_local_sso_sdweb", "arv_local_ps"])

df = df.join(
    df_arvore_prep,
    (df["cod__empresa"] == F.col("arv_empresa_ps")) &
    (df["cd_local_sso_final"] == F.col("arv_local_sso_sdweb")) &
    (df["cd_local_fisico_nao_t"] == F.col("arv_local_ps")),
    how="left"
).drop("arv_empresa_ps", "arv_local_sso_sdweb", "arv_local_ps")

df = df.withColumn(
    "id_externo",
    F.concat_ws("_", F.col("codigo_gere"), F.col("cd_local_sso_final"), F.col("cod__empresa"))
)

df = df.dropDuplicates()
print(f"Após joins: {df.count():,}")

# ── 6. Gerar Agrupador_GERE_Codificado internamente ──────────────────────────

from pyspark.sql.window import Window

df_para_codificar = df.filter(F.col("local_sso_ec").isNotNull())

df_cod = df_para_codificar.select(
    "codigo_gere", "gere", "cd_local_sso_final", "id_externo"
).dropDuplicates()

df_cod = df_cod.withColumn("gere_60_upper", F.upper(F.substring(F.concat(F.lit("GERE_"), F.col("gere")), 1, 56)))
df_cod = df_cod.withColumn("gere_40_upper", F.upper(F.substring(F.concat(F.lit("GEREQL_"), F.col("gere")), 1, 36)))

w_60 = Window.partitionBy("gere_60_upper").orderBy("id_externo", "gere")
w_40 = Window.partitionBy("gere_40_upper").orderBy("id_externo", "gere")
w_id = Window.partitionBy("codigo_gere").orderBy("id_externo", "gere")

df_cod = df_cod.withColumn("idx_60", F.row_number().over(w_60) - 1)
df_cod = df_cod.withColumn("idx_40", F.row_number().over(w_40) - 1)
df_cod = df_cod.withColumn("idx_id", F.row_number().over(w_id) - 1)

df_cod = df_cod.withColumn(
    "agrupador_60_caracteres",
    F.when(F.col("idx_60") > 0,
        F.concat(F.substring(F.concat(F.lit("GERE_"), F.col("gere")), 1, 56), F.lit(" "), F.col("idx_60").cast("string"))
    ).otherwise(F.substring(F.concat(F.lit("GERE_"), F.col("gere")), 1, 56))
)

df_cod = df_cod.withColumn(
    "agrupador_quali_40_caracteres",
    F.when(F.col("idx_40") > 0,
        F.concat(F.substring(F.concat(F.lit("GEREQL_"), F.col("gere")), 1, 36), F.lit(" "), F.col("idx_40").cast("string"))
    ).otherwise(F.substring(F.concat(F.lit("GEREQL_"), F.col("gere")), 1, 36))
)

df_cod = df_cod.withColumn(
    "id_externo_agrupador_vale",
    F.when(F.col("idx_id") > 0,
        F.concat(F.lit("GERE_"), F.col("codigo_gere"), F.lit("_"), F.lpad(F.col("idx_id").cast("string"), 3, "0"))
    ).otherwise(F.concat(F.lit("GERE_"), F.col("codigo_gere")))
)

df_codificado = df_cod.select(
    F.col("id_externo").alias("cod_id_externo"),
    F.col("gere").alias("cod_gere"),
    "agrupador_60_caracteres",
    "agrupador_quali_40_caracteres",
    "id_externo_agrupador_vale"
).dropDuplicates(["cod_id_externo", "cod_gere"])

print(f"Codificado gerado: {df_codificado.count():,}")

# ── 7. Join com Codificado gerado ────────────────────────────────────────────

df = df.join(
    df_codificado,
    (df["id_externo"] == F.col("cod_id_externo")) &
    (df["gere"] == F.col("cod_gere")),
    how="left"
).drop("cod_id_externo", "cod_gere")

# ── 8. Filtrar registros válidos ──────────────────────────────────────────────

df = df.filter(
    F.col("local_sso_ec").isNotNull() & (F.trim(F.col("local_sso_ec")) != "")
)
df = df.dropDuplicates()
print(f"Após filtro LOCAL SSO EC: {df.count():,}")

# ── 9. Formata saída ─────────────────────────────────────────────────────────

df_formata_agrupadores = df.select(
    F.lit("").alias("ID Localização do Tipo Físico"),
    F.lit("").alias("ID da Atividade (Agrupador)"),
    F.col("local_fisico_ec").alias("ID Externo Localização VALE"),
    F.col("id_externo_agrupador_vale").alias("ID Externo (Agrupador) VALE"),
    F.lit("").alias("DELIMITADOR COLUNA"),
    F.col("id_matriz").alias("ID Matriz"),
    F.col("cod__empresa").alias("Cód. Empresa"),
    F.col("empresa").alias("Empresa"),
    F.col("cod__local_sso").alias("Cód. Local SSO"),
    F.col("local_sso").alias("Local SSO"),
    F.col("sso_cd_unidade_para").alias("Local SSO_ DE X PARA.CD_UNIDADE (PARA)"),
    F.col("sso_ds_unidade_new").alias("Local SSO_ DE X PARA.DS_UNIDADE_NEW"),
    F.col("cd_local_sso_final").alias("CD LOCAL SSO"),
    F.col("ds_local_sso_final").alias("DS LOCAL SSO"),
    F.col("matricula").alias("Matricula"),
    F.col("nome").alias("Nome"),
    F.col("cod__cargo").alias("Cód. Cargo"),
    F.col("cargo").alias("Cargo"),
    F.col("cod__funcao").alias("Cód. Função"),
    F.col("funcao").alias("Função"),
    F.col("cod__local_de_trabalho").alias("Cód. Local de Trabalho"),
    F.col("local_de_trabalho").alias("Local de Trabalho"),
    F.col("lt_local_nao_t").alias("DE_PARA_Local_Fisico_T.LOCAL NÃO-T"),
    F.col("lt_desc_local_nao_t").alias("DE_PARA_Local_Fisico_T.DESCR_1"),
    F.col("cd_local_fisico_nao_t").alias("CD LOCAL FISICO NAO T"),
    F.col("ds_local_fisico_nao_t").alias("DS LOCAL FISICO NAO T"),
    F.col("turno").alias("Turno"),
    F.col("codigo_ghe_sdweb").alias("Código GHE (SDWEB)"),
    F.col("ghe_sdweb").alias("GHE (SDWEB)"),
    F.col("codigo_gere").alias("Código GERE"),
    F.col("gere").alias("GERE"),
    F.col("fator_de_risco").alias("Fator de Risco"),
    F.col("fator_de_risco_para").alias("FATOR DE RISCO: PARA"),
    F.col("exigencias_ergonomicas").alias("Exigências Ergonômicas"),
    F.col("exigencias_ergonomicas_para").alias("Exigências Ergonômicas: PARA"),
    F.col("exigencia_de_tempo").alias("Exigência de tempo"),
    F.col("exgencia_de_intensidade").alias("Exgência de Intensidade"),
    F.col("severidade").alias("Severidade"),
    F.col("categoria_risco").alias("Categoria Risco"),
    F.col("natureza_atividade").alias("Natureza Atividade"),
    F.col("perfil_do_gere").alias("Perfil do GERE")
    # F.col("agrupador_60_caracteres").alias("Agrupador 60 Caracteres"),
    # F.col("local_fisico_ec").alias("LOCAL FISICO EC"),
    # F.col("local_sso_ec").alias("LOCAL SSO EC"),
    # F.col("id_externo").alias("ID EXTERNO")
).dropDuplicates()


# ── 10. Layout SAP final + salvar ────────────────────────────────────────────

df_final = df_formata_agrupadores.select(
    F.col("ID Localização do Tipo Físico").alias("ID_Localizacao_Tipo_Fisico"),
    F.col("ID da Atividade (Agrupador)").alias("ID_Atividade_Agrupador"),
    F.col("ID Externo Localização VALE").alias("ID_Externo_Localizacao_VALE"),
    F.col("ID Externo (Agrupador) VALE").alias("ID_Externo_Agrupador_VALE"),
    F.lit("GERE").alias("Tipo_Fonte")
).dropDuplicates()

# print(f"Layout SAP final: {df_final.count():,}")

# spark.sql(f"TRUNCATE TABLE {SILVER_GERE}")
# df_final_normalized = normalize_column_names(df_final)
# df_final_normalized.write.insertInto(SILVER_GERE)
print("Silver GERE salva!")

# COMMAND ----------

export_df_to_csv_excel(df_formata_agrupadores, '/Volumes/humanresources_insight/acqu_pcehslocalagrupador/acqu_pcehslocalagrupador/localizacao_agrupador/output/', 'Formata_Localizacao_Agrupador_GERE')
