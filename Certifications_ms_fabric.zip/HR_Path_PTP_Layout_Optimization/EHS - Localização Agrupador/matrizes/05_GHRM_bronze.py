# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Localização Agrupador/utils/utils"
# MAGIC

# COMMAND ----------

# ── 1. Arvore_Localizacao_EC ──────────────────────────────────────────────────
df_arvore = read_excel(ARVORE_EC_PATH, ARVORE_EC_SHEET)
df_arvore = normalize_column_names(df_arvore)

print(f"[Arvore_Localizacao_EC] Registros: {df_arvore.count()} | Colunas: {df_arvore.columns}")
display(df_arvore)

# ── 2. Agrupador_GHRM_Codificado ──────────────────────────────────────────────
df_agrupador = read_excel(AGRUPADOR_GHRM_CODIFICADO_PATH, AGRUPADOR_GHRM_CODIFICADO_SHEET)
df_agrupador = normalize_column_names(df_agrupador)

print(f"[Agrupador_GHRM_Codificado] Registros: {df_agrupador.count()} | Colunas: {df_agrupador.columns}")
display(df_agrupador)