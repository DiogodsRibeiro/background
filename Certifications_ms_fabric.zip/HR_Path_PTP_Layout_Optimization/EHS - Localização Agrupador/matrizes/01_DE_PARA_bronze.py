# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Localização Agrupador/utils/utils"
# MAGIC

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

# # GERE_SANEADO
# df_gere_saneado = read_excel(GERE_SANEADO_PATH, GERE_SANEADO_SHEET)
# spark.sql(f"""TRUNCATE TABLE {BRONZE_GERE_SANEADO}""")
# df_gere_saneado_normalized = normalize_column_names(df_gere_saneado)
# df_gere_saneado_normalized.write.insertInto(BRONZE_GERE_SANEADO)

# COMMAND ----------

# # GERE_CODIFICADO
# df_gere_codificado = read_excel(GERE_CODIFICADO_PATH, GERE_CODIFICADO_SHEET)
# # spark.sql(f"""TRUNCATE TABLE {BRONZE_GERE_CODIFICADO}""")
# df_gere_codificado_normalized = normalize_column_names(df_gere_codificado)
# # df_gere_codificado_normalized.write.insertInto(BRONZE_GERE_CODIFICADO)
# (
#         df_gere_codificado_normalized.write
#         .format("delta")
#         .mode("overwrite")
#         .option("overwriteSchema", "true")
#         .saveAsTable(BRONZE_GERE_CODIFICADO)
# )

# COMMAND ----------

# GHE_CODIFICADO (COM TRIM)
df_ghe_codificado = read_excel(GHE_CODIFICADO_PATH, GHE_CODIFICADO_SHEET)
df_ghe_codificado = trim_columns(df_ghe_codificado, "CD_GHE", "DS_GHE")
# spark.sql(f"""TRUNCATE TABLE {BRONZE_GHE_CODIFICADO}""")
df_ghe_codificado_normalized = normalize_column_names(df_ghe_codificado)
# df_ghe_codificado_normalized.write.insertInto(BRONZE_GHE_CODIFICADO)
(
        df_ghe_codificado_normalized.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(BRONZE_GHE_CODIFICADO)
)

# COMMAND ----------

# GHRM_CODIFICADO
df_ghrm_codificado = read_excel(GHRM_CODIFICADO_PATH, GHRM_CODIFICADO_SHEET)
spark.sql(f"""TRUNCATE TABLE {BRONZE_GHRM_CODIFICADO}""")
df_ghrm_codificado_normalized = normalize_column_names(df_ghrm_codificado)
df_ghrm_codificado_normalized.write.insertInto(BRONZE_GHRM_CODIFICADO)

# COMMAND ----------

# GHP_CODIFICADO
df_ghp_codificado = read_excel(GHP_CODIFICADO_PATH, GHP_CODIFICADO_SHEET)
spark.sql(f"""TRUNCATE TABLE {BRONZE_GHP_CODIFICADO}""")
df_ghp_codificado_normalized = normalize_column_names(df_ghp_codificado)
df_ghp_codificado_normalized.write.insertInto(BRONZE_GHP_CODIFICADO)

# COMMAND ----------

# LOCAL_T_NAO_T
df_local_t = read_excel(LOCAL_T_NAO_T_PATH, LOCAL_T_SHEET)
spark.sql(f"""TRUNCATE TABLE {BRONZE_LOCAL_T_NAO_T}""")
df_local_t_normalized = normalize_column_names(df_local_t)
df_local_t_normalized.write.insertInto(BRONZE_LOCAL_T_NAO_T)

# COMMAND ----------

# LOCAL_FISICO_EC (COM TRIM)
df_local_ec = read_excel(LOCAL_FISICO_DE_PARA_PATH, LOCAL_FISICO_EC_SHEET)
df_local_ec = trim_columns(df_local_ec, "LOCAL PEOPLESOFT")
spark.sql(f"""TRUNCATE TABLE {BRONZE_LOCAL_FISICO_EC}""")
df_local_ec_normalized = normalize_column_names(df_local_ec)
df_local_ec_normalized.write.insertInto(BRONZE_LOCAL_FISICO_EC)

# COMMAND ----------

# GHE (arquivo principal)
df_ghe = read_excel(GHE_INPUT_PATH, GHE_SHEET_NAME)
# spark.sql(f"""TRUNCATE TABLE {BRONZE_GHE}""")
df_ghe_normalized = normalize_column_names(df_ghe)
# df_ghe_normalized.write.insertInto(BRONZE_GHE)

(
        df_ghe_normalized.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(BRONZE_GHE)
)

# COMMAND ----------

# GHRM (arquivo principal)
df_ghrm = read_excel(GHRM_INPUT_PATH, GHRM_SHEET_NAME)
spark.sql(f"""TRUNCATE TABLE {BRONZE_GHRM}""")
df_ghrm_normalized = normalize_column_names(df_ghrm)
df_ghrm_normalized.write.insertInto(BRONZE_GHRM)

# COMMAND ----------

# GHP (arquivo principal)
df_ghp = read_excel(GHP_INPUT_PATH, GHP_SHEET_NAME)
# spark.sql(f"""TRUNCATE TABLE {BRONZE_GHP}""")
df_ghp_normalized = normalize_column_names(df_ghp)
# df_ghp_normalized.write.insertInto(BRONZE_GHP)

(
        df_ghp_normalized.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(BRONZE_GHP)
)

print("Bronze DE-PARA finalizado.")