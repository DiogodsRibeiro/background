# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Localização Agrupador/matrizes/05_GHRM_bronze"

# COMMAND ----------

# ── 1. Dados_GHRM_FULL ────────────────────────────────────────────────────────
cols_drop = [
    "geozone", "pais_regiao", "pais_orig", "pais",
    "uf_orig", "uf", "cidade_orig", "cidade",
    "endereco", "cep", "email",
    "setid__peoplesoft", "descricao"
]
df = df_arvore.drop(*[c for c in cols_drop if c in df_arvore.columns])

df = (
    df
    .withColumnRenamed("empresa_peoplesoft_1",              "DS_EMPRESA")
    .withColumnRenamed("nome_local_sso_sdweb",              "DS_UNIDADE")
    .withColumnRenamed("nome_estabelecimento_peoplesoft",   "DS_ESTABELECIMENTO")
)

df = (
    df
    .withColumn("CODIGO_GHRM", F.concat_ws("_", F.trim(F.col("local_sso_sdweb")), F.trim(F.col("local_peoplesoft"))))
    .withColumn("DESC_GHRM_FULL", F.concat(F.lit("GHRM-"), F.trim(F.col("DS_UNIDADE")), F.lit(" "), F.trim(F.col("nome"))))
)

df = trim_all_columns(df)

str_cols = [f.name for f in df.schema.fields if str(f.dataType) == "StringType()"]
for c in str_cols:
    df = df.withColumn(c, F.trim(F.col(c)))

df = df.dropDuplicates()

# ── 2. Formata_Agrupador_GHRM ─────────────────────────────────────────────────
cols_drop_formata = ["empresa", "estabelecimento", "local_sso_codigo"]
df = df.drop(*[c for c in cols_drop_formata if c in df.columns])

df = (
    df
    .withColumn("ID_LOCALIZACAO_DO_TIPO_FISICO", F.lit(""))
    .withColumn("ID_DA_ATIVIDADE_AGRUPADOR",     F.lit(""))
    .withColumn("DELIMITADOR_COLUNA",             F.lit(""))
)

df_agrupador_j = df_agrupador \
    .select("codigo_ghrm", "desc_ghrm_full", "id_externo_agrupador_vale") \
    .withColumnRenamed("codigo_ghrm",              "_join_codigo_ghrm") \
    .withColumnRenamed("desc_ghrm_full",            "_join_desc_ghrm_full") \
    .withColumnRenamed("id_externo_agrupador_vale", "DEPARA_id_externo_agrupador_vale")

df.cache()
df = (
    df
    .join(
        F.broadcast(df_agrupador_j),
        (df["CODIGO_GHRM"]    == df_agrupador_j["_join_codigo_ghrm"]) &
        (df["DESC_GHRM_FULL"] == df_agrupador_j["_join_desc_ghrm_full"]),
        "left"
    )
    .drop("_join_codigo_ghrm", "_join_desc_ghrm_full")
)
df.unpersist()

df = df.withColumnRenamed("codigo", "ID_EXTERNO_LOCALIZACAO_VALE")

str_cols = [f.name for f in df.schema.fields if str(f.dataType) == "StringType()"]
for c in str_cols:
    df = df.withColumn(c, F.trim(F.col(c)))

df = df.dropDuplicates()

# Reordena e renomeia para o layout esperado
df = df.select(
    F.col("ID_LOCALIZACAO_DO_TIPO_FISICO").alias("ID Localização do Tipo Físico"),
    F.col("ID_DA_ATIVIDADE_AGRUPADOR").alias("ID da Atividade (Agrupador)"),
    F.col("ID_EXTERNO_LOCALIZACAO_VALE").alias("ID Externo Localização VALE"),
    F.col("DEPARA_id_externo_agrupador_vale").alias("ID Externo Agrupador VALE"),
    F.col("DELIMITADOR_COLUNA").alias("DELIMITADOR COLUNA"),
    F.col("empresa_peoplesoft").alias("Empresa Peoplesoft"),
    F.col("DS_EMPRESA"),
    F.col("estabelecimento_peoplesoft").alias("Estabelecimento Peoplesoft"),
    F.col("DS_ESTABELECIMENTO"),
    F.col("local_sso_sdweb").alias("Local SSO SDWEB"),
    F.col("DS_UNIDADE"),
    F.col("local_peoplesoft").alias("LOCAL PEOPLESOFT"),
    F.col("nome").alias("Nome"),
    F.col("status").alias("Status"),
    F.col("CODIGO_GHRM").alias("Codigo GHRM"),
    F.col("DESC_GHRM_FULL").alias("Desc GHRM Full"),
)

# ── 3. Arquivo_Layout_SAP ─────────────────────────────────────────────────────
df_final = df.select(
    F.col("ID Localização do Tipo Físico"),
    F.col("ID da Atividade (Agrupador)"),
    F.col("ID Externo Localização VALE"),
    F.col("ID Externo Agrupador VALE"),
)

df_final = null_to_empty(df_final, FINAL_COL_ORDER_GHRM)

duplicados = df_final.groupBy("ID Externo Localização VALE").count().filter(F.col("count") > 1)
if duplicados.count() > 0:
    print(f"⚠️  {duplicados.count()} IDs duplicados detectados!")
else:
    print("✅ Nenhum ID duplicado — integridade OK.")

print(f"Registros finais: {df_final.count()}")
# display(df_final)

# COMMAND ----------

export_df_to_csv_excel(df, '/Volumes/humanresources_insight/acqu_pcehslocalagrupador/acqu_pcehslocalagrupador/localizacao_agrupador/output/', 'Formata_Localizacao_Agrupador_GHRM')