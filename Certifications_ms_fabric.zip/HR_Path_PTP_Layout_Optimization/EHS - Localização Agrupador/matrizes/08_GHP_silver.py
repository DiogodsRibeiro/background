# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Localização Agrupador/utils/utils"
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

# Carregar tabelas Bronze
df_ghp_raw        = spark.table(BRONZE_GHP)
df_ghp_codificado = spark.table(BRONZE_GHP_CODIFICADO)

# DE_PARA_Local_Fisico_T — lido direto do Volume
df_local_t = read_excel(DE_PARA_LOCAL_FISICO_T_PATH, DE_PARA_LOCAL_T_SHEET)
df_local_t = normalize_column_names(df_local_t)
df_local_t = trim_all_columns(df_local_t)

# Arvore_Localizacao_EC — lido direto do Volume
df_arvore_ec = read_excel(ARVORE_EC_PATH, ARVORE_EC_SHEET)
df_arvore_ec = normalize_column_names(df_arvore_ec)
df_arvore_ec = trim_all_columns(df_arvore_ec)
for c in df_arvore_ec.columns:
    df_arvore_ec = df_arvore_ec.withColumn(c, F.regexp_replace(F.col(c), "^'|'$", ""))

# Local SSO_ DE X PARA — lido direto do Volume
df_local_sso_depara = read_excel(LOCAL_SSO_DE_PARA_PATH, LOCAL_SSO_DE_PARA_SHEET)
df_local_sso_depara = normalize_column_names(df_local_sso_depara)
df_local_sso_depara = trim_all_columns(df_local_sso_depara)

# COMMAND ----------

# ── 1. Preparar GHP base ──────────────────────────────────────────────────────
df = trim_all_columns(df_ghp_raw)

df = df.withColumn(
    "descricao_do_ghp_02",
    F.regexp_replace(F.col("descricao_do_ghp_02"), u"[\u00A0\\s]+$", "")
)

# Checar se o tamanho mudou
df.filter(
    F.col("descricao_do_ghp_02").contains("GHP004997_00001_SLS0000015")
).select(
    F.col("descricao_do_ghp_02"),
    F.length(F.col("descricao_do_ghp_02")).alias("len")
).show(1, truncate=False)

# ── 2. Join com DE_PARA_Local_Fisico_T ────────────────────────────────────────

df_local_t_prep = df_local_t.select(
    F.col("local_t").alias("lt_location"),
    F.col("local_nao_t").alias("lt_location_1"),
    F.col("descr_1").alias("lt_descr_2")
).dropDuplicates(["lt_location"])

df = df.join(df_local_t_prep, df["cod_local_fisico"] == F.col("lt_location"), how="left").drop("lt_location")

df = df.withColumn(
    "cd_local_fisico_nao_t",
    F.when(F.col("lt_location_1").isNotNull() & (F.trim(F.col("lt_location_1")) != ""), F.col("lt_location_1"))
    .otherwise(F.col("cod_local_fisico"))
).withColumn(
    "ds_local_fisico_nao_t",
    F.when(F.col("lt_descr_2").isNotNull() & (F.trim(F.col("lt_descr_2")) != ""), F.col("lt_descr_2"))
    .otherwise(F.col("des_local_fisico"))
)

# ── 3. Join com Local SSO_ DE X PARA ─────────────────────────────────────────

df_local_sso_prep = df_local_sso_depara.select(
    F.col("cd_empresa").alias("sso_cd_empresa"),
    F.col("cd_estabelecimento").alias("sso_cd_estabelecimento"),
    F.col("cd_unidadede").alias("sso_cd_unidade_de"),
    F.col("cd_local_fisico").alias("sso_cd_local_fisico"),
    F.col("cd_unidade_para").alias("sso_cd_unidade_para"),
    F.col("ds_unidade_new").alias("sso_ds_unidade_new")
).dropDuplicates(["sso_cd_empresa", "sso_cd_estabelecimento", "sso_cd_unidade_de", "sso_cd_local_fisico"])

df = df.join(
    df_local_sso_prep,
    (df["cd_empresa"]            == F.col("sso_cd_empresa")) &
    (df["cod_estabelecimento"]   == F.col("sso_cd_estabelecimento")) &
    (df["cod_local_sso"]         == F.col("sso_cd_unidade_de")) &
    (df["cd_local_fisico_nao_t"] == F.col("sso_cd_local_fisico")),
    how="left"
).drop("sso_cd_empresa", "sso_cd_estabelecimento", "sso_cd_unidade_de", "sso_cd_local_fisico")

df = df.withColumn(
    "cd_local_sso_final",
    F.when(F.col("sso_cd_unidade_para").isNotNull() & (F.trim(F.col("sso_cd_unidade_para")) != ""), F.col("sso_cd_unidade_para"))
    .otherwise(F.col("cod_local_sso"))
).withColumn(
    "ds_local_sso_final",
    F.when(F.col("sso_ds_unidade_new").isNotNull() & (F.trim(F.col("sso_ds_unidade_new")) != ""), F.col("sso_ds_unidade_new"))
    .otherwise(F.col("des_local_sso"))
)

# ── 4. Join com Arvore_Localizacao_EC ─────────────────────────────────────────

df_arvore_prep = df_arvore_ec.select(
    F.col("empresa_peoplesoft").alias("arv_empresa_ps"),
    F.col("local_sso_sdweb").alias("arv_local_sso_sdweb"),
    F.col("local_peoplesoft").alias("arv_local_ps"),
    F.col("codigo").alias("ec_codigo"),
    F.col("local_sso_codigo").alias("ec_local_sso_codigo")
).dropDuplicates(["arv_empresa_ps", "arv_local_sso_sdweb", "arv_local_ps"])

df = df.join(
    df_arvore_prep,
    (df["cd_empresa"]            == F.col("arv_empresa_ps")) &
    (df["cd_local_sso_final"]    == F.col("arv_local_sso_sdweb")) &
    (df["cd_local_fisico_nao_t"] == F.col("arv_local_ps")),
    how="left"
).drop("arv_empresa_ps", "arv_local_sso_sdweb", "arv_local_ps")

df = df.dropDuplicates()

# ── 5. Join com GHP_Codificado ────────────────────────────────────────────────

df_ghp_codificado_prep = df_ghp_codificado.select(
    F.col("descricao_ghp_02").alias("ghp_cod_descricao"),
    F.col("agrupador_60_caracteres"),
    F.col("agrupador_externo_vale")
).dropDuplicates(["ghp_cod_descricao"])

df = df.join(
    df_ghp_codificado_prep,
    df["descricao_do_ghp_02"] == F.col("ghp_cod_descricao"),
    how="left"
).drop("ghp_cod_descricao")

# ── 6. Filtro e dedup final ───────────────────────────────────────────────────

df = df.filter(F.col("ec_codigo").isNotNull())
df = df.dropDuplicates()

print(f"Após filtro Arvore EC: {df.count():,}")

# ── 7. Formata saída + Layout SAP ─────────────────────────────────────────────

df_formata_agrupadores = df.select(
    F.lit("").alias("ID Localização do Tipo Físico"),
    F.lit("").alias("ID da Atividade (Agrupador)"),
    F.col("ec_codigo").alias("ID Externo Localização VALE"),
    F.col("agrupador_externo_vale").alias("ID Externo (Agrupador) VALE"),
    F.lit("").alias("DELIMITADOR COLUNA"),
    F.col("descricao_do_ghp_02").alias("DESCRICAO DO GHP 02"),
    F.col("cd_empresa").alias("CD_EMPRESA"),
    F.col("ds_empresa").alias("DS_EMPRESA"),
    F.col("matricula").alias("MATRICULA"),
    F.col("nome").alias("NOME"),
    F.col("dt_admissao").alias("DT_ADMISSAO"),
    F.col("dt_demissao").alias("DT_DEMISSAO"),
    F.col("ds_situacao").alias("DS_SITUACAO"),
    F.col("cod_cargo").alias("COD_CARGO"),
    F.col("des_cargo").alias("DES_CARGO"),
    F.col("cod_carga_hor").alias("COD_CARGA_HOR"),
    F.col("cod_turno").alias("COD_TURNO"),
    F.col("cod_funcao").alias("COD_FUNCAO"),
    F.col("des_funcao").alias("DES_FUNCAO"),
    F.col("cod_estabelecimento").alias("COD_ESTABELECIMENTO"),
    F.col("ds_estabelecimento").alias("DS_ESTABELECIMENTO"),
    F.col("cd_local_sso_final").alias("CD LOCAL SSO"),
    F.col("ds_local_sso_final").alias("DS LOCAL SSO"),
    F.col("cd_local_fisico_nao_t").alias("CD LOCAL FISICO"),
    F.col("ds_local_fisico_nao_t").alias("DS LOCAL FISICO"),
    F.col("id_matriz_rac_peric_ghrm").alias("ID_MATRIZ_RAC_PERIC_GHRM"),
    F.col("periculoso").alias("PERICULOSO"),
    F.col("percent_periculosidade").alias("PERCENT_PERICULOSIDADE"),
    F.col("tipo_periculosidade").alias("TIPO_PERICULOSIDADE"),
    F.col("nu_matriz_ghe").alias("NU_MATRIZ_GHE"),
    F.col("cd_ghe").alias("CD_GHE"),
    F.col("ds_ghe").alias("DS_GHE")
).dropDuplicates()

df_final = df_formata_agrupadores.select(
    F.col("ID Localização do Tipo Físico").alias("ID_Localizacao_Tipo_Fisico"),
    F.col("ID da Atividade (Agrupador)").alias("ID_Atividade_Agrupador"),
    F.col("ID Externo Localização VALE").alias("ID_Externo_Localizacao_VALE"),
    F.col("ID Externo (Agrupador) VALE").alias("ID_Externo_Agrupador_VALE"),
    F.lit("GHP").alias("Tipo_Fonte")
).dropDuplicates()

# spark.sql(f"TRUNCATE TABLE {SILVER_GHP}")
df_final_normalized = normalize_column_names(df_final)
df_final_normalized.write.insertInto(SILVER_GHP)
print(f"Silver GHP salva: {df_final.count():,} registros.")

# COMMAND ----------

export_df_to_csv_excel(
    df_formata_agrupadores,
    '/Volumes/humanresources_insight/acqu_pcehslocalagrupador/acqu_pcehslocalagrupador/localizacao_agrupador/output/',
    'Formata_Localizacao_Agrupador_GHP'
)

# COMMAND ----------

# from pyspark.sql.functions import md5, concat_ws, col, coalesce, lit
# from pyspark.sql.types import StringType
# from pyspark.sql import functions as F
# import pandas as pd
# import unicodedata
# import matplotlib.pyplot as plt

# VAL_BASE = "/Volumes/humanresources_insight/acqu_pcehslocalagrupador/acqu_pcehslocalagrupador/localizacao_agrupador/validation_files"

# def normalize_pandas_columns(pdf):
#     new_cols = []
#     for column in pdf.columns:
#         new_column = unicodedata.normalize('NFKD', column).encode('ASCII', 'ignore').decode('ASCII')
#         new_column = (new_column
#             .replace(" ", "_").replace("/", "_").replace("(", "")
#             .replace(".", "_").replace(")", "").replace(":", "").replace("-", "_")
#             .lower()
#         )
#         new_cols.append(new_column)
#     pdf.columns = new_cols
#     return pdf

# def plot_match(title, total, com_match, sem_match, pct_com, pct_sem):
#     plt.figure(figsize=(10, 6))
#     barras = plt.bar(['Sem Match', 'Com Match'], [sem_match, com_match],
#                      color=['#e74c3c', '#2ecc71'], edgecolor='black', linewidth=1.2)
#     for barra, valor, pct in zip(barras, [sem_match, com_match], [pct_sem, pct_com]):
#         plt.text(barra.get_x() + barra.get_width()/2, barra.get_height()/2,
#                  f'{valor:,}\n({pct:.1f}%)', ha='center', va='center',
#                  fontsize=12, fontweight='bold', color='white')
#     plt.ylabel('Quantidade', fontsize=12)
#     plt.title(title, fontsize=14, fontweight='bold')
#     plt.grid(axis='y', alpha=0.3, linestyle='--')
#     plt.tight_layout()
#     plt.show()
#     print(f"\n{'='*60}")
#     print(f"Total PQ (esperado):   {total:,}")
#     print(f"Com Match:             {com_match:,} ({pct_com:.2f}%)")
#     print(f"Sem Match:             {sem_match:,} ({pct_sem:.2f}%)")
#     print(f"{'='*60}\n")

# # ══════════════════════════════════════════════════════════════
# # VALIDAÇÃO 1 — Formata_Agrupador_GHP
# # ══════════════════════════════════════════════════════════════

# pdf_formata = pd.read_excel(
#     f"{VAL_BASE}/Template_Localizacao_Agrupadores-GHP-V11.xlsm",
#     sheet_name="Formata_Agrupador_GHP", dtype=str, engine="openpyxl"
# ).fillna("")
# pdf_formata.columns = [c.strip() for c in pdf_formata.columns]
# pdf_formata = normalize_pandas_columns(pdf_formata)
# for c in pdf_formata.columns:
#     pdf_formata[c] = pdf_formata[c].astype(str).str.strip()

# df_pq_formata = spark.createDataFrame(pdf_formata)
# COLS_HASH_FORMATA = [c for c in df_pq_formata.columns if c != "hash_key"]

# # Normaliza nomes do Silver
# pdf_cols = pd.DataFrame(columns=df_formata_agrupadores.columns)
# pdf_cols = normalize_pandas_columns(pdf_cols)
# df_silver_formata = df_formata_agrupadores
# for old, new in zip(df_formata_agrupadores.columns, pdf_cols.columns):
#     if old != new:
#         df_silver_formata = df_silver_formata.withColumnRenamed(old, new)

# cols_em_comum_formata = [c for c in COLS_HASH_FORMATA if c in df_silver_formata.columns and c != "hash_key"]

# # Normaliza null → vazio nos dois lados
# for c in cols_em_comum_formata:
#     df_pq_formata = df_pq_formata.withColumn(
#         c, F.regexp_replace(F.coalesce(F.col(c).cast(StringType()), F.lit("")), '""', '"')
#     )
#     df_silver_formata = df_silver_formata.withColumn(
#         c, F.regexp_replace(F.coalesce(F.col(c).cast(StringType()), F.lit("")), '""', '"')
#     )

# # Normaliza datas e percent antes do hash
# for c in ["dt_admissao", "dt_demissao"]:
#     df_pq_formata = df_pq_formata.withColumn(
#         c, F.date_format(F.to_date(F.col(c), "dd/MM/yyyy"), "dd/MM/yyyy")
#     )
#     df_silver_formata = df_silver_formata.withColumn(
#         c, F.date_format(F.to_date(F.col(c)), "dd/MM/yyyy")
#     )

# df_pq_formata = df_pq_formata.withColumn(
#     "percent_periculosidade",
#     F.date_format(F.to_date(F.col("percent_periculosidade"), "dd/MM/yyyy"), "dd/MM/yyyy")
# )
# df_silver_formata = df_silver_formata.withColumn(
#     "percent_periculosidade",
#     F.date_format(F.to_date(F.col("percent_periculosidade")), "dd/MM/yyyy")
# )

# # Hash
# df_pq_formata = df_pq_formata.withColumn(
#     "hash_key",
#     md5(concat_ws("||", *[col(c) for c in cols_em_comum_formata]))
# )
# df_silver_formata = df_silver_formata.withColumn(
#     "hash_key",
#     md5(concat_ws("||", *[col(c) for c in cols_em_comum_formata]))
# )

# total     = df_pq_formata.count()
# sem_match = df_pq_formata.join(df_silver_formata.select("hash_key"), "hash_key", "left_anti").count()
# com_match = total - sem_match
# pct_sem   = (sem_match / total * 100) if total > 0 else 0
# pct_com   = (com_match / total * 100) if total > 0 else 0

# plot_match("Análise de Match — GHP (Formata_Agrupador_GHP)", total, com_match, sem_match, pct_com, pct_sem)

# # ══════════════════════════════════════════════════════════════
# # VALIDAÇÃO 2 — Arquivo_Layout_SAP
# # ══════════════════════════════════════════════════════════════

# pdf_layout = pd.read_excel(
#     f"{VAL_BASE}/Template_Localizacao_Agrupadores-GHP-V11.xlsm",
#     sheet_name="Arquivo_Layout_SAP", dtype=str, engine="openpyxl"
# ).fillna("")
# pdf_layout.columns = [c.strip() for c in pdf_layout.columns]
# pdf_layout = normalize_pandas_columns(pdf_layout)
# for c in pdf_layout.columns:
#     pdf_layout[c] = pdf_layout[c].astype(str).str.strip()

# df_pq_layout = spark.createDataFrame(pdf_layout)
# COLS_HASH_LAYOUT = [c for c in df_pq_layout.columns if c != "hash_key"]

# # Normaliza nomes do df_final
# pdf_cols_f = pd.DataFrame(columns=df_final.columns)
# pdf_cols_f = normalize_pandas_columns(pdf_cols_f)
# df_silver_layout = df_final
# for old, new in zip(df_final.columns, pdf_cols_f.columns):
#     if old != new:
#         df_silver_layout = df_silver_layout.withColumnRenamed(old, new)

# cols_em_comum_layout = [c for c in COLS_HASH_LAYOUT if c in df_silver_layout.columns and c != "hash_key"]

# # Normaliza null → vazio nos dois lados
# for c in cols_em_comum_layout:
#     df_pq_layout = df_pq_layout.withColumn(
#         c, F.regexp_replace(F.coalesce(F.col(c).cast(StringType()), F.lit("")), '""', '"')
#     )
#     df_silver_layout = df_silver_layout.withColumn(
#         c, F.regexp_replace(F.coalesce(F.col(c).cast(StringType()), F.lit("")), '""', '"')
#     )

# # Hash
# df_pq_layout = df_pq_layout.withColumn(
#     "hash_key",
#     md5(concat_ws("||", *[col(c) for c in cols_em_comum_layout]))
# )
# df_silver_layout = df_silver_layout.withColumn(
#     "hash_key",
#     md5(concat_ws("||", *[col(c) for c in cols_em_comum_layout]))
# )

# total_l     = df_pq_layout.count()
# sem_match_l = df_pq_layout.join(df_silver_layout.select("hash_key"), "hash_key", "left_anti").count()
# com_match_l = total_l - sem_match_l
# pct_sem_l   = (sem_match_l / total_l * 100) if total_l > 0 else 0
# pct_com_l   = (com_match_l / total_l * 100) if total_l > 0 else 0

# plot_match("Análise de Match — GHP (Arquivo_Layout_SAP)", total_l, com_match_l, sem_match_l, pct_com_l, pct_sem_l)