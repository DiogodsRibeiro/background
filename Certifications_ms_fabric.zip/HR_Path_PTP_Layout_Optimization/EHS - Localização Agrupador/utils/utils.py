# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Localização Agrupador/config/config"
# MAGIC

# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import StringType
import pandas as pd
import os

# COMMAND ----------

def prefix_df(df: DataFrame, prefix: str, join_col: str, join_alias: str) -> DataFrame:
    """
    Prefixa todas as colunas de um DataFrame exceto a coluna de join,
    que recebe um alias separado para uso na condição de JOIN.
    Evita colisão de nomes ao unir DataFrames com colunas homônimas.

    Args:
        df:         DataFrame a ser prefixado
        prefix:     prefixo a aplicar nas colunas (ex: 'DEPARA')
        join_col:   coluna que será usada como chave de join
        join_alias: alias temporário para a coluna de join (ex: '_join_agrupador')
    """
    renamed = []
    for col in df.columns:
        if col == join_col:
            renamed.append(F.col(col).alias(join_alias))
        else:
            renamed.append(F.col(col).alias(f"{prefix}_{col}"))
    return df.select(renamed)


def null_to_empty(df: DataFrame, cols: list) -> DataFrame:
    """
    Substitui NULL por string vazia nas colunas informadas.
    Deve ser chamada antes de exportar o arquivo final,
    garantindo que não haja NULL nas colunas de entrega.

    Args:
        df:   DataFrame Spark
        cols: lista de colunas a tratar (ex: FINAL_COL_ORDER_GHRM)
    """
    for col in cols:
        if col in df.columns:
            df = df.withColumn(col, F.coalesce(F.col(col), F.lit("")))
    return df

def read_csv_folder(folder_path: str, delimiter: str = ";", encoding: str = "utf-8") -> DataFrame:
    """
    Lê todos os arquivos CSV de uma pasta e retorna um DataFrame Spark unificado.
    Equivale ao Folder.Files + Transform File do Power Query.
    Preserva o nome do arquivo de origem na coluna 'Source.Name',
    necessário para o distinct por-arquivo feito no Silver (Dados_GHE).
    """
    all_dfs = []
    for fname in sorted(os.listdir(folder_path)):
        if fname.lower().endswith(".csv"):
            fpath = os.path.join(folder_path, fname)
            pdf = pd.read_csv(fpath, sep=delimiter, dtype=str, encoding=encoding)
            pdf.columns = [c.strip() for c in pdf.columns]
            pdf = pdf.fillna("")
            pdf.insert(0, "Source.Name", fname)
            all_dfs.append(pdf)
    if not all_dfs:
        raise ValueError(f"Nenhum CSV encontrado em {folder_path}")
    combined = pd.concat(all_dfs, ignore_index=True)
    return spark.createDataFrame(combined)

def read_excel(path: str, sheet_name: str) -> DataFrame:
    """
    Lê um arquivo Excel do Volume e retorna um DataFrame Spark.
    Todos os campos são lidos como string.
    """
    pdf = pd.read_excel(path, sheet_name=sheet_name, dtype=str, header=0)
    pdf.columns = [c.strip() for c in pdf.columns]
    return spark.createDataFrame(pdf.fillna(""))

def save_table(df: DataFrame, table: str) -> None:
    """Grava um DataFrame como tabela Delta com overwrite."""
    (
        df.write
        .format("delta")
        .mode("overwrite")
        .option("overwriteSchema", "true")
        .saveAsTable(table)
    )
    print(f"✅ Gravado: {table} ({df.count()} registros)")


def trim_columns(df: DataFrame, *cols: str) -> DataFrame:
    """Aplica trim em colunas específicas."""
    for col in cols:
        if col in df.columns:
            df = df.withColumn(col, F.trim(F.col(col)))
    return df


def add_custom_column(df: DataFrame, new_col: str, condition_col: str, fallback_col: str) -> DataFrame:
    """
    Adiciona coluna custom com lógica:
    - Se condition_col é null ou vazio → usa fallback_col
    - Caso contrário → usa condition_col
    """
    return df.withColumn(
        new_col,
        F.when(
            (F.col(condition_col).isNull()) | (F.length(F.col(condition_col)) == 0),
            F.col(fallback_col)
        ).otherwise(F.col(condition_col))
    )


def left_outer_join(df_left: DataFrame, df_right: DataFrame, left_keys: list, right_keys: list) -> DataFrame:
    """Realiza left outer join entre dois DataFrames."""
    join_condition = [df_left[lk] == df_right[rk] for lk, rk in zip(left_keys, right_keys)]
    return df_left.join(df_right, join_condition, "left")


def format_final_layout_sap(
    df: DataFrame,
    id_externo_loc_col: str,
    id_externo_agrup_col: str,
    tipo_fonte: str
) -> DataFrame:
    """
    Formata o DataFrame final para o layout SAP com as 5 colunas padronizadas.
    Remove nulos e duplicatas.
    """
    return (
        df
        .select(
            F.lit("").alias(COL_ID_LOC_FISICO),
            F.lit("").alias(COL_ID_ATIVIDADE),
            F.col(id_externo_loc_col).alias(COL_ID_EXTERNO_LOC),
            F.col(id_externo_agrup_col).alias(COL_ID_EXTERNO_AGRUP)
        )
        .withColumn(COL_TIPO_FONTE, F.lit(tipo_fonte))
        .filter(
            F.col(COL_ID_EXTERNO_LOC).isNotNull() & 
            (F.col(COL_ID_EXTERNO_LOC) != "") &
            F.col(COL_ID_EXTERNO_AGRUP).isNotNull() &
            (F.col(COL_ID_EXTERNO_AGRUP) != "")
        )
        .dropDuplicates([COL_ID_LOC_FISICO, COL_ID_ATIVIDADE, COL_ID_EXTERNO_LOC, COL_ID_EXTERNO_AGRUP])
        .orderBy(COL_ID_EXTERNO_LOC, COL_ID_EXTERNO_AGRUP)
    )

def normalize_column_names(df):
    """Remove caracteres inválidos dos nomes das colunas e converte para minúsculas"""
    import unicodedata
    for column in df.columns:

        new_column = unicodedata.normalize('NFKD', column).encode('ASCII', 'ignore').decode('ASCII')
        
        new_column = (new_column
            .replace(" ", "_")
            .replace("/", "_")
            .replace("(", "")
            .replace(".", "_")    
            .replace(")", "")
            .replace(":", "")
            .replace("-", "_")
            .lower() 
        )
        
        df = df.withColumnRenamed(column, new_column)
    return df


def export_df_to_csv_excel(df: DataFrame, volume_path: str, file_base: str) -> None:
    """
    Exporta um DataFrame para arquivos CSV e Excel em um volume.
    Args:
        df: DataFrame Spark a ser exportado
        volume_path: caminho do volume (ex: '/Volumes/meu_volume/pasta')
        file_base: nome base do arquivo (ex: 'export_agrupador')
    """
    import io
    import openpyxl
    # Remove barra final se houver e monta os caminhos manualmente
    base = volume_path.rstrip("/")
    final_csv   = f"{base}/{file_base}.csv"
    final_excel = f"{base}/{file_base}.xlsx"

    # Garante que o diretório existe
    dbutils.fs.mkdirs(base)

    # Converte Spark -> Pandas uma única vez
    pdf = df.toPandas()

    # --- CSV ---
    with open(final_csv, "w", encoding="utf-8-sig") as f:
        pdf.to_csv(f, index=False)
    print(f"CSV exportado: {final_csv}")

    # --- Excel ---
    buffer = io.BytesIO()
    pdf.to_excel(buffer, index=False, engine="openpyxl")
    buffer.seek(0)
    with open(final_excel, "wb") as f:
        f.write(buffer.read())
    print(f"Excel exportado: {final_excel}")


def trim_all_columns(df):
    for c in df.columns:
        df = df.withColumn(c, F.trim(F.regexp_replace(F.col(c), r"\t", "")))
    return df

print(" Utilitários carregados.")