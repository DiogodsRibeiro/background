# Databricks notebook source
# MAGIC %run "/Workspace/Insight/HumanResources/RH_PTP/HR_Path_PTP_Layout_Optimization/EHS - Localização Agrupador/utils/utils"

# COMMAND ----------

from pyspark.sql.functions import md5, concat_ws, col, coalesce, lit
import os
import requests
import pandas as pd
import unicodedata
import re
import matplotlib.pyplot as plt
from pyspark.sql import *
from pyspark.sql.types import *
import unicodedata
from pyspark.sql import functions as F


# COMMAND ----------

# MAGIC %pip install openpyxl

# COMMAND ----------

cols = ["id_localizacao_tipo_fisico", "id_atividade_agrupador", "id_externo_localizacao_vale", "id_externo_agrupador_vale"]

df_consolidado = (
    spark.table(SILVER_CONSOLIDADO).select(cols)
    .dropDuplicates(cols)
)

print(f"Total consolidado: {df_consolidado.count():,}")

cols_hash = [c for c in df_consolidado.columns if c != COL_TIPO_FONTE]

df_consolidado = df_consolidado.withColumn(
    "hash_key",
    md5(
        concat_ws(
            "||",
            *[coalesce(col(c).cast(StringType()), lit("")) for c in cols_hash]
        )
    )
)

# display(df_consolidado)

# print(f"Total consolidado: {df_consolidado.count():,}")
# df_consolidado.groupBy(COL_TIPO_FONTE).count().show()

# COMMAND ----------

VAL_BASE = "/Volumes/humanresources_insight/acqu_pcehslocalagrupador/acqu_pcehslocalagrupador/localizacao_agrupador/validation_files"

arquivos_excel = [
    f"{VAL_BASE}/Template_Localizacao_Agrupadores-GERE-V7.xlsm",
    f"{VAL_BASE}/Template_Localizacao_Agrupadores-GHE-V4.xlsm",
    f"{VAL_BASE}/Template_Localizacao_Agrupadores-GHP-V7.xlsm",
    f"{VAL_BASE}/Template_Localizacao_Agrupadores-GHRM-V6.xlsm",
]

import unicodedata

def normalize_pandas_columns(pdf):
    new_cols = []
    for column in pdf.columns:
        new_column = unicodedata.normalize('NFKD', column).encode('ASCII', 'ignore').decode('ASCII')
        new_column = (new_column
            .replace(" ", "_")
            .replace("/", "_")
            .replace("(", "")
            .replace(".", "_")
            .replace(")", "")
            .replace(":", "")
            .replace("-", "_")
            .lower()
        )
        new_cols.append(new_column)
    pdf.columns = new_cols
    return pdf

EXCEL_COL_ID_LOC_FISICO    = "id_localizacao_do_tipo_fisico"
EXCEL_COL_ID_ATIVIDADE     = "id_da_atividade_agrupador"
EXCEL_COL_ID_EXTERNO_LOC   = "id_externo_localizacao_vale"
EXCEL_COL_ID_EXTERNO_AGRUP = "id_externo_agrupador_vale"

rename_por_arquivo = {
    "Template_Localizacao_Agrupadores-GHRM-V6.xlsm": {
        "ec_codigo":                              "id_externo_localizacao_vale",
        "ghrm_codificado_agrupador_externo_vale": "id_externo_agrupador_vale"
    }
}

df_excel_consolidado = None

for path in arquivos_excel:
    nome_arquivo = path.split("/")[-1]

    pdf = pd.read_excel(path, sheet_name="Arquivo_Layout_SAP", dtype=str, engine="openpyxl").fillna("")
    pdf.columns = [c.strip() for c in pdf.columns]
    pdf = normalize_pandas_columns(pdf)
    for c in pdf.columns:
        pdf[c] = pdf[c].astype(str).str.strip()

    if nome_arquivo in rename_por_arquivo:
        pdf = pdf.rename(columns=rename_por_arquivo[nome_arquivo])

    df_tmp = spark.createDataFrame(pdf)
    df_tmp = df_tmp.withColumn("tipo_fonte_excel", F.lit(nome_arquivo))
    df_excel_consolidado = df_tmp if df_excel_consolidado is None else df_excel_consolidado.unionByName(df_tmp)

df_excel_consolidado = df_excel_consolidado.dropDuplicates([
    EXCEL_COL_ID_LOC_FISICO,
    EXCEL_COL_ID_ATIVIDADE,
    EXCEL_COL_ID_EXTERNO_LOC,
    EXCEL_COL_ID_EXTERNO_AGRUP
])

cols_hash_excel = [
    EXCEL_COL_ID_LOC_FISICO,
    EXCEL_COL_ID_ATIVIDADE,
    EXCEL_COL_ID_EXTERNO_LOC,
    EXCEL_COL_ID_EXTERNO_AGRUP
]

df_excel_consolidado = df_excel_consolidado.withColumn(
    "hash_key",
    md5(
        concat_ws(
            "||",
            *[coalesce(col(c).cast(StringType()), lit("")) for c in cols_hash_excel]
        )
    )
)

# Faltantes no notebook vs Excel
df_faltantes = df_excel_consolidado \
    .join(
        df_consolidado.select("hash_key"),
        "hash_key",
        "left_anti"
    )

# Group by com todos os arquivos, incluindo os com zero faltantes
df_todos = df_excel_consolidado.groupBy("tipo_fonte_excel").count().withColumnRenamed("count", "total_excel")

df_faltantes_por_fonte = df_faltantes.groupBy("tipo_fonte_excel").count().withColumnRenamed("count", "faltantes")

df_resumo = df_todos.join(df_faltantes_por_fonte, "tipo_fonte_excel", "left") \
    .fillna(0, subset=["faltantes"]) \
    .withColumn("presentes", F.col("total_excel") - F.col("faltantes")) \
    .orderBy("faltantes", ascending=False)

# print(f"Total Excel consolidado:    {df_excel_consolidado.count():,}")
# print(f"Total notebook consolidado: {df_consolidado.count():,}")
# print(f"Total faltantes:            {df_faltantes.count():,}")
# print()
# df_resumo.show(truncate=False)
# display(df_faltantes)

# COMMAND ----------

# MAGIC %md
# MAGIC ## VALIDAÇÃO

# COMMAND ----------

# MAGIC %md
# MAGIC ### 01 - Gráfico de Barra

# COMMAND ----------

# Total de registros únicos do Excel consolidado
total = df_excel_consolidado.count()

# Registros do Excel que NÃO existem no consolidado do notebook
sem_match = (
    df_excel_consolidado.alias("xl")
    .join(
        df_consolidado.select("hash_key").distinct().alias("nb"),
        on="hash_key",
        how="left_anti"
    )
    .count()
)

# Registros do Excel que existem no consolidado do notebook
com_match = total - sem_match

# Percentuais
pct_sem = (sem_match / total * 100) if total > 0 else 0
pct_com = (com_match / total * 100) if total > 0 else 0

# ============================================
# GRÁFICO GERAL
# ============================================
categorias = ['Sem Match', 'Com Match']
valores = [sem_match, com_match]
cores = ['#e74c3c', '#2ecc71']

plt.figure(figsize=(10, 6))
barras = plt.bar(categorias, valores, color=cores, edgecolor='black', linewidth=1.2)

for barra, valor, pct in zip(barras, valores, [pct_sem, pct_com]):
    altura = barra.get_height()
    plt.text(
        barra.get_x() + barra.get_width()/2,
        altura/2,
        f'{valor:,}\n({pct:.1f}%)',
        ha='center',
        va='center',
        fontsize=12,
        fontweight='bold',
        color='white'
    )

plt.ylabel('Quantidade', fontsize=12)
plt.title('Análise Geral de Matches (Excels Consolidados)', fontsize=14, fontweight='bold')
plt.grid(axis='y', alpha=0.3, linestyle='--')
plt.tight_layout()
plt.show()

# ============================================
# RESUMO
# ============================================
print(f"\n{'='*60}")
print("RESUMO GERAL - EXCELS CONSOLIDADOS")
print(f"{'='*60}")
print(f"Total de registros únicos no Excel consolidado: {total:,}")
print(f"Com Match: {com_match:,} ({pct_com:.2f}%)")
print(f"Sem Match: {sem_match:,} ({pct_sem:.2f}%)")
print(f"{'='*60}")

# COMMAND ----------

# MAGIC %md
# MAGIC ### 02 - tempo de execução

# COMMAND ----------

# # Configurações
# DATABRICKS_INSTANCE = "https://adb-1155906991732329.9.azuredatabricks.net"
# TOKEN = "dapi6886e3457cca7ea63ffc3c9ba1236940"
# JOB_ID = 342241574922024

# headers = {
#     "Authorization": f"Bearer {TOKEN}"
# }

# # 1. Buscar a última run do job
# runs_url = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/list"
# params = {
#     "job_id": JOB_ID,
#     "limit": 1,
#     "active_only": False
# }
# runs_resp = requests.get(runs_url, headers=headers, params=params)
# run_data = runs_resp.json()
# latest_run = run_data["runs"][0]
# run_id = latest_run["run_id"]

# # 2. Buscar detalhes da run (incluindo tasks)
# run_detail_url = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/get"
# run_detail_resp = requests.get(run_detail_url, headers=headers, params={"run_id": run_id})
# run_detail = run_detail_resp.json()

# # 3. Extrair duração de cada notebook (task)
# tasks = run_detail.get("tasks", [])
# task_data = []
# for t in tasks:
#     if t.get("not") or t.get("notebook_task"):
#         name = t.get("task_key", t.get("notebook_task", {}).get("notebook_path", ""))
#         duration = (t["end_time"] - t["start_time"]) / 1000 if t.get("end_time") and t.get("start_time") else 0
#         task_data.append({"notebook": name, "duration_sec": duration})

# df_tasks = pd.DataFrame(task_data)
# df_tasks = df_tasks.sort_values("duration_sec", ascending=False)

# # 4. Calcular tempo total em minutos considerando paralelismo em dois momentos
# parallel_notebooks_1 = [
#     #"01_DE_PARA_bronze",
#     "02_GERE_bronze",
#     "03_GHE_bronze",
#     "04_GHP_bronze",
#     "05_GHRM_bronze"
# ]

# parallel_notebooks_2 = [
#     "06_GERE_silver",
#     "07_GHE_silver",
#     "08_GHP_silver",
#     "09_GHRM_silver"
# ]

# df_parallel_1 = df_tasks[df_tasks["notebook"].isin(parallel_notebooks_1)]
# df_parallel_2 = df_tasks[df_tasks["notebook"].isin(parallel_notebooks_2)]
# df_non_parallel = df_tasks[~df_tasks["notebook"].isin(parallel_notebooks_1 + parallel_notebooks_2)]

# parallel_duration_1 = df_parallel_1["duration_sec"].max() if not df_parallel_1.empty else 0
# parallel_duration_2 = df_parallel_2["duration_sec"].max() if not df_parallel_2.empty else 0
# non_parallel_duration = df_non_parallel["duration_sec"].sum()
# total_duration_sec = parallel_duration_1 + parallel_duration_2 + non_parallel_duration
# total_duration_min = total_duration_sec / 60

# # Tempo total no formato mm:ss
# total_min = int(total_duration_sec // 60)
# total_sec = int(total_duration_sec % 60)
# total_time_str = f"{total_min}m {total_sec}s"

# # 5. Gráfico
# import matplotlib.patches as mpatches
# import matplotlib.lines as mlines

# def get_color(nb):
#     if nb in parallel_notebooks_1:
#         return "#FFD580"
#     elif nb in parallel_notebooks_2:
#         return "#E89DFA"
#     else:
#         return "skyblue"

# colors = [get_color(nb) for nb in df_tasks["notebook"]]

# plt.figure(figsize=(10, 6))
# bars = plt.barh(df_tasks["notebook"], df_tasks["duration_sec"], color=colors)

# for bar, duration in zip(bars, df_tasks["duration_sec"]):
#     plt.text(bar.get_width() + 1, bar.get_y() + bar.get_height()/2, f"{duration:.1f}s", va='center')

# plt.axvline(total_duration_sec, color="#FFD580", linestyle="--")

# # Legenda customizada com espaçamento aumentado
# orange_patch = mpatches.Patch(color='#FFD580', label='Notebooks em paralelo (Momento 1)')
# purple_patch = mpatches.Patch(color='#E89DFA', label='Notebooks em paralelo (Momento 2)')
# blue_patch = mpatches.Patch(color='skyblue', label='Notebooks sequenciais')
# total_line = mlines.Line2D([], [], color='#FFD580', linestyle='--', label=f'Total: {total_time_str}')

# plt.legend(
#     handles=[orange_patch, purple_patch, blue_patch, total_line],
#     loc='lower right',
#     borderpad=1.5,      # aumenta o espaçamento interno da legenda
#     labelspacing=1.5,   # aumenta o espaçamento entre as linhas da legenda
#     handletextpad=1.5,  # aumenta o espaçamento entre o símbolo e o texto
#     borderaxespad=7     # aumenta o espaçamento da legenda em relação ao gráfico
# )
# plt.xlabel("Duração (segundos)")
# plt.title("Tempo de execução por notebook - Localização agrupador")
# plt.tight_layout()
# plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC ### 03 - gráfico de barra por planilha

# COMMAND ----------

# Dados por fonte
fontes = [
    "Template_Localizacao_Agrupadores-GERE-V7.xlsm",
    "Template_Localizacao_Agrupadores-GHE-V4.xlsm",
    "Template_Localizacao_Agrupadores-GHP-V7.xlsm",
    "Template_Localizacao_Agrupadores-GHRM-V6.xlsm",
]

resultados = []

print(f"{'='*80}")
print(f"{'Fonte':<45} {'Total':<10} {'Match':<10} {'Faltantes':<10} {'% Match':<10}")
print(f"{'='*80}")

for fonte in fontes:
    total = df_excel_consolidado.filter(F.col("tipo_fonte_excel") == fonte).count()
    
    faltantes = df_excel_consolidado \
        .filter(F.col("tipo_fonte_excel") == fonte) \
        .join(df_consolidado.select("hash_key"), "hash_key", "left_anti") \
        .count()
    
    com_match = total - faltantes
    pct_match = (com_match / total * 100) if total > 0 else 0
    
    nome_curto = fonte.replace("Template_Localizacao_Agrupadores-", "").replace(".xlsm", "")
    
    resultados.append({
        "fonte": nome_curto,
        "total": total,
        "com_match": com_match,
        "faltantes": faltantes,
        "pct_match": pct_match
    })
    
    print(f"{nome_curto:<45} {total:<10} {com_match:<10} {faltantes:<10} {pct_match:<10.2f}%")

print(f"{'='*80}\n")

df_resultados = pd.DataFrame(resultados).sort_values("pct_match", ascending=False)

# ============================================
# GRÁFICO 1: Barras empilhadas por fonte
# ============================================
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

x_pos = range(len(df_resultados))

ax1.barh(x_pos, df_resultados["com_match"], color="#2ecc71", label="Com Match")
ax1.barh(x_pos, df_resultados["faltantes"], left=df_resultados["com_match"],
         color="#e74c3c", label="Faltantes")

for i, (_, row) in enumerate(df_resultados.iterrows()):
    ax1.text(row["total"] / 2, i, f"{row['pct_match']:.1f}%",
             ha="center", va="center", fontsize=10, fontweight="bold", color="white")

ax1.set_yticks(x_pos)
ax1.set_yticklabels(df_resultados["fonte"])
ax1.set_xlabel("Quantidade de Registros", fontsize=11)
ax1.set_title("Análise de Match por Fonte (valores absolutos)", fontsize=13, fontweight="bold")
ax1.legend(loc="lower right")
ax1.grid(axis="x", alpha=0.3, linestyle="--")

# ============================================
# GRÁFICO 2: % de match por fonte
# ============================================
cores = ["#27ae60" if pct >= 90 else "#f39c12" if pct >= 70 else "#e74c3c"
         for pct in df_resultados["pct_match"]]

bars = ax2.barh(x_pos, df_resultados["pct_match"], color=cores, edgecolor="black", linewidth=1.2)

for i, (bar, pct) in enumerate(zip(bars, df_resultados["pct_match"])):
    ax2.text(pct + 1, i, f"{pct:.1f}%",
             ha="left", va="center", fontsize=10, fontweight="bold")

ax2.set_yticks(x_pos)
ax2.set_yticklabels(df_resultados["fonte"])
ax2.set_xlabel("Porcentagem de Match (%)", fontsize=11)
ax2.set_title("% de Match por Fonte", fontsize=13, fontweight="bold")
ax2.set_xlim(0, 115)
ax2.axvline(x=100, color="green", linestyle="--", alpha=0.5, label="Meta: 100%")
ax2.legend()
ax2.grid(axis="x", alpha=0.3, linestyle="--")

plt.tight_layout()
plt.show()

# ============================================
# RESUMO FINAL
# ============================================
print("\n" + "=" * 80)
print("RESUMO GERAL:")
print("=" * 80)
print(f"Total Excel consolidado:         {df_excel_consolidado.count():,}")
print(f"Total notebook consolidado:      {df_consolidado.count():,}")
print(f"Total faltantes:                 {df_faltantes.count():,}")
print(f"Fontes com 100% de match:        {len(df_resultados[df_resultados['pct_match'] == 100])}")
print(f"Fontes com <100% de match:       {len(df_resultados[df_resultados['pct_match'] < 100])}")
print(f"\nMédia de match:   {df_resultados['pct_match'].mean():.2f}%")
print(f"Melhor fonte:     {df_resultados.iloc[0]['fonte']} ({df_resultados.iloc[0]['pct_match']:.2f}%)")
print(f"Pior fonte:       {df_resultados.iloc[-1]['fonte']} ({df_resultados.iloc[-1]['pct_match']:.2f}%)")
print("=" * 80)