# Databricks notebook source
# MAGIC %md
# MAGIC | Frente | Layout/JOB/Integração | Status | Validadores | Pendências |
# MAGIC |--------|-----------------------|--------|-------------|-----------|
# MAGIC | EC | 49 | ❌ | Stenio Stein | **_Não faremos mais. Layout de responsabilidade da Vale_** |
# MAGIC | BN | JOB Benefícios | ❌ | | 
# MAGIC | BN | 007 - Integração de BN | ❌ | |
# MAGIC | ECP | Ficha Financeira | ❌ | Matheus Sequine Motta | **_Não faremos mais. Layout de responsabilidade da Vale_** |
# MAGIC | ECP | PTP | ❌ | |
# MAGIC | EHS | BIB299 | ❌ | |
# MAGIC | EHS | Agrupador | ✅ | Jeane Lima e Ananias Rocha | Vale - Retornar validação |
# MAGIC | EHS | Localização Agrupador | ✅ | Jeane Lima e Ananias Rocha | Vale - Retornar validação |
# MAGIC | EHS | Gestão Previdenciária | ⏳ | Jeane Lima e Ananias Rocha | Vale - Criar tabela de staging no Databricks |
# MAGIC | EHS | Matriz | ✅ | Jeane Lima e Ananias Rocha | Vale - Começar extração dos dados crus |
# MAGIC | EHS | Prontuário Médico | ⏳ | Jeane Lima e Ananias Rocha | Vale - Disponibilizar query para o layout de Exames Complementares |
# MAGIC | EHS | 128 | ❌ | | |
# MAGIC | EHS | 129 | ❌ | | |
# MAGIC | ECP | PTP - Ausências | ❌ | | |