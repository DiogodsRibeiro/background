"""
Build script to create a standalone .exe file.
Run this script to package the application: python build_exe.py
"""

import os
import subprocess
import sys
import shutil


def build():
    """Build the executable using PyInstaller."""
    print("=" * 50)
    print("  Building Staffing Tool Automation Executable")
    print("=" * 50)

    # Get the directory where this script is located
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)

    # Check that .env file exists
    env_file = os.path.join(script_dir, '.env')
    if not os.path.exists(env_file):
        print("\n❌ ERROR: .env file not found!")
        print("Create a .env file with url_get_user and url_create_schedule before building.")
        sys.exit(1)

    # Check that templates/index.html exists
    template_file = os.path.join(script_dir, 'templates', 'index.html')
    if not os.path.exists(template_file):
        print("\n❌ ERROR: templates/index.html not found!")
        print("Make sure the templates folder exists with index.html inside.")
        sys.exit(1)

    # Clean previous builds
    dist_dir = os.path.join(script_dir, 'dist')
    build_dir = os.path.join(script_dir, 'build')
    spec_file = os.path.join(script_dir, 'staffing_tool.spec')

    for path in [dist_dir, build_dir]:
        if os.path.exists(path):
            print(f"Cleaning {path}...")
            shutil.rmtree(path)

    if os.path.exists(spec_file):
        os.remove(spec_file)

    # PyInstaller command
    cmd = [
        sys.executable, '-m', 'PyInstaller',
        '--name=StaffingTool',
        '--onefile',
        '--windowed',
        '--hidden-import=worker',
        '--hidden-import=get_users',
        '--hidden-import=post_schedule_automatizado',
        '--clean',
        '--noconfirm',
        '--exclude-module=cryptography',
        '--exclude-module=_cffi_backend',
        '--exclude-module=cffi',
        'app.py'
    ]

    # Add data files (different separator for Windows vs Unix)
    sep = ';' if sys.platform == 'win32' else ':'

    data_files = [
        f'--add-data=templates{sep}templates',
        f'--add-data=.env{sep}.',
    ]
    for i, data_flag in enumerate(data_files):
        cmd.insert(6 + i, data_flag)

    print("\nRunning PyInstaller...")
    print(f"Command: {' '.join(cmd)}\n")

    try:
        result = subprocess.run(cmd, check=True)
        print("\n" + "=" * 50)
        print("  Build completed successfully!")
        print("=" * 50)

        exe_name = 'StaffingTool.exe' if sys.platform == 'win32' else 'StaffingTool'
        exe_path = os.path.join(dist_dir, exe_name)

        if os.path.exists(exe_path):
            size_mb = os.path.getsize(exe_path) / (1024 * 1024)
            print(f"\nExecutable created: {exe_path}")
            print(f"File size: {size_mb:.1f} MB")
        else:
            print(f"\nExecutable should be in: {dist_dir}")

        print("\n✅ The .env file has been embedded in the executable.")
        print("Just send the .exe and they can double-click to run!")

    except subprocess.CalledProcessError as e:
        print(f"\nBuild failed with error code: {e.returncode}")
        sys.exit(1)
    except FileNotFoundError:
        print("\nError: PyInstaller not found. Install it with: pip install pyinstaller")
        sys.exit(1)


if __name__ == '__main__':
    build()