# Staffing Tool Automation

A web-based automation tool for managing staffing schedules. Upload your allocations CSV file and cookie through a simple browser interface, then let the tool handle the rest.

## Features

- Web-based interface with progress tracking
- CSV file upload for allocations
- Cookie-based authentication
- Real-time progress updates and logging
- Stop/cancel functionality

## Requirements

- Python 3.8 or higher

## Installation

1. Clone the repository:
```bash
git clone https://github.com/paulosawaya/staffing_tool_automation.git
cd staffing_tool_automation
```

2. Create a virtual environment:
```bash
python -m venv venv
```

3. Activate the virtual environment:

**Windows:**
```bash
venv\Scripts\activate
```

**Linux/macOS:**
```bash
source venv/bin/activate
```

4. Install dependencies:
```bash
pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org -r requirements.txt
```

## Configuration

Create a `.env` file in the project root with the following variables:

```env
url_get_user=<URL for fetching users>
url_create_schedule=<URL for creating schedules>
```

## Usage

1. Start the application:
```bash
python app.py
```

2. The browser will automatically open at `http://127.0.0.1:5000`

3. In the web interface:
   - Enter your `staffingplanning_` cookie value
   - Upload your `alocacoes.csv` file
   - Click "Start Process"

4. Monitor the progress in the output log

## CSV File Format

The `alocacoes.csv` file should have the following columns:

| Column | Description |
|--------|-------------|
| email | User email address |
| data_inicial | Start date (YYYY-MM-DD format) |
| data_final | End date (YYYY-MM-DD format) |
| %alocacao | Allocation percentage |

## Building Executable (Optional)

To create a standalone executable:

```bash
python build_exe.py
```

The executable will be created in the `dist` folder.

## Project Structure

```
staffing_tool_automation/
├── app.py                      # Flask web server
├── worker.py                   # Task orchestration
├── get_users.py                # Fetch users from staffing tool
├── post_schedule_automatizado.py # Post schedules to staffing tool
├── build_exe.py                # PyInstaller build script
├── requirements.txt            # Python dependencies
├── .env                        # Environment variables (not tracked)
├── templates/
│   └── index.html              # Web interface
└── data/
    └── alocacoes.csv           # Uploaded CSV files (auto-created)
```

## Troubleshooting

### SSL Certificate Errors
If you encounter SSL certificate errors during pip install, use the trusted-host flags:
```bash
pip install --trusted-host pypi.org --trusted-host pypi.python.org --trusted-host files.pythonhosted.org -r requirements.txt
```

### Missing .env File
Make sure you have created a `.env` file with the required URLs before running the application.

### Cookie Expired
If you get authentication errors, obtain a fresh `staffingplanning_` cookie from your browser.
