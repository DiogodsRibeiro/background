"""
Staffing Tool Automation - Web Interface
Runs a Python script and displays progress in a web browser.
"""

import json
import os
import sys
import threading
import time
import webbrowser
from queue import Queue, Empty

from flask import Flask, Response, render_template, jsonify, request

# Import the worker module (customize worker.py with your actual tasks)
import worker

# Determine base path for PyInstaller compatibility
if getattr(sys, 'frozen', False):
    BASE_DIR = sys._MEIPASS
    TEMPLATE_DIR = os.path.join(BASE_DIR, 'templates')
    DATA_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    TEMPLATE_DIR = os.path.join(BASE_DIR, 'templates')
    DATA_DIR = BASE_DIR

app = Flask(__name__, template_folder=TEMPLATE_DIR)

# Global state
message_queue = Queue()
stop_flag = threading.Event()
current_thread = None

# Configuration storage
current_config = {
    'cookie': None,
    'csv_path': None
}


def run_worker_script():
    """Run the worker script from worker.py module."""
    # Set up the worker module with our callbacks
    worker.setup(send_progress, lambda: stop_flag.is_set())

    # Run the task defined in worker.py with the current configuration
    return worker.run_task(current_config['cookie'], current_config['csv_path'])


def send_progress(progress, message, msg_type="info"):
    """Send progress update to the web UI."""
    data = {
        "message": message,
        "type": msg_type
    }
    if progress is not None:
        data["progress"] = progress
    message_queue.put(data)


def worker_wrapper():
    """Wrapper function that handles the worker script execution."""
    global current_thread

    try:
        send_progress(0, "Process started", "info", )
        message_queue.put({"status": "running", "status_message": "Processing..."})

        success = run_worker_script()

        message_queue.put({
            "complete": True,
            "success": success,
            "status": "complete" if success else "error",
            "status_message": "Completed successfully!" if success else "Process stopped"
        })
    except Exception as e:
        message_queue.put({
            "message": f"Fatal error: {str(e)}",
            "type": "error",
            "complete": True,
            "success": False,
            "status": "error",
            "status_message": "An error occurred"
        })
    finally:
        current_thread = None


@app.route('/')
def index():
    """Serve the main HTML page."""
    return render_template('index.html')


@app.route('/upload-config', methods=['POST'])
def upload_config():
    """Handle file upload and cookie configuration."""
    global current_config

    try:
        # Get cookie from form
        cookie = request.form.get('cookie')
        if not cookie:
            return jsonify({'success': False, 'message': 'Cookie is required'}), 400

        # Get CSV file
        csv_file = request.files.get('csv_file')
        if not csv_file:
            return jsonify({'success': False, 'message': 'CSV file is required'}), 400

        # Create data directory if it doesn't exist
        data_dir = os.path.join(DATA_DIR, 'data')
        os.makedirs(data_dir, exist_ok=True)

        # Save the CSV file
        csv_path = os.path.join(data_dir, 'alocacoes.csv')
        csv_file.save(csv_path)

        # Store configuration
        current_config['cookie'] = cookie
        current_config['csv_path'] = csv_path

        return jsonify({'success': True, 'message': 'Configuration uploaded successfully'})

    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/run-script')
def run_script():
    """Start the script and stream progress via Server-Sent Events."""
    global current_thread

    def generate():
        global current_thread

        # Clear the queue and reset stop flag
        while not message_queue.empty():
            try:
                message_queue.get_nowait()
            except Empty:
                break
        stop_flag.clear()

        # Start the worker thread
        current_thread = threading.Thread(target=worker_wrapper, daemon=True)
        current_thread.start()

        # Stream messages to the client
        while True:
            try:
                msg = message_queue.get(timeout=0.5)
                yield f"data: {json.dumps(msg)}\n\n"

                if msg.get('complete'):
                    break
            except Empty:
                # Send heartbeat to keep connection alive
                yield f"data: {json.dumps({'heartbeat': True})}\n\n"

                # Check if thread is still running
                if current_thread is None or not current_thread.is_alive():
                    if message_queue.empty():
                        break

    return Response(
        generate(),
        mimetype='text/event-stream',
        headers={
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'X-Accel-Buffering': 'no'
        }
    )


@app.route('/stop-script', methods=['POST'])
def stop_script():
    """Stop the currently running script."""
    stop_flag.set()
    return jsonify({"status": "stopping"})


def open_browser():
    """Open the web browser after a short delay."""
    time.sleep(1.5)
    webbrowser.open('http://127.0.0.1:5000')


def main():
    """Main entry point."""
    print("=" * 50)
    print("  Staffing Tool Automation")
    print("=" * 50)
    print("\nStarting web server...")
    print("Opening browser at http://127.0.0.1:5000")
    print("\nPress Ctrl+C to stop the server.\n")

    # Open browser automatically
    browser_thread = threading.Thread(target=open_browser, daemon=True)
    browser_thread.start()

    # Run Flask app
    app.run(host='127.0.0.1', port=5000, debug=False, threaded=True)


if __name__ == '__main__':
    main()
