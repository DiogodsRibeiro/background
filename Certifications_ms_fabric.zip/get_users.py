import requests
import urllib3
import re
import json
import sys
from bs4 import BeautifulSoup
from pathlib import Path
from dotenv import load_dotenv
import os
import unicodedata

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# PyInstaller compatibility: when frozen, _MEIPASS has the bundled files
if getattr(sys, 'frozen', False):
    BUNDLE_DIR = Path(sys._MEIPASS)
    BASE_DIR = Path(sys.executable).resolve().parent
else:
    BUNDLE_DIR = Path(__file__).resolve().parent
    BASE_DIR = BUNDLE_DIR

load_dotenv(BUNDLE_DIR / ".env")


def remover_acentos(texto):
    """Remove acentos e caracteres especiais, mantendo apenas letras e números"""
    # Normaliza o texto (remove acentos)
    texto_normalizado = unicodedata.normalize('NFD', texto)
    # Remove os caracteres de combinação (acentos)
    texto_sem_acento = ''.join(char for char in texto_normalizado if unicodedata.category(char) != 'Mn')
    return texto_sem_acento


def fetch_users(cookie_string, output_path=None):
    """
    Fetch users from the staffing tool and save to usuarios.json.

    Args:
        cookie_string: The staffingplanning_ cookie value
        output_path: Optional path for output file. Defaults to BASE_DIR/usuarios.json

    Returns:
        tuple: (success: bool, message: str, user_count: int)
    """
    if output_path is None:
        output_path = BASE_DIR / "usuarios.json"

    url = os.getenv("url_get_user")
    if not url:
        return False, "Variável 'url_get_user' não encontrada no arquivo .env", 0

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "cookie": f"staffingplanning_={cookie_string}"
    }

    try:
        response = requests.get(url, headers=headers, verify=False)
        html = response.text

        soup = BeautifulSoup(html, "html.parser")

        dados = []

        for row in soup.find_all("tr", id=re.compile(r"^group")):
            link = row.find("a", href=re.compile(r"xajax_modifUserSimple"))
            if not link:
                continue

            nome = link.get_text(strip=True)
            href = link.get("href", "")
            m = re.search(r"xajax_modifUserSimple\('([^']+)'", href)
            codigo = m.group(1) if m else None

            if nome:
                # Remove acentos e caracteres especiais
                nome = remover_acentos(nome)
                # Converte para minúsculas e substitui espaços por pontos
                nome = nome.lower().replace(" ", ".")
                # Remove qualquer caractere que não seja letra, número ou ponto
                nome = re.sub(r'[^a-z0-9.]', '', nome)

            if nome and codigo:
                dados.append({
                    "nome": nome,
                    "codigo": codigo
                })

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(dados, f, ensure_ascii=False, indent=4)

        return True, f"Arquivo 'usuarios.json' criado com {len(dados)} registros.", len(dados)

    except Exception as e:
        return False, f"Erro ao buscar usuários: {str(e)}", 0


# For backwards compatibility - run as standalone script
if __name__ == "__main__":
    cookie_file = BASE_DIR / "cookie.txt"
    if not cookie_file.exists():
        raise FileNotFoundError(f"Arquivo cookie.txt não encontrado: {cookie_file}")

    with open(cookie_file, "r", encoding="utf-8") as f:
        staffing_id = f.read().strip()

    success, message, count = fetch_users(staffing_id)
    print(f"{'✅' if success else '❌'} {message}")