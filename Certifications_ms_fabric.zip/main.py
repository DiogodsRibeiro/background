import subprocess
import sys
import time
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent      
PROJECT_DIR = BASE_DIR.parent                   
SRC_DIR = BASE_DIR                             

def run_script(script_name: str):
    script_path = SRC_DIR / script_name
    print(f"\n==============================")
    print(f"Executando: {script_path}")
    print(f"==============================")

    result = subprocess.run(
        [sys.executable, str(script_path)],
        cwd=PROJECT_DIR,  
    )

    if result.returncode != 0:
        print(f"❌ Erro ao executar {script_name} (returncode={result.returncode})")
    else:
        print(f"✅ Finalizado: {script_name}")


if __name__ == "__main__":
    # 1) roda get_users.py
    "Buscando id dos usuários"
    run_script("get_users.py")

    # espera 5 segundos
    print("\n⏳ Aguardando 5 segundos antes de enviar as alocações...")
    time.sleep(5)

    # 2) roda post_schedule_automatizado.py
    # run_script("post_schedule_automatizado.py")

    print("\n🎯 Fluxo completo finalizado.")
