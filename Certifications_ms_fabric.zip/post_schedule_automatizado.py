import requests
import urllib3
import sys
from pathlib import Path
import csv
import json
import time
from dotenv import load_dotenv
import os
from datetime import datetime

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# PyInstaller compatibility: when frozen, _MEIPASS has the bundled files
if getattr(sys, 'frozen', False):
    BUNDLE_DIR = Path(sys._MEIPASS)
    BASE_DIR = Path(sys.executable).resolve().parent
else:
    BUNDLE_DIR = Path(__file__).resolve().parent
    BASE_DIR = BUNDLE_DIR

load_dotenv(BUNDLE_DIR / ".env")


def converter_data_iso_para_br(data_iso: str) -> str:
    if not data_iso:
        return ""
    data_iso = data_iso.strip()
    if not data_iso:
        return ""
    parte_data = data_iso.split(" ")[0]  # '2025-03-25'
    ano, mes, dia = parte_data.split("-")
    return f"{dia}/{mes}/{ano}"


def extrair_alocacao(percent_str: str) -> str:
    if not percent_str:
        return ""
    txt = percent_str.strip()
    if "%" in txt:
        txt = txt.split("%")[0]
    txt = txt.replace(".", "").replace(",", ".").strip()
    return txt


def post_schedules(cookie_string, csv_path, usuarios_path=None, progress_callback=None, should_stop=None):
    """
    Post schedules to the staffing tool.

    Args:
        cookie_string: The staffingplanning_ cookie value
        csv_path: Path to the alocacoes.csv file
        usuarios_path: Optional path to usuarios.json. Defaults to BASE_DIR/usuarios.json
        progress_callback: Optional callback function(progress, message, msg_type) for progress updates
        should_stop: Optional callback function() that returns True if the process should stop

    Returns:
        tuple: (success: bool, message: str, stats: dict)
    """
    if usuarios_path is None:
        usuarios_path = BASE_DIR / "usuarios.json"

    def report(progress, message, msg_type="info"):
        if progress_callback:
            progress_callback(progress, message, msg_type)
        else:
            print(f"[{msg_type.upper()}] {message}")

    def check_stop():
        if should_stop and should_stop():
            return True
        return False

    # Validate paths
    csv_path = Path(csv_path)
    usuarios_path = Path(usuarios_path)

    if not usuarios_path.exists():
        return False, f"Arquivo usuarios.json não encontrado: {usuarios_path}", {}

    if not csv_path.exists():
        return False, f"Arquivo alocacoes.csv não encontrado: {csv_path}", {}

    # Setup error directory
    ERROR_DIR = BASE_DIR / "error"
    ERROR_DIR.mkdir(exist_ok=True)

    # Get URL from env
    url = os.getenv("url_create_schedule")
    if not url:
        return False, "Variável 'url_create_schedule' não encontrada no arquivo .env", {}

    # Setup headers
    headers = {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Cookie": f"staffingplanning_={cookie_string}"
    }

    # Load usuarios
    try:
        with open(usuarios_path, "r", encoding="utf-8") as f:
            usuarios = json.load(f)
        mapa_usuarios = {u["nome"].lower(): u["codigo"] for u in usuarios}
        report(None, f"Carregados {len(usuarios)} usuários do arquivo usuarios.json", "info")
    except Exception as e:
        return False, f"Erro ao carregar usuarios.json: {str(e)}", {}

    # Count rows first for progress
    try:
        with open(csv_path, "r", encoding="utf-8", newline="") as f:
            total_rows = sum(1 for _ in csv.DictReader(f, delimiter=","))
    except Exception as e:
        return False, f"Erro ao ler CSV: {str(e)}", {}

    # Process CSV
    sucessos = 0
    falhas = 0
    erros_email = []
    erros_login = []
    logins_csv = set()
    processed = 0

    try:
        with open(csv_path, "r", encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f, delimiter=",")
            for raw_row in reader:
                if check_stop():
                    return False, "Processo cancelado pelo usuário", {
                        "sucessos": sucessos,
                        "falhas": falhas,
                        "processados": processed
                    }

                processed += 1
                progress = (processed / total_rows) * 100 if total_rows > 0 else 0

                row = {
                    (k or "").strip().lstrip("\ufeff").lower(): (v or "").strip()
                    for k, v in raw_row.items()
                }

                email = row.get("email")
                data_inicial_iso = row.get("data_inicial")
                data_final_iso = row.get("data_final")
                alocacao_str = row.get("%alocação")

                # Line without email (not counted as failure)
                if not email:
                    report(progress, f"[{processed}/{total_rows}] Linha sem email, ignorando", "warning")
                    erros_email.append({
                        "motivo": "email_vazio_ou_ausente",
                        "linha_original": raw_row
                    })
                    continue

                login = email.split("@")[0].lower()

                # Login not found in users map
                if login not in mapa_usuarios:
                    report(progress, f"[{processed}/{total_rows}] Usuário não encontrado: {login}", "warning")
                    falhas += 1
                    erros_login.append({
                        "motivo": "login_nao_encontrado_no_mapa_usuarios",
                        "login": login,
                        "email": email,
                        "linha_original": raw_row
                    })
                    continue

                # Valid login
                logins_csv.add(login)

                codigo = mapa_usuarios[login]
                data_inicial_br = converter_data_iso_para_br(data_inicial_iso)
                data_final_br = converter_data_iso_para_br(data_final_iso)
                alocacao_valor = extrair_alocacao(alocacao_str)

                report(progress, f"[{processed}/{total_rows}] Enviando schedule para {login}", "info")

                xml_codigo = f"<xjxobj><e><k>0</k><v>{codigo}</v></e></xjxobj>"
                xajax_args = [
                    "0", "YO4E6961DS", xml_codigo,
                    data_inicial_br, "undefined", data_final_br,
                    "", "", "", "", "false", "false", "", "", "", "",
                    "1", "1", "1", "1", "1", "true", "fait", "", "",
                    "non", "", "Inclusão via automação", "", "",
                    alocacao_valor, "liste_affectations",
                    "", "", "", "", "", "", "", ""
                ]

                payload = [("xajax", "submitFormPeriode")]
                for arg in xajax_args:
                    payload.append(("xajaxargs[]", arg))

                try:
                    resp = requests.post(url, headers=headers, data=payload, verify=False, allow_redirects=False)
                    if resp.status_code == 200:
                        sucessos += 1
                        report(progress, f"[{processed}/{total_rows}] Schedule enviado com sucesso para {login}", "success")
                    else:
                        report(progress, f"[{processed}/{total_rows}] Falha ao enviar schedule para {login} (HTTP {resp.status_code})", "error")
                except Exception as e:
                    report(progress, f"[{processed}/{total_rows}] Erro na requisição para {login}: {e}", "error")
                    continue

                time.sleep(0.1)

    except Exception as e:
        return False, f"Erro ao processar CSV: {str(e)}", {}

    # Save error files
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    if erros_email:
        erros_email_file_ts = ERROR_DIR / f"erros_email_{timestamp}.json"
        with open(erros_email_file_ts, "w", encoding="utf-8") as f:
            json.dump(erros_email, f, ensure_ascii=False, indent=4)
        report(None, f"Arquivo de erros de email salvo em: {erros_email_file_ts}", "info")

    if erros_login:
        erros_login_file_ts = ERROR_DIR / f"erros_login_{timestamp}.json"
        with open(erros_login_file_ts, "w", encoding="utf-8") as f:
            json.dump(erros_login, f, ensure_ascii=False, indent=4)
        report(None, f"Arquivo de erros de login salvo em: {erros_login_file_ts}", "info")

    stats = {
        "sucessos": sucessos,
        "falhas": falhas,
        "total_processados": processed,
        "erros_email": len(erros_email),
        "erros_login": len(erros_login)
    }

    success = falhas == 0
    message = f"Concluído: {sucessos} sucessos, {falhas} falhas de {processed} registros processados"

    return success, message, stats


# For backwards compatibility - run as standalone script
if __name__ == "__main__":
    cookie_file = BASE_DIR / "cookie.txt"
    usuarios_file = BASE_DIR / "usuarios.json"
    csv_file = BASE_DIR / "data" / "alocacoes.csv"

    if not cookie_file.exists():
        raise FileNotFoundError(f"Arquivo cookie.txt não encontrado: {cookie_file}")

    if not usuarios_file.exists():
        raise FileNotFoundError(f"Arquivo usuarios.json não encontrado: {usuarios_file}")

    if not csv_file.exists():
        raise FileNotFoundError(f"Arquivo alocacoes.csv não encontrado: {csv_file}")

    with open(cookie_file, "r", encoding="utf-8") as f:
        staffing_id = f.read().strip()

    success, message, stats = post_schedules(staffing_id, csv_file, usuarios_file)

    print("\n================ RESUMO ================")
    print(f"Sucessos: {stats.get('sucessos', 0)}")
    print(f"Falhas  : {stats.get('falhas', 0)}")
    print("========================================")
    print(f"{'✅' if success else '❌'} {message}")
